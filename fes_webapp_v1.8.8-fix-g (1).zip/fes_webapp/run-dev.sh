#!/usr/bin/env bash
# =============================================================================
# fes_webapp/run-dev.sh
# =============================================================================
# Local development launcher. Production uses docker-compose.
# =============================================================================
set -euo pipefail

cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
    echo "[setup] creating venv"
    python3 -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate

echo "[setup] installing deps"
pip install -q --upgrade pip
pip install -q -r requirements.txt

echo "[run] starting FES web app on http://localhost:8000"
echo "      INI: config/fes_webapp.ini"
echo "      toolkit: toolkit_v11/"
echo ""

cd app
exec python -m uvicorn main:app \
    --host 0.0.0.0 \
    --port 8000 \
    --reload
