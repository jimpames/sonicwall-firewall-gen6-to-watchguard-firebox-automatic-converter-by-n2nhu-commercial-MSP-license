"""
comment_preserving_ini.py
==========================

A round-trip INI reader/writer that preserves *everything* the standard
configparser silently destroys: block comments, blank lines, inline
comments (`; ...` and trailing `# ...`), continuation indentation,
spacing around `=`, and original section/key ordering.

The strategy is a two-layer model:

    Document  -- the file as a flat list of *raw items* in source order
    Section   -- a logical grouping of keys (no own state; just a window
                 into the document's items between two section headers)

When the GUI mutates a value, we mark only that one item dirty.
On save:

    For every item in the document, in original order:
      * if it's a comment / blank / section header / non-dirty key,
        re-emit its raw source verbatim
      * if it's a dirty key, re-emit using the same key/`=`/indentation
        style observed on the original, but with the new value
      * if a section gained new keys via the GUI, they are appended at
        the section's natural end (just before the next section header)
      * if a section was added entirely, it is appended at end-of-file

This module is intentionally GUI-agnostic. It speaks ConfigParser-shaped
dict-of-dicts, but writes the file via this preserving writer.

The dialect matches the rest of the toolkit: comment_prefixes=('#',),
inline_comment_prefixes=(';',), continuation lines are indented.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Token types
# ---------------------------------------------------------------------------
# A document is a flat list of these. Each token carries enough source
# information to be re-emitted byte-identical when nothing about it changed.

@dataclass
class CommentLine:
    """A full-line comment or a blank line."""
    raw: str  # includes trailing newline


@dataclass
class SectionHeader:
    """A `[name]` line."""
    name: str
    raw: str  # includes trailing newline; may include trailing comment


@dataclass
class KeyValue:
    """A `key = value` plus any continuation lines that follow it.

    `raw_lines` holds the *original* source text (with newlines).
    `value` holds the parsed value as a Python string (possibly
    multi-line, with continuations joined by `\\n`).

    On write, if `dirty` is False we emit `raw_lines` verbatim.
    If dirty, we re-render using the captured key, separator, and
    continuation indent from the original source.
    """
    section: str
    key: str
    value: str
    raw_lines: list[str]                  # original source lines (with \n)
    key_separator: str = " = "             # text between key and value
    continuation_indent: str = "    "      # whitespace prefix on continuation lines
    inline_comment: str = ""               # trailing `; ...` if present (no leading space)
    dirty: bool = False                    # value mutated since load
    deleted: bool = False                  # marked for removal on next save


@dataclass
class _Document:
    """Ordered list of tokens + an index of (section, key) -> KeyValue."""
    items: list[Any] = field(default_factory=list)
    _kv_index: dict[tuple[str, str], KeyValue] = field(default_factory=dict)
    # Track sections we know about (in declaration order)
    section_order: list[str] = field(default_factory=list)
    # Map section -> last item index that "belongs" to that section
    # (used to know where to append new keys for an existing section)
    _section_end: dict[str, int] = field(default_factory=dict)
    # Sections added at runtime (no original SectionHeader)
    added_sections: list[str] = field(default_factory=list)
    # Keys added at runtime, by section: section -> [(key, value)]
    added_keys: dict[str, list[tuple[str, str]]] = field(default_factory=dict)
    # Sections marked for deletion entirely
    deleted_sections: set[str] = field(default_factory=set)


# ---------------------------------------------------------------------------
# Tokenizer
# ---------------------------------------------------------------------------

_SECTION_RE = re.compile(r"^\s*\[([^\]]+)\]\s*(?:[;#].*)?\s*$")
# Match a "key = value" or "key: value" line. Allow keys with spaces.
# Captures: leading-ws, key, separator-block (with =/colon), value-rest.
_KEYVALUE_RE = re.compile(
    r"^(?P<lead>[ \t]*)"
    r"(?P<key>[^=:#;\[\]\s][^=:#;]*?)"     # key chars (no = : # ; or section brackets)
    r"(?P<sep>[ \t]*[=:][ \t]*)"            # separator with surrounding ws
    r"(?P<rest>.*)$"
)


def _is_continuation(line: str) -> bool:
    """A continuation candidate is a line that doesn't terminate a
    multi-line value. Per ConfigParser's `empty_lines_in_values=True`
    semantics, this includes:
      * Indented non-empty lines (the typical case)
      * Blank lines (whitespace-only or zero-width) — if MORE indented
        content follows, they're kept as `\\n` in the value; if they
        trail at the end, they're stripped.

    The actual "stop" decision happens in the collection loop, which
    checks whether more indented content follows after a run of blanks.
    """
    if not line:
        return False
    if line.strip() == "":
        # Blank line — could be internal-to-value or trailing
        return True
    return line[0] in (" ", "\t")


def _is_indented_comment(line: str) -> bool:
    """An indented `#` comment line that should be SKIPPED inside a
    multi-line value (ConfigParser drops these but doesn't terminate
    the value at them). Lines must start with whitespace and have a
    `#` as the first non-whitespace char.
    """
    if not line or not line[0] in (" ", "\t"):
        return False
    stripped = line.lstrip(" \t")
    return stripped.startswith("#")


def _is_comment_or_blank(stripped: str) -> bool:
    return stripped == "" or stripped.startswith("#") or stripped.startswith(";")


def _split_inline_comment(rest: str) -> tuple[str, str]:
    """Split `value ; comment` into (value, comment).

    Matches Python's configparser dialect: `;` is an inline-comment
    marker ONLY when preceded by whitespace. `; in mid-value` (no
    leading whitespace) is part of the value, not a comment. `#` is
    never an inline-comment marker (full-line only).
    """
    in_q = False
    q_char = ""
    for i, ch in enumerate(rest):
        if in_q:
            if ch == q_char:
                in_q = False
            continue
        if ch in ('"', "'"):
            in_q = True
            q_char = ch
            continue
        if ch == ";":
            # Must be preceded by whitespace (or be at start of line)
            if i == 0 or rest[i - 1] in (" ", "\t"):
                return rest[:i].rstrip(), rest[i:].rstrip("\n")
    return rest.rstrip("\n"), ""


def parse(path: Path) -> _Document:
    """Tokenize an INI file into a _Document.

    Pre-conditions:
      * comment_prefixes = ('#',)  (i.e. # only at line start)
      * inline_comment_prefixes = (';',)
      * continuation lines are indented with whitespace
    """
    with open(path, encoding="utf-8") as f:
        raw_lines = f.readlines()

    doc = _Document()
    current_section: str | None = None

    i = 0
    n = len(raw_lines)
    while i < n:
        line = raw_lines[i]
        stripped = line.strip()

        # 1. Section header
        m_sect = _SECTION_RE.match(line)
        if m_sect and not stripped.startswith("#"):
            sect_name = m_sect.group(1).strip()
            doc.items.append(SectionHeader(name=sect_name, raw=line))
            current_section = sect_name
            if sect_name not in doc.section_order:
                doc.section_order.append(sect_name)
            doc._section_end[sect_name] = len(doc.items) - 1
            i += 1
            continue

        # 2. Comment or blank line
        if _is_comment_or_blank(stripped):
            doc.items.append(CommentLine(raw=line))
            if current_section is not None:
                doc._section_end[current_section] = len(doc.items) - 1
            i += 1
            continue

        # 3. Key/value line (with possible continuation lines)
        if current_section is None:
            # Stray non-comment text before any section. Treat as comment-ish.
            doc.items.append(CommentLine(raw=line))
            i += 1
            continue

        m_kv = _KEYVALUE_RE.match(line)
        if not m_kv:
            # Unknown shape; preserve verbatim.
            doc.items.append(CommentLine(raw=line))
            doc._section_end[current_section] = len(doc.items) - 1
            i += 1
            continue

        key = m_kv.group("key").rstrip()
        sep = m_kv.group("sep")
        rest = m_kv.group("rest")
        # Split inline comment from value
        first_value_part, inline_comment = _split_inline_comment(rest)

        raw_lines_for_kv = [line]
        value_parts = [first_value_part]
        cont_indent = "    "

        # Collect continuation lines. Per ConfigParser semantics:
        #   * Indented non-blank, non-comment lines → value content
        #   * Blank lines → kept as `\n` if MORE value lines follow,
        #     stripped if they trail
        #   * Indented `#` comment lines → SKIPPED in value (don't
        #     terminate the multi-line range, but don't add to value);
        #     preserved in raw_lines for byte-identity on unchanged emit
        #
        # The collection scans forward as long as lines are
        # continuation candidates (per _is_continuation, which now
        # includes blank lines). Stops at any non-indented non-blank
        # line — that's a new key, section header, or EOF.
        j = i + 1
        cont_indents_seen: list[str] = []
        while j < n:
            nxt = raw_lines[j]
            if not _is_continuation(nxt):
                break
            raw_lines_for_kv.append(nxt)
            if _is_indented_comment(nxt):
                # Skip in value; preserve in raw_lines (so unchanged
                # emit produces byte-identity).
                j += 1
                continue
            if nxt.strip() == "":
                # Blank line: append empty string to value_parts.
                # Trailing blanks will be stripped after the loop.
                value_parts.append("")
                j += 1
                continue
            # Real value continuation line: track its indent and
            # append the (left-stripped) content to value_parts.
            lead = nxt[: len(nxt) - len(nxt.lstrip(" \t"))]
            cont_indents_seen.append(lead)
            cont_value, _cont_comment = _split_inline_comment(nxt)
            value_parts.append(cont_value.lstrip())
            j += 1

        # Strip trailing blank value_parts (matches ConfigParser, which
        # discards trailing blanks before the next key/section/EOF).
        # Note: raw_lines retains them — the blank lines are still
        # part of the file structure; we just don't include them in
        # the logical value.
        while len(value_parts) > 1 and value_parts[-1] == "":
            value_parts.pop()

        if cont_indents_seen:
            # Use the most-common indent (ties: first one)
            cont_indent = max(set(cont_indents_seen), key=cont_indents_seen.count)

        joined_value = "\n".join(value_parts)

        kv = KeyValue(
            section=current_section,
            key=key,
            value=joined_value,
            raw_lines=raw_lines_for_kv,
            key_separator=sep,
            continuation_indent=cont_indent,
            inline_comment=inline_comment,
        )
        doc.items.append(kv)
        doc._kv_index[(current_section, key)] = kv
        doc._section_end[current_section] = len(doc.items) - 1
        i = j

    return doc


# ---------------------------------------------------------------------------
# Mutation API
# ---------------------------------------------------------------------------

def get(doc: _Document, section: str, key: str, default: str = "") -> str:
    kv = doc._kv_index.get((section, key))
    if kv is None or kv.deleted:
        return default
    return kv.value


def has(doc: _Document, section: str) -> bool:
    return section in doc.section_order and section not in doc.deleted_sections


def has_key(doc: _Document, section: str, key: str) -> bool:
    kv = doc._kv_index.get((section, key))
    return kv is not None and not kv.deleted


def set_value(doc: _Document, section: str, key: str, value: str) -> None:
    """Set a key's value. Marks dirty if changed; creates new key if absent.

    Whitespace-tolerant: if the existing value is equivalent to the new
    one after per-line trailing-whitespace stripping (which is how
    ConfigParser normalizes values it reads), the key is NOT marked
    dirty. This preserves byte-identity on round-trips through the
    GUI's ConfigParser-mediated save path, where ConfigParser strips
    trailing whitespace on read and we'd otherwise see false changes.
    """
    kv = doc._kv_index.get((section, key))
    if kv is not None:
        if kv.deleted:
            kv.deleted = False
        # Normalize for comparison: per-line rstrip mimics ConfigParser
        existing_norm = "\n".join(ln.rstrip() for ln in kv.value.split("\n"))
        new_norm = "\n".join(ln.rstrip() for ln in value.split("\n"))
        if existing_norm != new_norm:
            kv.value = value
            kv.dirty = True
        return

    # New key. If section exists, queue it for append into that section.
    # If section doesn't exist, add the section and the key.
    if section not in doc.section_order:
        add_section(doc, section)
    doc.added_keys.setdefault(section, []).append((key, value))


def delete_key(doc: _Document, section: str, key: str) -> bool:
    kv = doc._kv_index.get((section, key))
    if kv is None or kv.deleted:
        # Maybe a freshly added one not yet rendered
        added = doc.added_keys.get(section, [])
        for idx, (k, _v) in enumerate(added):
            if k == key:
                added.pop(idx)
                return True
        return False
    kv.deleted = True
    return True


def add_section(doc: _Document, section: str) -> None:
    if section in doc.section_order:
        # Maybe was deleted; un-delete
        doc.deleted_sections.discard(section)
        return
    doc.section_order.append(section)
    doc.added_sections.append(section)
    doc.added_keys.setdefault(section, [])


def delete_section(doc: _Document, section: str) -> None:
    """Mark a section (and all its keys) for deletion on next render.

    A subsequent add_section() call followed by set_value() calls
    produces a CLEAN section — old KeyValue items stay deleted unless
    explicitly resurrected by set_value() on the same key.

    This matches the natural "delete + re-create with new content"
    semantics that the GUI and config-rebuild scripts expect.
    """
    doc.deleted_sections.add(section)
    # Mark all KeyValue items in this section as deleted, so a
    # subsequent re-add of the section produces a clean slate.
    # set_value() can still resurrect a specific key by name (it
    # un-deletes the matching KV) — that's intentional and useful
    # for "rebuild this key with new content" workflows.
    for item in doc.items:
        if isinstance(item, KeyValue) and item.section == section:
            item.deleted = True
    # Also drop any pending added keys
    doc.added_keys.pop(section, None)
    # Remove from added_sections if it was a runtime-add
    if section in doc.added_sections:
        doc.added_sections.remove(section)


def sections(doc: _Document) -> list[str]:
    return [s for s in doc.section_order if s not in doc.deleted_sections]


def keys(doc: _Document, section: str) -> list[str]:
    """Return keys in source order, plus any runtime-added keys."""
    out: list[str] = []
    seen: set[str] = set()
    for item in doc.items:
        if isinstance(item, KeyValue) and item.section == section and not item.deleted:
            if item.key not in seen:
                out.append(item.key)
                seen.add(item.key)
    for k, _v in doc.added_keys.get(section, []):
        if k not in seen:
            out.append(k)
            seen.add(k)
    return out


def section_dict(doc: _Document, section: str) -> dict[str, str]:
    return {k: get(doc, section, k) for k in keys(doc, section)}


def to_dict(doc: _Document) -> dict[str, dict[str, str]]:
    """Snapshot the whole document as a dict-of-dicts."""
    return {s: section_dict(doc, s) for s in sections(doc)}


def apply_dict(doc: _Document, data: dict[str, dict[str, str]]) -> None:
    """Reconcile the document against a target dict-of-dicts.

    Sections / keys present in `data` but not in `doc` are added.
    Sections / keys present in `doc` but not in `data` are deleted.
    Keys whose values changed are marked dirty.
    """
    # Sections to delete
    for s in sections(doc):
        if s not in data:
            delete_section(doc, s)
    # Sections / keys to add or update
    for s, kv_dict in data.items():
        if s in doc.deleted_sections:
            doc.deleted_sections.discard(s)
        if s not in doc.section_order:
            add_section(doc, s)
        # Keys to delete
        for k in keys(doc, s):
            if k not in kv_dict:
                delete_key(doc, s, k)
        # Keys to add or update
        for k, v in kv_dict.items():
            set_value(doc, s, k, v)


# ---------------------------------------------------------------------------
# Renderer
# ---------------------------------------------------------------------------

def _render_keyvalue(kv: KeyValue) -> str:
    """Render a (possibly mutated) KeyValue back to INI source.

    Preserves:
      * the original `=` separator (with surrounding whitespace)
      * the continuation-line indent
      * the inline `; comment` if present
    Multi-line values are rendered with `value_part` per line.
    """
    out_lines: list[str] = []
    parts = kv.value.split("\n")
    first = parts[0]

    # First line: key + separator + first value part + optional inline comment
    head = f"{kv.key}{kv.key_separator}{first}"
    if kv.inline_comment:
        head = f"{head}    {kv.inline_comment}"
    out_lines.append(head + "\n")

    # Continuation lines
    for p in parts[1:]:
        out_lines.append(f"{kv.continuation_indent}{p}\n")

    return "".join(out_lines)


def _render_added_kv(section: str, key: str, value: str,
                     style: tuple[str, str]) -> str:
    """Render a runtime-added key with default style.

    `style` is (separator, continuation_indent). Defaults to ' = ' and 4 spaces.
    """
    sep, cont = style
    parts = value.split("\n")
    out = [f"{key}{sep}{parts[0]}\n"]
    for p in parts[1:]:
        out.append(f"{cont}{p}\n")
    return "".join(out)


def _detect_section_style(doc: _Document, section: str) -> tuple[str, str]:
    """Look at existing keys in `section` to learn the separator and
    continuation indent in use. Falls back to defaults if no examples.
    """
    sep = " = "
    cont = "    "
    for item in doc.items:
        if isinstance(item, KeyValue) and item.section == section and not item.deleted:
            sep = item.key_separator
            cont = item.continuation_indent
            return sep, cont
    return sep, cont


def render(doc: _Document) -> str:
    """Render the document back to a single string."""
    out: list[str] = []
    rendered_keys: dict[str, set[str]] = {s: set() for s in doc.section_order}
    skip_until_next_section: bool = False

    # Pre-compute: for each section, the index of its LAST non-deleted
    # KeyValue. Appends go right after that item, BEFORE any trailing
    # comments/blanks (which usually serve as dividers for the next section).
    # If a section has no KeyValue items, fall back to the last item-index
    # belonging to that section.
    last_kv_idx: dict[str, int] = {}
    last_any_idx: dict[str, int] = {}
    current: str | None = None
    for idx, item in enumerate(doc.items):
        if isinstance(item, SectionHeader):
            current = item.name
            last_any_idx[current] = idx
            continue
        if current is None:
            continue
        last_any_idx[current] = idx
        if isinstance(item, KeyValue) and not item.deleted:
            last_kv_idx[current] = idx

    def _flush_appends(sect: str | None) -> None:
        if sect is None or sect in doc.deleted_sections:
            return
        adds = doc.added_keys.get(sect, [])
        if not adds:
            return
        style = _detect_section_style(doc, sect)
        for k, v in adds:
            if k in rendered_keys.setdefault(sect, set()):
                continue
            out.append(_render_added_kv(sect, k, v, style))
            rendered_keys[sect].add(k)

    for idx, item in enumerate(doc.items):
        if isinstance(item, SectionHeader):
            if item.name in doc.deleted_sections:
                skip_until_next_section = True
                continue
            skip_until_next_section = False
            out.append(item.raw)
            continue

        if skip_until_next_section:
            continue

        if isinstance(item, CommentLine):
            out.append(item.raw)
            continue

        if isinstance(item, KeyValue):
            if item.deleted:
                # Still flush appends if this was the section's natural
                # insert point (last KV that just got deleted)
                sect = item.section
                if last_kv_idx.get(sect) == idx:
                    _flush_appends(sect)
                continue
            if item.dirty:
                out.append(_render_keyvalue(item))
            else:
                out.extend(item.raw_lines)
            rendered_keys.setdefault(item.section, set()).add(item.key)
            # If this is the section's last KV, flush appends right here.
            if last_kv_idx.get(item.section) == idx:
                _flush_appends(item.section)
            continue

    # For sections that have appends but had NO KeyValue items at all
    # (only comments), flush at end. Iterate added_keys to catch them.
    for sect in list(doc.added_keys.keys()):
        if sect in doc.deleted_sections:
            continue
        if rendered_keys.get(sect) and all(
            k in rendered_keys[sect] for k, _ in doc.added_keys[sect]
        ):
            continue  # already flushed
        if sect in last_kv_idx:
            continue  # had a KV; would have been flushed above
        # Append-only section that existed (no KVs) — flush at end
        if sect in last_any_idx:
            _flush_appends(sect)

    # Newly added sections (that had no original SectionHeader) go at end
    for sect in doc.added_sections:
        if sect in doc.deleted_sections:
            continue
        # Skip if this section actually had a real header (shouldn't happen
        # given add_section's guard, but be safe)
        had_real_header = any(
            isinstance(it, SectionHeader) and it.name == sect for it in doc.items
        )
        if had_real_header:
            continue
        # Ensure a blank line separator before the appended section (unless
        # we're the very start of file)
        if out and not out[-1].endswith("\n\n"):
            if not out[-1].endswith("\n"):
                out.append("\n")
            out.append("\n")
        out.append(f"[{sect}]\n")
        style = (" = ", "    ")
        for k, v in doc.added_keys.get(sect, []):
            out.append(_render_added_kv(sect, k, v, style))

    return "".join(out)


def write(doc: _Document, path: Path) -> None:
    """Render and write to disk (UTF-8)."""
    content = render(doc)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    # After a successful write, all dirty flags can be cleared.
    # (We don't re-tokenize here — caller should re-parse if they want
    #  fresh raw_lines for newly-added keys to round-trip cleanly.)
    for item in doc.items:
        if isinstance(item, KeyValue) and item.dirty and not item.deleted:
            # Update raw_lines so future writes are byte-clean
            new_text = _render_keyvalue(item)
            item.raw_lines = new_text.splitlines(keepends=True)
            item.dirty = False
