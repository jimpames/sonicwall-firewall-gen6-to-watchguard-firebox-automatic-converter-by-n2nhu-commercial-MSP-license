"""
schema_lib.py
==============

Schema-driven validation for the toolkit's INI configs.

Used by:
  - Engines at INI load time (typos & missing-required-keys caught loud)
  - The GUI editor for live field validation
  - CI/regression runs to detect drift between code and schema

Public API:
    load_schema(schema_path) -> Schema
    validate_config(config_path, schema) -> ValidationReport

The schema dialect is documented in docs/schema_format.md. Keep this
module's type vocabulary and the spec doc in lockstep.
"""
from __future__ import annotations

import configparser
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Type validators — one per `type=` keyword in the schema.
# Each takes (raw_value, field_spec) and returns (ok, normalized_value, error)
# ---------------------------------------------------------------------------


def _v_string(raw: str, fs: dict) -> tuple[bool, Any, str]:
    if "\n" in raw and not fs.get("allow_multiline"):
        return False, raw, "value contains newline; use multiline_string type"
    return True, raw, ""


def _v_multiline_string(raw: str, fs: dict) -> tuple[bool, Any, str]:
    return True, raw, ""


def _v_int(raw: str, fs: dict) -> tuple[bool, Any, str]:
    try:
        v = int(raw.strip())
    except ValueError:
        return False, raw, f"not an integer: {raw!r}"
    if "min" in fs and v < int(fs["min"]):
        return False, v, f"value {v} below minimum {fs['min']}"
    if "max" in fs and v > int(fs["max"]):
        return False, v, f"value {v} above maximum {fs['max']}"
    return True, v, ""


_BOOL_TRUE = {"true", "1", "yes", "on"}
_BOOL_FALSE = {"false", "0", "no", "off"}


def _v_bool(raw: str, fs: dict) -> tuple[bool, Any, str]:
    s = raw.strip().lower()
    if s in _BOOL_TRUE:
        return True, True, ""
    if s in _BOOL_FALSE:
        return True, False, ""
    return False, raw, f"not a boolean: {raw!r}"


def _v_enum(raw: str, fs: dict) -> tuple[bool, Any, str]:
    allowed = [x.strip() for x in fs.get("enum_values", "").split(",")
               if x.strip()]
    s = raw.strip()
    if s not in allowed:
        return False, raw, (f"value {s!r} not in enum_values "
                            f"({', '.join(allowed)})")
    return True, s, ""


def _v_csv(raw: str, fs: dict) -> tuple[bool, Any, str]:
    items = [x.strip() for x in raw.replace("\n", ",").split(",")
             if x.strip()]
    item_type = fs.get("csv_item_type", "string")
    if item_type == "string":
        return True, items, ""
    # Validate each item against its sub-type
    sub_validator = TYPE_VALIDATORS.get(item_type)
    if not sub_validator:
        return False, items, f"unknown csv_item_type: {item_type}"
    errs = []
    out = []
    for it in items:
        ok, norm, err = sub_validator(it, fs)
        if not ok:
            errs.append(err)
        out.append(norm)
    if errs:
        return False, out, "; ".join(errs)
    return True, out, ""


def _v_regex(raw: str, fs: dict) -> tuple[bool, Any, str]:
    try:
        re.compile(raw)
    except re.error as e:
        return False, raw, f"invalid regex: {e}"
    return True, raw, ""


def _v_xpath(raw: str, fs: dict) -> tuple[bool, Any, str]:
    # Lightweight check — full XPath validation requires lxml.
    # Reject obvious nonsense.
    if not raw.strip():
        return False, raw, "empty xpath"
    return True, raw, ""


def _v_path(raw: str, fs: dict) -> tuple[bool, Any, str]:
    # Don't insist on the path EXISTING (it may be relative & resolved later)
    if not raw.strip():
        return False, raw, "empty path"
    return True, raw, ""


def _v_kv_list(raw: str, fs: dict) -> tuple[bool, Any, str]:
    """Parse `k = v` pairs (one per line OR comma-separated).

    Standard format throughout the toolkit:
        child_map = name              = name
                    enable            = enabled | wg_bool_text
    """
    out: list[tuple[str, str]] = []
    pieces: list[str] = []
    # First split lines; for each line, also handle comma-separated form
    # but be careful — values may contain commas (regex patterns, etc.)
    # so default to one-pair-per-line which is how the toolkit writes them.
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        pieces.append(line)
    for piece in pieces:
        if "=" not in piece:
            return False, out, f"missing '=' in pair: {piece!r}"
        k, v = piece.split("=", 1)
        out.append((k.strip(), v.strip()))
    return True, out, ""


TYPE_VALIDATORS = {
    "string": _v_string,
    "multiline_string": _v_multiline_string,
    "int": _v_int,
    "bool": _v_bool,
    "enum": _v_enum,
    "csv": _v_csv,
    "regex": _v_regex,
    "xpath": _v_xpath,
    "path": _v_path,
    "kv_list": _v_kv_list,
}


# ---------------------------------------------------------------------------
# Schema dataclasses
# ---------------------------------------------------------------------------


@dataclass
class FieldSpec:
    name: str
    type: str
    required: bool = False
    default: str | None = None
    help: str = ""
    raw: dict = field(default_factory=dict)  # all other attributes


@dataclass
class SectionSpec:
    name: str  # for section_pattern, this is the regex pattern key
    is_pattern: bool
    match_pattern: re.Pattern | None
    description: str
    required: bool
    fields: dict[str, FieldSpec] = field(default_factory=dict)
    field_order: list[str] = field(default_factory=list)
    # When dynamic_keys=true, the section accepts arbitrary key=value pairs
    # beyond the declared `fields`. Each unknown key's value is validated
    # against `dynamic_value_type` instead of warning about it.
    dynamic_keys: bool = False
    dynamic_value_type: str = "string"
    dynamic_keys_help: str = ""

    def matches(self, section_name: str) -> bool:
        if self.is_pattern:
            return self.match_pattern is not None and bool(
                self.match_pattern.match(section_name)
            )
        return self.name == section_name


@dataclass
class Schema:
    config_name: str
    description: str
    version: str
    sections: list[SectionSpec] = field(default_factory=list)
    raw_path: Path | None = None

    def find_section(self, name: str) -> SectionSpec | None:
        # Prefer exact match before pattern match
        for s in self.sections:
            if not s.is_pattern and s.name == name:
                return s
        for s in self.sections:
            if s.is_pattern and s.matches(name):
                return s
        return None


@dataclass
class ValidationIssue:
    severity: str  # "error" | "warning"
    section: str
    field_name: str
    message: str


@dataclass
class ValidationReport:
    config_path: Path
    schema_path: Path | None
    issues: list[ValidationIssue] = field(default_factory=list)

    @property
    def errors(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self) -> list[ValidationIssue]:
        return [i for i in self.issues if i.severity == "warning"]

    @property
    def ok(self) -> bool:
        return not self.errors

    def format(self) -> str:
        if not self.issues:
            return f"OK: {self.config_path} validates against schema."
        lines = [f"Validation report for {self.config_path}:"]
        for i in self.issues:
            loc = f"[{i.section}]" + (f".{i.field_name}" if i.field_name else "")
            lines.append(f"  {i.severity.upper():<7} {loc}: {i.message}")
        lines.append(
            f"  Summary: {len(self.errors)} errors, {len(self.warnings)} warnings"
        )
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Schema loading
# ---------------------------------------------------------------------------


def _read_ini(path: Path) -> configparser.ConfigParser:
    cp = configparser.ConfigParser(
        interpolation=None,
        inline_comment_prefixes=(";",),
        comment_prefixes=("#",),
    )
    cp.read(path, encoding="utf-8")
    return cp


def load_schema(path: Path) -> Schema:
    """Parse a schema INI into a Schema dataclass."""
    cp = _read_ini(path)
    meta = cp["meta"] if "meta" in cp else {}

    schema = Schema(
        config_name=meta.get("config_name", path.stem),
        description=meta.get("description", "").strip(),
        version=meta.get("version", "1.0").strip(),
        raw_path=path,
    )

    # Two passes: first collect section specs, then attach field specs.
    # Section keys: [section.X] or [section_pattern.X]
    # Field keys:   [section.X.field.Y] or [section_pattern.X.field.Y]
    section_specs: dict[str, SectionSpec] = {}

    for sect_name in cp.sections():
        if sect_name.startswith("section.") and ".field." not in sect_name:
            short = sect_name.split(".", 1)[1]
            sect = cp[sect_name]
            section_specs[("section", short)] = SectionSpec(
                name=short,
                is_pattern=False,
                match_pattern=None,
                description=sect.get("description", "").strip(),
                required=_to_bool(sect.get("required", "false")),
                field_order=[
                    x.strip() for x in
                    sect.get("fields", "").replace("\n", ",").split(",")
                    if x.strip()
                ],
                dynamic_keys=_to_bool(sect.get("dynamic_keys", "false")),
                dynamic_value_type=sect.get("dynamic_value_type", "string").strip(),
                dynamic_keys_help=sect.get("dynamic_keys_help", "").strip(),
            )
        elif sect_name.startswith("section_pattern.") and ".field." not in sect_name:
            short = sect_name.split(".", 1)[1]
            sect = cp[sect_name]
            pat_str = sect.get("match_pattern", "").strip()
            try:
                pat = re.compile(pat_str) if pat_str else None
            except re.error:
                pat = None
            section_specs[("section_pattern", short)] = SectionSpec(
                name=short,
                is_pattern=True,
                match_pattern=pat,
                description=sect.get("description", "").strip(),
                required=False,  # patterns are zero-or-more
                field_order=[
                    x.strip() for x in
                    sect.get("fields", "").replace("\n", ",").split(",")
                    if x.strip()
                ],
                dynamic_keys=_to_bool(sect.get("dynamic_keys", "false")),
                dynamic_value_type=sect.get("dynamic_value_type", "string").strip(),
                dynamic_keys_help=sect.get("dynamic_keys_help", "").strip(),
            )

    # Second pass: attach field specs
    for sect_name in cp.sections():
        if ".field." not in sect_name:
            continue
        # e.g. "section.meta.field.name" or "section_pattern.value_map.field.canonical_to_watchguard"
        parts = sect_name.split(".field.", 1)
        if len(parts) != 2:
            continue
        parent_key = parts[0]
        field_name = parts[1]

        if parent_key.startswith("section_pattern."):
            short = parent_key.split(".", 1)[1]
            owner = section_specs.get(("section_pattern", short))
        elif parent_key.startswith("section."):
            short = parent_key.split(".", 1)[1]
            owner = section_specs.get(("section", short))
        else:
            continue
        if owner is None:
            continue

        sect = cp[sect_name]
        fs = FieldSpec(
            name=field_name,
            type=sect.get("type", "string").strip(),
            required=_to_bool(sect.get("required", "false")),
            default=sect.get("default", None),
            help=sect.get("help", "").strip(),
            raw=dict(sect),
        )
        owner.fields[field_name] = fs
        if field_name not in owner.field_order:
            owner.field_order.append(field_name)

    schema.sections = list(section_specs.values())
    return schema


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def validate_config(config_path: Path, schema: Schema) -> ValidationReport:
    """Validate a config INI against a schema."""
    report = ValidationReport(
        config_path=config_path,
        schema_path=schema.raw_path,
    )
    if not config_path.is_file():
        report.issues.append(ValidationIssue(
            "error", "", "", f"config file not found: {config_path}"
        ))
        return report

    cp = _read_ini(config_path)

    # Track which schema sections were satisfied (for required-section check)
    satisfied: set[str] = set()

    for cfg_sect_name in cp.sections():
        spec = schema.find_section(cfg_sect_name)
        if spec is None:
            report.issues.append(ValidationIssue(
                "warning", cfg_sect_name, "",
                "no matching section in schema (unknown section)"
            ))
            continue
        satisfied.add(spec.name)

        sect = cp[cfg_sect_name]
        # Check required fields are present
        for fname, fspec in spec.fields.items():
            if fspec.required and fname not in sect:
                report.issues.append(ValidationIssue(
                    "error", cfg_sect_name, fname,
                    f"required field missing"
                ))

        # Validate each present field
        for key in sect:
            fspec = spec.fields.get(key)
            if fspec is None:
                # Unknown field — but if section accepts dynamic keys, validate
                # against dynamic_value_type rather than warn.
                if spec.dynamic_keys:
                    raw = sect.get(key, "")
                    validator = TYPE_VALIDATORS.get(spec.dynamic_value_type)
                    if validator is None:
                        report.issues.append(ValidationIssue(
                            "error", cfg_sect_name, key,
                            f"unknown dynamic_value_type "
                            f"{spec.dynamic_value_type!r} in schema"
                        ))
                        continue
                    ok, _, err = validator(raw, {})
                    if not ok:
                        report.issues.append(ValidationIssue(
                            "error", cfg_sect_name, key,
                            f"dynamic key value (type={spec.dynamic_value_type}): {err}"
                        ))
                else:
                    report.issues.append(ValidationIssue(
                        "warning", cfg_sect_name, key,
                        "field not declared in schema (unknown field)"
                    ))
                continue
            raw = sect.get(key, "")
            validator = TYPE_VALIDATORS.get(fspec.type)
            if validator is None:
                report.issues.append(ValidationIssue(
                    "error", cfg_sect_name, key,
                    f"unknown type {fspec.type!r} in schema"
                ))
                continue
            ok, _, err = validator(raw, fspec.raw)
            if not ok:
                report.issues.append(ValidationIssue(
                    "error", cfg_sect_name, key,
                    f"type={fspec.type}: {err}"
                ))

    # Check required sections present
    for spec in schema.sections:
        if spec.required and not spec.is_pattern and spec.name not in satisfied:
            report.issues.append(ValidationIssue(
                "error", spec.name, "",
                "required section missing from config"
            ))

    return report


def _to_bool(s: str) -> bool:
    return s.strip().lower() in _BOOL_TRUE


# ---------------------------------------------------------------------------
# Engine-startup helper
# ---------------------------------------------------------------------------

def _find_sibling_schema(config_path: Path) -> Path | None:
    """Locate the schema file beside config_path. Tries:
        <config>.schema.ini    (preferred — e.g. parser_config.schema.ini)
        <config_stem>.schema.ini   (fallback)
    Returns None if nothing is found.
    """
    candidate = config_path.with_suffix(".schema.ini")
    if candidate.is_file():
        return candidate
    candidate = config_path.parent / (config_path.stem + ".schema.ini")
    if candidate.is_file():
        return candidate
    return None


def validate_at_startup(
    config_path: Path,
    *,
    engine_name: str = "engine",
    strict: bool = False,
    quiet: bool = False,
    stream=None,
) -> ValidationReport | None:
    """Run schema validation at engine startup.

    Behavior:
      * If a sibling schema is found, validate and print a summary.
      * If validation has errors and strict=True, print and return the
        report so the caller can sys.exit appropriately.
      * If no schema is found, print a single line and return None
        (the engine still runs — the toolkit must work on configs
        without schemas during migration).

    Returns the ValidationReport (or None if no schema found). Callers
    are expected to honor `report.ok` themselves if they want to fail
    fast even outside strict mode.
    """
    import sys as _sys
    out = stream if stream is not None else _sys.stderr

    schema_path = _find_sibling_schema(config_path)
    if schema_path is None:
        if not quiet:
            print(
                f"[{engine_name}] no sibling schema found for {config_path.name}; "
                "running without validation",
                file=out,
            )
        return None

    try:
        schema = load_schema(schema_path)
    except Exception as e:
        print(
            f"[{engine_name}] failed to load schema {schema_path.name}: {e}",
            file=out,
        )
        return None

    report = validate_config(config_path, schema)
    n_err = len(report.errors)
    n_warn = len(report.warnings)

    if not quiet:
        if report.ok and n_warn == 0:
            print(
                f"[{engine_name}] config validates cleanly against "
                f"{schema_path.name}",
                file=out,
            )
        else:
            print(
                f"[{engine_name}] schema validation: {n_err} errors, "
                f"{n_warn} warnings against {schema_path.name}",
                file=out,
            )
            for issue in report.errors[:20]:
                print(
                    f"  ERROR  [{issue.section}] {issue.field_name}: "
                    f"{issue.message}",
                    file=out,
                )
            for issue in report.warnings[:10]:
                print(
                    f"  WARN   [{issue.section}] {issue.field_name}: "
                    f"{issue.message}",
                    file=out,
                )
            if n_err > 20:
                print(f"  ... and {n_err - 20} more errors", file=out)
            if n_warn > 10:
                print(f"  ... and {n_warn - 10} more warnings", file=out)

    return report

