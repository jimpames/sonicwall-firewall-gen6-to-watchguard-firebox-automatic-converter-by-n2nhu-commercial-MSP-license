#!/usr/bin/env python3
"""
test_phase6_tier_filtering.py
==============================

Phase 6 regression tests for enabled-status detection and tier-filtered
triage, per the conversation that started with Captain Ames' insight:

    "we see it's OFF in the html, we actually SKIP that entire
    translation and make a note in our report - could save us
    weeks of aggravation"

This test suite verifies:
  1. The engine computes enabled_status from XML alone (no HTML needed)
     across three patterns: leaf-with-boolean, empty-container,
     populated-container
  2. tier_suggestion correctly maps from enabled_status
  3. The findings JSON includes the new fields
  4. The triage walk --tier filter restricts the active set
  5. --auto-sideline-deferred routes deferred findings to the sideline
     queue with the right reason string
  6. Existing approved-corpus and banned-suppression flows still work
     (no regression on Phase 1/Phase 2 behavior)

The operator-override path is preserved: --tier all behaves identically
to current behavior, no surfaces auto-deferred without --auto-sideline-
deferred flag.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "schema_learner"))

from feature_vectors import ElementFeatureVector  # noqa: E402
from schema_learner import SchemaLearner  # noqa: E402


# ---------------------------------------------------------------------------
# State snapshot/restore for tests that touch sideline queue
# ---------------------------------------------------------------------------

def _snapshot_state() -> dict[str, bytes | None]:
    snap: dict[str, bytes | None] = {}
    from corpus_tiers import _sideline_queue_path, _sideline_root
    paths_to_track = [_sideline_queue_path()]
    for p in paths_to_track:
        snap[str(p)] = p.read_bytes() if p.is_file() else None
    if _sideline_root().is_dir():
        for f in _sideline_root().iterdir():
            if f.is_file():
                snap[str(f)] = f.read_bytes()
    return snap


def _restore_state(snap: dict[str, bytes | None]) -> None:
    from corpus_tiers import _sideline_root
    if _sideline_root().is_dir():
        for f in list(_sideline_root().iterdir()):
            if str(f) not in snap and f.is_file():
                f.unlink()
    for path_str, contents in snap.items():
        p = Path(path_str)
        if contents is None:
            if p.is_file():
                p.unlink()
        else:
            p.write_bytes(contents)


# ---------------------------------------------------------------------------
# Enabled-status detection unit tests
# ---------------------------------------------------------------------------

def test_pattern_a_enabled_leaf() -> tuple[bool, str]:
    """Pattern A: leaf with on-style text value → enabled, tier 1."""
    fv = ElementFeatureVector(
        tag='Botnet',
        instance_count=1,
        sample_own_text_values=['1'],
        leaf_with_value_count=1,
    )
    status, tier, evidence = SchemaLearner._compute_enabled_status(fv)
    if status != 'enabled':
        return False, f"got status={status!r}, expected 'enabled'"
    if tier != 1:
        return False, f"got tier={tier}, expected 1"
    if 'leaf value' not in evidence:
        return False, f"evidence missing 'leaf value': {evidence!r}"
    return True, "leaf <Botnet>1 → enabled/tier-1"


def test_pattern_a_disabled_leaf() -> tuple[bool, str]:
    """Pattern A: leaf with off-style text → disabled, tier 3."""
    fv = ElementFeatureVector(
        tag='DLP',
        instance_count=1,
        sample_own_text_values=['0'],
        leaf_with_value_count=1,
    )
    status, tier, evidence = SchemaLearner._compute_enabled_status(fv)
    if status != 'disabled':
        return False, f"got status={status!r}, expected 'disabled'"
    if tier != 3:
        return False, f"got tier={tier}, expected 3"
    return True, "leaf <DLP>0 → disabled/tier-3"


def test_pattern_a_various_boolean_words() -> tuple[bool, str]:
    """Pattern A handles various boolean-style words case-insensitive."""
    cases = [
        (['true'], 'enabled'),
        (['yes'], 'enabled'),
        (['ON'], 'enabled'),
        (['Enabled'], 'enabled'),
        (['false'], 'disabled'),
        (['NO'], 'disabled'),
        (['Off'], 'disabled'),
        (['disabled'], 'disabled'),
    ]
    for values, expected in cases:
        fv = ElementFeatureVector(
            tag='test',
            instance_count=1,
            sample_own_text_values=values,
            leaf_with_value_count=1,
        )
        status, _, _ = SchemaLearner._compute_enabled_status(fv)
        if status != expected:
            return False, (f"values={values!r}: got {status!r}, "
                           f"expected {expected!r}")
    return True, f"all {len(cases)} boolean variants classified correctly"


def test_pattern_a_mixed_values_unknown() -> tuple[bool, str]:
    """Pattern A with mixed enabled/disabled values → unknown, tier 1.
    
    Operator must investigate when some instances are on and others off."""
    fv = ElementFeatureVector(
        tag='Mixed',
        instance_count=2,
        sample_own_text_values=['1', '0'],
        leaf_with_value_count=2,
    )
    status, tier, _ = SchemaLearner._compute_enabled_status(fv)
    if status != 'unknown':
        return False, f"mixed values should be unknown, got {status!r}"
    if tier != 1:
        return False, f"mixed values should be tier 1, got {tier}"
    return True, "mixed enabled/disabled values → unknown/tier-1"


def test_pattern_b_empty_container() -> tuple[bool, str]:
    """Pattern B: no children + no text → disabled (tier 3)."""
    fv = ElementFeatureVector(
        tag='ras-user-list',
        instance_count=1,
        # No children_tags, no sample_own_text_values
    )
    status, tier, evidence = SchemaLearner._compute_enabled_status(fv)
    if status != 'disabled':
        return False, f"empty container should be disabled, got {status!r}"
    if tier != 3:
        return False, f"empty container should be tier 3, got {tier}"
    if 'empty container' not in evidence:
        return False, f"evidence wrong: {evidence!r}"
    return True, "empty container → disabled/tier-3"


def test_pattern_c_populated_container() -> tuple[bool, str]:
    """Pattern C: has children → unknown (tier 1), operator decides."""
    from collections import Counter
    fv = ElementFeatureVector(
        tag='policy-list',
        instance_count=1,
        children_tags=Counter({'policy': 47}),
    )
    status, tier, _ = SchemaLearner._compute_enabled_status(fv)
    if status != 'unknown':
        return False, (f"populated container should be unknown "
                       f"(operator decides), got {status!r}")
    if tier != 1:
        return False, f"populated container should be tier 1, got {tier}"
    return True, "populated container → unknown/tier-1 (operator decides)"


def test_pattern_c_freetext_leaf() -> tuple[bool, str]:
    """Free-text leaf (not boolean-style) → unknown, tier 1.
    
    E.g. <description>Some text</description> shouldn't be auto-tiered."""
    fv = ElementFeatureVector(
        tag='description',
        instance_count=1,
        sample_own_text_values=['Some free text describing the thing'],
        leaf_with_value_count=1,
    )
    status, tier, _ = SchemaLearner._compute_enabled_status(fv)
    if status != 'unknown':
        return False, (f"free-text leaf should be unknown, "
                       f"got {status!r}")
    if tier != 1:
        return False, f"free-text leaf should be tier 1, got {tier}"
    return True, "free-text leaf → unknown/tier-1"


# ---------------------------------------------------------------------------
# Finding serialization tests
# ---------------------------------------------------------------------------

def test_finding_json_includes_phase6_fields() -> tuple[bool, str]:
    """findings.json must include enabled_status, tier_suggestion,
    enabled_status_evidence for Category-1 findings."""
    # Run the engine against the corpus to produce a real findings.json
    from schema_learner import (
        LearnerConfig, SchemaLearner, write_findings_json,
    )
    
    # Use a tiny synthetic XML
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        # Create a fake corpus structure
        corpus = td / "corpus"
        corpus.mkdir()
        # Empty corpus index (engine handles this gracefully)
        proposals = td / "proposals"
        proposals.mkdir()
        schema_path = td / "schema.ini"
        schema_path.write_text("; empty schema\n", encoding='utf-8')
        
        # Synthetic input XML with a leaf-with-bool and an empty container
        input_xml = td / "input.xml"
        input_xml.write_text("""<?xml version="1.0"?>
<profile>
  <BotnetTest>1</BotnetTest>
  <EmptyContainerTest/>
  <PolicyListTest>
    <Policy><name>P1</name></Policy>
  </PolicyListTest>
</profile>
""", encoding='utf-8')
        
        config = LearnerConfig(
            corpus_dir=corpus,
            proposals_dir=proposals,
            existing_schema_path=schema_path,
            findings_format='both',
            auto_propose_minimum=0.4,
            high_confidence=0.85,
            medium_confidence=0.5,
            top_k_neighbors=10,
            neighbor_minimum_similarity=0.1,
            auto_reuse_threshold=0.85,
            auto_reuse_emit_provenance=True,
            auto_reuse_report_findings=True,
            banned_suppress_threshold=0.8,
            require_operator_approval=True,
            report_unplaceable_findings=True,
            backup_before_merge=True,
        )
        learner = SchemaLearner(config)
        learner.load_existing_schema()
        learner.load_corpus()
        findings = learner.detect_findings(input_xml, "TEST")
        
        json_path = td / "findings.json"
        write_findings_json(findings, json_path)
        data = json.loads(json_path.read_text(encoding='utf-8'))
    
    # Check each Cat-1 finding has Phase 6 fields
    for f in data['findings']:
        if f['category'] == 'novel_element_type':
            if 'enabled_status' not in f:
                return False, "Cat-1 finding missing enabled_status field"
            if 'tier_suggestion' not in f:
                return False, "Cat-1 finding missing tier_suggestion field"
            if 'enabled_status_evidence' not in f:
                return False, "Cat-1 finding missing evidence field"
    
    # The specific element types should have specific statuses
    by_tag = {f['element_tag']: f
              for f in data['findings']
              if f['category'] == 'novel_element_type'}
    
    if 'BotnetTest' in by_tag:
        if by_tag['BotnetTest']['enabled_status'] != 'enabled':
            return False, ("BotnetTest with value=1 should be enabled, "
                           f"got {by_tag['BotnetTest']['enabled_status']}")
    
    if 'EmptyContainerTest' in by_tag:
        if by_tag['EmptyContainerTest']['enabled_status'] != 'disabled':
            return False, ("EmptyContainerTest should be disabled, "
                           f"got {by_tag['EmptyContainerTest']['enabled_status']}")
        if by_tag['EmptyContainerTest']['tier_suggestion'] != 3:
            return False, "EmptyContainerTest should be tier 3"
    
    return True, "findings.json contains Phase 6 fields with correct values"


# ---------------------------------------------------------------------------
# Triage CLI integration tests
# ---------------------------------------------------------------------------

def test_triage_walk_tier_filter_acceptance() -> tuple[bool, str]:
    """--tier flag accepts valid values; rejects invalid ones."""
    triage_path = ROOT / 'schema_learner' / 'triage.py'
    
    # Valid: "all" — should not error on argparse alone
    r = subprocess.run(
        [sys.executable, str(triage_path), 'walk', '--help'],
        capture_output=True, text=True)
    if r.returncode != 0:
        return False, f"walk --help failed: {r.stderr[:200]}"
    if '--tier' not in r.stdout:
        return False, "--tier not in walk --help output"
    if '--auto-sideline-deferred' not in r.stdout:
        return False, "--auto-sideline-deferred not in walk --help"
    return True, "Phase 6 CLI flags --tier and --auto-sideline-deferred present"


def test_triage_walk_tier_filter_actually_filters() -> tuple[bool, str]:
    """End-to-end: --tier 1 must include enabled findings and exclude
    tier-3 findings."""
    triage_path = ROOT / 'schema_learner' / 'triage.py'
    
    with tempfile.TemporaryDirectory() as td:
        prop_dir = Path(td) / "test_prop"
        prop_dir.mkdir()
        
        # Synthesize a findings.json with mixed tier suggestions
        findings = {
            'findings': [
                {
                    'category': 'novel_element_type',
                    'element_tag': 'EnabledThing',
                    'source_file': 'TEST',
                    'detail': {},
                    'enabled_status': 'enabled',
                    'tier_suggestion': 1,
                    'enabled_status_evidence': 'leaf value=1',
                    'structural_facts': {
                        'instance_count': 1,
                        'distinct_children_tags': 0,
                        'distinct_field_shapes': 1,
                        'naming_tokens': ['enabled', 'thing'],
                        'top_children_tags': [],
                        'value_pattern_summary': {},
                    },
                    'neighbors': [],
                    'placement_confidence': 0.0,
                },
                {
                    'category': 'novel_element_type',
                    'element_tag': 'EmptyThing',
                    'source_file': 'TEST',
                    'detail': {},
                    'enabled_status': 'disabled',
                    'tier_suggestion': 3,
                    'enabled_status_evidence': 'empty container',
                    'structural_facts': {
                        'instance_count': 1,
                        'distinct_children_tags': 0,
                        'distinct_field_shapes': 1,
                        'naming_tokens': ['empty', 'thing'],
                        'top_children_tags': [],
                        'value_pattern_summary': {},
                    },
                    'neighbors': [],
                    'placement_confidence': 0.0,
                },
            ],
        }
        (prop_dir / 'findings.json').write_text(
            json.dumps(findings), encoding='utf-8')
        
        # Run walk with --tier 1 and echo 'q' to exit immediately. The
        # output should announce "1 finding(s); 1 deferred" — proving
        # the filter is being applied.
        r = subprocess.run(
            [sys.executable, str(triage_path), 'walk',
             '--proposal', str(prop_dir),
             '--operator', 'jimames',
             '--tier', '1',
             '--no-llm'],
            input='q\n',
            capture_output=True, text=True, timeout=15)
        
        if 'tier filter' not in r.stdout.lower():
            return False, ("output should mention tier filter: "
                           f"{r.stdout[:400]}")
        if '1 deferred' not in r.stdout:
            return False, ("output should report '1 deferred' (the "
                           "tier-3 finding), got: "
                           f"{r.stdout[:400]}")
        return True, ("--tier 1 correctly includes tier-1 and excludes "
                      "tier-3")


def test_triage_walk_tier_all_no_filter() -> tuple[bool, str]:
    """--tier all should be identical to default (no filter, all
    findings appear). Compatibility check — no regression on Phase 1-5."""
    triage_path = ROOT / 'schema_learner' / 'triage.py'
    
    with tempfile.TemporaryDirectory() as td:
        prop_dir = Path(td) / "test_prop"
        prop_dir.mkdir()
        findings = {
            'findings': [
                {
                    'category': 'novel_element_type',
                    'element_tag': 'OnlyThing',
                    'source_file': 'TEST',
                    'detail': {},
                    'enabled_status': 'unknown',
                    'tier_suggestion': 1,
                    'enabled_status_evidence': '',
                    'structural_facts': {
                        'instance_count': 1, 'distinct_children_tags': 0,
                        'distinct_field_shapes': 1, 'naming_tokens': [],
                        'top_children_tags': [], 'value_pattern_summary': {},
                    },
                    'neighbors': [], 'placement_confidence': 0.0,
                },
            ],
        }
        (prop_dir / 'findings.json').write_text(
            json.dumps(findings), encoding='utf-8')
        
        r = subprocess.run(
            [sys.executable, str(triage_path), 'walk',
             '--proposal', str(prop_dir),
             '--operator', 'jimames',
             '--tier', 'all',
             '--no-llm'],
            input='q\n',
            capture_output=True, text=True, timeout=15)
        
        # With --tier all, there should be NO "tier filter" message
        if 'tier filter' in r.stdout.lower():
            return False, ("--tier all should NOT apply filter, but "
                           f"output mentions filter: {r.stdout[:300]}")
        if 'OnlyThing' not in r.stdout:
            return False, "the single finding should appear"
        return True, "--tier all = no filter, all findings included"


# ---------------------------------------------------------------------------
# Auto-sideline deferred test
# ---------------------------------------------------------------------------

def test_auto_sideline_deferred_routes_to_queue() -> tuple[bool, str]:
    """--auto-sideline-deferred must route excluded findings to the
    sideline queue with reason 'deferred_disabled_in_source'."""
    snap = _snapshot_state()
    try:
        triage_path = ROOT / 'schema_learner' / 'triage.py'
        unique = uuid.uuid4().hex[:8]
        
        with tempfile.TemporaryDirectory() as td:
            prop_dir = Path(td) / f"test_prop_{unique}"
            prop_dir.mkdir()
            disabled_tag = f"DisabledThing_{unique}"
            enabled_tag = f"EnabledThing_{unique}"
            findings = {
                'findings': [
                    {
                        'category': 'novel_element_type',
                        'element_tag': enabled_tag,
                        'source_file': 'TEST',
                        'detail': {},
                        'enabled_status': 'enabled',
                        'tier_suggestion': 1,
                        'enabled_status_evidence': 'leaf value=1',
                        'structural_facts': {
                            'instance_count': 1, 'distinct_children_tags': 0,
                            'distinct_field_shapes': 1,
                            'naming_tokens': ['enabled'],
                            'top_children_tags': [],
                            'value_pattern_summary': {},
                        },
                        'neighbors': [],
                        'placement_confidence': 0.0,
                    },
                    {
                        'category': 'novel_element_type',
                        'element_tag': disabled_tag,
                        'source_file': 'TEST',
                        'detail': {},
                        'enabled_status': 'disabled',
                        'tier_suggestion': 3,
                        'enabled_status_evidence': 'empty container',
                        'structural_facts': {
                            'instance_count': 1, 'distinct_children_tags': 0,
                            'distinct_field_shapes': 1,
                            'naming_tokens': ['disabled'],
                            'top_children_tags': [],
                            'value_pattern_summary': {},
                        },
                        'neighbors': [],
                        'placement_confidence': 0.0,
                    },
                ],
            }
            (prop_dir / 'findings.json').write_text(
                json.dumps(findings), encoding='utf-8')
            
            # Run with --auto-sideline-deferred and quit immediately
            r = subprocess.run(
                [sys.executable, str(triage_path), 'walk',
                 '--proposal', str(prop_dir),
                 '--operator', 'jimames',
                 '--tier', '1',
                 '--auto-sideline-deferred',
                 '--no-llm'],
                input='q\n',
                capture_output=True, text=True, timeout=15)
            
            if 'auto-sidelining' not in r.stdout.lower():
                return False, (f"expected auto-sidelining message, got: "
                               f"{r.stdout[:500]}")
            
            # Verify the disabled tag is now in the sideline queue
            from corpus_tiers import load_sideline_queue
            queue = load_sideline_queue()
            sidelined_tags = {e.surface_tag for e in queue}
            if disabled_tag not in sidelined_tags:
                return False, (f"{disabled_tag!r} not found in sideline "
                               f"queue. Queue has: {sidelined_tags}")
            
            # Verify the reason captures Phase 6 evidence
            sl_entry = next(e for e in queue
                            if e.surface_tag == disabled_tag)
            if 'auto-defer' not in sl_entry.reason.lower():
                return False, (f"sideline entry reason should mention "
                               f"auto-defer, got: {sl_entry.reason}")
            if 'disabled' not in sl_entry.reason.lower():
                return False, (f"sideline reason should mention disabled "
                               f"status: {sl_entry.reason}")
            
            return True, ("--auto-sideline-deferred routes excluded "
                          "findings to sideline queue with Phase 6 reason")
    finally:
        _restore_state(snap)


# ---------------------------------------------------------------------------
# Provenance audit
# ---------------------------------------------------------------------------

def test_phase6_provenance_audit_clean() -> tuple[bool, str]:
    """Phase 6 artifacts (findings with tier metadata) must pass
    the provenance audit."""
    audit = subprocess.run(
        [sys.executable,
         str(ROOT / 'harness' / 'test_schema_learner_provenance.py')],
        capture_output=True, text=True)
    if audit.returncode != 0:
        return False, ("provenance audit failed on Phase 6 output: "
                       f"{audit.stdout[:500]}")
    return True, "provenance audit clean on Phase 6 output"


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

TESTS = [
    ("pattern_a_enabled_leaf", test_pattern_a_enabled_leaf),
    ("pattern_a_disabled_leaf", test_pattern_a_disabled_leaf),
    ("pattern_a_various_boolean_words",
     test_pattern_a_various_boolean_words),
    ("pattern_a_mixed_values_unknown",
     test_pattern_a_mixed_values_unknown),
    ("pattern_b_empty_container", test_pattern_b_empty_container),
    ("pattern_c_populated_container", test_pattern_c_populated_container),
    ("pattern_c_freetext_leaf", test_pattern_c_freetext_leaf),
    ("finding_json_includes_phase6_fields",
     test_finding_json_includes_phase6_fields),
    ("triage_walk_tier_filter_acceptance",
     test_triage_walk_tier_filter_acceptance),
    ("triage_walk_tier_filter_actually_filters",
     test_triage_walk_tier_filter_actually_filters),
    ("triage_walk_tier_all_no_filter",
     test_triage_walk_tier_all_no_filter),
    ("auto_sideline_deferred_routes_to_queue",
     test_auto_sideline_deferred_routes_to_queue),
    ("phase6_provenance_audit_clean",
     test_phase6_provenance_audit_clean),
]


def main() -> int:
    print("Phase 6 — Tier filtering + enabled-status detection")
    print()
    print(f"{'TEST':<55} {'RESULT':<8} DETAIL")
    print("-" * 95)
    fail = 0
    for name, fn in TESTS:
        try:
            ok, msg = fn()
        except Exception as e:
            ok, msg = False, f"EXC: {type(e).__name__}: {e}"
        status = "PASS" if ok else "FAIL"
        print(f"{name:<55} {status:<8} {msg[:140]}")
        if not ok:
            fail += 1
    print()
    if fail == 0:
        print(f"All {len(TESTS)} Phase 6 tests passed.")
        return 0
    print(f"{fail} of {len(TESTS)} Phase 6 tests FAILED.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
