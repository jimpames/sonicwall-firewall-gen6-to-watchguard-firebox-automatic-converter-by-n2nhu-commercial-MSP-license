#!/usr/bin/env python3
"""
Round-trip test for comment_preserving_ini.

We test three things:

1. IDENTITY: parse(file) -> render() == original bytes, for every INI
   we have in the toolkit. If any byte differs without us having
   mutated anything, the writer is broken.

2. MUTATION: change one value via set_value, render, re-parse, verify
   the new value is there AND that ALL surrounding comments survived.

3. APPEND: add a new key to an existing section, render, verify the
   key appears at the section's end and nothing else changed.

4. ADD_SECTION: add a brand-new section, render, verify it appears at
   end-of-file and existing content is byte-identical.

5. DELETE_KEY: delete a key, render, verify the key is gone and
   surrounding comments survive.
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from schema_lib import comment_preserving_ini as cpi


def diff_first_n(a: str, b: str, n: int = 200) -> str:
    """Show first n chars where strings diverge."""
    for i, (ca, cb) in enumerate(zip(a, b)):
        if ca != cb:
            return (
                f"  divergence at byte {i}\n"
                f"  expected: {a[max(0,i-30):i+30]!r}\n"
                f"  got:      {b[max(0,i-30):i+30]!r}"
            )
    if len(a) != len(b):
        return f"  length mismatch: expected {len(a)}, got {len(b)}"
    return "  (identical)"


def test_identity(path: Path) -> tuple[bool, str]:
    """parse + render with no mutations should be byte-identical."""
    with open(path, encoding="utf-8") as f:
        original = f.read()
    doc = cpi.parse(path)
    rendered = cpi.render(doc)
    if rendered == original:
        return True, "byte-identical"
    return False, diff_first_n(original, rendered)


def test_mutation(path: Path) -> tuple[bool, str]:
    """Mutate one value, verify it's there + comments preserved."""
    doc = cpi.parse(path)
    sections = cpi.sections(doc)
    if not sections:
        return True, "no sections to test"
    # Find first section with at least one key
    target_section = None
    target_key = None
    for s in sections:
        ks = cpi.keys(doc, s)
        if ks:
            target_section = s
            target_key = ks[0]
            break
    if target_section is None:
        return True, "no keys to test"

    original_value = cpi.get(doc, target_section, target_key)
    new_value = "TEST_MUTATION_MARKER_" + str(hash(path))[:8]
    cpi.set_value(doc, target_section, target_key, new_value)
    rendered = cpi.render(doc)

    # Verify new value is in output
    if new_value not in rendered:
        return False, f"new value not found in rendered output"

    # Re-parse and verify
    with tempfile.NamedTemporaryFile("w", suffix=".ini", delete=False,
                                     encoding="utf-8") as f:
        f.write(rendered)
        tmp_path = Path(f.name)
    try:
        doc2 = cpi.parse(tmp_path)
        readback = cpi.get(doc2, target_section, target_key)
        if readback != new_value:
            return False, (
                f"mutation didn't round-trip:\n"
                f"  set:      {new_value!r}\n"
                f"  got back: {readback!r}"
            )
    finally:
        tmp_path.unlink()

    # Verify comment count preserved (count `#` and `;` line starts)
    with open(path, encoding="utf-8") as f:
        original = f.read()
    orig_comment_lines = sum(
        1 for l in original.splitlines() if l.lstrip().startswith(("#", ";"))
    )
    rendered_comment_lines = sum(
        1 for l in rendered.splitlines() if l.lstrip().startswith(("#", ";"))
    )
    if orig_comment_lines != rendered_comment_lines:
        return False, (
            f"comment count changed: was {orig_comment_lines}, "
            f"now {rendered_comment_lines}"
        )

    return True, (
        f"mutated [{target_section}] {target_key} "
        f"({orig_comment_lines} comment lines preserved)"
    )


def test_append_key(path: Path) -> tuple[bool, str]:
    """Add a new key to an existing section."""
    doc = cpi.parse(path)
    if not cpi.sections(doc):
        return True, "no sections"
    target = cpi.sections(doc)[0]
    cpi.set_value(doc, target, "_test_appended_key", "appended_value")
    rendered = cpi.render(doc)
    import re as _re
    if not _re.search(r"^_test_appended_key\s*=\s*appended_value", rendered,
                      _re.MULTILINE):
        return False, "appended key not found in output"
    # Re-parse
    with tempfile.NamedTemporaryFile("w", suffix=".ini", delete=False,
                                     encoding="utf-8") as f:
        f.write(rendered)
        tmp = Path(f.name)
    try:
        doc2 = cpi.parse(tmp)
        if cpi.get(doc2, target, "_test_appended_key") != "appended_value":
            return False, "round-trip failed"
    finally:
        tmp.unlink()
    return True, f"appended to [{target}]"


def test_add_section(path: Path) -> tuple[bool, str]:
    doc = cpi.parse(path)
    cpi.add_section(doc, "_test_added_section")
    cpi.set_value(doc, "_test_added_section", "k", "v")
    rendered = cpi.render(doc)
    if "[_test_added_section]" not in rendered:
        return False, "added section not in output"
    import re as _re
    if not _re.search(r"^k\s*=\s*v\s*$", rendered, _re.MULTILINE):
        return False, "added key not in output"
    # Re-parse
    with tempfile.NamedTemporaryFile("w", suffix=".ini", delete=False,
                                     encoding="utf-8") as f:
        f.write(rendered)
        tmp = Path(f.name)
    try:
        doc2 = cpi.parse(tmp)
        if cpi.get(doc2, "_test_added_section", "k") != "v":
            return False, "round-trip failed"
    finally:
        tmp.unlink()
    return True, "section appended at EOF"


def test_delete_key(path: Path) -> tuple[bool, str]:
    doc = cpi.parse(path)
    sections = cpi.sections(doc)
    target_s = target_k = None
    for s in sections:
        ks = cpi.keys(doc, s)
        if ks:
            target_s, target_k = s, ks[0]
            break
    if target_s is None:
        return True, "no keys"
    cpi.delete_key(doc, target_s, target_k)
    rendered = cpi.render(doc)
    # Re-parse
    with tempfile.NamedTemporaryFile("w", suffix=".ini", delete=False,
                                     encoding="utf-8") as f:
        f.write(rendered)
        tmp = Path(f.name)
    try:
        doc2 = cpi.parse(tmp)
        if cpi.has_key(doc2, target_s, target_k):
            return False, "key survived deletion"
    finally:
        tmp.unlink()
    return True, f"deleted [{target_s}] {target_k}"


# ---------------------------------------------------------------------------

def main():
    toolkit = Path("/mnt/user-data/outputs/migration_toolkit")
    targets = sorted(toolkit.rglob("*.ini"))
    # Exclude generated outputs
    targets = [
        t for t in targets
        if "/output/" not in str(t)
        and "/dry_run/" not in str(t)
    ]

    print(f"Testing comment_preserving_ini against {len(targets)} INI files\n")
    print(f"{'FILE':<60} {'IDENTITY':<10} {'MUTATE':<10} {'APPEND':<10} "
          f"{'ADDSECT':<10} {'DELKEY':<10}")
    print("-" * 110)

    fail = 0
    for path in targets:
        rel = path.relative_to(toolkit)
        results = {}
        for name, fn in [
            ("identity", test_identity),
            ("mutate", test_mutation),
            ("append", test_append_key),
            ("addsect", test_add_section),
            ("delkey", test_delete_key),
        ]:
            try:
                ok, msg = fn(path)
                results[name] = (ok, msg)
                if not ok:
                    fail += 1
            except Exception as e:
                results[name] = (False, f"EXC: {e}")
                fail += 1

        flags = "  ".join(
            ("✓" if results[k][0] else "✗") + " " * 8
            for k in ("identity", "mutate", "append", "addsect", "delkey")
        )
        print(f"{str(rel):<60} {flags}")

        # Show details for any failures
        for name, (ok, msg) in results.items():
            if not ok:
                print(f"    [{name}] FAIL:")
                for ln in msg.splitlines():
                    print(f"        {ln}")

    print()
    if fail == 0:
        print(f"ALL TESTS PASSED across {len(targets)} INI files")
        return 0
    else:
        print(f"{fail} FAILURES")
        return 1


if __name__ == "__main__":
    sys.exit(main())
