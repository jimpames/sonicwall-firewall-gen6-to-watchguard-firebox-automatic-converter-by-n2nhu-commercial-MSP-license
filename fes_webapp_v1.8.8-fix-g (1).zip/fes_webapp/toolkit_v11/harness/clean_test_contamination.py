#!/usr/bin/env python3
"""
clean_test_contamination.py
============================

One-time cleanup for stale test fixtures left in
wg_validator/wg_xml_schema.ini and concept_map/concept_map.ini
when prior test runs aborted between apply and rollback.

Detection rules (a section is contamination if EITHER applies):

  1. Surface tag matches a known test-fixture pattern:
     - element.test-merge-engine-element-*
     - element.cite-test-element-*
     - element.audit-check-element-*
     - element.harness-test-*
     - element.test-audit-* (Phase 4 fixtures)
     - element.test-stale-* (Phase 5 fixtures)
     - element.test-claim-*, element.test-deprecation-*, etc.

  2. The section's `declared_by` field is a test-identity marker:
     - declared_by = test-suite
     - declared_by = audit-test
     - declared_by = harness-test
     - declared_by = audit-check
     The toolkit's convention is that real entries carry team-roster
     names. Test fixtures use these reserved markers. Forward-compatible:
     any future test that uses --operator test-suite gets caught even
     if it picks a new surface tag.

Usage:
  python clean_test_contamination.py              # dry-run
  python clean_test_contamination.py --confirm    # actually do it
  python clean_test_contamination.py --verbose    # detailed output
"""
from __future__ import annotations

import argparse
import datetime as _dt
import re
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent if __file__ else Path.cwd()


# Rule 1: known test-fixture surface tag patterns
TEST_FIXTURE_PATTERNS = [
    re.compile(r"^element\.test-merge-engine-element-.*$"),
    re.compile(r"^element\.cite-test-element-.*$"),
    re.compile(r"^element\.audit-check-element-.*$"),
    re.compile(r"^element\.harness-test-.*$"),
    re.compile(r"^element\.test-audit-.*$"),
    re.compile(r"^element\.test-stale-.*$"),
    re.compile(r"^element\.test-claim-.*$"),
    re.compile(r"^element\.test-deprecation-.*$"),
    re.compile(r"^element\.test-lab-artifact-.*$"),
    re.compile(r"^element\.test-roster-.*$"),
    re.compile(r"^element\.test-dis-.*$"),
    re.compile(r"^element\.test-lock-.*$"),
    re.compile(r"^element\.test-list-.*$"),
    re.compile(r"^element\.test-force-.*$"),
]

# Rule 2: declared_by values that mark a section as test fixture
TEST_DECLARED_BY = {
    "test-suite",
    "audit-test",
    "harness-test",
    "audit-check",
    "test-claim",
    "test-roster",
    "test-deprecation",
}


def _section_matches_pattern(section: str) -> bool:
    for pattern in TEST_FIXTURE_PATTERNS:
        if pattern.match(section):
            return True
    return False


def _is_test_declared_by(value: str) -> bool:
    return value.strip() in TEST_DECLARED_BY


def find_contamination_sections(
    file_path: Path,
) -> list[tuple[int, str, str]]:
    """Linear scan that walks the file once, tracking section context
    and declared_by per section. Returns (line_no, section, reason)."""
    if not file_path.is_file():
        return []
    
    found: list[tuple[int, str, str]] = []
    current_section: str | None = None
    current_section_line: int = 0
    current_declared_by: str | None = None
    
    def _flush_pending():
        if current_section is None:
            return
        if _section_matches_pattern(current_section):
            found.append((current_section_line, current_section,
                         "tag-pattern"))
            return
        if (current_declared_by is not None
                and _is_test_declared_by(current_declared_by)):
            found.append((current_section_line, current_section,
                         f"declared_by={current_declared_by}"))
    
    with file_path.open("r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, start=1):
            stripped = line.strip()
            is_section_header = (
                stripped.startswith("[") and stripped.endswith("]")
            )
            if is_section_header:
                _flush_pending()
                current_section = stripped[1:-1]
                current_section_line = lineno
                current_declared_by = None
                continue
            if current_section is not None and "=" in stripped:
                key, _, value = stripped.partition("=")
                if key.strip() == "declared_by":
                    current_declared_by = value.strip()
        _flush_pending()
    
    return found


def remove_sections_from_ini(
    file_path: Path,
    target_lines: set[int],
) -> tuple[int, int]:
    """Remove sections whose header is at one of target_lines. Linear
    scan keeps everything else byte-for-byte. Returns (sects, lines)."""
    if not file_path.is_file():
        return (0, 0)
    
    output_lines: list[str] = []
    skip_until_next_section = False
    sections_removed = 0
    lines_removed = 0
    
    with file_path.open("r", encoding="utf-8") as f:
        for lineno, line in enumerate(f, start=1):
            stripped = line.strip()
            is_section_header = (
                stripped.startswith("[") and stripped.endswith("]")
            )
            if is_section_header:
                if lineno in target_lines:
                    skip_until_next_section = True
                    sections_removed += 1
                    lines_removed += 1
                    continue
                else:
                    skip_until_next_section = False
                    output_lines.append(line)
                    continue
            if skip_until_next_section:
                lines_removed += 1
                continue
            output_lines.append(line)

    file_path.write_text("".join(output_lines), encoding="utf-8")
    return (sections_removed, lines_removed)


def backup_file(file_path: Path) -> Path:
    ts = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = file_path.with_suffix(
        file_path.suffix + f".contamination-backup-{ts}")
    backup.write_bytes(file_path.read_bytes())
    return backup


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--confirm", action="store_true",
        help="Actually remove sections (default: dry-run only)")
    ap.add_argument("--verbose", "-v", action="store_true",
        help="Show every contamination occurrence with detection rule")
    args = ap.parse_args()

    targets = [
        ROOT / "wg_validator" / "wg_xml_schema.ini",
        ROOT / "concept_map" / "concept_map.ini",
    ]
    
    print(f"Scanning for test-fixture contamination...")
    print(f"  Toolkit root: {ROOT}")
    print()

    cleanup_plan: list[tuple[Path,
                              list[tuple[int, str, str]]]] = []

    for target in targets:
        rel = target.relative_to(ROOT)
        print(f"  {rel}:")
        if not target.is_file():
            print(f"    (file not found — skipping)")
            continue
        contamination = find_contamination_sections(target)
        if not contamination:
            print(f"    ✓ clean")
            continue
        # Group by section name for compact output
        section_counts = Counter(s for _, s, _ in contamination)
        reason_counts = Counter(r for _, _, r in contamination)
        print(f"    ⚠ {len(contamination)} contamination section(s) "
              f"({len(section_counts)} unique tag(s)):")
        for section, count in section_counts.most_common():
            print(f"        {count:>3} × [{section}]")
        if args.verbose:
            print(f"    Detection-rule breakdown:")
            for reason, count in reason_counts.most_common():
                print(f"        {count:>3} via {reason}")
            print(f"    First several line numbers:")
            for lineno, section, reason in contamination[:8]:
                print(f"        line {lineno:>5}: [{section}] "
                      f"({reason})")
        cleanup_plan.append((target, contamination))

    print()
    total_found = sum(len(c) for _, c in cleanup_plan)
    if total_found == 0:
        print(f"✓ No contamination found. Nothing to do.")
        return 0

    print(f"Total: {total_found} stale test-fixture section(s) "
          f"across {len(cleanup_plan)} file(s)")
    print()

    if not args.confirm:
        print(f"This was a DRY RUN. To actually clean up, re-run with:")
        print(f"  python {Path(__file__).name} --confirm")
        if not args.verbose:
            print(f"")
            print(f"Tip: pass --verbose to see detection-rule breakdown.")
        return 0

    print(f"Backing up and cleaning...")
    for target, contamination in cleanup_plan:
        backup = backup_file(target)
        rel = target.relative_to(ROOT)
        print(f"  {rel}:")
        print(f"    backup: {backup.name}")
        target_lines = {lineno for lineno, _, _ in contamination}
        removed, lines = remove_sections_from_ini(target, target_lines)
        print(f"    removed {removed} section(s), {lines} line(s)")

    print()
    print(f"✓ Cleanup complete. If anything looks wrong, the backups can")
    print(f"  be renamed back to restore the prior state.")
    print()
    print(f"Recommended next steps:")
    print(f"  1. Re-run schema_learner to confirm clean startup")
    print(f"  2. python -u harness\\run_all.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
