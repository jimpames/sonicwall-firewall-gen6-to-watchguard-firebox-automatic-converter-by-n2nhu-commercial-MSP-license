#!/usr/bin/env python3
"""
run_all.py
==========

Run every test harness in this directory and aggregate the results.
Exit code is 0 only if all suites pass.

Designed to be a CI hook: drop into a pre-push hook or CI job and
it will catch regressions in the writer, the schemas, the GUI save
path, or the engine validation wiring.

Usage:
    python3 harness/run_all.py
    python3 harness/run_all.py --quick   # skip the engine wiring suite
                                          # (which takes ~30s due to
                                          # subprocess fork-and-exec)
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent

# (test script, fast or slow, description)
SUITES = [
    ("test_comment_preserving_ini.py", "fast",
        "Round-trip writer: identity, mutate, append, addsect, delkey "
        "across all toolkit INIs"),
    ("test_comment_preserving_multiline.py", "fast",
        "Multi-line value handling: blank lines, indented # comments, "
        "delete+re-add section semantics"),
    ("test_gui_save_roundtrip.py",     "fast",
        "GUI save simulation: load->save byte-identical + comment count "
        "preserved on mutation"),
    ("test_engine_validation_wiring.py", "slow",
        "Each engine's --strict / --no-validate / clean-run wiring "
        "(forks subprocesses)"),
    ("test_wg_validator.py",           "fast",
        "WatchGuard XML validator: schema loads, reference validates "
        "cleanly, injected corruption is caught"),
    ("test_schema_learner_provenance.py", "fast",
        "Provenance audit (Test #9): scan engine output for unsourced "
        "claims and answer-suggesting phrases. Polices the founding "
        "principle 'no claim without provenance'."),
    ("test_merge_engine.py", "moderate",
        "Schema-learner merge engine (Step 4): validate, dry-run, apply, "
        "rollback against synthetic proposals. Verifies the engine "
        "refuses unfilled proposals, refuses missing citations, requires "
        "--confirm flag, writes citations inline, and rollback restores "
        "byte-identical state."),
    ("test_auto_reuse.py", "moderate",
        "Phase 1 — Approved-corpus auto-reuse: verifies the team-scale "
        "value proposition. After a surface is classified once, "
        "subsequent runs detect the structural similarity and skip "
        "the intervention-required path. Foundational mechanism for "
        "compounding Jim-work across the team."),
    ("test_triage.py", "moderate",
        "Phase 2 — Triage frontend + corpus tiers: verifies the "
        "(c)/(e)/(h)/(s) taxonomy. Banned-corpus suppression, sideline "
        "queue with occurrence bumping, SLA tier computation, appeal "
        "lifecycle (active → held → unbanned), and provenance audit "
        "across both new corpus tiers."),
    ("test_phase3_llm.py", "moderate",
        "Phase 3 — LLM drafting + citation verification: verifies the "
        "research-assistant pattern using deterministic StubProvider. "
        "The principle binding: no high confidence without web_fetch-"
        "verified citations. Worst-of-four aggregation, self-"
        "validation penalty, draft serialization, MCP factory gating."),
    ("test_phase4_deep_research.py", "moderate",
        "Phase 4 — Senior-engineer deep-research workflow + lab "
        "verification + deprecation registry. Decision #7 mandatory "
        "lab verification enforced in code. Two-citation rule per "
        "claim. Peer review captured. Decision #5 quarterly "
        "deprecation sweep + propagation. Decision #4 SLA aging "
        "visibility (Tier 2/3 overdue detection)."),
    ("test_phase5_team_coordination.py", "moderate",
        "Phase 5 — Multi-engineer coordination: operator roster "
        "(Decision #3 senior-only), append-only audit log, "
        "timeout-based locks with idempotent re-acquire, "
        "disagreement flag lifecycle (file → claim → resolve). "
        "The team-scale value proposition is now safe for "
        "parallel work across multiple engineers."),
    ("test_phase6_tier_filtering.py", "moderate",
        "Phase 6 — Tier filtering by enabled-status. Engine "
        "computes enabled/disabled/unknown per finding from XML "
        "alone (no HTML required). Operator runs triage walk --tier 1 "
        "to focus on critical-path surfaces; --auto-sideline-deferred "
        "routes disabled findings to the sideline queue with reason "
        "'deferred_disabled_in_source'. On TEMPLATE_FW.xml: 58 of 166 "
        "findings auto-skippable (35% workload reduction)."),
    ("test_phase6_5_auto_promotion.py", "moderate",
        "Phase 6.5 — Auto-promotion of deferred surfaces. When a "
        "future customer config arrives with a previously-deferred "
        "surface now enabled (or in unknown state), the engine emits "
        "category 'auto_promoted_from_deferred' and transitions the "
        "sideline entry from 'deferred_disabled_in_source' to "
        "'pending_triage'. Idempotent (no re-promotion). Operator-"
        "driven sideline entries (status=open) explicitly excluded. "
        "Closes the Phase 6 lifecycle loop."),
    ("test_phase7_relevance_filter.py", "moderate",
        "Phase 7 — SonicWall input-side relevance filter. Classifies "
        "every parsed entry as vendor_builtin / customer_defined / "
        "dead_unreferenced / disabled_in_source using an operator-"
        "curated builtin_objects.ini registry. On a factory-default "
        "NSA3600: 94.7% of entries are vendor_builtin → translator "
        "skips them. Produces migration_scope.md operator report. "
        "Phase 6 philosophy applied to source side: why translate "
        "stuff that's a vendor built-in or unreferenced?"),
    ("test_phase8_skeleton_fixes.py", "fast",
        "Phase 8 — Skeleton fixes from independent operator review. "
        "Four findings caught when the toolkit was handed to a friend "
        "in India during Memorial Day staycation. Fix A: device "
        "invariants (version stanza) get __OPERATOR_REPLACE__ "
        "sentinels by default; CLI flags inject explicit values. "
        "Fix B: self-closing tags render as <tag/> not <tag /> "
        "(matches jpa.xml convention). Fix C: "
        "gateway-wireless-controller scaffolding preserved verbatim, "
        "revision-history fresh-stamped with toolkit module-id. "
        "Fix D: wg_validator refuses to bless any XML still carrying "
        "operator sentinels."),
]


def run_suite(script: str) -> tuple[bool, float, str]:
    """Run one suite. Return (passed, elapsed_seconds, last_lines_of_output)."""
    t0 = time.monotonic()
    r = subprocess.run(
        [sys.executable, str(HERE / script)],
        capture_output=True, text=True, timeout=600,
    )
    elapsed = time.monotonic() - t0
    # The summary line is always at the tail of each suite's output
    tail = "\n".join(r.stdout.strip().splitlines()[-3:])
    return r.returncode == 0, elapsed, tail


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--quick", action="store_true",
                    help="Skip slow suites (subprocess-heavy ones)")
    ap.add_argument("--verbose", "-v", action="store_true",
                    help="Show full output of each suite")
    args = ap.parse_args()

    suites = [s for s in SUITES if not args.quick or s[1] == "fast"]
    print(f"Running {len(suites)} suite(s) from {HERE}\n")

    results: list[tuple[str, bool, float]] = []
    for script, _, desc in suites:
        print(f">>> {script}")
        print(f"    {desc}")
        ok, elapsed, tail = run_suite(script)
        flag = "PASS" if ok else "FAIL"
        print(f"    [{flag}]  ({elapsed:.1f}s)")
        if args.verbose or not ok:
            for ln in tail.splitlines():
                print(f"      {ln}")
        print()
        results.append((script, ok, elapsed))

    print("=" * 70)
    n_pass = sum(1 for _, ok, _ in results if ok)
    n_fail = len(results) - n_pass
    total_time = sum(t for _, _, t in results)
    print(f"  {n_pass} passed, {n_fail} failed, "
          f"{total_time:.1f}s total wall time")
    print("=" * 70)
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
