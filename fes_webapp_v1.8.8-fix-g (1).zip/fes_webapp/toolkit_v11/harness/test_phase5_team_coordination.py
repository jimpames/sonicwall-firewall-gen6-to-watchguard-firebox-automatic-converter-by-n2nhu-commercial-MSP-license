#!/usr/bin/env python3
"""
test_phase5_team_coordination.py
=================================

Phase 5 regression tests for multi-engineer coordination per
DESIGN_team_scale_addendum.md.

Tests cover four primitives:
  - Operator roster (Decision #3: senior-only, no role split)
  - Audit log (append-only, monthly rotation)
  - Locks (timeout-based, idempotent re-acquire)
  - Disagreement flags (filed → claimed → resolved lifecycle)

State is snapshotted and restored per test to keep tests isolated.
The audit log specifically is tested for append-only behavior —
existing entries must never be modified by new writes.
"""
from __future__ import annotations

import datetime as _dt
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "schema_learner"))

from team_coordination import (  # noqa: E402
    AuditEntry, DisagreementFlag, LockInfo, TeamMember,
    _audit_root, _current_audit_log_path,
    _disagreements_index_path, _disagreements_root,
    _engineers_ini_path, _locks_root,
    acquire_lock, claim_disagreement,
    file_disagreement_flag, force_release_lock,
    is_authenticated_operator, list_active_locks,
    load_audit_log, load_disagreement_flags,
    load_team_roster, log_action, release_lock,
    remove_team_member, require_authenticated_operator,
    resolve_disagreement, write_audit_entry, write_team_member,
)


# ---------------------------------------------------------------------------
# Snapshot/restore (Phase 5 directories)
# ---------------------------------------------------------------------------

def _snapshot_phase5_state() -> dict[str, bytes | None]:
    snap: dict[str, bytes | None] = {}
    paths_to_track: list[Path] = []
    # Engineers roster
    p = _engineers_ini_path()
    paths_to_track.append(p)
    # Audit log directory contents
    if _audit_root().is_dir():
        for f in _audit_root().iterdir():
            if f.is_file():
                paths_to_track.append(f)
    # Locks directory contents
    if _locks_root().is_dir():
        for f in _locks_root().iterdir():
            if f.is_file():
                paths_to_track.append(f)
    # Disagreements directory contents
    if _disagreements_root().is_dir():
        for f in _disagreements_root().iterdir():
            if f.is_file():
                paths_to_track.append(f)
    for p in paths_to_track:
        snap[str(p)] = p.read_bytes() if p.is_file() else None
    return snap


def _restore_phase5_state(snap: dict[str, bytes | None]) -> None:
    # Remove anything added since snapshot
    for d in (_audit_root(), _locks_root(), _disagreements_root()):
        if d.is_dir():
            for f in list(d.iterdir()):
                if f.is_file() and str(f) not in snap:
                    f.unlink()
    # Restore snapshot contents
    for path_str, contents in snap.items():
        p = Path(path_str)
        if contents is None:
            if p.is_file():
                p.unlink()
        else:
            p.write_bytes(contents)


# ---------------------------------------------------------------------------
# Roster tests
# ---------------------------------------------------------------------------

def test_roster_round_trip() -> tuple[bool, str]:
    """Add → load → remove a team member."""
    snap = _snapshot_phase5_state()
    try:
        unique_name = f"test-roster-{uuid.uuid4().hex[:8]}"
        member = TeamMember(
            name=unique_name,
            email=f"{unique_name}@example.com",
            added_at="2026-05-07T10:00:00",
            added_by="bootstrap-tester",
            notes="test fixture",
        )
        write_team_member(member)
        roster = load_team_roster()
        if unique_name not in roster:
            return False, "added member not found in roster"
        loaded = roster[unique_name]
        if loaded.email != member.email:
            return False, "email not preserved"
        # Remove
        ok = remove_team_member(unique_name)
        if not ok:
            return False, "remove returned False"
        roster_after = load_team_roster()
        if unique_name in roster_after:
            return False, "member still present after remove"
        return True, "team roster round-trips through write/load/remove"
    finally:
        _restore_phase5_state(snap)


def test_authentication_bootstrap_mode() -> tuple[bool, str]:
    """When roster is empty: allow_bootstrap=True accepts; False refuses."""
    snap = _snapshot_phase5_state()
    try:
        # Ensure roster is empty
        if _engineers_ini_path().is_file():
            _engineers_ini_path().unlink()

        # Bootstrap mode: any name OK
        if not is_authenticated_operator("anyone", allow_bootstrap=True):
            return False, "bootstrap mode should accept any non-empty name"
        # Empty name still rejected even in bootstrap
        if is_authenticated_operator("", allow_bootstrap=True):
            return False, "empty name should never authenticate"
        # Strict mode on empty roster: rejects everyone
        if is_authenticated_operator("anyone", allow_bootstrap=False):
            return False, "strict-mode empty roster should refuse"
        return True, "bootstrap toggle works correctly"
    finally:
        _restore_phase5_state(snap)


def test_authentication_with_populated_roster() -> tuple[bool, str]:
    """Once roster has members, only listed names authenticate
    (regardless of allow_bootstrap)."""
    snap = _snapshot_phase5_state()
    try:
        # Add one member
        write_team_member(TeamMember(
            name="alice", email="a@x", added_at="2026-05-07",
            added_by="self-bootstrap",
        ))
        # alice authenticates
        if not is_authenticated_operator("alice", allow_bootstrap=True):
            return False, "listed member should authenticate"
        if not is_authenticated_operator("alice", allow_bootstrap=False):
            return False, "listed member must authenticate strict-mode"
        # Non-member is refused — bootstrap allowance ends once roster
        # has any member
        if is_authenticated_operator("eve", allow_bootstrap=True):
            return False, ("non-roster name authenticated against "
                           "non-empty roster — bootstrap allowance "
                           "must end once first member added")
        return True, "populated-roster authentication enforced"
    finally:
        _restore_phase5_state(snap)


def test_require_authenticated_operator_messages() -> tuple[bool, str]:
    """require_authenticated_operator returns useful (ok, message) pairs."""
    snap = _snapshot_phase5_state()
    try:
        # Empty operator
        ok, msg = require_authenticated_operator("")
        if ok or "empty" not in msg.lower():
            return False, f"empty operator should fail with 'empty' message: {msg}"
        # Bootstrap empty roster, non-empty name → ok
        if _engineers_ini_path().is_file():
            _engineers_ini_path().unlink()
        ok, msg = require_authenticated_operator("alice")
        if not ok:
            return False, f"bootstrap should succeed: {msg}"
        # Populate roster, alice now authenticates
        write_team_member(TeamMember(
            name="alice", added_at="2026-05-07", added_by="boot",
        ))
        ok, msg = require_authenticated_operator("alice")
        if not ok:
            return False, f"alice should authenticate: {msg}"
        # eve does not
        ok, msg = require_authenticated_operator("eve")
        if ok:
            return False, "eve should not authenticate"
        if "not in team roster" not in msg:
            return False, f"unhelpful denial message: {msg}"
        return True, "require_authenticated_operator returns useful messages"
    finally:
        _restore_phase5_state(snap)


# ---------------------------------------------------------------------------
# Audit log tests
# ---------------------------------------------------------------------------

def test_audit_log_round_trip() -> tuple[bool, str]:
    """Write entries, read them back, verify all fields."""
    snap = _snapshot_phase5_state()
    try:
        # Write three
        ids = []
        for i in range(3):
            entry = log_action(
                operator=f"user-{i}",
                action_type=f"test_action_{i}",
                target=f"target_{i}",
                source_proposal=f"proposal_{i}",
                detail=f"test detail {i}",
            )
            ids.append(entry.action_id)
        # Read back current month
        loaded = load_audit_log()
        if len(loaded) < 3:
            return False, f"expected at least 3 entries, got {len(loaded)}"
        # All three IDs must be present
        loaded_ids = {e.action_id for e in loaded}
        for aid in ids:
            if aid not in loaded_ids:
                return False, f"audit ID {aid} not loaded back"
        return True, f"audit log round-trips {len(ids)} entries"
    finally:
        _restore_phase5_state(snap)


def test_audit_log_append_only() -> tuple[bool, str]:
    """Existing entries must NOT be modified by new writes."""
    snap = _snapshot_phase5_state()
    try:
        first = log_action(operator="alice", action_type="first",
                           target="t1", detail="first detail")
        # Read raw bytes to get the exact section block for `first`
        raw_after_first = _current_audit_log_path().read_bytes()
        # Write second
        second = log_action(operator="bob", action_type="second",
                            target="t2", detail="second detail")
        raw_after_second = _current_audit_log_path().read_bytes()
        # The first's bytes must be a prefix-substring of the second's
        # (i.e. nothing was rewritten — only appended).
        if not raw_after_second.startswith(raw_after_first):
            return False, ("audit log was REWRITTEN, not appended — "
                           "this is a critical correctness bug")
        return True, "audit log is append-only (existing bytes preserved)"
    finally:
        _restore_phase5_state(snap)


# ---------------------------------------------------------------------------
# Lock tests
# ---------------------------------------------------------------------------

def test_lock_acquire_and_release() -> tuple[bool, str]:
    """Basic acquire → contention → release flow."""
    snap = _snapshot_phase5_state()
    try:
        surface = f"test-lock-{uuid.uuid4().hex[:8]}"
        proposal = "test_proposal"
        # alice acquires
        ok, msg, info = acquire_lock(surface, proposal, "alice")
        if not ok:
            return False, f"alice should have acquired: {msg}"
        # alice re-acquires (idempotent)
        ok, msg, info = acquire_lock(surface, proposal, "alice")
        if not ok:
            return False, f"alice should re-acquire idempotently: {msg}"
        # bob refused
        ok, msg, info = acquire_lock(surface, proposal, "bob")
        if ok:
            return False, "bob should be refused while alice holds"
        if "alice" not in msg:
            return False, f"refusal should mention holder: {msg}"
        # alice releases
        ok, msg = release_lock(surface, proposal, "alice")
        if not ok:
            return False, f"alice should release her own lock: {msg}"
        # bob now succeeds
        ok, msg, info = acquire_lock(surface, proposal, "bob")
        if not ok:
            return False, f"bob should acquire after alice released: {msg}"
        # cleanup
        release_lock(surface, proposal, "bob")
        return True, "lock acquire / contention / release flow correct"
    finally:
        _restore_phase5_state(snap)


def test_lock_expiration_reclaims() -> tuple[bool, str]:
    """A stale lock is auto-reclaimed by a new acquirer."""
    snap = _snapshot_phase5_state()
    try:
        surface = f"test-stale-{uuid.uuid4().hex[:8]}"
        proposal = "test_proposal"
        # alice acquires, but use timeout=0.0 so the lock is immediately stale
        # (we test by setting a very-old acquired_at via direct write)
        ok, msg, info = acquire_lock(surface, proposal, "alice",
                                     timeout_hours=1)
        if not ok:
            return False, "initial acquire failed"
        # Forge a stale acquired_at
        from team_coordination import _read_lock, _write_lock
        existing = _read_lock(surface, proposal)
        if existing is None:
            return False, "lock should exist"
        existing.acquired_at = (
            _dt.datetime.now() - _dt.timedelta(hours=24)
        ).isoformat()
        _write_lock(existing)
        # bob now acquires — should auto-reclaim
        ok, msg, info = acquire_lock(surface, proposal, "bob",
                                     timeout_hours=1)
        if not ok:
            return False, f"bob should reclaim stale lock: {msg}"
        if "reclaimed" not in msg.lower():
            return False, f"reclaim message expected: {msg}"
        # Lock now held by bob
        existing = _read_lock(surface, proposal)
        if existing.held_by != "bob":
            return False, f"lock not transferred: held_by={existing.held_by}"
        # cleanup
        release_lock(surface, proposal, "bob")
        return True, "stale locks auto-reclaim with audit message"
    finally:
        _restore_phase5_state(snap)


def test_lock_force_release() -> tuple[bool, str]:
    """force_release_lock breaks any lock and reports prior holder."""
    snap = _snapshot_phase5_state()
    try:
        surface = f"test-force-{uuid.uuid4().hex[:8]}"
        proposal = "test_proposal"
        acquire_lock(surface, proposal, "alice")
        ok, msg, prior = force_release_lock(surface, proposal, "admin")
        if not ok:
            return False, f"force_release failed: {msg}"
        if prior != "alice":
            return False, f"prior_holder wrong: {prior}"
        # Alice no longer holds
        ok, msg, info = acquire_lock(surface, proposal, "bob")
        if not ok:
            return False, "bob should now acquire freely"
        release_lock(surface, proposal, "bob")
        return True, "force_release breaks lock and returns prior holder"
    finally:
        _restore_phase5_state(snap)


def test_lock_listing() -> tuple[bool, str]:
    """list_active_locks returns currently-active locks only."""
    snap = _snapshot_phase5_state()
    try:
        s1 = f"test-list-1-{uuid.uuid4().hex[:6]}"
        s2 = f"test-list-2-{uuid.uuid4().hex[:6]}"
        acquire_lock(s1, "p1", "alice")
        acquire_lock(s2, "p2", "bob")
        locks = list_active_locks()
        held_surfaces = {l.surface_tag for l in locks}
        if s1 not in held_surfaces or s2 not in held_surfaces:
            return False, f"locks not listed: {held_surfaces}"
        # Cleanup
        release_lock(s1, "p1", "alice")
        release_lock(s2, "p2", "bob")
        return True, f"list_active_locks returns {len(locks)} locks"
    finally:
        _restore_phase5_state(snap)


# ---------------------------------------------------------------------------
# Disagreement tests
# ---------------------------------------------------------------------------

def test_disagreement_lifecycle_keep() -> tuple[bool, str]:
    """File → claim → resolve_keep lifecycle."""
    snap = _snapshot_phase5_state()
    try:
        unique = f"test-dis-keep-{uuid.uuid4().hex[:8]}"
        flag = file_disagreement_flag(
            unique, "alice",
            "I think this prior classification was wrong because reasons.")
        if flag.status != "open":
            return False, f"new flag should be open, got {flag.status}"
        # Claim
        ok, msg = claim_disagreement(flag.flag_id, "reviewer-bob")
        if not ok:
            return False, f"claim failed: {msg}"
        # Resolve keep
        ok, msg = resolve_disagreement(
            flag.flag_id, "reviewer-bob", "keep",
            "I reviewed the original classification and confirm it stands.")
        if not ok:
            return False, f"resolve failed: {msg}"
        # Verify status
        flags = load_disagreement_flags()
        loaded = next((f for f in flags
                       if f.flag_id == flag.flag_id), None)
        if loaded is None:
            return False, "flag vanished after resolve"
        if loaded.status != "resolved_keep":
            return False, f"status is {loaded.status}, expected resolved_keep"
        if loaded.reviewer != "reviewer-bob":
            return False, f"reviewer wrong: {loaded.reviewer}"
        return True, "file → claim → resolve_keep lifecycle works"
    finally:
        _restore_phase5_state(snap)


def test_disagreement_resolve_validates_inputs() -> tuple[bool, str]:
    """resolve_disagreement refuses bad resolution and short notes."""
    snap = _snapshot_phase5_state()
    try:
        unique = f"test-dis-validate-{uuid.uuid4().hex[:8]}"
        flag = file_disagreement_flag(
            unique, "alice",
            "Substantive reason for filing the disagreement.")
        # Bad resolution string
        ok, msg = resolve_disagreement(flag.flag_id, "rev",
                                        "wrong-action",
                                        "long enough notes 12345")
        if ok:
            return False, "resolve should refuse bad action"
        # Too-short notes
        ok, msg = resolve_disagreement(flag.flag_id, "rev",
                                        "keep", "tooshort")
        if ok:
            return False, "resolve should refuse short notes"
        return True, "resolve validates resolution string and notes length"
    finally:
        _restore_phase5_state(snap)


def test_disagreement_claim_only_on_open() -> tuple[bool, str]:
    """claim_disagreement refuses entries that aren't 'open'."""
    snap = _snapshot_phase5_state()
    try:
        unique = f"test-dis-claim-{uuid.uuid4().hex[:8]}"
        flag = file_disagreement_flag(
            unique, "alice",
            "Substantive reason for filing the disagreement.")
        # First claim succeeds
        ok, msg = claim_disagreement(flag.flag_id, "rev1")
        if not ok:
            return False, f"first claim failed: {msg}"
        # Second claim should refuse (status is in_review)
        ok, msg = claim_disagreement(flag.flag_id, "rev2")
        if ok:
            return False, "double-claim should refuse"
        return True, "double-claim refused after status changes"
    finally:
        _restore_phase5_state(snap)


# ---------------------------------------------------------------------------
# CLI smoke tests
# ---------------------------------------------------------------------------

def test_phase5_cli_smoke() -> tuple[bool, str]:
    """All Phase 5 CLI subcommands respond to --help."""
    triage = ROOT / 'schema_learner' / 'triage.py'
    cmds = [
        ['team', 'list', '--help'],
        ['team', 'add', '--help'],
        ['team', 'remove', '--help'],
        ['audit', 'list', '--help'],
        ['disagreement', 'file', '--help'],
        ['disagreement', 'list', '--help'],
        ['disagreement', 'claim', '--help'],
        ['disagreement', 'resolve', '--help'],
        ['lock', 'list', '--help'],
        ['lock', 'break', '--help'],
    ]
    for cmd in cmds:
        r = subprocess.run([sys.executable, str(triage)] + cmd,
                           capture_output=True, text=True)
        if r.returncode != 0:
            return False, f"CLI failed: {' '.join(cmd)}: {r.stderr[:200]}"
    return True, f"all {len(cmds)} Phase 5 CLI subcommands respond"


def test_phase5_provenance_audit_clean() -> tuple[bool, str]:
    """Provenance audit must pass on Phase 5 artifacts."""
    snap = _snapshot_phase5_state()
    try:
        # Synthesize representative Phase 5 artifacts
        unique = f"test-audit-{uuid.uuid4().hex[:8]}"
        # Roster member
        write_team_member(TeamMember(
            name=unique, email="x", added_at="2026-05-07",
            added_by="audit-test",
        ))
        # Audit entry
        log_action(operator=unique, action_type="audit_test_action",
                   target="x", detail="audit fixture")
        # Disagreement
        file_disagreement_flag(unique, unique,
            "Substantive reason for the audit-test fixture flag.")

        audit = subprocess.run(
            [sys.executable,
             str(ROOT / 'harness'
                 / 'test_schema_learner_provenance.py')],
            capture_output=True, text=True,
        )
        if audit.returncode != 0:
            return False, ("provenance audit FAILED on Phase 5 output: "
                           f"{audit.stdout[:500]}")
        return True, "provenance audit clean on Phase 5 artifacts"
    finally:
        _restore_phase5_state(snap)


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

TESTS = [
    ("roster_round_trip", test_roster_round_trip),
    ("authentication_bootstrap_mode", test_authentication_bootstrap_mode),
    ("authentication_with_populated_roster",
     test_authentication_with_populated_roster),
    ("require_authenticated_operator_messages",
     test_require_authenticated_operator_messages),
    ("audit_log_round_trip", test_audit_log_round_trip),
    ("audit_log_append_only", test_audit_log_append_only),
    ("lock_acquire_and_release", test_lock_acquire_and_release),
    ("lock_expiration_reclaims", test_lock_expiration_reclaims),
    ("lock_force_release", test_lock_force_release),
    ("lock_listing", test_lock_listing),
    ("disagreement_lifecycle_keep", test_disagreement_lifecycle_keep),
    ("disagreement_resolve_validates_inputs",
     test_disagreement_resolve_validates_inputs),
    ("disagreement_claim_only_on_open",
     test_disagreement_claim_only_on_open),
    ("phase5_cli_smoke", test_phase5_cli_smoke),
    ("phase5_provenance_audit_clean",
     test_phase5_provenance_audit_clean),
]


def main() -> int:
    print("Phase 5 — Multi-engineer coordination tests")
    print()
    print(f"{'TEST':<55} {'RESULT':<8} DETAIL")
    print("-" * 95)
    fail = 0
    for name, fn in TESTS:
        try:
            ok, msg = fn()
        except Exception as e:
            ok, msg = False, f"EXC: {type(e).__name__}: {e}"
        status = "PASS" if ok else "FAIL"
        print(f"{name:<55} {status:<8} {msg[:140]}")
        if not ok:
            fail += 1
    print()
    if fail == 0:
        print(f"All {len(TESTS)} Phase 5 tests passed.")
        return 0
    print(f"{fail} of {len(TESTS)} Phase 5 tests FAILED.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
