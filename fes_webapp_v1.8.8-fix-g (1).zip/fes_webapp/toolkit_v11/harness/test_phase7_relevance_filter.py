#!/usr/bin/env python3
"""
test_phase7_relevance_filter.py
================================

Phase 7 regression tests for the SonicWall input-side relevance filter.

Verifies:
  - Builtin registry loads cleanly with [services], [service_groups],
    [zones], [address_objects], [schedules], [access_rule_patterns]
  - Reference index correctly counts mentions across access-rules,
    NAT, VPN, route, and group sections
  - Per-section classifiers produce the right buckets:
      vendor_builtin, customer_defined, dead_unreferenced,
      disabled_in_source
  - Access-rule classifier requires all-three-conditions for builtin
    (no name + matching comment + service=any)
  - The migration_scope.md report is structurally sound
  - Filtered JSONs preserve original entry data + add classification
    metadata
  - End-to-end: full pipeline against synthesized parser output
    produces correct counts
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "sonicwall_parser"))

from relevance_filter import (  # noqa: E402
    BuiltinRegistry, ClassificationResult, ReferenceIndex,
    build_reference_index, classify_access_rule,
    classify_address_object, classify_all, classify_schedule,
    classify_service_group, classify_service_object,
    classify_zone, load_builtin_registry,
    write_filtered_jsons, write_migration_scope_report,
)


# ---------------------------------------------------------------------------
# Builtin registry loading
# ---------------------------------------------------------------------------

def test_builtin_registry_loads_real_file() -> tuple[bool, str]:
    """The shipped builtin_objects.ini loads without error."""
    path = ROOT / "sonicwall_parser" / "builtin_objects.ini"
    reg = load_builtin_registry(path)
    if len(reg.services) < 50:
        return False, (f"expected >=50 services in registry, got "
                       f"{len(reg.services)}")
    if 'HTTP' not in reg.services:
        return False, "expected HTTP in services"
    if 'LAN' not in reg.zones:
        return False, "expected LAN in zones"
    return True, (f"registry loaded: {len(reg.services)} services, "
                  f"{len(reg.zones)} zones")


def test_builtin_registry_missing_file_raises() -> tuple[bool, str]:
    """Loading a nonexistent registry raises FileNotFoundError with
    helpful message."""
    try:
        load_builtin_registry(Path("/tmp/definitely-does-not-exist.ini"))
    except FileNotFoundError as e:
        if "builtin_objects.ini" not in str(e):
            return False, f"error msg should reference the file: {e}"
        return True, "missing file produces clear error"
    return False, "should have raised FileNotFoundError"


def test_builtin_registry_false_values_excluded() -> tuple[bool, str]:
    """Only entries with value 'true' count as built-in. 'false' or
    other values are excluded."""
    with tempfile.NamedTemporaryFile(
            mode='w', suffix='.ini', delete=False) as f:
        f.write(textwrap.dedent("""
            [meta]
            config_version = 1
            sonicos_version = test
            description = test
            maintained_by = test
            
            [services]
            HTTP = true
            HTTPS = true
            BadService = false
            AnotherBad = no
        """))
        tmp_path = Path(f.name)
    try:
        reg = load_builtin_registry(tmp_path)
        if 'HTTP' not in reg.services:
            return False, "HTTP=true should be included"
        if 'BadService' in reg.services:
            return False, "BadService=false should be excluded"
        if 'AnotherBad' in reg.services:
            return False, "AnotherBad=no should be excluded"
        return True, "false/no values correctly excluded from registry"
    finally:
        tmp_path.unlink()


# ---------------------------------------------------------------------------
# Reference index
# ---------------------------------------------------------------------------

def test_reference_index_counts_mentions() -> tuple[bool, str]:
    """build_reference_index walks parser output and counts mentions
    of object names using SonicWall CLI grammar.
    
    The scanner extracts names via two passes:
      1. Quoted-token extraction (every "..." is a candidate name)
      2. Keyword-then-bareword (after 'name', 'group', 'remote', etc.)
    
    Simple field assignments like 'service: MyService' are NOT picked
    up — the CLI grammar uses 'service name "MyService"' which IS
    picked up.
    """
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        # Synthesize parser output with CLI-grammar-style references.
        # The VPN policy uses 'remote name someremotepeerfake' which
        # the scanner's keyword-then-bareword pass extracts.
        (td / 'vpn_policies.json').write_text(json.dumps({
            'entries': [
                {
                    '_section': 'vpn_policies',
                    '_id': 'tunnel1',
                    'name': 'MyTunnel',
                    'network': [
                        'remote name someremotepeerfake',
                        'local group "LAN Subnets"',
                    ],
                },
            ],
        }), encoding='utf-8')
        # Access rule with quoted service-name reference
        (td / 'access_rules.json').write_text(json.dumps({
            'entries': [
                {
                    '_section': 'access_rules',
                    '_id': 'rule1',
                    'name': 'My Rule',
                    'service': 'service name "MyService"',
                },
                {
                    '_section': 'access_rules',
                    '_id': 'rule2',
                    'name': 'My Rule 2',
                    'service': 'service name "MyService"',
                },
            ],
        }), encoding='utf-8')
        
        idx = build_reference_index(td)
        # 'remote name someremotepeerfake' → 'someremotepeerfake'
        if idx.address_refs.get('someremotepeerfake', 0) < 1:
            return False, (f"someremotepeerfake ref count too low: "
                           f"{idx.address_refs.get('someremotepeerfake', 0)}")
        # 'local group "LAN Subnets"' → 'LAN Subnets'
        if idx.address_refs.get('LAN Subnets', 0) < 1:
            return False, (f"'LAN Subnets' ref count too low: "
                           f"{idx.address_refs.get('LAN Subnets', 0)}")
        # 'service name "MyService"' × 2 → MyService × 2
        if idx.service_refs.get('MyService', 0) < 2:
            return False, (f"MyService ref count too low: "
                           f"{idx.service_refs.get('MyService', 0)}")
        return True, ("reference index correctly extracts CLI-grammar "
                      "name references from parser output")


# ---------------------------------------------------------------------------
# Per-section classifiers
# ---------------------------------------------------------------------------

def _make_registry() -> BuiltinRegistry:
    """Build a small registry for testing."""
    reg = BuiltinRegistry(source_path='test', sonicos_version='test')
    reg.services = {'HTTP', 'HTTPS', 'SSH'}
    reg.service_groups = {'Web Services'}
    reg.zones = {'LAN', 'WAN', 'DMZ'}
    reg.address_objects = {'any'}
    reg.schedules = {'Work Hours', 'After Hours'}
    reg.access_rule_comment_patterns = {
        'IPv4:From Any to Any for Any service',
    }
    return reg


def test_classify_service_builtin() -> tuple[bool, str]:
    """A service in the registry is vendor_builtin."""
    reg = _make_registry()
    refs = ReferenceIndex()
    entry = {'_section': 'service_objects', 'name': 'HTTP',
             'protocol': 'TCP', 'port_low': 80, 'port_high': 80}
    result = classify_service_object(entry, reg, refs)
    if result.bucket != 'vendor_builtin':
        return False, f"got bucket {result.bucket!r}"
    if 'HTTP' not in result.reason:
        return False, f"reason should mention HTTP: {result.reason}"
    return True, "HTTP correctly classified as vendor_builtin"


def test_classify_service_dead_unreferenced() -> tuple[bool, str]:
    """A non-builtin service with zero references is dead."""
    reg = _make_registry()
    refs = ReferenceIndex()
    entry = {'_section': 'service_objects', 'name': 'CustomerSvc1',
             'protocol': 'TCP', 'port_low': 9999, 'port_high': 9999}
    result = classify_service_object(entry, reg, refs)
    if result.bucket != 'dead_unreferenced':
        return False, f"got bucket {result.bucket!r}"
    return True, "unreferenced customer service classified as dead"


def test_classify_service_customer_defined() -> tuple[bool, str]:
    """A non-builtin service with refs is customer-defined."""
    reg = _make_registry()
    refs = ReferenceIndex()
    refs.service_refs['CustomerSvc1'] = 3
    entry = {'_section': 'service_objects', 'name': 'CustomerSvc1',
             'protocol': 'TCP', 'port_low': 9999, 'port_high': 9999}
    result = classify_service_object(entry, reg, refs)
    if result.bucket != 'customer_defined':
        return False, f"got bucket {result.bucket!r}"
    if '3 ref' not in result.reason:
        return False, (f"reason should mention ref count: "
                       f"{result.reason}")
    return True, "referenced customer service classified correctly"


def test_classify_access_rule_auto_builtin() -> tuple[bool, str]:
    """Anonymous rule with auto-generated comment and service=any
    is vendor_builtin."""
    reg = _make_registry()
    refs = ReferenceIndex()
    entry = {
        '_section': 'access_rules',
        'name': False,  # anonymous
        'comment': 'IPv4:From Any to Any for Any service',
        'service': 'any',
        'from_zone': 'LAN',
        'to_zone': 'WAN',
        'action': 'allow',
        'enable': True,
    }
    result = classify_access_rule(entry, reg, refs)
    if result.bucket != 'vendor_builtin':
        return False, f"got bucket {result.bucket!r}"
    if 'auto-generated' not in result.reason.lower():
        return False, (f"reason should mention auto-generated: "
                       f"{result.reason}")
    return True, "auto-generated rule correctly classified as builtin"


def test_classify_access_rule_with_name_is_customer() -> tuple[bool, str]:
    """A named rule is customer-defined even with matching comment."""
    reg = _make_registry()
    refs = ReferenceIndex()
    entry = {
        '_section': 'access_rules',
        'name': 'My Custom Rule',
        'comment': 'IPv4:From Any to Any for Any service',  # not enough
        'service': 'any',
        'from_zone': 'LAN',
        'to_zone': 'WAN',
        'action': 'allow',
        'enable': True,
    }
    result = classify_access_rule(entry, reg, refs)
    if result.bucket != 'customer_defined':
        return False, (f"named rule should be customer, got "
                       f"{result.bucket!r}")
    return True, "named rule classified as customer (not builtin)"


def test_classify_access_rule_disabled_in_source() -> tuple[bool, str]:
    """A customer rule with enable=false goes to disabled_in_source."""
    reg = _make_registry()
    refs = ReferenceIndex()
    entry = {
        '_section': 'access_rules',
        'name': 'Disabled Test Rule',
        'comment': 'admin disabled this',
        'service': 'HTTP',
        'from_zone': 'LAN',
        'to_zone': 'WAN',
        'action': 'allow',
        'enable': False,  # disabled
    }
    result = classify_access_rule(entry, reg, refs)
    if result.bucket != 'disabled_in_source':
        return False, (f"disabled rule should be disabled_in_source, "
                       f"got {result.bucket!r}")
    return True, ("disabled customer rule routed to "
                  "disabled_in_source bucket")


def test_classify_access_rule_named_with_custom_service() -> tuple[bool, str]:
    """A named rule using a non-any service is customer-defined."""
    reg = _make_registry()
    refs = ReferenceIndex()
    entry = {
        '_section': 'access_rules',
        'name': 'Bonjour Rule',
        'comment': '',
        'service': 'Apple Bonjour',
        'from_zone': 'LAN',
        'to_zone': 'DMZ',
        'action': 'allow',
        'enable': True,
    }
    result = classify_access_rule(entry, reg, refs)
    if result.bucket != 'customer_defined':
        return False, f"got bucket {result.bucket!r}"
    return True, "named rule with custom service is customer_defined"


def test_classify_zone_builtin() -> tuple[bool, str]:
    """LAN/WAN/DMZ zones are vendor_builtin."""
    reg = _make_registry()
    refs = ReferenceIndex()
    for zone in ['LAN', 'WAN', 'DMZ']:
        entry = {'name': zone, '_id': zone, '_section': 'zones'}
        result = classify_zone(entry, reg, refs)
        if result.bucket != 'vendor_builtin':
            return False, (f"{zone} should be vendor_builtin, got "
                           f"{result.bucket!r}")
    return True, "standard zones correctly classified as builtin"


def test_classify_zone_custom() -> tuple[bool, str]:
    """A custom zone name is customer_defined."""
    reg = _make_registry()
    refs = ReferenceIndex()
    entry = {'name': 'CUSTOMER_VLAN', '_id': 'CUSTOMER_VLAN',
             '_section': 'zones'}
    result = classify_zone(entry, reg, refs)
    if result.bucket != 'customer_defined':
        return False, f"got bucket {result.bucket!r}"
    return True, "non-builtin zone classified as customer_defined"


# ---------------------------------------------------------------------------
# End-to-end test against real parser output
# ---------------------------------------------------------------------------

def test_e2e_against_real_parser_output() -> tuple[bool, str]:
    """Run classify_all against the real parser output. Verify the
    result is sensible: factory-default config should produce mostly
    builtin classifications."""
    parser_output = ROOT / 'sonicwall_parser' / 'output'
    builtins_path = ROOT / 'sonicwall_parser' / 'builtin_objects.ini'
    
    if not parser_output.is_dir():
        return False, f"parser output not found: {parser_output}"
    if not builtins_path.is_file():
        return False, f"builtins not found: {builtins_path}"
    
    reg = load_builtin_registry(builtins_path)
    results, stats, conservation = classify_all(parser_output, reg)
    
    if stats.total_entries == 0:
        return False, "no entries classified"
    
    # Verify the conservation report has some content
    if not hasattr(conservation, 'unclassified_sections'):
        return False, "conservation report missing unclassified_sections"
    
    # For factory-default config we expect:
    #   - Most service-objects are builtin
    #   - All access-rules with no name are builtin auto-generated
    by_bucket: dict[str, int] = {}
    for section, counts in stats.by_section.items():
        for bucket, count in counts.items():
            by_bucket[bucket] = by_bucket.get(bucket, 0) + count
    
    if by_bucket.get('vendor_builtin', 0) == 0:
        return False, "expected some vendor_builtin classifications"
    
    builtin_pct = (by_bucket['vendor_builtin']
                    / stats.total_entries * 100)
    if builtin_pct < 50:
        return False, (f"factory-default config should be >50% "
                       f"builtin, got {builtin_pct:.1f}%")
    
    return True, (f"E2E classification on real output: "
                  f"{by_bucket.get('vendor_builtin', 0)} builtin, "
                  f"{by_bucket.get('customer_defined', 0)} customer, "
                  f"{by_bucket.get('dead_unreferenced', 0)} dead "
                  f"({builtin_pct:.1f}% builtin)")


def test_filtered_json_outputs_written() -> tuple[bool, str]:
    """write_filtered_jsons creates one JSON per bucket with correct
    structure."""
    with tempfile.TemporaryDirectory() as td:
        out_dir = Path(td) / 'filtered'
        
        results = {
            'service_objects': {
                'vendor_builtin': [
                    {'name': 'HTTP', '_classification':
                        {'bucket': 'vendor_builtin',
                         'reason': 'test'}}],
                'customer_defined': [],
                'dead_unreferenced': [],
                'disabled_in_source': [],
            },
            'access_rules': {
                'vendor_builtin': [],
                'customer_defined': [
                    {'name': 'CustomRule', '_classification':
                        {'bucket': 'customer_defined',
                         'reason': 'test'}}],
                'dead_unreferenced': [],
                'disabled_in_source': [],
            },
        }
        
        write_filtered_jsons(results, out_dir)
        
        # Verify the four JSON files exist
        for bucket in ('vendor_builtin', 'customer_defined',
                       'dead_unreferenced', 'disabled_in_source'):
            p = out_dir / f'{bucket}.json'
            if not p.is_file():
                return False, f"missing output: {p.name}"
            data = json.loads(p.read_text(encoding='utf-8'))
            if '_meta' not in data:
                return False, f"{p.name} missing _meta"
            if 'by_section' not in data:
                return False, f"{p.name} missing by_section"
        
        # vendor_builtin should have HTTP
        vb = json.loads((out_dir / 'vendor_builtin.json').read_text())
        if 'service_objects' not in vb['by_section']:
            return False, "vendor_builtin.json missing service_objects"
        
        return True, "filtered JSON outputs written with correct shape"


def test_migration_scope_report_structure() -> tuple[bool, str]:
    """write_migration_scope_report produces a valid markdown report."""
    from relevance_filter import ClassificationStats
    stats = ClassificationStats()
    stats.bump('service_objects', 'vendor_builtin')
    stats.bump('service_objects', 'vendor_builtin')
    stats.bump('service_objects', 'customer_defined')
    stats.bump('access_rules', 'vendor_builtin')
    
    reg = _make_registry()
    
    with tempfile.TemporaryDirectory() as td:
        out_dir = Path(td)
        report_path = write_migration_scope_report(
            stats, reg, out_dir, source_label='test_source')
        if not report_path.is_file():
            return False, "report file not created"
        content = report_path.read_text(encoding='utf-8')
        if '# Migration Scope Report' not in content:
            return False, "report missing main header"
        if 'test_source' in content:
            pass  # good
        else:
            return False, "report missing source label"
        if 'workload reduction' not in content.lower():
            return False, "report missing workload reduction line"
        if '| `service_objects`' not in content:
            return False, "report missing per-section table"
        return True, "migration scope report has expected structure"


# ---------------------------------------------------------------------------
# CLI smoke test
# ---------------------------------------------------------------------------

def test_cli_runs_against_real_output() -> tuple[bool, str]:
    """End-to-end CLI invocation against real parser output."""
    rf_path = ROOT / 'sonicwall_parser' / 'relevance_filter.py'
    parser_out = ROOT / 'sonicwall_parser' / 'output'
    builtins = ROOT / 'sonicwall_parser' / 'builtin_objects.ini'
    
    if not parser_out.is_dir():
        return False, f"parser output missing: {parser_out}"
    
    with tempfile.TemporaryDirectory() as td:
        filt_dir = Path(td) / 'filtered'
        r = subprocess.run(
            [sys.executable, str(rf_path),
             '--parser-output', str(parser_out),
             '--builtins', str(builtins),
             '--output', str(filt_dir),
             '--source-label', 'cli_test'],
            capture_output=True, text=True, timeout=30)
        if r.returncode != 0:
            return False, (f"CLI failed rc={r.returncode}: "
                           f"{r.stderr[:300]}")
        if 'Translator workload reduction' not in r.stdout:
            return False, "CLI output missing reduction summary"
        if not (filt_dir / 'migration_scope.md').is_file():
            return False, "CLI did not produce migration_scope.md"
    return True, "CLI end-to-end run produces expected outputs"


def test_cli_missing_parser_output_exits_cleanly() -> tuple[bool, str]:
    """CLI with bad --parser-output exits with rc=2 and clear msg."""
    rf_path = ROOT / 'sonicwall_parser' / 'relevance_filter.py'
    r = subprocess.run(
        [sys.executable, str(rf_path),
         '--parser-output', '/tmp/definitely-does-not-exist',
         '--builtins', str(
             ROOT / 'sonicwall_parser' / 'builtin_objects.ini'),
         '--output', '/tmp/relfilter_test_out'],
        capture_output=True, text=True, timeout=15)
    if r.returncode != 2:
        return False, f"expected rc=2, got {r.returncode}"
    if 'parser output dir not found' not in r.stderr:
        return False, f"expected clear error, got: {r.stderr[:200]}"
    return True, "missing parser output exits with clear error"


# ---------------------------------------------------------------------------
# Phase 7 hardening: classifier coverage + conservation + freshness
# ---------------------------------------------------------------------------

def test_classify_nat_policy_customer() -> tuple[bool, str]:
    """A named NAT policy with enable=true is customer_defined."""
    from relevance_filter import classify_nat_policy
    reg = _make_registry()
    refs = ReferenceIndex()
    entry = {
        '_section': 'nat_policies',
        'name': 'fakenatforclaude',
        'enable': True,
    }
    result = classify_nat_policy(entry, reg, refs)
    if result.bucket != 'customer_defined':
        return False, (f"named enabled NAT policy should be "
                       f"customer_defined, got {result.bucket!r}")
    return True, "named enabled NAT policy classified as customer"


def test_classify_nat_policy_disabled() -> tuple[bool, str]:
    """A NAT policy with enable=false routes to disabled_in_source."""
    from relevance_filter import classify_nat_policy
    reg = _make_registry()
    refs = ReferenceIndex()
    entry = {
        '_section': 'nat_policies',
        'name': 'DisabledNAT',
        'enable': False,
    }
    result = classify_nat_policy(entry, reg, refs)
    if result.bucket != 'disabled_in_source':
        return False, (f"disabled NAT should route to disabled_in_source, "
                       f"got {result.bucket!r}")
    return True, "disabled NAT correctly routed to disabled_in_source"


def test_classify_vpn_policy_customer_site_to_site() -> tuple[bool, str]:
    """Customer-named site-to-site VPN with enable=true is customer_defined."""
    from relevance_filter import classify_vpn_policy
    reg = _make_registry()
    refs = ReferenceIndex()
    entry = {
        '_section': 'vpn_policies',
        'name': 'fakesite2site',
        'vpn_type': 'site-to-site',
        'enable': True,
    }
    result = classify_vpn_policy(entry, reg, refs)
    if result.bucket != 'customer_defined':
        return False, (f"customer site-to-site VPN should be customer, "
                       f"got {result.bucket!r}")
    return True, "customer site-to-site VPN classified correctly"


def test_classify_vpn_policy_disabled_group_vpn() -> tuple[bool, str]:
    """A disabled GroupVPN goes to disabled_in_source."""
    from relevance_filter import classify_vpn_policy
    reg = _make_registry()
    refs = ReferenceIndex()
    entry = {
        '_section': 'vpn_policies',
        'name': 'WAN GroupVPN',
        'vpn_type': 'group-vpn',
        'enable': False,
    }
    result = classify_vpn_policy(entry, reg, refs)
    if result.bucket != 'disabled_in_source':
        return False, (f"disabled GroupVPN should be disabled_in_source, "
                       f"got {result.bucket!r}")
    return True, "disabled GroupVPN routed to disabled_in_source"


def test_conservation_flags_unclassified_section() -> tuple[bool, str]:
    """classify_all reports sections that lack classifiers in
    conservation.unclassified_sections."""
    from relevance_filter import classify_all
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        # A section name that DEFINITELY has no classifier
        (td / 'totally_fake_section.json').write_text(json.dumps({
            'entries': [{'_section': 'totally_fake_section',
                          '_id': 'x', 'name': 'fake'}],
            '_meta': {'source_file': 'test.txt'},
        }), encoding='utf-8')
        reg = _make_registry()
        results, stats, conservation = classify_all(td, reg)
        if 'totally_fake_section' not in conservation.unclassified_sections:
            return False, (f"unclassified section should be tracked in "
                           f"conservation, got keys: "
                           f"{list(conservation.unclassified_sections.keys())}")
        return True, ("conservation report flags sections with no "
                      "classifier")


def test_freshness_check_reads_source_metadata() -> tuple[bool, str]:
    """The freshness check reads _meta.source_file from each JSON
    and aggregates the set of source files referenced. Useful for
    operators to spot stale-cache situations."""
    from relevance_filter import check_parser_output_freshness
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        (td / 'access_rules.json').write_text(json.dumps({
            'entries': [],
            '_meta': {'source_file': 'input/customer_A.txt'},
        }), encoding='utf-8')
        (td / 'service_objects.json').write_text(json.dumps({
            'entries': [],
            '_meta': {'source_file': 'input/customer_A.txt'},
        }), encoding='utf-8')
        report = check_parser_output_freshness(td)
        if 'input/customer_A.txt' not in report.source_files_seen:
            return False, (f"freshness check missing source file, got: "
                           f"{report.source_files_seen}")
        return True, ("freshness check correctly reads source_file "
                      "metadata from parser output")


def test_freshness_check_warns_on_multiple_sources() -> tuple[bool, str]:
    """If parser output has _meta.source_file from MULTIPLE different
    files, that's a stale-cache mix — the freshness check flags it."""
    from relevance_filter import check_parser_output_freshness
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        (td / 'access_rules.json').write_text(json.dumps({
            'entries': [],
            '_meta': {'source_file': 'input/old_config.txt'},
        }), encoding='utf-8')
        (td / 'service_objects.json').write_text(json.dumps({
            'entries': [],
            '_meta': {'source_file': 'input/new_config.txt'},
        }), encoding='utf-8')
        report = check_parser_output_freshness(td)
        if len(report.source_files_seen) < 2:
            return False, (f"expected 2 distinct source files, "
                           f"got {report.source_files_seen}")
        if not report.has_mixed_sources:
            return False, ("expected has_mixed_sources=True with two "
                           "different sources")
        return True, "freshness check flags mixed-source cache state"


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

TESTS = [
    ("builtin_registry_loads_real_file",
     test_builtin_registry_loads_real_file),
    ("builtin_registry_missing_file_raises",
     test_builtin_registry_missing_file_raises),
    ("builtin_registry_false_values_excluded",
     test_builtin_registry_false_values_excluded),
    ("reference_index_counts_mentions",
     test_reference_index_counts_mentions),
    ("classify_service_builtin", test_classify_service_builtin),
    ("classify_service_dead_unreferenced",
     test_classify_service_dead_unreferenced),
    ("classify_service_customer_defined",
     test_classify_service_customer_defined),
    ("classify_access_rule_auto_builtin",
     test_classify_access_rule_auto_builtin),
    ("classify_access_rule_with_name_is_customer",
     test_classify_access_rule_with_name_is_customer),
    ("classify_access_rule_disabled_in_source",
     test_classify_access_rule_disabled_in_source),
    ("classify_access_rule_named_with_custom_service",
     test_classify_access_rule_named_with_custom_service),
    ("classify_zone_builtin", test_classify_zone_builtin),
    ("classify_zone_custom", test_classify_zone_custom),
    ("e2e_against_real_parser_output",
     test_e2e_against_real_parser_output),
    ("filtered_json_outputs_written",
     test_filtered_json_outputs_written),
    ("migration_scope_report_structure",
     test_migration_scope_report_structure),
    ("cli_runs_against_real_output",
     test_cli_runs_against_real_output),
    ("cli_missing_parser_output_exits_cleanly",
     test_cli_missing_parser_output_exits_cleanly),
    # Phase 7 hardening tests — Captain Ames caught two failure modes
    # in initial Phase 7: stale parser output + missing classifiers.
    # These tests cover the four fixes.
    ("classify_nat_policy_customer",
     test_classify_nat_policy_customer),
    ("classify_nat_policy_disabled",
     test_classify_nat_policy_disabled),
    ("classify_vpn_policy_customer_site_to_site",
     test_classify_vpn_policy_customer_site_to_site),
    ("classify_vpn_policy_disabled_group_vpn",
     test_classify_vpn_policy_disabled_group_vpn),
    ("conservation_flags_unclassified_section",
     test_conservation_flags_unclassified_section),
    ("freshness_check_reads_source_metadata",
     test_freshness_check_reads_source_metadata),
    ("freshness_check_warns_on_multiple_sources",
     test_freshness_check_warns_on_multiple_sources),
]


def main() -> int:
    print("Phase 7 — Relevance filter (SonicWall input side)")
    print()
    print(f"{'TEST':<55} {'RESULT':<8} DETAIL")
    print("-" * 95)
    fail = 0
    for name, fn in TESTS:
        try:
            ok, msg = fn()
        except Exception as e:
            ok, msg = False, f"EXC: {type(e).__name__}: {e}"
        status = "PASS" if ok else "FAIL"
        print(f"{name:<55} {status:<8} {msg[:140]}")
        if not ok:
            fail += 1
    print()
    if fail == 0:
        print(f"All {len(TESTS)} Phase 7 tests passed.")
        return 0
    print(f"{fail} of {len(TESTS)} Phase 7 tests FAILED.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
