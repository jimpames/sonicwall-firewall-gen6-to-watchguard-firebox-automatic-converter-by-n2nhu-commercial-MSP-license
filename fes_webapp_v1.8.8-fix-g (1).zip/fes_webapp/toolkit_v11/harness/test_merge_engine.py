#!/usr/bin/env python3
"""
test_merge_engine.py
=====================

Regression tests for schema_learner/merge_engine.py — Step 4.

These tests exercise the full merge lifecycle (validate, dry-run,
apply, rollback) against synthetic proposals, verifying:

  * Validation correctly REFUSES proposals with missing declarations
  * Validation correctly REFUSES proposals with missing citations
  * Validation correctly ACCEPTS fully-filled proposals
  * Apply requires --confirm flag (mechanical safety)
  * Apply creates timestamped backups of all modified files
  * Apply writes provenance comments inline (citations preserved)
  * Apply writes warning blurbs for unmapped SonicWall sides
  * Rollback restores byte-identical pre-merge file state
  * The provenance audit passes against merge-engine-modified files
  * Invalid surface category in operator declaration is REJECTED

The merge engine is the part of the toolkit that modifies the
permanent INI knowledge base. These tests are the safety net.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# Make schema_learner importable
sys.path.insert(0, str(ROOT / "schema_learner"))


# ---------------------------------------------------------------------------
# Synthetic proposal builder
# ---------------------------------------------------------------------------

def _make_filled_intervention(
    surface_tag: str = "vpn-portal",
    purpose: str = "Configures a clientless web portal.",
    purpose_source: str = "https://www.example.com/docs/portal",
    category: str = "html-web-app",
    category_source: str = "Vendor docs URL above.",
    sw_equiv: str = "SonicWall Virtual Office.",
    sw_source: str = "Field experience.",
    notes: str = "Bookmarks need rebuild.",
    notes_source: str = "Field experience.",
) -> str:
    """Build a synthetic OPERATOR_INTERVENTION_REQUIRED.md with one
    surface filled in completely."""
    return f"""# OPERATOR INTERVENTION REQUIRED

Generated: 2026-05-05
Source: SYNTHETIC_TEST

---

## Surface 1: `<{surface_tag}>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

- Element tag: `{surface_tag}`
- Naming tokens: ['vpn', 'portal']

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

<!-- OPERATOR-AUTHORED-BEGIN -->

[X] **Q1: What does this element do?** (one sentence)

    Answer: {purpose}

    Source: {purpose_source}

[X] **Q2: Surface category from the toolkit's taxonomy?**

    Answer: {category}

    Source: {category_source}

[X] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    Answer: {sw_equiv}

    Source: {sw_source}

[X] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: {notes}

    Source: {notes_source}

<!-- OPERATOR-AUTHORED-END -->
"""


def _make_unfilled_intervention(surface_tag: str = "vpn-portal") -> str:
    """Build a synthetic OPERATOR_INTERVENTION_REQUIRED.md with all
    answer fields left as placeholder underscores (i.e. unfilled).
    Validation should refuse this."""
    return f"""# OPERATOR INTERVENTION REQUIRED

## Surface 1: `<{surface_tag}>`

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->
"""


def _make_minimal_findings_json(surface_tag: str = "vpn-portal") -> str:
    """Build a synthetic findings.json that the merge engine can read."""
    findings = {
        "findings": [
            {
                "category": "novel_element_type",
                "element_tag": surface_tag,
                "source_file": "synthetic",
                "detail": {},
                "placement_confidence": 0.5,
                "neighbors": [],
                "structural_facts": {
                    "instance_count": 1,
                    "distinct_children_tags": 3,
                    "distinct_field_shapes": 1,
                    "naming_tokens": surface_tag.split("-"),
                    "top_children_tags": [["port", 1], ["timeout", 1]],
                    "value_pattern_summary": {},
                    "observed_in_corpus_files": ["synthetic"],
                },
            }
        ],
        "generated_at": "2026-05-05T00:00:00",
        "finding_count": 1,
    }
    return json.dumps(findings, indent=2)


def _make_test_proposal(
    proposal_dir: Path,
    intervention_text: str,
    surface_tag: str = "vpn-portal",
) -> Path:
    """Create a synthetic proposal directory."""
    proposal_dir.mkdir(parents=True, exist_ok=True)
    (proposal_dir / "OPERATOR_INTERVENTION_REQUIRED.md").write_text(
        intervention_text, encoding="utf-8")
    (proposal_dir / "findings.json").write_text(
        _make_minimal_findings_json(surface_tag), encoding="utf-8")
    return proposal_dir


# ---------------------------------------------------------------------------
# Test runner helpers
# ---------------------------------------------------------------------------

def _run_merge_cli(
    args: list[str],
    cwd: Path | None = None,
) -> tuple[int, str, str]:
    """Run merge_engine.py as a subprocess; return (returncode, stdout, stderr)."""
    cmd = [sys.executable, str(ROOT / "schema_learner" / "merge_engine.py")] + args
    r = subprocess.run(
        cmd, capture_output=True, text=True,
        cwd=str(cwd) if cwd else None,
    )
    return r.returncode, r.stdout, r.stderr


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_validate_refuses_unfilled_proposal() -> tuple[bool, str]:
    """Operator hasn't filled in any answers — engine must refuse."""
    with tempfile.TemporaryDirectory() as td:
        prop_dir = Path(td) / "unfilled"
        _make_test_proposal(
            prop_dir, _make_unfilled_intervention())
        rc, out, err = _run_merge_cli(
            ["validate", "--proposal", str(prop_dir)])
        if rc == 0:
            return False, "engine accepted an unfilled proposal"
        if "NOT mergeable" not in out:
            return False, f"engine output didn't mention 'NOT mergeable': {out[:200]}"
        return True, "engine correctly refused unfilled proposal"


def test_validate_refuses_missing_citation() -> tuple[bool, str]:
    """Q1 answer present but source field empty — engine must refuse."""
    with tempfile.TemporaryDirectory() as td:
        prop_dir = Path(td) / "no_citation"
        # Build with empty source
        text = _make_filled_intervention(
            purpose_source="___________________________________________")
        _make_test_proposal(prop_dir, text)
        rc, out, err = _run_merge_cli(
            ["validate", "--proposal", str(prop_dir)])
        if rc == 0:
            return False, "engine accepted a proposal with missing citation"
        if "purpose_source" not in out:
            return False, "engine didn't flag the missing citation"
        return True, "engine correctly refused missing-citation proposal"


def test_validate_rejects_invalid_category() -> tuple[bool, str]:
    """Operator typed a category not in the taxonomy — engine must refuse."""
    with tempfile.TemporaryDirectory() as td:
        prop_dir = Path(td) / "bad_category"
        text = _make_filled_intervention(category="not-a-real-category")
        _make_test_proposal(prop_dir, text)
        rc, out, err = _run_merge_cli(
            ["validate", "--proposal", str(prop_dir)])
        if rc == 0:
            return False, "engine accepted invalid category"
        if "not a valid category" not in out:
            return False, "engine didn't explain the category was invalid"
        return True, "engine correctly rejected invalid category"


def test_validate_accepts_filled_proposal() -> tuple[bool, str]:
    """Fully-filled proposal — engine must accept."""
    with tempfile.TemporaryDirectory() as td:
        prop_dir = Path(td) / "filled"
        _make_test_proposal(
            prop_dir, _make_filled_intervention())
        rc, out, err = _run_merge_cli(
            ["validate", "--proposal", str(prop_dir)])
        if rc != 0:
            return False, f"engine refused a complete proposal: {out[:300]}"
        if "is mergeable" not in out:
            return False, f"engine output didn't say 'mergeable': {out[:200]}"
        return True, "engine correctly accepted filled proposal"


def test_dry_run_shows_plan_without_writing() -> tuple[bool, str]:
    """Dry-run should produce a plan but not modify any files."""
    with tempfile.TemporaryDirectory() as td:
        prop_dir = Path(td) / "for_dry_run"
        _make_test_proposal(
            prop_dir, _make_filled_intervention())
        # Snapshot current schema file before dry-run
        schema_path = ROOT / "wg_validator" / "wg_xml_schema.ini"
        before_size = schema_path.stat().st_size
        rc, out, err = _run_merge_cli(
            ["dry-run", "--proposal", str(prop_dir)])
        after_size = schema_path.stat().st_size
        if rc != 0:
            return False, f"dry-run failed: {out[:300]}"
        if "Schema entries to add" not in out:
            return False, "dry-run didn't show the plan"
        if before_size != after_size:
            return False, "dry-run modified the schema file (BUG)"
        return True, "dry-run shows plan, makes no changes"


def test_apply_requires_confirm_flag() -> tuple[bool, str]:
    """apply without --confirm must refuse."""
    with tempfile.TemporaryDirectory() as td:
        prop_dir = Path(td) / "for_apply_no_confirm"
        _make_test_proposal(
            prop_dir, _make_filled_intervention())
        rc, out, err = _run_merge_cli(
            ["apply", "--proposal", str(prop_dir)])
        if rc == 0:
            return False, "apply succeeded without --confirm (DANGEROUS)"
        if "without --confirm" not in out:
            return False, "engine didn't explain why it refused"
        return True, "apply correctly refused without --confirm flag"


def test_apply_then_rollback_restores_state() -> tuple[bool, str]:
    """Full apply→rollback cycle must restore byte-identical state.
    
    Crash-safe: the rollback runs in a finally block. If anything
    between apply and rollback raises (Windows path issue, missing
    Python interpreter, even Ctrl-C), the synthetic test fixture
    still gets removed from the schema files. Without this,
    interrupted test runs leave [element.test-merge-engine-element-*]
    sections in wg_xml_schema.ini and the next run hits
    DuplicateSectionError.
    """
    surface_tag = "test-merge-engine-element-2026"
    with tempfile.TemporaryDirectory() as td:
        prop_dir = Path(td) / "for_apply"
        _make_test_proposal(
            prop_dir,
            _make_filled_intervention(surface_tag=surface_tag),
            surface_tag=surface_tag,
        )
        # Snapshot all four target files before apply
        target_files = [
            ROOT / "wg_validator" / "wg_xml_schema.ini",
            ROOT / "concept_map" / "concept_map.ini",
            ROOT / "sonicwall_parser" / "parser_config.ini",
            ROOT / "xml_emitter" / "xml_emit_config.ini",
        ]
        before_contents = {f: f.read_bytes() for f in target_files}
        merge_id = None
        try:
            # Apply
            rc, out, err = _run_merge_cli(
                ["apply", "--proposal", str(prop_dir),
                 "--operator", "test-suite", "--confirm"])
            if rc != 0:
                return False, f"apply failed: {out[:300]}"
            # Extract merge_id from output
            for line in out.splitlines():
                if line.startswith("✓ Merge applied:"):
                    merge_id = line.split(":", 1)[1].strip()
                    break
            if merge_id is None:
                return False, "could not extract merge_id from apply output"
            # Verify files DID change
            any_changed = False
            for f in target_files:
                if f.read_bytes() != before_contents[f]:
                    any_changed = True
                    break
            if not any_changed:
                return False, "apply didn't modify any files"
            # Rollback
            rc, out, err = _run_merge_cli(
                ["rollback", "--merge-id", merge_id])
            merge_id = None  # rollback succeeded, no cleanup needed
            if rc != 0:
                return False, f"rollback failed: {out[:300]}"
            # Verify files restored
            for f in target_files:
                if f.read_bytes() != before_contents[f]:
                    return False, (
                        f"rollback did not restore {f.name} "
                        "(content differs)"
                    )
            return True, "apply→rollback restored byte-identical state"
        finally:
            # Crash-safety: if we got past apply but didn't reach a
            # successful rollback, force a rollback now. Without this,
            # the synthetic fixture stays glued to the real schema file
            # and contaminates subsequent runs.
            if merge_id is not None:
                _run_merge_cli(["rollback", "--merge-id", merge_id])


def test_apply_writes_citations_inline() -> tuple[bool, str]:
    """After apply, the modified INI files must contain the operator's
    citation URLs as provenance comments."""
    surface_tag = "cite-test-element-2026"
    with tempfile.TemporaryDirectory() as td:
        prop_dir = Path(td) / "for_citations"
        unique_url = "https://example.com/docs/test-citation-marker-12345"
        _make_test_proposal(
            prop_dir,
            _make_filled_intervention(
                surface_tag=surface_tag,
                purpose_source=unique_url,
            ),
            surface_tag=surface_tag,
        )
        # Apply
        rc, out, err = _run_merge_cli(
            ["apply", "--proposal", str(prop_dir),
             "--operator", "test-suite", "--confirm"])
        if rc != 0:
            return False, f"apply failed: {out[:300]}"
        merge_id = None
        for line in out.splitlines():
            if line.startswith("✓ Merge applied:"):
                merge_id = line.split(":", 1)[1].strip()
                break
        try:
            # Citation must appear in schema file
            schema_path = ROOT / "wg_validator" / "wg_xml_schema.ini"
            schema_text = schema_path.read_text(encoding='utf-8')
            if unique_url not in schema_text:
                return False, "citation URL not found in schema file"
        finally:
            # Always rollback to keep test isolated
            if merge_id:
                _run_merge_cli(["rollback", "--merge-id", merge_id])
        return True, f"citation URL written to schema file as provenance"


def test_apply_provenance_audit_clean() -> tuple[bool, str]:
    """After apply, the provenance audit must still pass against the
    modified files (provenance comments don't trip the audit)."""
    surface_tag = "audit-check-element-2026"
    with tempfile.TemporaryDirectory() as td:
        prop_dir = Path(td) / "for_audit_check"
        _make_test_proposal(
            prop_dir,
            _make_filled_intervention(surface_tag=surface_tag),
            surface_tag=surface_tag,
        )
        rc, out, err = _run_merge_cli(
            ["apply", "--proposal", str(prop_dir),
             "--operator", "test-suite", "--confirm"])
        if rc != 0:
            return False, f"apply failed: {out[:300]}"
        merge_id = None
        for line in out.splitlines():
            if line.startswith("✓ Merge applied:"):
                merge_id = line.split(":", 1)[1].strip()
                break
        try:
            # Run the provenance audit
            audit_rc = subprocess.run(
                [sys.executable, str(ROOT / "harness" /
                                "test_schema_learner_provenance.py")],
                capture_output=True, text=True,
            ).returncode
            if audit_rc != 0:
                return False, ("provenance audit FAILED after merge "
                               "(modified files contain unsourced claims)")
        finally:
            if merge_id:
                _run_merge_cli(["rollback", "--merge-id", merge_id])
        return True, "provenance audit clean after merge"


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

TESTS = [
    ("validate_refuses_unfilled_proposal", test_validate_refuses_unfilled_proposal),
    ("validate_refuses_missing_citation", test_validate_refuses_missing_citation),
    ("validate_rejects_invalid_category", test_validate_rejects_invalid_category),
    ("validate_accepts_filled_proposal", test_validate_accepts_filled_proposal),
    ("dry_run_shows_plan_without_writing", test_dry_run_shows_plan_without_writing),
    ("apply_requires_confirm_flag", test_apply_requires_confirm_flag),
    ("apply_then_rollback_restores_state", test_apply_then_rollback_restores_state),
    ("apply_writes_citations_inline", test_apply_writes_citations_inline),
    ("apply_provenance_audit_clean", test_apply_provenance_audit_clean),
]


def main() -> int:
    print("schema_learner merge_engine tests (Step 4)")
    print()
    print(f"{'TEST':<48} {'RESULT':<8} DETAIL")
    print("-" * 95)
    fail = 0
    for name, fn in TESTS:
        try:
            ok, msg = fn()
        except Exception as e:
            ok, msg = False, f"EXC: {type(e).__name__}: {e}"
        status = "PASS" if ok else "FAIL"
        print(f"{name:<48} {status:<8} {msg[:140]}")
        if not ok:
            fail += 1
    print()
    if fail == 0:
        print(f"All {len(TESTS)} tests passed.")
        return 0
    print(f"{fail} of {len(TESTS)} tests FAILED.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
