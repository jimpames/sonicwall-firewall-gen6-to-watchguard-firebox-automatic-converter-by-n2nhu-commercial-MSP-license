#!/usr/bin/env python3
"""
test_phase4_deep_research.py
=============================

Phase 4 regression tests for:
  - Sideline claim/promote workflow (senior engineer ownership)
  - Lab verification (Decision #7 mandatory)
  - DeepResearchPromotion strict validation
  - Deprecation registry (Decision #5 quarterly sweep)
  - Deprecation propagation (find affected prior proposals)
  - SLA aging visibility (Decision #4)

Tests use isolated temporary state where possible. Production sideline
queue, banned corpus, and deprecation log are snapshotted and restored.

The bar these tests hold:
  - Lab verification cannot be skipped — Decision #7 enforced in code
  - Two citations required per claim for deep research
  - Peer review acknowledgment captured
  - Deprecations are timestamped + cited by URL
  - Propagation correctly identifies affected proposals
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "schema_learner"))

from corpus_tiers import (  # noqa: E402
    SidelineEntry, _sideline_queue_path, _sideline_root,
    load_sideline_queue, write_sideline_entry, make_entry_id,
)
from deep_research import (  # noqa: E402
    DeepResearchPromotion, DeprecationEntry, LabVerification,
    _deprecation_log_path, _lab_verifications_root,
    claim_sideline_entry,
    days_since_iso, find_proposals_referencing_surface,
    is_sla_overdue, load_deprecation_log,
    mark_sideline_status, write_deprecation_entry,
    write_lab_verification_artifact,
)


# ---------------------------------------------------------------------------
# State snapshot/restore helpers (avoid leaking test state)
# ---------------------------------------------------------------------------

def _snapshot_state() -> dict[str, bytes | None]:
    snap: dict[str, bytes | None] = {}
    paths_to_track = [
        _sideline_queue_path(),
        _deprecation_log_path(),
    ]
    for p in paths_to_track:
        snap[str(p)] = p.read_bytes() if p.is_file() else None
    # Track files in directories
    for d in (_sideline_root(), _lab_verifications_root()):
        for f in d.iterdir():
            if f.is_file():
                snap[str(f)] = f.read_bytes()
    return snap


def _restore_state(snap: dict[str, bytes | None]) -> None:
    for d in (_sideline_root(), _lab_verifications_root()):
        for f in list(d.iterdir()):
            if str(f) not in snap and f.is_file():
                f.unlink()
    for path_str, contents in snap.items():
        p = Path(path_str)
        if contents is None:
            if p.is_file():
                p.unlink()
        else:
            p.write_bytes(contents)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_lab_verification_round_trips() -> tuple[bool, str]:
    """LabVerification serializes to/from a compact field string."""
    lv = LabVerification(
        firebox_model="T-30",
        firmware_version="12.11.0",
        verified_by="senior-jim",
        verified_at="2026-05-07T10:00:00",
        test_result="PASS",
        test_notes="Round-trip imported XML, exported XML, diff was clean.",
    )
    serialized = lv.to_field_string()
    if "model=T-30" not in serialized:
        return False, "field string missing model"
    if "result=PASS" not in serialized:
        return False, "field string missing result"
    parsed = LabVerification.from_field_string(serialized)
    if parsed.firebox_model != lv.firebox_model:
        return False, "model not preserved through round-trip"
    if parsed.test_result != lv.test_result:
        return False, "test_result not preserved"
    if parsed.verified_by != lv.verified_by:
        return False, "verified_by not preserved"
    return True, "LabVerification round-trips through field-string format"


def test_lab_verification_validates_required_fields() -> tuple[bool, str]:
    """Decision #7: every field required. Empty model → invalid."""
    lv = LabVerification()
    ok, missing = lv.is_complete()
    if ok:
        return False, "empty LabVerification should NOT validate"
    expected_fields = {'firebox_model', 'firmware_version', 'verified_by',
                       'verified_at'}
    missing_set = {m.split()[0] for m in missing}
    if not expected_fields.issubset(missing_set):
        return False, (f"expected at least {expected_fields} in missing, "
                       f"got {missing_set}")

    # Bad test_result value
    lv = LabVerification(
        firebox_model="T-30", firmware_version="12.11.0",
        verified_by="x", verified_at="2026-05-07",
        test_result="MAYBE",  # invalid
        test_notes="Long enough notes for the validator to accept here.",
    )
    ok, missing = lv.is_complete()
    if ok:
        return False, "invalid test_result should fail validation"
    if not any('test_result' in m for m in missing):
        return False, "test_result error not flagged"
    return True, "LabVerification correctly enforces required fields"


def test_deep_research_promotion_validation_empty() -> tuple[bool, str]:
    """An empty DeepResearchPromotion fails validation with clear errors."""
    promo = DeepResearchPromotion(
        surface_tag="x", sideline_entry_id="sl_x")
    ok, errors = promo.validate()
    if ok:
        return False, "empty promotion should NOT validate"
    # Must catch all four claims missing + lab + peer + researcher
    expected_phrases = [
        "Q1 purpose", "Q2 category", "Q3 sonicwall_equivalent",
        "Q4 operational_notes", "lab_verification", "peer_reviewer",
        "deep_researcher",
    ]
    err_text = " ".join(errors)
    for phrase in expected_phrases:
        if phrase not in err_text:
            return False, f"expected error about {phrase!r} not present"
    return True, (f"empty promotion correctly fails validation with "
                  f"{len(errors)} errors covering all required fields")


def test_deep_research_promotion_validates_complete() -> tuple[bool, str]:
    """A fully-filled DeepResearchPromotion validates successfully."""
    lv = LabVerification(
        firebox_model="T-30", firmware_version="12.11.0",
        verified_by="senior-jim", verified_at="2026-05-07T10:00:00",
        test_result="PASS",
        test_notes="Imported the XML containing this surface to the lab "
                   "Firebox. Exported it back. Diff was clean and the "
                   "translated config behaved as expected.",
    )
    promo = DeepResearchPromotion(
        surface_tag="vpn-portal", sideline_entry_id="sl_vpn-portal_xyz",
        purpose="Configures the WatchGuard Access Portal — clientless web VPN.",
        purpose_source_1="https://www.watchguard.com/help/docs/x.html",
        purpose_source_2="https://www.watchguard.com/help/docs/y.html",
        category="html-web-app",
        category_source_1="https://www.watchguard.com/help/docs/x.html",
        category_source_2="Vendor categorization in Fireware UI screenshots.",
        sonicwall_equivalent="SonicWall Virtual Office (SSL-VPN web portal).",
        sonicwall_source_1="Field experience (25 years dual-vendor).",
        sonicwall_source_2="https://www.sonicwall.com/support/...",
        operational_notes="Bookmarks need rebuild; CSS does not transfer.",
        operational_source_1="Field experience.",
        operational_source_2="WatchGuard migration guide URL.",
        lab_verification=lv,
        peer_reviewer="senior-bob",
        peer_reviewed_at="2026-05-07T11:00:00",
        peer_review_notes="I reviewed the citations and the lab artifact. "
                          "Classification looks correct.",
        deep_researcher="senior-jim",
        deep_research_at="2026-05-07T10:30:00",
    )
    ok, errors = promo.validate()
    if not ok:
        return False, (f"complete promotion failed validation with "
                       f"{len(errors)} errors: {errors[:3]}")
    return True, "complete DeepResearchPromotion validates successfully"


def test_deep_research_rejects_lab_fail() -> tuple[bool, str]:
    """Decision #7: a FAIL lab result must reject the promotion."""
    lv = LabVerification(
        firebox_model="T-30", firmware_version="12.11.0",
        verified_by="senior-jim", verified_at="2026-05-07T10:00:00",
        test_result="FAIL",
        test_notes="Round-trip diverged: imported XML, exported XML, "
                   "diff showed missing fields. Translation cannot be "
                   "considered reliable.",
    )
    promo = DeepResearchPromotion(
        surface_tag="vpn-portal", sideline_entry_id="sl_xyz",
        purpose="x", purpose_source_1="x", purpose_source_2="x",
        category="html-web-app", category_source_1="x", category_source_2="x",
        sonicwall_equivalent="x", sonicwall_source_1="x", sonicwall_source_2="x",
        operational_notes="x", operational_source_1="x", operational_source_2="x",
        lab_verification=lv,
        peer_reviewer="x", peer_reviewed_at="x",
        peer_review_notes="x", deep_researcher="x",
        deep_research_at="x",
    )
    ok, errors = promo.validate()
    if ok:
        return False, "FAIL lab result should reject promotion"
    if not any("FAIL" in e for e in errors):
        return False, f"expected FAIL error, got: {errors}"
    return True, "FAIL lab result correctly rejects deep-research promotion"


def test_lab_verification_artifact_written() -> tuple[bool, str]:
    """write_lab_verification_artifact creates the markdown file with
    provenance markers and populates artifact_path."""
    snap = _snapshot_state()
    try:
        unique_tag = f"test-lab-artifact-{uuid.uuid4().hex[:8]}"
        lv = LabVerification(
            firebox_model="T-30", firmware_version="12.11.0",
            verified_by="test-suite",
            verified_at="2026-05-07T10:00:00", test_result="PASS",
            test_notes="Substantive test notes about the round-trip.",
        )
        path = write_lab_verification_artifact(unique_tag, lv,
                                                additional_notes="Extra")
        if not path.is_file():
            return False, "artifact file not created"
        contents = path.read_text(encoding='utf-8')
        if 'Lab verification' not in contents:
            return False, "artifact missing header"
        if '<!-- ENGINE-OBSERVATION-BEGIN -->' not in contents:
            return False, "artifact missing observation markers"
        if 'PASS' not in contents:
            return False, "artifact missing test result"
        if not lv.artifact_path:
            return False, "artifact_path not populated on lv object"
        return True, "lab-verification artifact written with provenance markers"
    finally:
        _restore_state(snap)


def test_sideline_claim_workflow() -> tuple[bool, str]:
    """claim_sideline_entry transitions status open → in_research."""
    snap = _snapshot_state()
    try:
        unique_tag = f"test-claim-{uuid.uuid4().hex[:8]}"
        entry_id = make_entry_id(unique_tag, 'sl')
        entry = SidelineEntry(
            entry_id=entry_id,
            surface_tag=unique_tag,
            operator='original-operator',
            timestamp='2026-05-07T10:00:00',
            reason='test fixture',
            first_seen_in='p1', last_seen_in='p1',
            last_seen_at='2026-05-07T10:00:00',
            children_tags_fingerprint='', value_patterns_fingerprint='',
            naming_tokens_fingerprint='test, claim',
            source_proposal='p1', status='open',
        )
        write_sideline_entry(entry)

        # Claim
        ok, msg = claim_sideline_entry(entry_id, 'senior-jim')
        if not ok:
            return False, f"claim failed: {msg}"

        # Verify status updated
        queue = load_sideline_queue()
        loaded = next((e for e in queue if e.entry_id == entry_id), None)
        if loaded is None:
            return False, "entry vanished after claim"
        if loaded.status != 'in_research':
            return False, f"status is {loaded.status!r}, expected 'in_research'"
        if loaded.assigned_to != 'senior-jim':
            return False, f"assigned_to is {loaded.assigned_to!r}"

        # Try to claim again — should fail (already claimed)
        ok, msg = claim_sideline_entry(entry_id, 'another-jim')
        if ok:
            return False, "double-claim should have failed"
        return True, ("sideline claim workflow: open → in_research, "
                      "double-claim refused")
    finally:
        _restore_state(snap)


def test_deprecation_registry_round_trip() -> tuple[bool, str]:
    """Deprecation entries persist and load correctly."""
    snap = _snapshot_state()
    try:
        unique_tag = f"test-deprecation-{uuid.uuid4().hex[:8]}"
        entry = DeprecationEntry(
            surface_tag=unique_tag,
            deprecated_at="2026-05-07T10:00:00",
            deprecated_by="senior-jim",
            vendor_citation="https://www.watchguard.com/release-notes",
            deprecation_reason="Vendor announced this feature is removed in v13.",
            replacement_feature="Use 'foo-modern' instead.",
        )
        write_deprecation_entry(entry)

        loaded = load_deprecation_log()
        if unique_tag not in loaded:
            return False, "deprecation entry not loaded"
        l = loaded[unique_tag]
        if l.vendor_citation != entry.vendor_citation:
            return False, "vendor_citation not preserved"
        if l.replacement_feature != entry.replacement_feature:
            return False, "replacement_feature not preserved"
        return True, "deprecation registry round-trips with all fields"
    finally:
        _restore_state(snap)


def test_deprecation_propagation_finds_proposals() -> tuple[bool, str]:
    """find_proposals_referencing_surface finds matching proposals."""
    # Create a temp proposals tree with one matching and one non-matching
    with tempfile.TemporaryDirectory() as tmpdir:
        proposals_root = Path(tmpdir)
        # Matching proposal
        match_dir = proposals_root / "2026-05-01_customerA"
        match_dir.mkdir()
        target_tag = "test-deprecated-feature"
        (match_dir / "findings.json").write_text(json.dumps({
            "findings": [
                {"category": "novel_element_type",
                 "element_tag": target_tag,
                 "source_file": "customerA"},
                {"category": "novel_element_type",
                 "element_tag": "other-tag",
                 "source_file": "customerA"},
            ]
        }), encoding='utf-8')
        # Non-matching proposal
        nomatch_dir = proposals_root / "2026-05-02_customerB"
        nomatch_dir.mkdir()
        (nomatch_dir / "findings.json").write_text(json.dumps({
            "findings": [
                {"category": "novel_element_type",
                 "element_tag": "unrelated-tag",
                 "source_file": "customerB"},
            ]
        }), encoding='utf-8')

        matches = find_proposals_referencing_surface(
            target_tag, proposals_root=proposals_root)
        if len(matches) != 1:
            return False, f"expected 1 match, got {len(matches)}"
        if matches[0].name != "2026-05-01_customerA":
            return False, f"wrong proposal matched: {matches[0].name}"
        return True, ("deprecation propagation correctly identifies "
                      "proposals referencing deprecated surface")


def test_sla_aging_overdue_detection() -> tuple[bool, str]:
    """is_sla_overdue correctly flags Tier 2/3 entries past SLA."""
    cases = [
        # (tier, age_days, expected_overdue)
        (1, 365, False),       # Tier 1 indefinite — never overdue
        (2, 15, False),        # Tier 2 within 30
        (2, 35, True),         # Tier 2 over 30
        (3, 5, False),         # Tier 3 within 7
        (3, 10, True),         # Tier 3 over 7
        (1, None, False),      # Unknown age
    ]
    for tier, age, expected in cases:
        overdue, label = is_sla_overdue(tier, age)
        if overdue != expected:
            return False, (f"is_sla_overdue(tier={tier}, age={age}): "
                           f"got overdue={overdue}, expected {expected}")
    return True, f"is_sla_overdue correct on all {len(cases)} cases"


def test_phase4_cli_smoke() -> tuple[bool, str]:
    """All Phase 4 CLI subcommands accept --help without crashing."""
    triage = ROOT / 'schema_learner' / 'triage.py'
    cmds_to_test = [
        ['sideline', 'list', '--help'],
        ['sideline', 'claim', '--help'],
        ['sideline', 'promote', '--help'],
        ['deprecation', 'mark', '--help'],
        ['deprecation', 'list', '--help'],
        ['deprecation', 'show', '--help'],
        ['deprecation', 'propagate', '--help'],
    ]
    for cmd in cmds_to_test:
        r = subprocess.run([sys.executable, str(triage)] + cmd,
                           capture_output=True, text=True)
        if r.returncode != 0:
            return False, f"CLI failed: {' '.join(cmd)}: {r.stderr[:200]}"
    return True, f"all {len(cmds_to_test)} Phase 4 CLI subcommands respond"


def test_phase4_provenance_audit_clean() -> tuple[bool, str]:
    """Provenance audit must pass on Phase 4 output."""
    snap = _snapshot_state()
    try:
        # Synthesize one of each Phase 4 artifact
        unique_tag = f"test-audit-{uuid.uuid4().hex[:8]}"

        # Lab-verification artifact
        lv = LabVerification(
            firebox_model="T-30", firmware_version="12.11.0",
            verified_by="audit-test", verified_at="2026-05-07",
            test_result="PASS",
            test_notes="Audit-test: sufficient observations for the validator.",
        )
        write_lab_verification_artifact(unique_tag, lv)

        # Deprecation entry
        write_deprecation_entry(DeprecationEntry(
            surface_tag=unique_tag,
            deprecated_at="2026-05-07T10:00:00",
            deprecated_by="audit-test",
            vendor_citation="https://www.watchguard.com/audit-test",
            deprecation_reason="Audit fixture deprecation reason content.",
        ))

        audit = subprocess.run(
            [sys.executable,
             str(ROOT / 'harness'
                 / 'test_schema_learner_provenance.py')],
            capture_output=True, text=True,
        )
        if audit.returncode != 0:
            return False, ("provenance audit FAILED on Phase 4 output: "
                           f"{audit.stdout[:500]}")
        return True, "provenance audit clean on Phase 4 artifacts"
    finally:
        _restore_state(snap)


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

TESTS = [
    ("lab_verification_round_trips",
     test_lab_verification_round_trips),
    ("lab_verification_validates_required_fields",
     test_lab_verification_validates_required_fields),
    ("deep_research_promotion_validation_empty",
     test_deep_research_promotion_validation_empty),
    ("deep_research_promotion_validates_complete",
     test_deep_research_promotion_validates_complete),
    ("deep_research_rejects_lab_fail",
     test_deep_research_rejects_lab_fail),
    ("lab_verification_artifact_written",
     test_lab_verification_artifact_written),
    ("sideline_claim_workflow", test_sideline_claim_workflow),
    ("deprecation_registry_round_trip",
     test_deprecation_registry_round_trip),
    ("deprecation_propagation_finds_proposals",
     test_deprecation_propagation_finds_proposals),
    ("sla_aging_overdue_detection",
     test_sla_aging_overdue_detection),
    ("phase4_cli_smoke", test_phase4_cli_smoke),
    ("phase4_provenance_audit_clean",
     test_phase4_provenance_audit_clean),
]


def main() -> int:
    print("Phase 4 — Deep research + lab verification + deprecation tests")
    print()
    print(f"{'TEST':<55} {'RESULT':<8} DETAIL")
    print("-" * 95)
    fail = 0
    for name, fn in TESTS:
        try:
            ok, msg = fn()
        except Exception as e:
            ok, msg = False, f"EXC: {type(e).__name__}: {e}"
        status = "PASS" if ok else "FAIL"
        print(f"{name:<55} {status:<8} {msg[:140]}")
        if not ok:
            fail += 1
    print()
    if fail == 0:
        print(f"All {len(TESTS)} Phase 4 tests passed.")
        return 0
    print(f"{fail} of {len(TESTS)} Phase 4 tests FAILED.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
