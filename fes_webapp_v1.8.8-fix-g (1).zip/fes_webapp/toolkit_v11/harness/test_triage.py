#!/usr/bin/env python3
"""
test_triage.py
==============

Phase 2 regression tests for the four-state triage frontend.
Per DESIGN_team_scale_addendum.md.

Tests verify:
  1. Banned corpus storage round-trips (write, load, similarity match).
  2. Sideline queue storage round-trips with occurrence increment.
  3. Schema-learner integrates banned suppression: when a banned
     entry's surface tag and structural fingerprint are present in
     a new run, the matching surface gets banned_suppressed (not
     novel_element_type) and is routed to sideline.
  4. Triage CLI handlers for (h)armful and (s)ideline write the
     correct corpus tier with required fields.
  5. Provenance audit passes against banned/sideline output.
  6. Banned entry appeal lifecycle: active → held → restored OR
     active → held → unbanned, with audit fields populated.

The tests use synthetic findings and isolated temporary directories
where possible to avoid polluting the real corpus tiers.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "schema_learner"))

from corpus_tiers import (  # noqa: E402
    BannedEntry, SidelineEntry,
    _banned_index_path, _banned_root,
    _sideline_queue_path, _sideline_root,
    banned_suppression_similarity,
    check_banned_suppression,
    compute_sla_tier,
    fingerprint_from_feature_vector,
    find_existing_sideline_entry,
    load_banned_entries, load_sideline_queue,
    make_entry_id,
    write_banned_entry, write_sideline_entry,
)


# ---------------------------------------------------------------------------
# Helpers — backup/restore corpus tier state
# ---------------------------------------------------------------------------

def _snapshot_corpus_tiers() -> dict[str, bytes | None]:
    """Snapshot current banned and sideline state. Returns dict of
    paths to bytes (or None for non-existent files) so we can restore
    after each test without leaking state."""
    snap = {}
    for p in (_banned_index_path(), _sideline_queue_path()):
        if p.is_file():
            snap[str(p)] = p.read_bytes()
        else:
            snap[str(p)] = None
    # Also snapshot all .md files in both dirs
    for d in (_banned_root(), _sideline_root()):
        for md in d.glob('*.md'):
            snap[str(md)] = md.read_bytes()
    return snap


def _restore_corpus_tiers(snap: dict[str, bytes | None]) -> None:
    """Restore from a snapshot. Files not in snap are removed."""
    # Remove any files added since snapshot
    for d in (_banned_root(), _sideline_root()):
        for f in list(d.iterdir()):
            if str(f) not in snap and f.is_file():
                f.unlink()
    # Restore snapshot contents
    for path_str, contents in snap.items():
        p = Path(path_str)
        if contents is None:
            if p.is_file():
                p.unlink()
        else:
            p.write_bytes(contents)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_banned_entry_round_trip() -> tuple[bool, str]:
    """Write a banned entry, load it back, verify all fields preserved."""
    snap = _snapshot_corpus_tiers()
    try:
        unique_tag = f"test-banned-roundtrip-{uuid.uuid4().hex[:8]}"
        entry = BannedEntry(
            entry_id=make_entry_id(unique_tag, 'ban'),
            surface_tag=unique_tag,
            operator='test-suite-banned-roundtrip',
            timestamp='2026-05-06T12:00:00',
            reason='Test fixture: banned entry round-trip verification.',
            banned_draft_text='Synthetic LLM draft that was banned.',
            children_tags_fingerprint='child1, child2, child3',
            value_patterns_fingerprint='f1:port, f2:boolean-numeric',
            naming_tokens_fingerprint='test, banned, roundtrip',
            source_proposal='test_fixture_proposal',
            status='active',
        )
        write_banned_entry(entry)
        all_entries = load_banned_entries()
        # Find our entry (more specific than just last because of
        # potential test concurrency)
        loaded = next((e for e in all_entries
                       if e.entry_id == entry.entry_id), None)
        if loaded is None:
            return False, "banned entry not found after write/load"
        if loaded.surface_tag != unique_tag:
            return False, f"surface_tag mismatch: {loaded.surface_tag}"
        if 'banned entry round-trip' not in loaded.reason:
            return False, f"reason not preserved: {loaded.reason}"
        if loaded.children_tags_fingerprint != 'child1, child2, child3':
            return False, "fingerprint not preserved"
        if loaded.status != 'active':
            return False, f"status not preserved: {loaded.status}"
        return True, "banned entry round-trips with all fields preserved"
    finally:
        _restore_corpus_tiers(snap)


def test_sideline_entry_round_trip_with_occurrence_bump() -> tuple[bool, str]:
    """Write a sideline entry twice (same id) — verify occurrence increments."""
    snap = _snapshot_corpus_tiers()
    try:
        unique_tag = f"test-sideline-roundtrip-{uuid.uuid4().hex[:8]}"
        entry_id = make_entry_id(unique_tag, 'sl')
        entry = SidelineEntry(
            entry_id=entry_id,
            surface_tag=unique_tag,
            operator='test-suite-sideline',
            timestamp='2026-05-06T12:00:00',
            reason='Test fixture occurrence-bump verification.',
            first_seen_in='proposal_a',
            last_seen_in='proposal_a',
            last_seen_at='2026-05-06T12:00:00',
            children_tags_fingerprint='c1, c2',
            value_patterns_fingerprint='f1:port',
            naming_tokens_fingerprint='test, sideline',
            source_proposal='proposal_a',
            status='open',
        )
        write_sideline_entry(entry)
        # Second write with same entry_id — should bump occurrence
        entry.last_seen_in = 'proposal_b'
        entry.last_seen_at = '2026-05-06T13:00:00'
        write_sideline_entry(entry)

        all_entries = load_sideline_queue()
        loaded = next((e for e in all_entries
                       if e.entry_id == entry_id), None)
        if loaded is None:
            return False, "sideline entry not found after write/load"
        if loaded.occurrence_count != 2:
            return False, (f"expected occurrence_count=2 after second "
                           f"write, got {loaded.occurrence_count}")
        if loaded.last_seen_in != 'proposal_b':
            return False, f"last_seen_in not updated: {loaded.last_seen_in}"
        return True, ("sideline entry round-trips, occurrence_count "
                      "bumps correctly")
    finally:
        _restore_corpus_tiers(snap)


def test_sla_tier_calculation() -> tuple[bool, str]:
    """compute_sla_tier maps occurrence_count to the right tier."""
    cases = [
        (1, 1), (2, 1),                   # Tier 1: 1-2
        (3, 2), (5, 2), (9, 2),           # Tier 2: 3-9
        (10, 3), (50, 3), (100, 3),       # Tier 3: 10+
    ]
    for count, expected in cases:
        actual = compute_sla_tier(count)
        if actual != expected:
            return False, (f"compute_sla_tier({count}) = {actual}, "
                           f"expected {expected}")
    return True, f"all {len(cases)} SLA tier cases correct"


def test_banned_suppression_similarity_works() -> tuple[bool, str]:
    """check_banned_suppression returns the matched entry above threshold."""
    snap = _snapshot_corpus_tiers()
    try:
        unique_tag = f"test-suppression-{uuid.uuid4().hex[:8]}"
        # Write a banned entry with known fingerprint
        entry = BannedEntry(
            entry_id=make_entry_id(unique_tag, 'ban'),
            surface_tag=unique_tag,
            operator='test-suite',
            timestamp='2026-05-06T12:00:00',
            reason='Test: suppression similarity check.',
            children_tags_fingerprint='alpha, beta, gamma, delta',
            value_patterns_fingerprint='f1:port, f2:boolean-numeric',
            naming_tokens_fingerprint='test, suppression, check',
            status='active',
        )
        write_banned_entry(entry)

        # Identical fingerprint should match
        candidate_fp = {
            'children_tags_fingerprint': 'alpha, beta, gamma, delta',
            'value_patterns_fingerprint': 'f1:port, f2:boolean-numeric',
            'naming_tokens_fingerprint': 'test, suppression, check',
        }
        match = check_banned_suppression(
            candidate_fp, unique_tag, threshold=0.80)
        if match is None:
            return False, "identical fingerprint should match — got None"
        matched_entry, similarity = match
        if matched_entry.entry_id != entry.entry_id:
            return False, "matched wrong entry"
        if similarity < 0.99:
            return False, f"identical fingerprints should score ~1.0, got {similarity}"

        # Wrong surface tag should NOT match (per addendum disambiguation)
        match_wrong_tag = check_banned_suppression(
            candidate_fp, "different-surface", threshold=0.80)
        if match_wrong_tag is not None:
            return False, ("mismatched surface tag should NOT suppress "
                           "(addendum disambiguation rule)")
        return True, ("suppression matches identical fingerprint and "
                      "respects surface-tag disambiguation")
    finally:
        _restore_corpus_tiers(snap)


def test_banned_held_status_disables_suppression() -> tuple[bool, str]:
    """An entry with status='held' should NOT cause suppression
    (appeal mechanism per addendum risk management)."""
    snap = _snapshot_corpus_tiers()
    try:
        unique_tag = f"test-held-{uuid.uuid4().hex[:8]}"
        entry = BannedEntry(
            entry_id=make_entry_id(unique_tag, 'ban'),
            surface_tag=unique_tag,
            operator='test-suite',
            timestamp='2026-05-06T12:00:00',
            reason='Test: held status check.',
            children_tags_fingerprint='alpha, beta',
            value_patterns_fingerprint='f1:port',
            naming_tokens_fingerprint='test, held',
            status='held',  # appeal in progress
        )
        write_banned_entry(entry)
        candidate_fp = {
            'children_tags_fingerprint': 'alpha, beta',
            'value_patterns_fingerprint': 'f1:port',
            'naming_tokens_fingerprint': 'test, held',
        }
        match = check_banned_suppression(
            candidate_fp, unique_tag, threshold=0.80)
        if match is not None:
            return False, ("entry with status='held' caused suppression "
                           "— violates appeal mechanism")
        return True, "held status correctly disables suppression"
    finally:
        _restore_corpus_tiers(snap)


def test_existing_sideline_match() -> tuple[bool, str]:
    """find_existing_sideline_entry returns the entry when a similar
    surface is sidelined again."""
    snap = _snapshot_corpus_tiers()
    try:
        unique_tag = f"test-find-existing-{uuid.uuid4().hex[:8]}"
        entry = SidelineEntry(
            entry_id=make_entry_id(unique_tag, 'sl'),
            surface_tag=unique_tag,
            operator='test',
            timestamp='2026-05-06',
            reason='test',
            first_seen_in='p1',
            last_seen_in='p1',
            last_seen_at='2026-05-06',
            children_tags_fingerprint='x, y, z',
            value_patterns_fingerprint='f:port',
            naming_tokens_fingerprint='test, find, existing',
            source_proposal='p1',
        )
        write_sideline_entry(entry)
        candidate_fp = {
            'children_tags_fingerprint': 'x, y, z',
            'value_patterns_fingerprint': 'f:port',
            'naming_tokens_fingerprint': 'test, find, existing',
        }
        existing = find_existing_sideline_entry(
            unique_tag, candidate_fp, similarity_threshold=0.80)
        if existing is None:
            return False, "should have matched existing sideline entry"
        return True, "find_existing_sideline_entry detects re-occurrence"
    finally:
        _restore_corpus_tiers(snap)


def test_triage_cli_smoke() -> tuple[bool, str]:
    """The triage CLI subcommands all work without crashing on empty state."""
    # Snapshot first (writes test entries during this test)
    snap = _snapshot_corpus_tiers()
    try:
        triage = ROOT / 'schema_learner' / 'triage.py'
        # sideline list
        r = subprocess.run([sys.executable, str(triage), 'sideline', 'list'],
                           capture_output=True, text=True)
        if r.returncode != 0:
            return False, f"sideline list failed: {r.stderr[:200]}"
        # banned list
        r = subprocess.run([sys.executable, str(triage), 'banned', 'list'],
                           capture_output=True, text=True)
        if r.returncode != 0:
            return False, f"banned list failed: {r.stderr[:200]}"
        return True, "triage CLI subcommands smoke-tested clean"
    finally:
        _restore_corpus_tiers(snap)


def test_phase2_provenance_audit_clean() -> tuple[bool, str]:
    """The provenance audit must pass on Phase 2 corpus output. Write
    a synthetic banned and sideline entry, then run the audit."""
    snap = _snapshot_corpus_tiers()
    try:
        # Synthesize one of each
        bunique = f"test-audit-banned-{uuid.uuid4().hex[:8]}"
        bentry = BannedEntry(
            entry_id=make_entry_id(bunique, 'ban'),
            surface_tag=bunique,
            operator='audit-test',
            timestamp='2026-05-06',
            reason='Audit test: ensure provenance markers used.',
            children_tags_fingerprint='a, b',
            value_patterns_fingerprint='f:port',
            naming_tokens_fingerprint='audit, test',
            source_proposal='audit_test_proposal',
            status='active',
        )
        write_banned_entry(bentry)

        sunique = f"test-audit-sideline-{uuid.uuid4().hex[:8]}"
        sentry = SidelineEntry(
            entry_id=make_entry_id(sunique, 'sl'),
            surface_tag=sunique,
            operator='audit-test',
            timestamp='2026-05-06',
            reason='Audit test: ensure provenance markers used.',
            first_seen_in='audit_proposal',
            last_seen_in='audit_proposal',
            last_seen_at='2026-05-06',
            children_tags_fingerprint='x, y',
            value_patterns_fingerprint='f:port',
            naming_tokens_fingerprint='audit, sideline',
            source_proposal='audit_proposal',
            status='open',
        )
        write_sideline_entry(sentry)

        audit = subprocess.run(
            [sys.executable,
             str(ROOT / 'harness' / 'test_schema_learner_provenance.py')],
            capture_output=True, text=True,
        )
        if audit.returncode != 0:
            return False, ("provenance audit FAILED on Phase 2 output: "
                           f"{audit.stdout[:500]}")
        return True, "provenance audit clean on banned + sideline output"
    finally:
        _restore_corpus_tiers(snap)


def test_banned_appeal_lifecycle_unban() -> tuple[bool, str]:
    """active → held → unbanned with audit fields populated."""
    snap = _snapshot_corpus_tiers()
    try:
        unique_tag = f"test-appeal-unban-{uuid.uuid4().hex[:8]}"
        entry_id = make_entry_id(unique_tag, 'ban')
        entry = BannedEntry(
            entry_id=entry_id,
            surface_tag=unique_tag,
            operator='original-operator',
            timestamp='2026-05-06T10:00:00',
            reason='Original ban reason.',
            children_tags_fingerprint='a, b',
            value_patterns_fingerprint='f:port',
            naming_tokens_fingerprint='test, appeal',
            status='active',
        )
        write_banned_entry(entry)

        # Appeal — mark held
        triage = ROOT / 'schema_learner' / 'triage.py'
        r = subprocess.run(
            [sys.executable, str(triage), 'banned', 'appeal',
             '--entry-id', entry_id, '--operator', 'appellant'],
            capture_output=True, text=True,
        )
        if r.returncode != 0:
            return False, f"appeal failed: {r.stderr[:200]}"
        loaded = next((e for e in load_banned_entries()
                       if e.entry_id == entry_id), None)
        if loaded is None or loaded.status != 'held':
            return False, ("appeal did not set status=held (got "
                           f"{loaded.status if loaded else 'None'})")

        # Resolve — unban with reason
        r = subprocess.run(
            [sys.executable, str(triage), 'banned', 'resolve',
             '--entry-id', entry_id, '--action', 'unban',
             '--operator', 'reviewer',
             '--reason', 'Appeal granted: the original ban was a false positive.'],
            capture_output=True, text=True,
        )
        if r.returncode != 0:
            return False, f"resolve failed: {r.stderr[:200]}"
        loaded = next((e for e in load_banned_entries()
                       if e.entry_id == entry_id), None)
        if loaded is None or loaded.status != 'unbanned':
            return False, (f"unban did not set status=unbanned "
                           f"(got {loaded.status if loaded else 'None'})")
        if not loaded.unbanned_by or not loaded.unban_reason:
            return False, "unban audit fields not populated"
        return True, "active → held → unbanned lifecycle with audit fields"
    finally:
        _restore_corpus_tiers(snap)


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

TESTS = [
    ("banned_entry_round_trip", test_banned_entry_round_trip),
    ("sideline_entry_round_trip_with_occurrence_bump",
     test_sideline_entry_round_trip_with_occurrence_bump),
    ("sla_tier_calculation", test_sla_tier_calculation),
    ("banned_suppression_similarity_works",
     test_banned_suppression_similarity_works),
    ("banned_held_status_disables_suppression",
     test_banned_held_status_disables_suppression),
    ("existing_sideline_match", test_existing_sideline_match),
    ("triage_cli_smoke", test_triage_cli_smoke),
    ("phase2_provenance_audit_clean", test_phase2_provenance_audit_clean),
    ("banned_appeal_lifecycle_unban", test_banned_appeal_lifecycle_unban),
]


def main() -> int:
    print("Phase 2 — Triage frontend + corpus tiers tests")
    print()
    print(f"{'TEST':<55} {'RESULT':<8} DETAIL")
    print("-" * 95)
    fail = 0
    for name, fn in TESTS:
        try:
            ok, msg = fn()
        except Exception as e:
            ok, msg = False, f"EXC: {type(e).__name__}: {e}"
        status = "PASS" if ok else "FAIL"
        print(f"{name:<55} {status:<8} {msg[:140]}")
        if not ok:
            fail += 1
    print()
    if fail == 0:
        print(f"All {len(TESTS)} Phase 2 tests passed.")
        return 0
    print(f"{fail} of {len(TESTS)} Phase 2 tests FAILED.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
