#!/usr/bin/env python3
"""
test_phase3_llm.py
==================

Phase 3 regression tests for LLM drafting + citation verification.
Per DESIGN_team_scale_addendum.md.

Tests use StubProvider with deterministic responses — never go over
the network, never depend on API keys. The stub is the right tool
for testing the orchestration logic; the real Anthropic API
integration is exercised in production deployments.

Tests verify:
  1. The four-turn interview flow produces a complete LLMDraft
     when the LLM cooperates.
  2. Citation verification correctly downgrades confidence when
     URLs aren't reachable.
  3. Aggregate confidence respects the worst-of-four rule.
  4. Self-validation failure forces overall confidence to low.
  5. Draft serialization round-trips through JSON.
  6. The triage CLI's _format_draft_for_operator renders cleanly.
  7. Provenance audit passes against draft markdown rendering.
  8. The 'no-citation' admission pattern is honored.
  9. The MCP factory returns None when disabled or no key.

The bar these tests hold: the LLM CANNOT produce a high-confidence
draft without a verified citation. This is the principle binding
mechanically.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "schema_learner"))

from llm_provider import (  # noqa: E402
    AnthropicProvider, CitedClaim, LLMDraft, LLMDrafter,
    StubProvider, build_provider_from_config,
    relevant_terms_from_surface, verify_citation_url,
    _is_no_citation, _is_url, _is_yes,
    _parse_extract_response,
)


# ---------------------------------------------------------------------------
# Stub response fixtures
# ---------------------------------------------------------------------------

def _build_complete_stub() -> StubProvider:
    """A stub that produces a complete draft with a fake citation URL.
    The URL won't fetch (it's example.com/docs/...), so verification
    will fail and confidence will be low. That's the principle in
    action: the stub LLM produced a structured draft, but lack of
    verification kept confidence low."""
    return StubProvider(responses=[
        # Turn 1: discovery
        ('In 2-3 sentences', (
            "The vpn-portal element configures the WatchGuard Access "
            "Portal — a clientless web-based VPN where remote users "
            "authenticate to a browser page. It is distinct from "
            "tunnel-based VPN configurations in WatchGuard."
        )),
        # Turn 2: extraction
        ('Q1_PURPOSE:', (
            "Q1_PURPOSE: Configures the WatchGuard Access Portal, a "
            "browser-based clientless VPN feature.\n"
            "Q1_SOURCE: https://www.example.com/docs/access-portal\n"
            "\n"
            "Q2_CATEGORY: html-web-app\n"
            "Q2_SOURCE: https://www.example.com/docs/access-portal\n"
            "\n"
            "Q3_SW_EQUIVALENT: SonicWall Virtual Office (SSL-VPN web portal)\n"
            "Q3_SOURCE: Field experience\n"
            "\n"
            "Q4_OPERATIONAL: Bookmarks may need to be rebuilt; CSS "
            "branding does not transfer.\n"
            "Q4_SOURCE: Field experience\n"
        )),
        # Turn 3: self-validation
        ('Are these answers internally consistent', "yes"),
    ])


def _build_unknown_stub() -> StubProvider:
    """A stub that admits it doesn't know — produces drafts with
    'no citation found' markers."""
    return StubProvider(responses=[
        ('In 2-3 sentences', (
            "I don't recognize this element from training. Marking "
            "as low confidence."
        )),
        ('Q1_PURPOSE:', (
            "Q1_PURPOSE: Unknown element — I cannot confidently say "
            "what this configures.\n"
            "Q1_SOURCE: no citation found\n"
            "\n"
            "Q2_CATEGORY: administrative\n"
            "Q2_SOURCE: no citation found\n"
            "\n"
            "Q3_SW_EQUIVALENT: none — net-new on WatchGuard\n"
            "Q3_SOURCE: no citation found\n"
            "\n"
            "Q4_OPERATIONAL: Operator must research before relying on this draft.\n"
            "Q4_SOURCE: no citation found\n"
        )),
        ('Are these answers internally consistent', "no"),
    ])


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_drafter_produces_complete_draft_on_stub() -> tuple[bool, str]:
    """Four-turn interview against a cooperative stub produces a
    fully-populated LLMDraft."""
    stub = _build_complete_stub()
    drafter = LLMDrafter(provider=stub, verify_citations=False)
    structural_facts = {
        'naming_tokens': ['vpn', 'portal'],
        'top_children_tags': [['logon-banner', 1], ['custom-logo', 1]],
        'value_pattern_summary': {},
    }
    draft = drafter.draft(
        surface_tag='vpn-portal',
        structural_facts=structural_facts,
        neighbors=[],
    )
    if not draft.is_complete():
        return False, (f"draft incomplete: notes={draft.drafting_notes}, "
                       f"purpose={draft.purpose.claim_text[:60]!r}")
    if 'Access Portal' not in draft.purpose.claim_text:
        return False, f"Q1 not parsed: {draft.purpose.claim_text[:80]!r}"
    if draft.category.claim_text != 'html-web-app':
        return False, f"Q2 not parsed: {draft.category.claim_text!r}"
    if 'SonicWall Virtual Office' not in draft.sonicwall_equivalent.claim_text:
        return False, f"Q3 not parsed: {draft.sonicwall_equivalent.claim_text!r}"
    if not draft.self_validation_passed:
        return False, (f"self-validation should have passed on 'yes' "
                       f"but got: {draft.self_validation_response!r}")
    return True, "four-turn interview produces complete draft"


def test_citation_verification_downgrades_low_when_url_unreachable() -> tuple[bool, str]:
    """When verify_citations=True and the cited URL doesn't fetch
    (or fetches but lacks relevant terms), confidence stays low."""
    stub = _build_complete_stub()
    drafter = LLMDrafter(provider=stub, verify_citations=True,
                         verification_timeout=3)
    structural_facts = {
        'naming_tokens': ['vpn', 'portal'],
        'top_children_tags': [],
        'value_pattern_summary': {},
    }
    draft = drafter.draft(
        surface_tag='vpn-portal',
        structural_facts=structural_facts,
    )
    # The stub's URL is example.com/docs/access-portal which does not
    # serve a page mentioning 'vpn-portal' — verification fails.
    if draft.purpose.confidence == 'high':
        return False, ("verified URL that shouldn't have been verifiable "
                       "(example.com/docs/access-portal contains 'vpn-portal'?)")
    if draft.overall_confidence == 'high':
        return False, "overall confidence high despite unverified citations"
    return True, ("citation verification correctly downgrades confidence "
                  "when URL doesn't contain relevant terms")


def test_no_citation_admission_keeps_low_confidence() -> tuple[bool, str]:
    """When the LLM admits 'no citation found', confidence is low and
    the reason explicitly notes operator must research.
    
    Note: the no-citation handling lives inside _verify_claim, so
    verification must be enabled for this path to run. With
    verify_citations=False, claims stay at their default 'not yet
    verified' reason — that's a valid state, just not what this
    specific path tests."""
    stub = _build_unknown_stub()
    drafter = LLMDrafter(provider=stub, verify_citations=True,
                         verification_timeout=3)
    draft = drafter.draft(
        surface_tag='unknown-element',
        structural_facts={'naming_tokens': ['unknown']},
    )
    if draft.purpose.confidence != 'low':
        return False, (f"expected low confidence on no-citation draft, "
                       f"got {draft.purpose.confidence!r}")
    if 'research' not in draft.purpose.confidence_reason.lower():
        return False, (f"confidence_reason should mention research, "
                       f"got: {draft.purpose.confidence_reason!r}")
    if draft.overall_confidence != 'low':
        return False, ("self-validation said 'no' AND citations were absent, "
                       "overall confidence must be low")
    return True, "no-citation admission honored across all fields"


def test_aggregate_confidence_worst_of_four() -> tuple[bool, str]:
    """If any one of Q1-Q4 has low confidence, overall is low — even
    if other three would be high."""
    stub = _build_complete_stub()
    drafter = LLMDrafter(provider=stub, verify_citations=False)
    draft = drafter.draft(
        surface_tag='vpn-portal',
        structural_facts={'naming_tokens': ['vpn', 'portal']},
    )
    # Manually set three high, one low — overall should be low
    draft.purpose.confidence = 'high'
    draft.category.confidence = 'high'
    draft.sonicwall_equivalent.confidence = 'high'
    draft.operational_notes.confidence = 'low'
    draft.self_validation_passed = True  # remove the validation penalty
    overall = LLMDrafter._aggregate_confidence(draft)
    if overall != 'low':
        return False, (f"three high + one low should aggregate to low, "
                       f"got {overall!r}")
    return True, "aggregate confidence is worst-of-four"


def test_self_validation_failure_forces_low() -> tuple[bool, str]:
    """If self-validation says 'no', overall confidence is low even
    when all four claims would otherwise be high."""
    draft = LLMDraft(surface_tag='x')
    draft.purpose = CitedClaim(claim_text='ok', confidence='high')
    draft.category = CitedClaim(claim_text='ok', confidence='high')
    draft.sonicwall_equivalent = CitedClaim(claim_text='ok',
                                             confidence='high')
    draft.operational_notes = CitedClaim(claim_text='ok',
                                          confidence='high')
    draft.self_validation_passed = False
    overall = LLMDrafter._aggregate_confidence(draft)
    if overall != 'low':
        return False, (f"self-validation failed but overall is {overall!r}, "
                       f"expected low")
    return True, "self-validation failure forces overall=low"


def test_draft_serialization_round_trip() -> tuple[bool, str]:
    """LLMDraft → JSON → LLMDraft preserves all fields."""
    stub = _build_complete_stub()
    drafter = LLMDrafter(provider=stub, verify_citations=False)
    draft = drafter.draft(
        surface_tag='vpn-portal',
        structural_facts={'naming_tokens': ['vpn', 'portal']},
    )
    if not draft.is_complete():
        return False, "drafter didn't produce complete draft"
    # Serialize → deserialize via the triage helpers
    sys.path.insert(0, str(ROOT / "schema_learner"))
    from triage import _serialize_draft, _deserialize_draft
    payload = _serialize_draft(draft)
    json_str = json.dumps(payload)
    loaded = _deserialize_draft(json.loads(json_str))
    if loaded.surface_tag != draft.surface_tag:
        return False, "surface_tag not preserved"
    if loaded.purpose.claim_text != draft.purpose.claim_text:
        return False, "Q1 not preserved"
    if loaded.self_validation_passed != draft.self_validation_passed:
        return False, "self_validation_passed not preserved"
    if loaded.overall_confidence != draft.overall_confidence:
        return False, "overall_confidence not preserved"
    return True, "draft serialization round-trips through JSON cleanly"


def test_format_draft_renders_clean() -> tuple[bool, str]:
    """The triage display formatter doesn't raise and produces output
    with confidence markers."""
    sys.path.insert(0, str(ROOT / "schema_learner"))
    from triage import _format_draft_for_operator
    stub = _build_complete_stub()
    drafter = LLMDrafter(provider=stub, verify_citations=False)
    draft = drafter.draft(
        surface_tag='vpn-portal',
        structural_facts={'naming_tokens': ['vpn', 'portal']},
    )
    rendered = _format_draft_for_operator(draft)
    if 'LLM DRAFT' not in rendered:
        return False, "rendered output missing LLM DRAFT header"
    if 'Q1 Purpose' not in rendered:
        return False, "rendered output missing Q1 label"
    # Confidence marker symbols should be present
    if not any(m in rendered for m in ('✗', '~', '✓')):
        return False, "rendered output missing confidence markers"
    return True, "draft renders cleanly with confidence markers"


def test_phase3_provenance_audit_clean() -> tuple[bool, str]:
    """The provenance audit must pass on Phase 3 output."""
    audit = subprocess.run(
        [sys.executable, str(ROOT / 'harness'
                        / 'test_schema_learner_provenance.py')],
        capture_output=True, text=True,
    )
    if audit.returncode != 0:
        return False, ("provenance audit FAILED on Phase 3 output: "
                       f"{audit.stdout[:300]}")
    return True, "provenance audit clean on Phase 3 output"


def test_mcp_factory_returns_none_when_disabled() -> tuple[bool, str]:
    """build_provider_from_config returns None when [mcp] enabled=false
    or when API key env var is empty."""
    # Disabled
    p = build_provider_from_config({
        'enabled': 'false',
        'api_key_env_var': 'ANTHROPIC_API_KEY',
        'model': 'claude-haiku-4-5-20251001',
    })
    if p is not None:
        return False, "factory returned provider when enabled=false"
    # Enabled but no key
    saved_key = os.environ.pop('ANTHROPIC_API_KEY', None)
    try:
        p = build_provider_from_config({
            'enabled': 'true',
            'api_key_env_var': 'ANTHROPIC_API_KEY',
            'model': 'claude-haiku-4-5-20251001',
        })
        if p is not None:
            return False, "factory returned provider when no key available"
    finally:
        if saved_key is not None:
            os.environ['ANTHROPIC_API_KEY'] = saved_key
    return True, "factory correctly returns None when disabled or no key"


def test_factory_dispatches_to_gpt4all_provider() -> tuple[bool, str]:
    """When provider=gpt4all and the GPT4All server is unreachable
    (which is always true in CI), the factory returns None gracefully —
    no exception leaking to the caller."""
    # Use a guaranteed-unreachable port so test is deterministic.
    p = build_provider_from_config({
        'enabled': 'true',
        'provider': 'gpt4all',
        'gpt4all_host': 'localhost',
        'gpt4all_port': '1',  # port 1 is reserved, won't bind
        'gpt4all_model': 'Llama 3 8B Instruct',
    })
    if p is not None:
        return False, ("factory should return None when GPT4All "
                       "server is unreachable")
    return True, "GPT4All provider unreachable → factory returns None"


def test_factory_unknown_provider_returns_none() -> tuple[bool, str]:
    """Unknown provider name fails closed (returns None), not raises."""
    p = build_provider_from_config({
        'enabled': 'true',
        'provider': 'definitely-not-a-real-provider',
    })
    if p is not None:
        return False, "unknown provider should return None"
    return True, "unknown provider name fails closed cleanly"


def test_gpt4all_provider_class_shape() -> tuple[bool, str]:
    """GPT4AllProvider satisfies the LLMProvider Protocol shape: has
    is_available, model_label, generate(prompt). is_available returns
    False when server isn't running; generate returns empty string on
    network failure (not raise)."""
    from llm_provider import GPT4AllProvider
    p = GPT4AllProvider(host='localhost', port=1, model='test',
                         timeout=2)
    if p.is_available:
        return False, ("expected is_available=False with unreachable "
                       "server")
    if not p.model_label.startswith('gpt4all:'):
        return False, f"model_label format wrong: {p.model_label!r}"
    out = p.generate("test prompt")
    if out != "":
        return False, ("expected empty string on network failure, "
                       f"got {out!r}")
    return True, ("GPT4AllProvider satisfies Protocol shape, fails "
                  "gracefully on unreachable server")


def test_relevant_terms_includes_tag_and_tokens() -> tuple[bool, str]:
    """relevant_terms_from_surface returns the surface tag plus naming
    tokens. The dehyphenated form is also included for compound tags."""
    terms = relevant_terms_from_surface('vpn-portal', ['vpn', 'portal'])
    if 'vpn-portal' not in terms:
        return False, "surface tag missing from relevant terms"
    if 'vpn' not in terms or 'portal' not in terms:
        return False, "naming tokens missing from relevant terms"
    if 'vpnportal' not in terms:
        return False, "dehyphenated form missing for compound tag"
    return True, "relevant_terms includes tag, tokens, and dehyphenated form"


def test_url_and_citation_helpers() -> tuple[bool, str]:
    """_is_url and _is_no_citation classify their inputs correctly."""
    cases_url = [
        ('https://example.com/foo', True),
        ('http://example.com', True),
        ('Field experience', False),
        ('', False),
        ('no citation found', False),
    ]
    for inp, want in cases_url:
        if _is_url(inp) != want:
            return False, f"_is_url({inp!r}) = {_is_url(inp)}, want {want}"
    cases_nc = [
        ('no citation found', True),
        ('not found', True),
        ('unknown', True),
        ('https://example.com', False),
        ('', True),
        ('Field experience', False),
    ]
    for inp, want in cases_nc:
        if _is_no_citation(inp) != want:
            return False, (f"_is_no_citation({inp!r}) = "
                           f"{_is_no_citation(inp)}, want {want}")
    return True, "url and citation helpers classify correctly"


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

TESTS = [
    ("drafter_produces_complete_draft_on_stub",
     test_drafter_produces_complete_draft_on_stub),
    ("citation_verification_downgrades_low_when_url_unreachable",
     test_citation_verification_downgrades_low_when_url_unreachable),
    ("no_citation_admission_keeps_low_confidence",
     test_no_citation_admission_keeps_low_confidence),
    ("aggregate_confidence_worst_of_four",
     test_aggregate_confidence_worst_of_four),
    ("self_validation_failure_forces_low",
     test_self_validation_failure_forces_low),
    ("draft_serialization_round_trip",
     test_draft_serialization_round_trip),
    ("format_draft_renders_clean",
     test_format_draft_renders_clean),
    ("phase3_provenance_audit_clean",
     test_phase3_provenance_audit_clean),
    ("mcp_factory_returns_none_when_disabled",
     test_mcp_factory_returns_none_when_disabled),
    ("factory_dispatches_to_gpt4all_provider",
     test_factory_dispatches_to_gpt4all_provider),
    ("factory_unknown_provider_returns_none",
     test_factory_unknown_provider_returns_none),
    ("gpt4all_provider_class_shape",
     test_gpt4all_provider_class_shape),
    ("relevant_terms_includes_tag_and_tokens",
     test_relevant_terms_includes_tag_and_tokens),
    ("url_and_citation_helpers",
     test_url_and_citation_helpers),
]


def main() -> int:
    print("Phase 3 — LLM drafting + citation verification tests")
    print()
    print(f"{'TEST':<55} {'RESULT':<8} DETAIL")
    print("-" * 95)
    fail = 0
    for name, fn in TESTS:
        try:
            ok, msg = fn()
        except Exception as e:
            ok, msg = False, f"EXC: {type(e).__name__}: {e}"
        status = "PASS" if ok else "FAIL"
        print(f"{name:<55} {status:<8} {msg[:140]}")
        if not ok:
            fail += 1
    print()
    if fail == 0:
        print(f"All {len(TESTS)} Phase 3 tests passed.")
        return 0
    print(f"{fail} of {len(TESTS)} Phase 3 tests FAILED.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
