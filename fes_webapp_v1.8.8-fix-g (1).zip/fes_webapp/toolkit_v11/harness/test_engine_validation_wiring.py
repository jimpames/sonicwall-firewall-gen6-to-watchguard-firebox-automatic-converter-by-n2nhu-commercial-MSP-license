#!/usr/bin/env python3
"""
test_engine_validation_wiring.py
=================================

Confirms every engine's main() correctly invokes schema_lib's
validate_at_startup helper before doing real work, and that the
--strict and --no-validate flags work as documented.

For each engine, this exercises three scenarios:

    1. CLEAN: run with the real config; expect rc=0 and the
       'validates cleanly' banner on stderr.
    2. --NO-VALIDATE: run with --no-validate; expect rc=0 and NO
       validation banner on stderr.
    3. BROKEN + --STRICT: run with a config that has a real schema
       error (missing required field); expect rc=3 (strict abort).

Run as a standalone script from anywhere; locates the toolkit by the
test file's path.
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from schema_lib import comment_preserving_ini as cpi  # noqa: E402


ENGINES = [
    # (engine_dir, script, config_filename, extra_argv_for_clean_run)
    ("sonicwall_parser", "sonicwall_parser.py", "parser_config.ini",
        ["--input", "input/slimmed-sonicwallconfig.txt"]),
    ("enricher",         "enricher.py",         "enrich_config.ini",         []),
    ("xml_emitter",      "xml_emitter.py",      "xml_emit_config.ini",       []),
    ("xml_emitter",      "make_skeleton.py",    "skeleton_config.ini",       []),
    ("diff_scorer",      "diff_scorer.py",      "diff_score_config.ini",     []),
]


def break_config_with_error(src: Path) -> Path:
    """Make a copy of src with a real schema error injected.

    Drops the required `version` field from [meta]. Every schema marks
    that field required, so this reliably produces 1 validation error.
    """
    dst = Path(f"/tmp/broken_{src.name}")
    shutil.copy(src, dst)
    sch_src = src.with_suffix(".schema.ini")
    if sch_src.is_file():
        shutil.copy(sch_src, dst.with_suffix(".schema.ini"))
    doc = cpi.parse(dst)
    cpi.delete_key(doc, "meta", "version")
    cpi.write(doc, dst)
    return dst


def _abs(extra: list[str], engine_dir: Path) -> list[str]:
    """Convert relative file-path arguments to absolute paths so they
    resolve regardless of cwd."""
    out = []
    for a in extra:
        if Path(a).suffix in (".txt", ".xml", ".json", ".ini"):
            out.append(str((engine_dir / a).resolve()))
        else:
            out.append(a)
    return out


def run(cmd: list[str], cwd: Path, timeout: int = 180) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout
    )


def test_engine(eng_dir: str, script: str, cfg: str,
                extra: list[str]) -> tuple[int, list[str]]:
    """Run all three scenarios for one engine. Returns (failures, messages)."""
    e_dir = ROOT / eng_dir
    cfg_path = e_dir / cfg
    fails: list[str] = []

    # 1. Clean run
    r = run([sys.executable, script, "--config", cfg, *extra], e_dir)
    if r.returncode != 0:
        fails.append(f"  CLEAN: rc={r.returncode} (expected 0)")
    if "validates cleanly" not in r.stderr:
        fails.append("  CLEAN: missing 'validates cleanly' banner on stderr")

    # 2. --no-validate
    r = run([sys.executable, script, "--config", cfg, "--no-validate", *extra], e_dir)
    if r.returncode != 0:
        fails.append(f"  NO-VALIDATE: rc={r.returncode} (expected 0)")
    if "validates cleanly" in r.stderr:
        fails.append("  NO-VALIDATE: banner appeared (should be suppressed)")
    if "no sibling schema" in r.stderr:
        fails.append("  NO-VALIDATE: no-schema message appeared")

    # 3. Broken config + --strict
    broken = break_config_with_error(cfg_path)
    try:
        r = run(
            [sys.executable, script, "--config", str(broken),
             "--strict", *_abs(extra, e_dir)],
            e_dir,
        )
        if r.returncode != 3:
            fails.append(
                f"  BROKEN+STRICT: rc={r.returncode} (expected 3)\n"
                f"    stderr: {r.stderr[:300]}"
            )
    finally:
        broken.unlink(missing_ok=True)
        broken.with_suffix(".schema.ini").unlink(missing_ok=True)

    return len(fails), fails


def main() -> int:
    print(f"Engine validation-wiring smoke matrix")
    print(f"Toolkit root: {ROOT}\n")
    print(f"{'ENGINE':<40} {'CLEAN':<8} {'NO-VAL':<8} {'STRICT':<8}")
    print("-" * 70)

    grand_fail = 0
    for eng_dir, script, cfg, extra in ENGINES:
        label = f"{eng_dir}/{script}"
        fails, msgs = test_engine(eng_dir, script, cfg, extra)
        # Map fail-messages to per-scenario flags
        flags = {"CLEAN": "✓", "NO-VALIDATE": "✓", "BROKEN+STRICT": "✓"}
        for m in msgs:
            for k in flags:
                if k in m:
                    flags[k] = "✗"
        print(
            f"{label:<40} "
            f"{flags['CLEAN']:<8} {flags['NO-VALIDATE']:<8} "
            f"{flags['BROKEN+STRICT']:<8}"
        )
        for m in msgs:
            print(m)
        grand_fail += fails

    print()
    if grand_fail == 0:
        print(f"All {len(ENGINES) * 3} scenarios passed.")
        return 0
    print(f"{grand_fail} scenario failures.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
