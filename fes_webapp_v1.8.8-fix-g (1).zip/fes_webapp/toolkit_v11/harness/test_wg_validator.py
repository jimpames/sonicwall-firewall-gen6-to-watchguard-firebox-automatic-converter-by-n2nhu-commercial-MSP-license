#!/usr/bin/env python3
"""
test_wg_validator.py
=====================

Regression tests for the standalone WatchGuard XML validator.

Test scenarios:

    1. Loads schema cleanly: wg_xml_schema.ini parses without ConfigParser
       or schema-loader errors.
    2. Validates the reference XML cleanly: when fed the same T-30
       export it was bootstrapped from, the validator produces ZERO
       errors. (Warnings are tolerable while the schema is still
       hand-curated; errors mean a logic bug.)
    3. Validates the slim-sample emitter output: ensures the slim
       pipeline output runs through the validator without crashing.
       Produces a baseline issue-count we can use to detect drift.
    4. Catches injected errors: synthetically corrupts an XML and
       confirms the validator flags the corruption.

Each test is small and isolated. The test prints a clear pass/fail
verdict and exits 0 if everything passes, 1 if any test fails.
"""
from __future__ import annotations

import shutil
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from wg_validator.wg_validator import (  # noqa: E402
    load_wg_schema, load_wg_references, WgValidator,
)


# Paths
SCHEMA_PATH = ROOT / 'wg_validator' / 'wg_xml_schema.ini'
REFERENCE_XML = ROOT / 'docs' / 'reference_exports' / 'T30jpa1__1_.xml'
SLIM_EMIT_XML = ROOT / 'xml_emitter' / 'dry_run' / 'configuration.xml'
VALIDATOR_CONFIG = ROOT / 'wg_validator' / 'wg_validator_config.ini'


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _summarize(report) -> str:
    return (f'errors={len(report.errors)}, warnings={len(report.warnings)}, '
            f'infos={len(report.infos)}, '
            f'elements_checked={report.elements_checked}, '
            f'unknown={report.elements_unknown}')


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------
def test_schema_loads() -> tuple[bool, str]:
    """Schema must load and contain a reasonable number of element rules."""
    try:
        schema = load_wg_schema(SCHEMA_PATH)
    except Exception as e:
        return False, f'load_wg_schema failed: {e}'
    if len(schema) < 100:
        return False, f'expected >100 element rules, got {len(schema)}'
    if 'profile' not in schema:
        return False, 'schema missing the root <profile> rule'
    if 'nat' not in schema:
        return False, 'schema missing the <nat> rule'
    if 'address-group' not in schema:
        return False, 'schema missing the <address-group> rule'
    return True, f'{len(schema)} element rules loaded'


def test_validates_reference_cleanly() -> tuple[bool, str]:
    """The reference validates with ZERO findings. After hand-curation
    pass #3b, the schema's required_fields and value-domain enums no
    longer produce false-positive warnings even on the source it was
    bootstrapped from. Any regression means a schema rule got tightened
    too aggressively."""
    if not REFERENCE_XML.is_file():
        return False, f'reference XML missing: {REFERENCE_XML}'
    refs_path = ROOT / 'wg_validator' / 'wg_xml_references.ini'
    schema = load_wg_schema(SCHEMA_PATH)
    rules, builtins = load_wg_references(refs_path) if refs_path.is_file() else ([], {})
    # Pass reference_xml_path so the validator can recognize this is a
    # self-validation and skip rules that would flag legitimate
    # variations within the reference (xs:all ordering, required-by-
    # newer-firmware elements). Phase 9 addition.
    validator = WgValidator(schema, SCHEMA_PATH,
                            unknown_element_severity='warning',
                            references=rules, builtins=builtins,
                            reference_xml_path=REFERENCE_XML)
    report = validator.validate(REFERENCE_XML)
    if report.errors or report.warnings or report.infos:
        detail = (f'errors={len(report.errors)}, '
                  f'warnings={len(report.warnings)}, '
                  f'infos={len(report.infos)}')
        if report.warnings:
            sample = report.warnings[0]
            detail += f' | first: [{sample.rule}] {sample.message[:80]}'
        return False, detail
    return True, 'clean (0/0/0) on reference'


def test_validates_slim_emit() -> tuple[bool, str]:
    """The slim-sample emit output must validate with ZERO structural
    findings. Post Phase 8, the skeleton emits __OPERATOR_REPLACE__
    sentinels in the version stanza by default, which the validator
    hard-stops on. To verify structural cleanliness independent of
    operator action, this test strips sentinels to placeholder real
    values in a temp copy and validates that.
    """
    if not SLIM_EMIT_XML.is_file():
        return True, f'(skipped — slim emit missing: {SLIM_EMIT_XML})'
    refs_path = ROOT / 'wg_validator' / 'wg_xml_references.ini'
    schema = load_wg_schema(SCHEMA_PATH)
    rules, builtins = load_wg_references(refs_path) if refs_path.is_file() else ([], {})
    validator = WgValidator(schema, SCHEMA_PATH,
                            unknown_element_severity='warning',
                            references=rules, builtins=builtins)

    # Phase 8: confirm sentinels are present on the real emit
    raw = SLIM_EMIT_XML.read_text(encoding='utf-8')
    sentinel_re = re.compile(r'__OPERATOR_REPLACE__([A-Za-z0-9_-]+)__')
    sentinel_count = len(sentinel_re.findall(raw))

    # Create sentinel-stripped temp copy for structural validation
    import tempfile
    stripped = sentinel_re.sub('PLACEHOLDER', raw)
    with tempfile.NamedTemporaryFile(
            suffix='.xml', delete=False, mode='w', encoding='utf-8') as tf:
        tf.write(stripped)
        tmp_path = Path(tf.name)
    try:
        report = validator.validate(tmp_path)
    finally:
        tmp_path.unlink(missing_ok=True)

    if report.errors or report.warnings or report.infos:
        detail = (f'errors={len(report.errors)}, '
                  f'warnings={len(report.warnings)}, '
                  f'infos={len(report.infos)} (after sentinel-strip)')
        if report.warnings:
            sample = report.warnings[0]
            detail += f' | first warning: [{sample.rule}] {sample.message[:80]}'
        if report.errors:
            sample = report.errors[0]
            detail += f' | first error: [{sample.rule}] {sample.message[:80]}'
        return False, detail

    return True, (f'clean (0/0/0) on slim emit (after sentinel-strip; '
                  f'{sentinel_count} operator sentinels present in real emit, '
                  f'as expected for Phase 8)')


def test_catches_injected_corruption() -> tuple[bool, str]:
    """Synthetically corrupt an XML and confirm the validator flags it."""
    if not REFERENCE_XML.is_file():
        return False, f'reference XML missing: {REFERENCE_XML}'
    with tempfile.TemporaryDirectory() as tmp_str:
        tmp = Path(tmp_str)
        bad_xml = tmp / 'corrupted.xml'
        # Read the reference and inject an unknown element
        tree = ET.parse(REFERENCE_XML)
        root = tree.getroot()
        # Inject a fake top-level element that's NOT in the schema
        bogus = ET.SubElement(root, 'totally-fake-element-xyz')
        bogus.text = 'this should be flagged'
        tree.write(bad_xml, encoding='utf-8', xml_declaration=True)

        schema = load_wg_schema(SCHEMA_PATH)
        validator = WgValidator(schema, SCHEMA_PATH,
                                unknown_element_severity='warning')
        report = validator.validate(bad_xml)
        # Check that our injected element was flagged
        flagged = [i for i in report.issues
                   if i.element_tag == 'totally-fake-element-xyz']
        if not flagged:
            return False, ('injected unknown element not flagged — validator '
                           'is missing real schema gaps')
        return True, (f'injected element flagged correctly '
                      f'({len(flagged)} issue(s))')


def test_engine_cli_runs() -> tuple[bool, str]:
    """Engine CLI runs end-to-end on its default config without crashing."""
    if not VALIDATOR_CONFIG.is_file():
        return False, f'engine config missing: {VALIDATOR_CONFIG}'
    if not SLIM_EMIT_XML.is_file():
        return True, '(skipped — slim emit not available as default candidate)'

    cmd = [sys.executable,
           str(ROOT / 'wg_validator' / 'wg_validator.py'),
           '--config', str(VALIDATOR_CONFIG)]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    # Exit code can be 0/1/2 depending on findings — not an error
    if r.returncode > 2:
        return False, f'CLI returned unexpected exit code {r.returncode}'
    if 'WatchGuard XML Validation Report' not in r.stdout:
        return False, 'CLI output missing the expected report header'
    return True, f'rc={r.returncode}'


def test_references_file_loads() -> tuple[bool, str]:
    """Cross-reference rules and built-ins load from wg_xml_references.ini."""
    refs_path = ROOT / 'wg_validator' / 'wg_xml_references.ini'
    if not refs_path.is_file():
        return False, f'references file missing: {refs_path}'
    from wg_validator.wg_validator import load_wg_references
    rules, builtins = load_wg_references(refs_path)
    if len(rules) < 10:
        return False, f'expected >=10 cross-reference rules, got {len(rules)}'
    if 'alias' not in builtins:
        return False, 'missing builtin.alias (Any, Any-External, etc.)'
    if 'service' not in builtins:
        return False, 'missing builtin.service'
    # Spot-check a known builtin
    if 'Any' not in builtins['service'].names:
        return False, '"Any" should be in builtin.service'
    if 'Always On' not in builtins['schedule'].names:
        return False, '"Always On" should be in builtin.schedule'
    return True, f'{len(rules)} rules, {len(builtins)} builtin categories'


def test_cross_reference_catches_dangling() -> tuple[bool, str]:
    """Inject a policy with a service name that has no service-list/service
    definition, confirm the validator flags it as a cross-reference issue."""
    if not REFERENCE_XML.is_file():
        return False, f'reference XML missing: {REFERENCE_XML}'
    from wg_validator.wg_validator import (
        load_wg_schema, load_wg_references, WgValidator
    )
    refs_path = ROOT / 'wg_validator' / 'wg_xml_references.ini'

    with tempfile.TemporaryDirectory() as tmp_str:
        tmp = Path(tmp_str)
        bad_xml = tmp / 'corrupted.xml'
        tree = ET.parse(REFERENCE_XML)
        root = tree.getroot()
        # Find policy-list and inject a service reference to a fake name
        policy_list = root.find('policy-list')
        if policy_list is None:
            return False, 'reference has no policy-list'
        first_policy = policy_list.find('policy')
        if first_policy is None:
            return False, 'reference has no policies'
        svc = first_policy.find('service')
        if svc is None:
            svc = ET.SubElement(first_policy, 'service')
        svc.text = 'TotallyFakeService_xyz'
        tree.write(bad_xml, encoding='utf-8', xml_declaration=True)

        schema = load_wg_schema(SCHEMA_PATH)
        rules, builtins = load_wg_references(refs_path)
        validator = WgValidator(schema, SCHEMA_PATH,
                                references=rules, builtins=builtins)
        report = validator.validate(bad_xml)

        flagged = [i for i in report.issues
                   if i.rule == 'cross-reference'
                   and 'TotallyFakeService_xyz' in i.actual]
        if not flagged:
            return False, ('injected dangling service reference not flagged; '
                           'cross-reference rules are not firing')
        return True, f'dangling reference flagged ({len(flagged)} issue(s))'


def test_cross_reference_resolves_builtin() -> tuple[bool, str]:
    """A reference to a built-in name should NOT be flagged."""
    if not REFERENCE_XML.is_file():
        return False, f'reference XML missing: {REFERENCE_XML}'
    from wg_validator.wg_validator import (
        load_wg_schema, load_wg_references, WgValidator
    )
    refs_path = ROOT / 'wg_validator' / 'wg_xml_references.ini'

    with tempfile.TemporaryDirectory() as tmp_str:
        tmp = Path(tmp_str)
        bad_xml = tmp / 'with_builtin.xml'
        tree = ET.parse(REFERENCE_XML)
        root = tree.getroot()
        policy_list = root.find('policy-list')
        if policy_list is None:
            return False, 'reference has no policy-list'
        first_policy = policy_list.find('policy')
        if first_policy is None:
            return False, 'reference has no policies'
        svc = first_policy.find('service')
        if svc is None:
            svc = ET.SubElement(first_policy, 'service')
        # 'Any' is in [builtin.service]
        svc.text = 'Any'
        tree.write(bad_xml, encoding='utf-8', xml_declaration=True)

        schema = load_wg_schema(SCHEMA_PATH)
        rules, builtins = load_wg_references(refs_path)
        validator = WgValidator(schema, SCHEMA_PATH,
                                references=rules, builtins=builtins)
        report = validator.validate(bad_xml)

        # 'Any' should NOT be flagged as dangling (it's in the builtin list)
        wrong_flag = [i for i in report.issues
                      if i.rule == 'cross-reference' and i.actual == 'Any']
        if wrong_flag:
            return False, ('"Any" was wrongly flagged as dangling — '
                           'builtin allowance not applied')
        return True, '"Any" correctly resolved via builtin.service'


def test_emitter_normalizes_named_service_references() -> tuple[bool, str]:
    """Regression test for #5: SonicWall stores service references in
    access-rules as raw directive text like `name "Apple Bonjour"` or
    `group "Web Group"`. WatchGuard XML expects just the bare service
    name as the text of <service>. The enricher's
    [pass.normalize_service_references] strips the wrapper.

    This test creates a synthetic access-rules.json containing a
    SonicWall-style named service reference, runs the enricher, and
    verifies the normalized output is just the bare name.

    Without this normalization, the emit produces malformed
    <service>name "X"</service> elements that fail cross-reference
    validation.
    """
    import json
    import shutil
    import subprocess
    import tempfile

    # Build a minimal synthetic Phase-1 directory in a tmp location
    # mirroring the toolkit layout, then run enricher against it.
    with tempfile.TemporaryDirectory() as tdir:
        tmp = Path(tdir)
        # Copy enricher and its config (we'll override paths)
        shutil.copytree(ROOT / 'enricher', tmp / 'enricher')
        shutil.copytree(ROOT / 'schema_lib', tmp / 'schema_lib')

        # Synthetic Phase-1 input
        ph1 = tmp / 'sonicwall_parser' / 'output'
        ph1.mkdir(parents=True)
        synthetic_rules = {
            'entries': [
                {
                    '_id': 'r1',
                    'name': 'rule_with_named_service',
                    'service': 'name "Apple Bonjour"',
                    'destination': 'address group "DMZ Subnets"',
                    'source': ['address any', 'port any'],
                },
                {
                    '_id': 'r2',
                    'name': 'rule_with_any',
                    'service': 'any',
                    'destination': 'address any',
                    'source': ['address any', 'port any'],
                },
            ]
        }
        (ph1 / 'access_rules.json').write_text(
            json.dumps(synthetic_rules, indent=2))

        # Pre-create the other inputs the enricher expects (empty)
        for fname in ('vpn_policies.json', 'address_groups.json',
                      'address_objects.json', 'service_objects.json',
                      'service_groups.json', 'schedules.json',
                      'interfaces.json'):
            (ph1 / fname).write_text(json.dumps({'entries': []}))

        # Patch the enricher config's [io] section to point at our tmp
        cfg_path = tmp / 'enricher' / 'enrich_config.ini'
        cfg_text = cfg_path.read_text()
        cfg_text = cfg_text.replace(
            "input_dir = ../sonicwall_parser/output",
            f"input_dir = {ph1}"
        )
        # Output to tmp/enricher_out
        out_dir = tmp / 'enricher_out'
        out_dir.mkdir()
        cfg_text = cfg_text.replace(
            "output_dir = ./output",
            f"output_dir = {out_dir}"
        )
        cfg_path.write_text(cfg_text)

        r = subprocess.run(
            [sys.executable, str(tmp / 'enricher' / 'enricher.py'),
             '--config', str(cfg_path),
             '--no-validate'],
            capture_output=True, text=True, cwd=str(tmp))
        if r.returncode != 0:
            return False, f"enricher failed: {r.stderr[:500]}"

        # Read normalized output
        out_rules = json.loads(
            (out_dir / 'access_rules.json').read_text())
        entries = out_rules.get('entries', out_rules)
        if len(entries) != 2:
            return False, f"expected 2 entries, got {len(entries)}"

        r1 = next((e for e in entries if e.get('_id') == 'r1'), None)
        r2 = next((e for e in entries if e.get('_id') == 'r2'), None)
        if r1 is None or r2 is None:
            return False, f"missing entries: r1={r1}, r2={r2}"

        # r1: 'name "Apple Bonjour"' -> 'Apple Bonjour'
        if r1.get('service') != 'Apple Bonjour':
            return False, (
                f"r1 service: expected 'Apple Bonjour', "
                f"got {r1.get('service')!r}")
        # r1: 'address group "DMZ Subnets"' -> 'DMZ Subnets'
        if r1.get('destination') != 'DMZ Subnets':
            return False, (
                f"r1 destination: expected 'DMZ Subnets', "
                f"got {r1.get('destination')!r}")
        # r2: 'any' should be unchanged
        if r2.get('service') != 'any':
            return False, (
                f"r2 service should be unchanged 'any', "
                f"got {r2.get('service')!r}")

    return True, ('named-service references stripped, '
                  'address-group references stripped, '
                  '"any" preserved')


def test_emitter_emits_portshield_advisory() -> tuple[bool, str]:
    """Regression test for #9: SonicWall portshield directives must be
    detected and produce a migration_notes.md advisory pointing the
    operator at the WG Bridge interface migration playbook.

    Verifies:
        * The portshield_advisory rule fires when interfaces.json has
          an entry with 'portshield' in its ip-assignment
        * The advisory uses template-based rendering (advisory_preamble
          + advisory_template, NOT the legacy GVC-specific code path)
        * The advisory renders the {id} and {ip-assignment} fields
          correctly (verifies field-name regex extension)
        * The migration note points operator at the docs playbook
        * The output XML is unchanged by the advisory (advisory_only
          status)
    """
    notes_path = ROOT / 'xml_emitter' / 'dry_run' / 'migration_notes.md'
    if not notes_path.is_file():
        return False, f'migration_notes.md missing: {notes_path}'
    notes = notes_path.read_text(encoding='utf-8')

    # The advisory section must exist
    if '## portshield_advisory' not in notes:
        return False, 'portshield_advisory section missing from notes'

    # The preamble's pointer to the playbook must be present
    if 'docs/portshield_to_bridge.md' not in notes:
        return False, 'preamble pointer to playbook doc not found'

    # The detected interface (X4) and its ip-assignment must render
    if '`X4`' not in notes:
        return False, 'X4 interface not flagged in advisory'
    if 'LAN portshield X0' not in notes:
        return False, ('ip-assignment value not substituted into '
                       'advisory_template — check {ip-assignment} '
                       'placeholder substitution')

    # The playbook doc itself must exist
    playbook = ROOT / 'docs' / 'portshield_to_bridge.md'
    if not playbook.is_file():
        return False, f'playbook doc missing: {playbook}'
    pb_text = playbook.read_text(encoding='utf-8')
    # Spot-check the playbook has the operator step procedure
    if 'Step-by-step migration procedure' not in pb_text:
        return False, 'playbook missing the step procedure section'

    # The XML output must NOT contain a Bridge interface auto-emitted —
    # that's exactly what the advisory exists to prevent
    if not SLIM_EMIT_XML.is_file():
        return False, 'slim emit XML missing'
    xml_text = SLIM_EMIT_XML.read_text(encoding='utf-8')
    # No bridge-related elements should appear (we don't auto-generate them)
    forbidden_xml = ['<bridge-member-list>', 'item-type>bridge<']
    for needle in forbidden_xml:
        if needle in xml_text:
            return False, (f'advisory should be advisory-only, but XML '
                           f'contains {needle!r}')

    return True, 'portshield detected, advisory rendered, no auto-XML emit'


def test_emitter_merges_interfaces_no_phantoms() -> tuple[bool, str]:
    """Regression test for #6: interface emission must use the
    merge-into-existing semantics. The emit must:
      * NOT produce phantom <interface> entries with raw SonicWall
        names like X0, X1, etc.
      * Populate the skeleton's canonical interfaces (External,
        Trusted, Optional-N) with source IPs, gateways, and netmasks.
      * Skip interfaces with no resolvable zone (e.g. IPv6-only X2).
      * Log multi-port-same-zone collisions to migration_notes.md.
    """
    if not SLIM_EMIT_XML.is_file():
        return True, '(skipped — slim emit not available)'

    text = SLIM_EMIT_XML.read_text(encoding='utf-8')

    # No phantom interfaces with raw SonicWall names
    forbidden = ['<name>X0</name>', '<name>X1</name>', '<name>X2</name>',
                 '<name>X3</name>', '<name>X4</name>']
    for n in forbidden:
        if n in text:
            return False, f'phantom interface still present: {n!r}'

    # External and Trusted must be populated with real source data
    # (slim source has X1 WAN at 141.10.150.12 → External (eth0),
    #  X0 LAN at 10.12.20.177 → Trusted (eth1))
    import xml.etree.ElementTree as ET
    tree = ET.parse(SLIM_EMIT_XML)
    root = tree.getroot()
    iface_list = root.find('interface-list')
    if iface_list is None:
        return False, '<interface-list> missing'

    found = {}
    for iface in iface_list.findall('interface'):
        nm = iface.find('name')
        if nm is None:
            continue
        nm_text = nm.text
        if nm_text in ('External', 'Trusted'):
            phys = iface.find('.//physical-if')
            if phys is None:
                return False, f'{nm_text} interface has no physical-if'
            ip_el = phys.find('ip')
            ip_val = ip_el.text if ip_el is not None else ''
            found[nm_text] = ip_val

    if found.get('External') != '141.10.150.12':
        return False, (f'External should have X1 WAN ip 141.10.150.12, '
                       f'got {found.get("External")!r}')
    if found.get('Trusted') != '10.12.20.177':
        return False, (f'Trusted should have X0 LAN ip 10.12.20.177, '
                       f'got {found.get("Trusted")!r}')

    # Migration notes should mention the X2-no-zone skip and the
    # X3/X4 collision in Trusted
    notes_path = ROOT / 'xml_emitter' / 'dry_run' / 'migration_notes.md'
    if not notes_path.is_file():
        return False, 'migration_notes.md missing'
    notes = notes_path.read_text(encoding='utf-8')
    if 'Skipped IDs: `X2`' not in notes:
        return False, 'migration_notes.md missing X2 (no-zone skip) entry'
    if 'Merge collisions' not in notes:
        return False, 'migration_notes.md missing collisions section'

    return True, 'phantoms eliminated, External & Trusted merged correctly'


def test_emitter_filters_orphan_ipv6_aliases() -> tuple[bool, str]:
    """Regression test for #4: the emitter must filter SonicWall-only
    orphan IPv6 system aliases (LAN IPv6 Subnets, X0 IPv6 Addresses, etc.)
    via the skip_name_patterns mechanism, AND log each filtered entry to
    migration_notes.md.

    Verifies:
        * The skip_name_patterns directive is being honored
        * No filtered names appear as <name> children of any <alias>
        * No filtered names appear as <alias-name> references either
          (since the host alias they belonged to is also filtered)
        * migration_notes.md contains the filtered-entries section
    """
    if not SLIM_EMIT_XML.is_file():
        return True, '(skipped — slim emit not available)'

    text = SLIM_EMIT_XML.read_text(encoding='utf-8')

    # Names that must NOT appear in the emit (they're filtered)
    forbidden_names = [
        'LAN IPv6 Subnets',
        'WAN IPv6 Subnets',
        'X0 IPv6 Addresses',
        'X1 IPv6 Addresses',
        'X2 Management IPv6 Addresses',
        'U0 IPv6 Addresses',
        'Default Geo-IP and Botnet Exclusion Group',
    ]
    for name in forbidden_names:
        # Must not be defined as an alias
        if f'<name>{name}</name>' in text:
            return False, (f'filtered alias {name!r} still defined '
                           '(skip_name_patterns not applied)')

    # Check migration_notes.md got the filtered-entries section
    notes_path = ROOT / 'xml_emitter' / 'dry_run' / 'migration_notes.md'
    if not notes_path.is_file():
        return False, 'migration_notes.md not produced'
    notes = notes_path.read_text(encoding='utf-8')
    if 'Filtered entries — emit.aliases' not in notes:
        return False, ('migration_notes.md missing the filtered-entries '
                       'section heading')
    if 'SonicWall IPv6 system aliases' not in notes:
        return False, 'migration_notes.md missing the category label'
    # Spot-check that at least one filtered entry is logged
    if 'LAN IPv6 Subnets' not in notes:
        return False, ('a known filtered entry should appear in '
                       'migration_notes.md but does not')

    return True, 'orphan IPv6 aliases filtered with notes'


def test_emitter_canonicalizes_service_and_schedule() -> tuple[bool, str]:
    """Regression test for #3a: the emitter must produce the canonical
    WG forms 'Any' (capital) for service and 'Always On' (canonical
    spacing) for schedule, NOT the SonicWall-source forms 'any' and
    'always-on'. Verifies the wg_canonical_service and
    wg_canonical_schedule value_maps are wired into both
    firewall_policies and firewall_policies_runtime.
    """
    if not SLIM_EMIT_XML.is_file():
        return True, '(skipped — slim emit not available)'

    text = SLIM_EMIT_XML.read_text(encoding='utf-8')

    # Forbidden forms — these would mean canonicalization didn't run
    forbidden = {
        '<service>any</service>': '"any" (lowercase) should be "Any"',
        '<schedule>always-on</schedule>': '"always-on" should be "Always On"',
    }
    for needle, msg in forbidden.items():
        if needle in text:
            return False, msg

    # Required forms — must be present at least once
    required = {
        '<service>Any</service>': 'no <service>Any</service> emitted',
        '<schedule>Always On</schedule>': 'no <schedule>Always On</schedule> emitted',
    }
    for needle, msg in required.items():
        if needle not in text:
            return False, msg

    return True, 'service=Any and schedule=Always On both emitted correctly'


def test_emitter_post_emit_validation() -> tuple[bool, str]:
    """The xml_emitter, run end-to-end, runs the post-emit validation
    pass and produces validation_report.{json,txt} alongside the XML."""
    emitter = ROOT / 'xml_emitter' / 'xml_emitter.py'
    config = ROOT / 'xml_emitter' / 'xml_emit_config.ini'
    if not emitter.is_file():
        return False, f'emitter missing: {emitter}'
    if not config.is_file():
        return False, f'emit config missing: {config}'

    # Run the emitter; it should call validation automatically
    cmd = [sys.executable, str(emitter), '--config', str(config)]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=120,
                       cwd=str(emitter.parent))
    if r.returncode not in (0, 4):
        return False, (f'emitter rc={r.returncode} (expected 0 or 4); '
                       f'stderr: {r.stderr[:200]}')
    if 'Post-emit validation' not in r.stdout:
        return False, 'emitter did not run post-emit validation'

    # The reports should exist alongside the XML
    out_dir = ROOT / 'xml_emitter' / 'dry_run'
    json_report = out_dir / 'validation_report.json'
    txt_report = out_dir / 'validation_report.txt'
    if not json_report.is_file():
        return False, f'JSON report not written: {json_report}'
    if not txt_report.is_file():
        return False, f'text report not written: {txt_report}'

    return True, f'rc={r.returncode}, reports written'


def test_emitter_no_validate_output() -> tuple[bool, str]:
    """--no-validate-output skips the post-emit validation pass."""
    emitter = ROOT / 'xml_emitter' / 'xml_emitter.py'
    config = ROOT / 'xml_emitter' / 'xml_emit_config.ini'
    cmd = [sys.executable, str(emitter), '--config', str(config),
           '--no-validate-output']
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=120,
                       cwd=str(emitter.parent))
    if r.returncode != 0:
        return False, f'emitter rc={r.returncode} (expected 0)'
    if 'Post-emit validation' in r.stdout:
        return False, ('--no-validate-output did NOT suppress validation '
                       '(the section header is still in stdout)')
    return True, 'validation correctly skipped'


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------
TESTS = [
    ('schema_loads', test_schema_loads),
    ('validates_reference_cleanly', test_validates_reference_cleanly),
    ('validates_slim_emit', test_validates_slim_emit),
    ('catches_injected_corruption', test_catches_injected_corruption),
    ('engine_cli_runs', test_engine_cli_runs),
    ('references_file_loads', test_references_file_loads),
    ('cross_reference_catches_dangling', test_cross_reference_catches_dangling),
    ('cross_reference_resolves_builtin', test_cross_reference_resolves_builtin),
    ('emitter_normalizes_named_service_references',
     test_emitter_normalizes_named_service_references),
    ('emitter_emits_portshield_advisory',
     test_emitter_emits_portshield_advisory),
    ('emitter_merges_interfaces_no_phantoms',
     test_emitter_merges_interfaces_no_phantoms),
    ('emitter_filters_orphan_ipv6_aliases',
     test_emitter_filters_orphan_ipv6_aliases),
    ('emitter_canonicalizes_service_and_schedule',
     test_emitter_canonicalizes_service_and_schedule),
    ('emitter_post_emit_validation', test_emitter_post_emit_validation),
    ('emitter_no_validate_output', test_emitter_no_validate_output),
]


def main() -> int:
    print(f'wg_validator regression tests — toolkit root: {ROOT}\n')
    print(f'{"TEST":<35} {"RESULT":<8} DETAIL')
    print('-' * 95)
    failures = 0
    for name, fn in TESTS:
        try:
            ok, detail = fn()
        except Exception as e:
            ok = False
            detail = f'EXCEPTION: {type(e).__name__}: {e}'
        flag = 'PASS' if ok else 'FAIL'
        print(f'{name:<35} {flag:<8} {detail}')
        if not ok:
            failures += 1

    print()
    if failures == 0:
        print(f'All {len(TESTS)} tests passed.')
        return 0
    print(f'{failures} of {len(TESTS)} tests failed.')
    return 1


if __name__ == '__main__':
    sys.exit(main())
