#!/usr/bin/env python3
"""
test_comment_preserving_multiline.py
=====================================

Regression tests for #10: hardened multi-line value handling in
comment_preserving_ini. These tests prove that our parser matches
ConfigParser's exact semantics for multi-line values, including the
edge cases that broke the portshield advisory work in #9:

  Bug 1: Blank lines INSIDE multi-line values must be preserved as
         `\\n` in the joined value (not terminate the value).

  Bug 2: Indented `#` comment lines inside a multi-line value must
         be SKIPPED (not added to the value), but must not terminate
         the multi-line range. They are preserved in raw_lines for
         byte-identity on unchanged emit.

  Bug 3: A multi-line value followed by content that LOOKS like
         continuation (after a blank line) must not produce orphan
         CommentLine items that re-attach as continuation on
         round-trip through ConfigParser.

The test strategy is to (a) verify our parser produces the SAME
joined value as ConfigParser would for tricky inputs, (b) verify the
full round-trip cycle (cpi.parse → set_value → render → re-parse) is
byte-clean even for multi-line values, and (c) verify ConfigParser
load → cpi.apply_dict → cpi.write produces byte-identical output (the
GUI-save scenario).
"""
from __future__ import annotations

import configparser
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from schema_lib import comment_preserving_ini as cpi


def _cp_read(src: str) -> dict[str, dict[str, str]]:
    """Read INI source via ConfigParser, return as plain dict-of-dicts."""
    cp = configparser.ConfigParser(
        interpolation=None,
        comment_prefixes=('#',),
        inline_comment_prefixes=(';',),
    )
    cp.optionxform = str
    cp.read_string(src)
    return {s: dict(cp[s]) for s in cp.sections()}


def _diff(a: str, b: str) -> str:
    for i, (ca, cb) in enumerate(zip(a, b)):
        if ca != cb:
            return (f"divergence at byte {i}\n"
                    f"  expected: {a[max(0,i-30):i+30]!r}\n"
                    f"  got:      {b[max(0,i-30):i+30]!r}")
    if len(a) != len(b):
        return f"length mismatch: expected {len(a)}, got {len(b)}"
    return "(identical)"


# ---------------------------------------------------------------------------
# Test cases — each produces (label, expected_pass, callable)
# ---------------------------------------------------------------------------

def test_internal_blank_line_kept(tmp: Path) -> tuple[bool, str]:
    """Blank line INSIDE multi-line value must be preserved as `\\n`."""
    src = "[s]\nk = first\n    second\n    \n    fourth\n"
    p = tmp / "internal_blank.ini"
    p.write_text(src)
    doc = cpi.parse(p)
    expected = "first\nsecond\n\nfourth"
    got = cpi.get(doc, "s", "k")
    if got != expected:
        return False, f"expected {expected!r}, got {got!r}"
    # Cross-check ConfigParser produces same value
    cp_val = _cp_read(src)["s"]["k"]
    if cp_val != expected:
        return False, f"ConfigParser disagrees: got {cp_val!r}"
    return True, "blank kept as \\n"


def test_indented_hash_comment_skipped(tmp: Path) -> tuple[bool, str]:
    """Indented `#` comment line inside multi-line value must be
    skipped from the value (matches ConfigParser)."""
    src = "[s]\nk = first\n    # note\n    third\n"
    p = tmp / "indented_hash.ini"
    p.write_text(src)
    doc = cpi.parse(p)
    expected = "first\nthird"
    got = cpi.get(doc, "s", "k")
    if got != expected:
        return False, f"expected {expected!r}, got {got!r}"
    cp_val = _cp_read(src)["s"]["k"]
    if cp_val != expected:
        return False, f"ConfigParser disagrees: got {cp_val!r}"
    return True, "# comment skipped from value"


def test_trailing_blanks_stripped(tmp: Path) -> tuple[bool, str]:
    """Trailing blank lines before next section must be stripped."""
    src = "[s]\nk = first\n    second\n    \n    \n[other]\nx = y\n"
    p = tmp / "trailing_blanks.ini"
    p.write_text(src)
    doc = cpi.parse(p)
    expected = "first\nsecond"
    got = cpi.get(doc, "s", "k")
    if got != expected:
        return False, f"expected {expected!r}, got {got!r}"
    return True, "trailing blanks stripped"


def test_indented_hash_then_blank_then_more(tmp: Path) -> tuple[bool, str]:
    """Sequence # then blank then content: the blank is kept."""
    src = "[s]\nk = first\n    # note\n    \n    fourth\n"
    p = tmp / "hash_blank_more.ini"
    p.write_text(src)
    doc = cpi.parse(p)
    expected = "first\n\nfourth"
    got = cpi.get(doc, "s", "k")
    if got != expected:
        return False, f"expected {expected!r}, got {got!r}"
    cp_val = _cp_read(src)["s"]["k"]
    if cp_val != expected:
        return False, f"ConfigParser disagrees: got {cp_val!r}"
    return True, "blank-after-comment kept as \\n"


def test_no_orphan_commentline_pollution(tmp: Path) -> tuple[bool, str]:
    """The bug-3 reproduction: a blank inside a multi-line value
    must not split the value such that subsequent indented content
    becomes orphan CommentLine items (which would re-attach as
    continuation on round-trip through ConfigParser)."""
    src = ("[meta]\n"
           "preamble = first paragraph A\n"
           "    first paragraph B\n"
           "    \n"
           "    second paragraph A\n"
           "    second paragraph B\n"
           "key2 = value2\n")
    p = tmp / "no_orphans.ini"
    p.write_text(src)
    doc = cpi.parse(p)
    # The value should include all four lines plus the blank
    expected = ("first paragraph A\n"
                "first paragraph B\n"
                "\n"
                "second paragraph A\n"
                "second paragraph B")
    got = cpi.get(doc, "meta", "preamble")
    if got != expected:
        return False, f"expected {expected!r}, got {got!r}"
    # And there must be no CommentLine items between preamble and key2
    # (those orphans were the bug-3 source)
    items_in_meta = []
    in_section = False
    for it in doc.items:
        cls = type(it).__name__
        if cls == "SectionHeader" and getattr(it, "name", None) == "meta":
            in_section = True
            continue
        if cls == "SectionHeader":
            in_section = False
        if in_section:
            items_in_meta.append(cls)
    # Should have only KeyValue items (preamble, key2) and possibly
    # interspersed blank CommentLines OUTSIDE multi-line values
    # (none in this synthetic case). No orphan indented content.
    cls_count = {c: items_in_meta.count(c) for c in set(items_in_meta)}
    if cls_count.get("KeyValue", 0) != 2:
        return False, (f"expected 2 KeyValue items in [meta], "
                       f"got {cls_count}")
    return True, "no orphan continuation items"


def test_full_roundtrip_with_blanks(tmp: Path) -> tuple[bool, str]:
    """Full GUI-save cycle: parse → ConfigParser-dict → apply_dict →
    write → byte-identical to original. With blank lines in values."""
    src = ("[s]\n"
           "preamble = paragraph 1 line A\n"
           "    paragraph 1 line B\n"
           "    \n"
           "    paragraph 2 line A\n"
           "    paragraph 2 line B\n"
           "other = simple\n")
    p = tmp / "roundtrip_blanks.ini"
    p.write_text(src)
    # Simulate the GUI-save flow:
    cp = configparser.ConfigParser(
        interpolation=None,
        comment_prefixes=('#',),
        inline_comment_prefixes=(';',),
    )
    cp.optionxform = str
    cp.read(p, encoding="utf-8")
    cp_dict = {s: dict(cp[s]) for s in cp.sections()}
    doc = cpi.parse(p)
    cpi.apply_dict(doc, cp_dict)
    cpi.write(doc, p)
    after = p.read_text(encoding="utf-8")
    if after != src:
        return False, _diff(src, after)
    return True, "byte-identical round-trip with blank lines"


def test_mutate_multiline_with_blank(tmp: Path) -> tuple[bool, str]:
    """Mutate a multi-line value containing a blank line; verify the
    mutated value parses back correctly (round-trip through cpi only)."""
    src = ("[s]\n"
           "preamble = original line 1\n"
           "    original line 2\n"
           "    \n"
           "    original line 3\n"
           "after = thing\n")
    p = tmp / "mutate_multiline.ini"
    p.write_text(src)
    doc = cpi.parse(p)

    # Mutate to a NEW multi-line value containing its own blank line
    new_value = "new line 1\nnew line 2\n\nnew line 3\nnew line 4"
    cpi.set_value(doc, "s", "preamble", new_value)
    cpi.write(doc, p)

    # Re-parse and verify
    doc2 = cpi.parse(p)
    got = cpi.get(doc2, "s", "preamble")
    if got != new_value:
        return False, f"after re-parse, expected {new_value!r}, got {got!r}"

    # And `after = thing` should still be there
    if cpi.get(doc2, "s", "after") != "thing":
        return False, "neighboring key 'after' got disturbed"

    return True, "multi-line mutation round-trips cleanly"


def test_mutate_multiline_via_gui_save(tmp: Path) -> tuple[bool, str]:
    """The full bug-3 scenario: read via cpi, simulate GUI mutation
    via ConfigParser-flavored dict, apply_dict, write. Must produce
    output that re-parses to the new value (no orphan pollution)."""
    src = ("[s]\n"
           "preamble = original line 1\n"
           "    original line 2\n"
           "    \n"
           "    original line 3\n"
           "after = thing\n")
    p = tmp / "gui_save_multiline.ini"
    p.write_text(src)
    doc = cpi.parse(p)

    # Mutate via the dict-based API (what apply_dict does internally)
    new_dict = {
        "s": {
            "preamble": "v2 line 1\nv2 line 2\n\nv2 line 3",
            "after": "thing",
        }
    }
    cpi.apply_dict(doc, new_dict)
    cpi.write(doc, p)

    # Re-parse and verify
    doc2 = cpi.parse(p)
    got = cpi.get(doc2, "s", "preamble")
    expected = "v2 line 1\nv2 line 2\n\nv2 line 3"
    if got != expected:
        return False, f"after gui-save, expected {expected!r}, got {got!r}"

    return True, "GUI-save flow handles multi-line mutation"


def test_repeated_setvalue_no_concatenation(tmp: Path) -> tuple[bool, str]:
    """The portshield-session bug: repeated set_value calls on a
    multi-line key must NOT concatenate. The final value must be the
    one from the last call, with no leftover text."""
    src = ("[meta]\n"
           "preamble = original A\n"
           "    original B\n"
           "    original C\n")
    p = tmp / "repeated_set.ini"
    p.write_text(src)
    doc = cpi.parse(p)

    cpi.set_value(doc, "meta", "preamble", "v1 A\nv1 B\nv1 C")
    cpi.set_value(doc, "meta", "preamble", "v2 A\nv2 B")
    cpi.set_value(doc, "meta", "preamble", "v3 A\nv3 B\nv3 C\nv3 D")
    cpi.write(doc, p)

    # Re-parse: value must be exactly v3, nothing else
    doc2 = cpi.parse(p)
    got = cpi.get(doc2, "meta", "preamble")
    expected = "v3 A\nv3 B\nv3 C\nv3 D"
    if got != expected:
        return False, f"expected {expected!r}, got {got!r}"
    return True, "no concatenation across repeated set_value"


def test_delete_then_add_section_recreates_clean(tmp: Path) -> tuple[bool, str]:
    """delete_section + add_section + set_value must produce a clean
    section, not retain old keys/values from before the delete."""
    src = ("[meta]\n"
           "preamble = old A\n"
           "    old B\n"
           "old_key = old_value\n")
    p = tmp / "del_add.ini"
    p.write_text(src)
    doc = cpi.parse(p)

    cpi.delete_section(doc, "meta")
    cpi.add_section(doc, "meta")
    cpi.set_value(doc, "meta", "preamble", "fresh A\nfresh B")
    cpi.set_value(doc, "meta", "new_key", "new_value")
    cpi.write(doc, p)

    # Re-parse: should have ONLY preamble (fresh A/B) and new_key
    doc2 = cpi.parse(p)
    keys = cpi.keys(doc2, "meta")
    got_preamble = cpi.get(doc2, "meta", "preamble")
    got_old = cpi.get(doc2, "meta", "old_key", default="<MISSING>")

    if got_preamble != "fresh A\nfresh B":
        return False, f"preamble: expected fresh, got {got_preamble!r}"
    if got_old != "<MISSING>":
        return False, f"old_key should be gone, but found {got_old!r}"
    if "new_key" not in keys:
        return False, f"new_key missing from keys: {keys!r}"
    return True, "delete+add section produces clean state"


# ---------------------------------------------------------------------------

TESTS = [
    ("internal_blank_line_kept", test_internal_blank_line_kept),
    ("indented_hash_comment_skipped", test_indented_hash_comment_skipped),
    ("trailing_blanks_stripped", test_trailing_blanks_stripped),
    ("indented_hash_then_blank_then_more",
     test_indented_hash_then_blank_then_more),
    ("no_orphan_commentline_pollution",
     test_no_orphan_commentline_pollution),
    ("full_roundtrip_with_blanks", test_full_roundtrip_with_blanks),
    ("mutate_multiline_with_blank", test_mutate_multiline_with_blank),
    ("mutate_multiline_via_gui_save", test_mutate_multiline_via_gui_save),
    ("repeated_setvalue_no_concatenation",
     test_repeated_setvalue_no_concatenation),
    ("delete_then_add_section_recreates_clean",
     test_delete_then_add_section_recreates_clean),
]


def main() -> int:
    import tempfile
    import shutil
    print("comment_preserving_ini: multi-line edge cases (#10)")
    print()
    print(f"{'TEST':<48} {'RESULT':<8} DETAIL")
    print("-" * 95)

    fail = 0
    for name, fn in TESTS:
        with tempfile.TemporaryDirectory() as td:
            tmp = Path(td)
            try:
                ok, msg = fn(tmp)
            except Exception as e:
                ok, msg = False, f"EXC: {type(e).__name__}: {e}"
            status = "PASS" if ok else "FAIL"
            print(f"{name:<48} {status:<8} {msg}")
            if not ok:
                fail += 1

    print()
    if fail == 0:
        print(f"All {len(TESTS)} multi-line tests passed.")
        return 0
    print(f"{fail} of {len(TESTS)} tests FAILED.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
