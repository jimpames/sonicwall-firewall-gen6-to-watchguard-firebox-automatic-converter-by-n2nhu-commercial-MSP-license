#!/usr/bin/env python3
"""
test_gui_save_roundtrip.py
============================

Simulates exactly what the GUI does on a no-mutation save (load → save)
and verifies the file is byte-identical to the original. This is the
critical contract: opening any toolkit INI in the GUI and clicking
Save with no changes must NEVER alter the file.

Also tests a single-value mutation round-trip and confirms all the
file's comment lines, blank lines, and section headers survive.
"""
from __future__ import annotations

import configparser
import hashlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from schema_lib import comment_preserving_ini as cpi


def gui_simulate_load(path: Path) -> tuple[configparser.ConfigParser, object]:
    """What the GUI does on file open."""
    cp = configparser.ConfigParser(
        interpolation=None,
        inline_comment_prefixes=(";",),
        comment_prefixes=("#",),
    )
    cp.optionxform = str
    cp.read(path, encoding="utf-8")
    doc = cpi.parse(path)
    return cp, doc


def gui_simulate_save(cp: configparser.ConfigParser, doc, path: Path) -> None:
    """What the GUI does on save."""
    cp_dict = {s: dict(cp[s]) for s in cp.sections()}
    cpi.apply_dict(doc, cp_dict)
    cpi.write(doc, path)


def file_sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def test_no_op_save(src: Path) -> tuple[bool, str]:
    """Load + immediate save with no mutation must be byte-identical."""
    import shutil
    work = Path(f"/tmp/cpi_gui_{src.name}")
    shutil.copy(src, work)
    try:
        original = file_sha(work)
        cp, doc = gui_simulate_load(work)
        gui_simulate_save(cp, doc, work)
        after = file_sha(work)
        if original == after:
            return True, "byte-identical"
        # Show first divergence
        a = src.read_text(encoding="utf-8")
        b = work.read_text(encoding="utf-8")
        for i, (ca, cb) in enumerate(zip(a, b)):
            if ca != cb:
                ctx_a = a[max(0, i - 20):i + 40]
                ctx_b = b[max(0, i - 20):i + 40]
                return False, (
                    f"diverge @ byte {i}\n"
                    f"      expected: {ctx_a!r}\n"
                    f"      got:      {ctx_b!r}"
                )
        return False, f"length: orig={len(a)} new={len(b)}"
    finally:
        work.unlink(missing_ok=True)


def test_mutate_via_gui_path(src: Path) -> tuple[bool, str]:
    """Mutate a value through the cp+doc path, verify count of comment
    lines is preserved and the new value sticks on re-read."""
    import shutil
    work = Path(f"/tmp/cpi_mut_{src.name}")
    shutil.copy(src, work)
    try:
        original = src.read_text(encoding="utf-8")
        original_comments = sum(
            1 for ln in original.splitlines()
            if ln.lstrip().startswith(("#", ";"))
        )
        cp, doc = gui_simulate_load(work)
        # Pick first section with at least one key
        target_s = target_k = None
        for s in cp.sections():
            keys = list(cp[s].keys())
            if keys:
                target_s, target_k = s, keys[0]
                break
        if target_s is None:
            return True, "no keys to test"

        marker = f"GUI_TEST_{abs(hash(src.name))}"
        cp[target_s][target_k] = marker
        gui_simulate_save(cp, doc, work)

        modified = work.read_text(encoding="utf-8")
        new_comments = sum(
            1 for ln in modified.splitlines()
            if ln.lstrip().startswith(("#", ";"))
        )
        if new_comments != original_comments:
            return False, (
                f"comment-line count changed: {original_comments} -> "
                f"{new_comments}"
            )

        # Re-load and verify
        cp2, _ = gui_simulate_load(work)
        if cp2[target_s][target_k] != marker:
            return False, "round-trip didn't capture mutation"

        return True, (
            f"mutated [{target_s}] {target_k}, {original_comments} "
            f"comment lines preserved"
        )
    finally:
        work.unlink(missing_ok=True)


def test_mutate_multiline_via_gui_path(src: Path) -> tuple[bool, str]:
    """Mutate a MULTI-LINE value through the cp+doc path, verify the
    new multi-line value (containing its own internal blank line)
    survives the round-trip. This guards against the #10 family of
    bugs where blank-line-bearing values would get truncated or
    cause orphan continuation pollution."""
    import shutil
    work = Path(f"/tmp/cpi_mlmut_{src.name}")
    shutil.copy(src, work)
    try:
        cp, doc = gui_simulate_load(work)

        # Find the first key whose value spans multiple lines
        target_s = target_k = None
        for s in cp.sections():
            for k in cp[s]:
                v = cp[s][k]
                if "\n" in v:
                    target_s, target_k = s, k
                    break
            if target_s:
                break
        if target_s is None:
            return True, "(no multi-line values in this file)"

        # Mutate to a multi-line value with its own blank line
        marker = f"GUI_ML_{abs(hash(src.name)) % 100000}"
        new_val = (
            f"{marker} line A\n"
            f"{marker} line B\n"
            f"\n"
            f"{marker} line D\n"
            f"{marker} line E"
        )
        cp[target_s][target_k] = new_val
        gui_simulate_save(cp, doc, work)

        # Re-load and verify the mutation survived
        cp2, _ = gui_simulate_load(work)
        got = cp2[target_s][target_k]
        if got != new_val:
            return False, (
                f"multi-line round-trip failed for [{target_s}] {target_k}\n"
                f"     expected: {new_val!r}\n"
                f"     got:      {got!r}"
            )

        return True, (
            f"mutated [{target_s}] {target_k} to a 5-line value with "
            f"internal blank, survived round-trip"
        )
    finally:
        work.unlink(missing_ok=True)


def main() -> int:
    toolkit = Path(__file__).parent.parent
    targets = sorted(toolkit.rglob("*.ini"))
    targets = [
        t for t in targets
        if "/output/" not in str(t) and "/dry_run/" not in str(t)
    ]

    print(f"GUI save simulation against {len(targets)} INI files\n")
    print(f"{'FILE':<55} {'NO-OP':<10} {'MUTATE':<10} {'ML-MUT':<10}")
    print("-" * 90)

    fail = 0
    for path in targets:
        rel = path.relative_to(toolkit)
        ok1, msg1 = test_no_op_save(path)
        ok2, msg2 = test_mutate_via_gui_path(path)
        ok3, msg3 = test_mutate_multiline_via_gui_path(path)
        flag1 = "✓ pass" if ok1 else "✗ FAIL"
        flag2 = "✓ pass" if ok2 else "✗ FAIL"
        flag3 = "✓ pass" if ok3 else "✗ FAIL"
        print(f"{str(rel):<55} {flag1:<10} {flag2:<10} {flag3:<10}")
        if not ok1:
            print(f"    no-op:  {msg1}")
            fail += 1
        if not ok2:
            print(f"    mutate: {msg2}")
            fail += 1
        if not ok3:
            print(f"    ml-mut: {msg3}")
            fail += 1

    print()
    if fail == 0:
        print(f"ALL TESTS PASSED across {len(targets)} INI files")
        print("Comment-preserving GUI save path is correct.")
        return 0
    print(f"{fail} FAILURES")
    return 1


if __name__ == "__main__":
    sys.exit(main())
