#!/usr/bin/env python3
"""
test_schema_learner_provenance.py
==================================

Test #9 from the schema_learner DESIGN.md — the principle-policing
meta-test. Built BEFORE the schema-learner engine itself, so the
founding principle has teeth from the moment any code that produces
operator-facing text gets written.

The founding principle:

    No claim without provenance.
    
    Every assertion the toolkit makes — about element semantics,
    surface categories, vendor mappings, value validity, cross-
    reference targets, or operator guidance — must trace back to an
    observed artifact: a working config export, a published vendor
    specification, a documented attack reference, or recorded field
    experience.

This test enforces the principle by scanning generated artifacts for:

  1. UNSOURCED SEMANTIC CLAIMS — sentences that assert what something
     means without an accompanying citation marker.

  2. ENGINE-SUGGESTED ANSWERS — phrases that bias engineer research
     by hinting at conclusions, even framed as observations.

The test is intentionally pessimistic: it flags suspicious phrases
and requires they be either removed or tagged with explicit citation
markers. False positives are acceptable; false negatives are not.

Test scope:

    schema_learner/proposals/*/findings.md
    schema_learner/proposals/*/OPERATOR_INTERVENTION_REQUIRED.md
    schema_learner/proposals/*/proposed_diff.md
    xml_emitter/dry_run/migration_notes.md
    Any file matching "intervention*.md" or "findings*.md"

Plus inline INI warning blurbs added by the schema-learner.

This test runs every CI cycle. If it fails, the founding principle
has been violated somewhere in the toolkit's output pipeline.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# ---------------------------------------------------------------------------
# Suspicion patterns: phrases that suggest the engine is making a
# semantic claim or hinting at an answer.
# ---------------------------------------------------------------------------

# Phrases that often introduce an unsourced semantic claim.
# When found, the surrounding text MUST also contain a citation marker.
SEMANTIC_CLAIM_INTRODUCERS = [
    r"\bis (?:a |an |the )(?!structural|measurable|observed|engineer|operator)",
    r"\bbelongs to\b",
    r"\bmeans\b",
    r"\brepresents\b",
    r"\bcorresponds to\b",
    r"\bequivalent to\b",
    r"\bmaps to\b",
    r"\bsame (?:family|category|kind) as\b",
]

# Phrases that bias engineer research by hinting at answers.
# These should NEVER appear in engine-generated output. Period.
# (Operator-authored sections are excluded — those are wrapped in
#  EXPLICIT_OPERATOR_BLOCK markers.)
ANSWER_SUGGESTING_PHRASES = [
    r"\blooks like\b",
    r"\bappears to be\b",
    r"\bprobably\b",
    r"\blikely\b",
    r"\bmay correspond to\b",
    r"\bsuggests that\b",
    r"\bseems to\b",
    r"\bmight be\b",
    r"\bcould be\b",
    r"\bnearest (?:semantic )?kin\b",
    r"\bin the same family\b",
    r"\bbest match\b",
    r"\bequivalent feature\b(?! is unknown)",
]

# Citation markers that satisfy the provenance requirement when found
# in the same paragraph as a semantic claim introducer.
CITATION_MARKERS = [
    r"\bsource:\s*\S",          # "Source: <something>"
    r"\bcited:\s*\S",
    r"\bciting\b",
    r"https?://\S+",            # any URL
    r"\bRFC ?\d+",
    r"\bCVE-\d{4}-\d+",
    r"\b\d{4}\b.*field experience",
    r"declared by\s+\S+",
    r"per\s+(?:the\s+)?(?:vendor|operator|RFC|specification|documentation|engineer)",
    r"per\s+\S+\s+documentation",
    r"according to\s+\S",
    r"vendor doc\b",
    r"WatchGuard help center",
    r"SonicWall documentation",
]

# Marker that explicitly delimits operator-authored sections.
# Anything between these markers is exempt from engine-output rules.
EXPLICIT_OPERATOR_BLOCK_OPEN = "<!-- OPERATOR-AUTHORED-BEGIN -->"
EXPLICIT_OPERATOR_BLOCK_CLOSE = "<!-- OPERATOR-AUTHORED-END -->"

# Marker that explicitly delimits structural-observation sections.
# Inside these, "is" claims about structure (e.g., "is a top-level child")
# are allowed without citations because they're observations, not claims.
EXPLICIT_OBSERVATION_BLOCK_OPEN = "<!-- ENGINE-OBSERVATION-BEGIN -->"
EXPLICIT_OBSERVATION_BLOCK_CLOSE = "<!-- ENGINE-OBSERVATION-END -->"


# ---------------------------------------------------------------------------
# Strip operator-authored sections so we only audit engine-generated text
# ---------------------------------------------------------------------------

def _strip_blocks(text: str, open_marker: str, close_marker: str) -> str:
    """Replace text between open/close markers with placeholder lines
    of the same line-count, so error-line numbers remain meaningful."""
    pattern = re.compile(
        re.escape(open_marker) + r".*?" + re.escape(close_marker),
        flags=re.DOTALL,
    )
    def replace_with_blanks(m):
        n_lines = m.group(0).count("\n")
        return "\n" * n_lines
    return pattern.sub(replace_with_blanks, text)


def _engine_only_text(text: str) -> str:
    """Return text with operator-authored and observation blocks blanked."""
    text = _strip_blocks(
        text, EXPLICIT_OPERATOR_BLOCK_OPEN, EXPLICIT_OPERATOR_BLOCK_CLOSE)
    text = _strip_blocks(
        text, EXPLICIT_OBSERVATION_BLOCK_OPEN,
        EXPLICIT_OBSERVATION_BLOCK_CLOSE)
    return text


# ---------------------------------------------------------------------------
# Audit primitives
# ---------------------------------------------------------------------------

def _paragraph_has_citation(paragraph: str) -> bool:
    """Return True if the paragraph contains any citation marker."""
    for pat in CITATION_MARKERS:
        if re.search(pat, paragraph, flags=re.IGNORECASE):
            return True
    return False


def _split_paragraphs(text: str) -> list[tuple[int, str]]:
    """Split text into paragraphs (separated by blank lines).
    Returns list of (start_line_number, paragraph_text)."""
    paragraphs = []
    current = []
    current_start = 1
    line_no = 0
    for line in text.splitlines(keepends=False):
        line_no += 1
        if line.strip() == "":
            if current:
                paragraphs.append((current_start, "\n".join(current)))
                current = []
            current_start = line_no + 1
        else:
            if not current:
                current_start = line_no
            current.append(line)
    if current:
        paragraphs.append((current_start, "\n".join(current)))
    return paragraphs


def _scan_unsourced_claims(text: str, file_path: Path) -> list[str]:
    """Find paragraphs containing semantic-claim introducers WITHOUT
    accompanying citation markers."""
    findings = []
    paragraphs = _split_paragraphs(text)
    for start_line, para in paragraphs:
        for pat in SEMANTIC_CLAIM_INTRODUCERS:
            m = re.search(pat, para, flags=re.IGNORECASE)
            if not m:
                continue
            # A claim introducer is present. Is there a citation?
            if _paragraph_has_citation(para):
                continue
            # Found an unsourced claim
            snippet = para[:200].replace("\n", " ")
            findings.append(
                f"{file_path}:{start_line}: unsourced semantic claim "
                f"matching pattern {pat!r}\n"
                f"    snippet: {snippet}"
            )
            break  # One finding per paragraph is enough
    return findings


def _scan_answer_suggesting_phrases(
        text: str, file_path: Path) -> list[str]:
    """Find any answer-suggesting phrases in engine-output text.
    These are forbidden regardless of context."""
    findings = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        for pat in ANSWER_SUGGESTING_PHRASES:
            m = re.search(pat, line, flags=re.IGNORECASE)
            if m:
                findings.append(
                    f"{file_path}:{line_no}: answer-suggesting phrase "
                    f"{m.group(0)!r} (pattern {pat!r}) in engine output\n"
                    f"    line: {line.strip()[:200]}"
                )
    return findings


# ---------------------------------------------------------------------------
# Audit a single file
# ---------------------------------------------------------------------------

def audit_file(file_path: Path) -> list[str]:
    """Return list of findings for one file. Empty list = clean."""
    if not file_path.is_file():
        return []
    try:
        text = file_path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        return []
    engine_text = _engine_only_text(text)
    findings = []
    findings.extend(_scan_unsourced_claims(engine_text, file_path))
    findings.extend(_scan_answer_suggesting_phrases(engine_text, file_path))
    return findings


# ---------------------------------------------------------------------------
# Determine which files in the toolkit are subject to the audit
# ---------------------------------------------------------------------------

def files_to_audit() -> list[Path]:
    """Return all files that should be audited for engine-output
    provenance compliance.
    
    Currently in scope:
      - schema_learner/proposals/**/*.md     (when they exist)
      - xml_emitter/dry_run/migration_notes.md
      - Any *intervention*.md or *findings*.md anywhere in the toolkit
    
    NOT in scope:
      - DESIGN.md, README.md, GETTING_STARTED.md (these ARE
        engineer-authored — exempt by file path)
      - SCHEMA_CURATION_NOTES.md and similar (engineer-authored)
      - test_*.py (test code includes these phrases as patterns to detect)
      - Inside skills/ directories (third-party docs)
    """
    targets: list[Path] = []

    # Schema-learner proposals (when the engine starts producing them)
    proposals_dir = ROOT / "schema_learner" / "proposals"
    if proposals_dir.is_dir():
        targets.extend(proposals_dir.rglob("*.md"))

    # The migration notes file is engine output and must comply
    migration_notes = ROOT / "xml_emitter" / "dry_run" / "migration_notes.md"
    if migration_notes.is_file():
        targets.append(migration_notes)

    # Any intervention or findings doc anywhere in the toolkit's
    # output paths (defensive — covers future engines that produce
    # similar artifacts)
    for pattern in ("**/intervention*.md", "**/findings*.md"):
        for f in ROOT.glob(pattern):
            # Exclude design docs and the test itself
            rel = f.relative_to(ROOT)
            if rel.parts[0] in {"harness", "schema_lib", "docs"}:
                continue
            if f not in targets:
                targets.append(f)

    return targets


# ---------------------------------------------------------------------------
# Self-test: synthetic violations to prove the audit works
# ---------------------------------------------------------------------------

def test_audit_catches_unsourced_claim() -> tuple[bool, str]:
    """The audit must flag a known-bad sentence missing a citation."""
    bad = "The element vpn-portal represents a tunnel-VPN surface."
    # Wrap in fake-file context
    findings = _scan_unsourced_claims(bad, Path("synthetic.md"))
    if not findings:
        return False, ("audit FAILED to catch unsourced claim "
                       "'represents a tunnel-VPN surface'")
    return True, f"caught unsourced claim ({len(findings)} finding(s))"


def test_audit_passes_cited_claim() -> tuple[bool, str]:
    """The audit must NOT flag a sentence with an inline citation."""
    good = ("The element vpn-portal represents the WatchGuard Access "
            "Portal HTML5 web app, per WatchGuard help center "
            "documentation https://www.watchguard.com/help/docs/")
    findings = _scan_unsourced_claims(good, Path("synthetic.md"))
    if findings:
        return False, (f"audit flagged a cited claim: {findings[0]}")
    return True, "cited claim correctly passed"


def test_audit_catches_answer_suggesting_phrase() -> tuple[bool, str]:
    """The audit must flag answer-suggesting phrases in engine output."""
    bad = "This element looks like a VPN tunnel surface."
    findings = _scan_answer_suggesting_phrases(bad, Path("synthetic.md"))
    if not findings:
        return False, "audit FAILED to catch 'looks like'"
    return True, f"caught answer-suggesting phrase ({len(findings)} finding(s))"


def test_audit_respects_operator_block() -> tuple[bool, str]:
    """Content inside operator-authored blocks must NOT be audited."""
    bad_in_op_block = (
        "Engine text here, no claims.\n"
        "\n"
        f"{EXPLICIT_OPERATOR_BLOCK_OPEN}\n"
        "I, the operator, declare this looks like a VPN portal.\n"
        f"{EXPLICIT_OPERATOR_BLOCK_CLOSE}\n"
    )
    engine_only = _engine_only_text(bad_in_op_block)
    findings = _scan_answer_suggesting_phrases(
        engine_only, Path("synthetic.md"))
    if findings:
        return False, (
            f"audit flagged operator-authored text: {findings[0]}")
    return True, "operator-authored block correctly exempted"


def test_audit_respects_observation_block() -> tuple[bool, str]:
    """Content inside engine-observation blocks allows structural
    'is' statements without citation."""
    structural = (
        f"{EXPLICIT_OBSERVATION_BLOCK_OPEN}\n"
        "Element vpn-portal is a top-level child of root.\n"
        "Element vpn-portal has 12 child element types.\n"
        f"{EXPLICIT_OBSERVATION_BLOCK_CLOSE}\n"
    )
    engine_only = _engine_only_text(structural)
    findings = _scan_unsourced_claims(engine_only, Path("synthetic.md"))
    if findings:
        return False, (
            f"audit flagged structural observation: {findings[0]}")
    return True, "structural observation block correctly exempted"


def test_audit_finds_real_violations_in_toolkit() -> tuple[bool, str]:
    """Run the audit against the real toolkit. Should currently be
    clean (or surface only known issues we've documented)."""
    targets = files_to_audit()
    all_findings: list[str] = []
    for f in targets:
        all_findings.extend(audit_file(f))
    if all_findings:
        # If real findings exist, this is the test telling us we have
        # actual provenance violations to fix in the toolkit's output.
        report = "\n".join(all_findings[:10])
        return False, (
            f"audit found {len(all_findings)} provenance violation(s) "
            f"in toolkit output:\n{report}"
        )
    return True, (f"audit clean across {len(targets)} target file(s)")


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

TESTS = [
    ("audit_catches_unsourced_claim", test_audit_catches_unsourced_claim),
    ("audit_passes_cited_claim", test_audit_passes_cited_claim),
    ("audit_catches_answer_suggesting_phrase",
     test_audit_catches_answer_suggesting_phrase),
    ("audit_respects_operator_block", test_audit_respects_operator_block),
    ("audit_respects_observation_block",
     test_audit_respects_observation_block),
    ("audit_finds_real_violations_in_toolkit",
     test_audit_finds_real_violations_in_toolkit),
]


def main() -> int:
    print("schema_learner provenance audit (Test #9 — principle policing)")
    print()
    print(f"{'TEST':<48} {'RESULT':<8} DETAIL")
    print("-" * 95)

    fail = 0
    for name, fn in TESTS:
        try:
            ok, msg = fn()
        except Exception as e:
            ok, msg = False, f"EXC: {type(e).__name__}: {e}"
        status = "PASS" if ok else "FAIL"
        print(f"{name:<48} {status:<8} {msg[:140]}")
        if not ok:
            fail += 1

    print()
    if fail == 0:
        print(f"All {len(TESTS)} tests passed. Founding principle is enforced.")
        return 0
    print(f"{fail} of {len(TESTS)} tests FAILED. Principle violations exist.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
