#!/usr/bin/env python3
"""
test_phase8_skeleton_fixes.py
=============================

Phase 8 regression suite — the four fixes Captain's friend (independent
operator) caught when reviewing the emitted XML during Memorial Day
staycation:

  Fix A — Device invariants (version stanza) get __OPERATOR_REPLACE__
          sentinels by default; CLI flags inject explicit values.
  Fix B — Self-closing tags render as <tag/> not <tag />.
  Fix C — Two flavors of scaffolding preservation:
            * gateway-wireless-controller kept verbatim (was being
              flattened to <gateway-wireless-controller/>)
            * revision-history fresh-stamped with one toolkit-signed entry
  Fix D — wg_validator refuses to bless any XML still carrying
          __OPERATOR_REPLACE__ sentinels.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "xml_emitter"))
sys.path.insert(0, str(ROOT / "wg_validator"))

# Direct imports for fast unit-test coverage
from make_skeleton import Scrubber  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_tmp_skeleton_config(tmp: Path) -> Path:
    """Build a minimal, valid skeleton_config.ini and a tiny input XML
    in tmp/ so tests don't touch the real corpus."""
    # Make a minimal input XML to scrub
    src_xml = tmp / "input.xml"
    src_xml.write_text(
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<profile>\n'
        '  <product-grade>2</product-grade>\n'
        '  <rs-version>1068452504</rs-version>\n'
        '  <using-cpm-profile>0</using-cpm-profile>\n'
        '  <for-version>12.5.9</for-version>\n'
        '  <xml-purpose>2</xml-purpose>\n'
        '  <base-model></base-model>\n'
        '  <service-list>\n'
        '    <service><name>Foo</name></service>\n'
        '  </service-list>\n'
        '  <ras-user-list>\n'
        '    <ras-user><name>alice</name></ras-user>\n'
        '  </ras-user-list>\n'
        '  <gateway-wireless-controller>\n'
        '    <ap-list/>\n'
        '    <ssid-list/>\n'
        '    <policy-domain-list/>\n'
        '    <global-settings>\n'
        '      <gwc-enabled>0</gwc-enabled>\n'
        '      <auto-firmware-update>1</auto-firmware-update>\n'
        '    </global-settings>\n'
        '  </gateway-wireless-controller>\n'
        '  <revision-history>\n'
        '    <revision>\n'
        '      <module-id>Old Policy Manager</module-id>\n'
        '      <time>1000000000</time>\n'
        '      <comment>Original revision from JPA reference</comment>\n'
        '    </revision>\n'
        '  </revision-history>\n'
        '</profile>\n',
        encoding="utf-8")

    cfg = tmp / "skeleton_config.ini"
    cfg.write_text(f"""[io]
input_export = {src_xml}
output_skeleton = {tmp / 'skeleton.xml'}
output_audit = {tmp / 'audit.json'}

[empty_lists]
description = test
migration_replaceable = service-list
migration_optional = ras-user-list

[empty_lists_secondary]
description = test
audit_trails =

[preserve_lists]
description = test
device_defaults =
device_invariants = product-grade, rs-version, using-cpm-profile, for-version,
                    xml-purpose, base-model
preserve_with_caveats =

[preserve_scaffolding]
description = test
verbatim_from_reference = gateway-wireless-controller
fresh_stamp = revision-history

[redact]
description = test

[device_identity_redact]
description = test
xpaths =

[output]
xml_declaration = <?xml version="1.0" encoding="UTF-8"?>
header_comment = TEST SKELETON
""", encoding="utf-8")
    return cfg


# ---------------------------------------------------------------------------
# Fix A — device invariants
# ---------------------------------------------------------------------------

def test_device_invariants_default_to_sentinels() -> tuple[bool, str]:
    """Without CLI overrides, each device_invariant gets a sentinel."""
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        cfg = _make_tmp_skeleton_config(td)
        s = Scrubber(cfg)
        s.run()
        out = (td / "skeleton.xml").read_text(encoding="utf-8")
        for tag in ["product-grade", "rs-version", "using-cpm-profile",
                    "for-version", "xml-purpose", "base-model"]:
            sentinel = f"__OPERATOR_REPLACE__{tag}__"
            if sentinel not in out:
                return False, f"missing sentinel for {tag!r}"
        return True, ("all 6 device invariants emit "
                      "__OPERATOR_REPLACE__ sentinels by default")


def test_device_invariants_cli_overrides_bypass_sentinels() -> tuple[bool, str]:
    """When invariant_overrides is provided, those tags get explicit
    values instead of sentinels."""
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        cfg = _make_tmp_skeleton_config(td)
        s = Scrubber(cfg, invariant_overrides={
            "for-version": "12.10.2",
            "rs-version": "1234567890",
            "product-grade": "2",
            "xml-purpose": "2",
        })
        s.run()
        out = (td / "skeleton.xml").read_text(encoding="utf-8")
        if "<for-version>12.10.2</for-version>" not in out:
            return False, "for-version override did not apply"
        if "<rs-version>1234567890</rs-version>" not in out:
            return False, "rs-version override did not apply"
        if "__OPERATOR_REPLACE__for-version__" in out:
            return False, "for-version still has sentinel despite override"
        # Partial override should still leave others as sentinels
        if "__OPERATOR_REPLACE__using-cpm-profile__" not in out:
            return False, ("using-cpm-profile should still be sentinel "
                           "(not overridden)")
        return True, ("CLI overrides bypass sentinels; partial overrides "
                      "leave un-overridden fields as sentinels")


def test_device_invariants_was_dead_config_now_consumed() -> tuple[bool, str]:
    """Regression: device_invariants was DECLARED in skeleton_config.ini
    but never READ by make_skeleton.py before Phase 8. This test ensures
    we don't slide back into the dead-config state."""
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        cfg = _make_tmp_skeleton_config(td)
        s = Scrubber(cfg)
        # The list must be populated
        if not s.device_invariants:
            return False, "device_invariants list is empty — config is dead"
        if len(s.device_invariants) != 6:
            return False, (f"expected 6 invariants, got "
                           f"{len(s.device_invariants)}")
        s.run()
        # And the audit must show they were actually processed
        audit = json.loads((td / "audit.json").read_text(encoding="utf-8"))
        if len(audit.get("device_invariants_processed", [])) != 6:
            return False, (f"expected 6 invariants processed, got "
                           f"{len(audit.get('device_invariants_processed', []))}")
        return True, ("device_invariants config is now consumed; "
                      "no longer dead config")


def test_guidance_comment_present_when_sentinels_used() -> tuple[bool, str]:
    """When sentinels are emitted, the skeleton carries an XML comment
    above the version stanza explaining what the operator must do."""
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        cfg = _make_tmp_skeleton_config(td)
        s = Scrubber(cfg)
        s.run()
        out = (td / "skeleton.xml").read_text(encoding="utf-8")
        if "OPERATOR ACTION REQUIRED" not in out:
            return False, "missing OPERATOR ACTION REQUIRED comment"
        if "wg_validator will fail validation" not in out:
            return False, "missing validator reference in comment"
        return True, "guidance comment present when sentinels are emitted"


# ---------------------------------------------------------------------------
# Fix B — self-closing tags
# ---------------------------------------------------------------------------

def test_self_closing_tags_have_no_space() -> tuple[bool, str]:
    """Output uses <tag/> not <tag />."""
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        cfg = _make_tmp_skeleton_config(td)
        s = Scrubber(cfg)
        s.run()
        out = (td / "skeleton.xml").read_text(encoding="utf-8")
        if re.search(r'<[a-zA-Z][a-zA-Z0-9_-]* />', out):
            sample = re.findall(r'<[a-zA-Z][a-zA-Z0-9_-]* />', out)[:3]
            return False, f"self-closing tags with space: {sample}"
        # Confirm there ARE self-closing tags (just no space form)
        if not re.search(r'<[a-zA-Z][a-zA-Z0-9_-]*/>', out):
            return False, "no self-closing tags present at all (suspicious)"
        return True, "all self-closing tags render as <tag/> with no space"


# ---------------------------------------------------------------------------
# Fix C-scaffolding — gateway-wireless-controller preserved verbatim
# ---------------------------------------------------------------------------

def test_scaffolding_preserved_verbatim() -> tuple[bool, str]:
    """gateway-wireless-controller's inner structure is kept, not flattened.

    Independent operator caught: emitted XML had <gateway-wireless-controller/>
    (empty) but JPA reference has 8+ inner elements that the importer expects.
    """
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        cfg = _make_tmp_skeleton_config(td)
        s = Scrubber(cfg)
        s.run()
        out = (td / "skeleton.xml").read_text(encoding="utf-8")
        # Must have the inner structure, not just <gateway-wireless-controller/>
        if "<gateway-wireless-controller/>" in out:
            return False, ("gateway-wireless-controller was flattened "
                           "to self-closing (regression)")
        if "<ap-list/>" not in out:
            return False, "missing <ap-list/> inside scaffolding"
        if "<ssid-list/>" not in out:
            return False, "missing <ssid-list/> inside scaffolding"
        if "<gwc-enabled>0</gwc-enabled>" not in out:
            return False, "missing <gwc-enabled>0</gwc-enabled> default"
        return True, ("gateway-wireless-controller scaffolding "
                      "preserved verbatim with inner elements intact")


def test_scaffolding_verbatim_listed_in_audit() -> tuple[bool, str]:
    """Audit records each scaffolding container preserved."""
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        cfg = _make_tmp_skeleton_config(td)
        s = Scrubber(cfg)
        s.run()
        audit = json.loads((td / "audit.json").read_text(encoding="utf-8"))
        preserved = audit.get("scaffolding_preserved_verbatim", [])
        tags = [item["tag"] for item in preserved]
        if "gateway-wireless-controller" not in tags:
            return False, ("audit does not record "
                           "gateway-wireless-controller preservation")
        return True, "scaffolding preservation is recorded in the audit"


# ---------------------------------------------------------------------------
# Fix C-revision — revision-history fresh-stamped
# ---------------------------------------------------------------------------

def test_revision_history_gets_fresh_stamp() -> tuple[bool, str]:
    """revision-history is cleared and replaced with one fresh entry."""
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        cfg = _make_tmp_skeleton_config(td)
        s = Scrubber(cfg)
        s.run()
        out = (td / "skeleton.xml").read_text(encoding="utf-8")
        if "n2nhu lab migration toolkit" not in out:
            return False, "fresh stamp module-id not found"
        # The original revision content should NOT be in the output
        if "Old Policy Manager" in out:
            return False, ("old revision content leaked into output "
                           "(fresh-stamp should have cleared it)")
        if "Original revision from JPA reference" in out:
            return False, ("old revision comment leaked into output "
                           "(fresh-stamp should have cleared it)")
        return True, ("revision-history fresh-stamped with toolkit module-id; "
                      "old content cleared")


def test_revision_history_stamp_has_current_time() -> tuple[bool, str]:
    """The fresh-stamped revision has a recent Unix timestamp."""
    import time
    before = int(time.time())
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        cfg = _make_tmp_skeleton_config(td)
        s = Scrubber(cfg)
        s.run()
        out = (td / "skeleton.xml").read_text(encoding="utf-8")
        m = re.search(
            r'<module-id>n2nhu lab migration toolkit</module-id>\s*'
            r'<time>(\d+)</time>', out)
        if not m:
            return False, "fresh-stamp time field not found in expected shape"
        stamp = int(m.group(1))
        after = int(time.time())
        # Stamp must be in [before-1, after+1] window
        if not (before - 1 <= stamp <= after + 1):
            return False, (f"stamp {stamp} not in expected window "
                           f"[{before-1}, {after+1}]")
        return True, ("revision-history stamp time is current "
                      "(within test window)")


# ---------------------------------------------------------------------------
# Fix D — validator catches unreplaced sentinels
# ---------------------------------------------------------------------------

def test_validator_fails_on_unreplaced_sentinel() -> tuple[bool, str]:
    """wg_validator refuses to bless XML still carrying sentinels."""
    from wg_validator import WgValidator, load_wg_schema
    schema_path = ROOT / "wg_validator" / "wg_xml_schema.ini"
    if not schema_path.is_file():
        return False, f"schema missing: {schema_path}"

    schema = load_wg_schema(schema_path)
    validator = WgValidator(schema=schema, schema_path=schema_path)
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        xml = td / "bad.xml"
        xml.write_text(
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<profile>\n'
            '  <for-version>__OPERATOR_REPLACE__for-version__</for-version>\n'
            '</profile>\n', encoding="utf-8")
        report = validator.validate(xml)
        errors = [i for i in report.issues
                  if i.severity == 'error' and i.rule == 'operator-sentinel']
        if not errors:
            return False, "validator did not flag the sentinel"
        if 'for-version' not in errors[0].message:
            return False, ("sentinel message did not name the offending tag: "
                           f"{errors[0].message}")
        return True, "validator catches unreplaced operator sentinel"


def test_validator_passes_when_sentinels_replaced() -> tuple[bool, str]:
    """When sentinels are replaced with real values, validator proceeds
    past the sentinel check (may still flag other issues, but
    operator-sentinel is not among them)."""
    from wg_validator import WgValidator, load_wg_schema
    schema_path = ROOT / "wg_validator" / "wg_xml_schema.ini"
    schema = load_wg_schema(schema_path)
    validator = WgValidator(schema=schema, schema_path=schema_path)
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        xml = td / "good.xml"
        xml.write_text(
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<profile>\n'
            '  <for-version>12.10.2</for-version>\n'
            '</profile>\n', encoding="utf-8")
        report = validator.validate(xml)
        sentinel_errors = [i for i in report.issues
                           if i.rule == 'operator-sentinel']
        if sentinel_errors:
            return False, ("validator flagged sentinel on clean XML: "
                           f"{sentinel_errors[0].message}")
        return True, ("validator does NOT flag sentinels when all are "
                      "replaced with real values")


def test_validator_sentinel_check_is_a_hard_stop() -> tuple[bool, str]:
    """When a sentinel is present, validator returns immediately —
    elements_checked should be 0 (no downstream walk happened)."""
    from wg_validator import WgValidator, load_wg_schema
    schema_path = ROOT / "wg_validator" / "wg_xml_schema.ini"
    schema = load_wg_schema(schema_path)
    validator = WgValidator(schema=schema, schema_path=schema_path)
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        xml = td / "bad.xml"
        xml.write_text(
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            '<profile>\n'
            '  <for-version>__OPERATOR_REPLACE__for-version__</for-version>\n'
            '  <service-list><service><name>BadShape</name></service></service-list>\n'
            '</profile>\n', encoding="utf-8")
        report = validator.validate(xml)
        # If sentinel check is a hard stop, the schema walk shouldn't run.
        # That means no 'unknown-element' or schema-walk errors should appear.
        non_sentinel = [i for i in report.issues
                        if i.rule != 'operator-sentinel']
        if non_sentinel:
            return False, ("sentinel check should be a hard stop, but "
                           f"got non-sentinel issues: {non_sentinel[:2]}")
        return True, ("sentinel check is a hard stop; downstream "
                      "validation does not run")


# ---------------------------------------------------------------------------
# End-to-end: CLI run produces a self-consistent skeleton
# ---------------------------------------------------------------------------

def test_cli_invocation_produces_skeleton() -> tuple[bool, str]:
    """End-to-end: invoking make_skeleton.py via CLI with overrides
    produces a skeleton with only the un-overridden invariant remaining
    as a sentinel."""
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        cfg = _make_tmp_skeleton_config(td)
        result = subprocess.run(
            [sys.executable, str(ROOT / "xml_emitter" / "make_skeleton.py"),
             "--config", str(cfg), "--no-validate",
             "--for-version", "12.10.2",
             "--rs-version", "1234567890",
             "--product-grade", "2",
             "--xml-purpose", "2",
             "--using-cpm-profile", "0"],
            capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            return False, (f"CLI returned {result.returncode}; "
                           f"stderr: {result.stderr[:300]}")
        skel = td / "skeleton.xml"
        if not skel.is_file():
            return False, "skeleton not produced"
        out = skel.read_text(encoding="utf-8")
        # Count REAL sentinels (matching the validator's regex), not
        # literal "__OPERATOR_REPLACE__" text in the guidance comment.
        real_sentinels = re.findall(
            r'__OPERATOR_REPLACE__([A-Za-z0-9_-]+)__', out)
        # Only one real sentinel should remain: base-model (not overridden)
        if len(real_sentinels) != 1 or real_sentinels[0] != "base-model":
            return False, (f"expected exactly 1 sentinel for base-model, "
                           f"got: {real_sentinels}")
        # Confirm the explicit overrides landed in the output
        if "<for-version>12.10.2</for-version>" not in out:
            return False, "for-version override not in output"
        return True, ("CLI invocation produces a clean skeleton; "
                      "only un-overridden invariants remain as sentinels")


# ---------------------------------------------------------------------------
# Test registry
# ---------------------------------------------------------------------------

TESTS = [
    # Fix A
    ("device_invariants_default_to_sentinels",
     test_device_invariants_default_to_sentinels),
    ("device_invariants_cli_overrides_bypass_sentinels",
     test_device_invariants_cli_overrides_bypass_sentinels),
    ("device_invariants_was_dead_config_now_consumed",
     test_device_invariants_was_dead_config_now_consumed),
    ("guidance_comment_present_when_sentinels_used",
     test_guidance_comment_present_when_sentinels_used),
    # Fix B
    ("self_closing_tags_have_no_space",
     test_self_closing_tags_have_no_space),
    # Fix C-scaffolding
    ("scaffolding_preserved_verbatim",
     test_scaffolding_preserved_verbatim),
    ("scaffolding_verbatim_listed_in_audit",
     test_scaffolding_verbatim_listed_in_audit),
    # Fix C-revision
    ("revision_history_gets_fresh_stamp",
     test_revision_history_gets_fresh_stamp),
    ("revision_history_stamp_has_current_time",
     test_revision_history_stamp_has_current_time),
    # Fix D
    ("validator_fails_on_unreplaced_sentinel",
     test_validator_fails_on_unreplaced_sentinel),
    ("validator_passes_when_sentinels_replaced",
     test_validator_passes_when_sentinels_replaced),
    ("validator_sentinel_check_is_a_hard_stop",
     test_validator_sentinel_check_is_a_hard_stop),
    # End-to-end CLI
    ("cli_invocation_produces_skeleton",
     test_cli_invocation_produces_skeleton),
]


def main() -> int:
    print("=" * 70)
    print("Phase 8 — Skeleton Fixes (post-friend-review)")
    print("=" * 70)
    print()

    passed = 0
    failed = 0
    for name, fn in TESTS:
        try:
            ok, msg = fn()
        except Exception as e:
            ok, msg = False, f"exception: {e}"
        status = "PASS" if ok else "FAIL"
        print(f"  {name:<55} {status}  {msg}")
        if ok:
            passed += 1
        else:
            failed += 1

    print()
    if failed == 0:
        print(f"All {passed} Phase 8 tests passed.")
        return 0
    else:
        print(f"{passed} passed, {failed} failed.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
