#!/usr/bin/env python3
"""
test_phase6_5_auto_promotion.py
================================

Phase 6.5 regression tests for auto-promotion of deferred surfaces.

The Phase 6 lifecycle this completes:

  1. TEMPLATE_FW.xml: <DLP> appears disabled (empty container)
     → engine emits finding with tier_suggestion=3
     → operator runs triage --tier 1 --auto-sideline-deferred
     → sideline entry created with status='deferred_disabled_in_source'

  2. customerA.xml arrives later: <DLP> appears enabled
     (or any non-disabled status)
     → engine detects the deferred sideline entry by fingerprint match
     → emits finding with category='auto_promoted_from_deferred'
     → transitions sideline entry to status='pending_triage'
     → original deferral context preserved in finding detail

  3. customerB.xml arrives: <DLP> appears enabled
     → engine finds sideline entry but status != 'deferred_*'
     → NO auto-promotion fires (idempotency)
     → finding emits normally (Cat-1 or auto-reuse, depending on whether
       customerA's triage completed)

Tests verify:
  - find_deferred_sideline_entry only matches deferred-status entries
  - transition_sideline_status updates status + appends transition note
  - Engine emits auto_promoted_from_deferred category on resurface
  - Sideline status transitions to pending_triage on promotion
  - Idempotency: second resurface does NOT re-promote
  - Operator-driven sideline entries (status='open') don't auto-promote
  - Existing Phase 1/2 gates still apply (banned-suppression precedence)
  - The promoted finding carries the original deferral context
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "schema_learner"))

from corpus_tiers import (  # noqa: E402
    SidelineEntry, _sideline_queue_path, _sideline_root,
    find_deferred_sideline_entry,
    find_existing_sideline_entry,
    load_sideline_queue,
    make_entry_id,
    transition_sideline_status,
    write_sideline_entry,
)


# ---------------------------------------------------------------------------
# State snapshot/restore
# ---------------------------------------------------------------------------

def _snapshot_state() -> dict[str, bytes | None]:
    snap: dict[str, bytes | None] = {}
    paths = [_sideline_queue_path()]
    for p in paths:
        snap[str(p)] = p.read_bytes() if p.is_file() else None
    if _sideline_root().is_dir():
        for f in _sideline_root().iterdir():
            if f.is_file():
                snap[str(f)] = f.read_bytes()
    return snap


def _restore_state(snap: dict[str, bytes | None]) -> None:
    if _sideline_root().is_dir():
        for f in list(_sideline_root().iterdir()):
            if str(f) not in snap and f.is_file():
                f.unlink()
    for path_str, contents in snap.items():
        p = Path(path_str)
        if contents is None:
            if p.is_file():
                p.unlink()
        else:
            p.write_bytes(contents)


def _make_deferred_entry(
    surface_tag: str,
    tokens: str = "test, surface",
) -> SidelineEntry:
    """Create a Phase 6 deferred sideline entry for testing."""
    import datetime as _dt
    entry_id = make_entry_id(surface_tag, 'sl')
    entry = SidelineEntry(
        entry_id=entry_id,
        surface_tag=surface_tag,
        operator='test-suite',
        timestamp=_dt.datetime.now().isoformat(),
        reason=(f'Phase 6 auto-defer: enabled_status=disabled, '
                f'tier=3. Evidence: empty container'),
        first_seen_in='TEST_SOURCE',
        last_seen_in='TEST_SOURCE',
        last_seen_at=_dt.datetime.now().isoformat(),
        source_proposal='TEST_SOURCE',
        children_tags_fingerprint='',
        value_patterns_fingerprint='',
        naming_tokens_fingerprint=tokens,
        status='deferred_disabled_in_source',
    )
    write_sideline_entry(entry)
    return entry


# ---------------------------------------------------------------------------
# Helper unit tests
# ---------------------------------------------------------------------------

def test_find_deferred_matches_only_deferred_status() -> tuple[bool, str]:
    """find_deferred_sideline_entry must filter on status."""
    snap = _snapshot_state()
    try:
        # Create one deferred and one operator-open entry with same tag
        unique = uuid.uuid4().hex[:8]
        deferred_tag = f"DeferredOnly_{unique}"
        _make_deferred_entry(deferred_tag,
                              tokens=f"deferred, {unique}")

        # Lookup: matches the deferred one
        fp = {
            'children_tags_fingerprint': '',
            'value_patterns_fingerprint': '',
            'naming_tokens_fingerprint': f'deferred, {unique}',
        }
        match = find_deferred_sideline_entry(deferred_tag, fp)
        if match is None:
            return False, "deferred entry should have been found"
        if match.status != 'deferred_disabled_in_source':
            return False, ("matched entry has wrong status: "
                           f"{match.status}")

        # Transition the entry to pending_triage, then re-lookup
        ok = transition_sideline_status(
            match.entry_id, 'pending_triage',
            transition_note='test transition')
        if not ok:
            return False, "transition failed"
        match_after = find_deferred_sideline_entry(deferred_tag, fp)
        if match_after is not None:
            return False, ("after transition to pending_triage, "
                           "deferred lookup should return None")
        return True, ("find_deferred only matches "
                      "status=deferred_disabled_in_source")
    finally:
        _restore_state(snap)


def test_find_deferred_ignores_operator_sideline() -> tuple[bool, str]:
    """Operator-driven sideline (status='open') doesn't match
    find_deferred."""
    snap = _snapshot_state()
    try:
        import datetime as _dt
        unique = uuid.uuid4().hex[:8]
        surface_tag = f"OperatorSidelined_{unique}"
        entry_id = make_entry_id(surface_tag, 'sl')
        entry = SidelineEntry(
            entry_id=entry_id,
            surface_tag=surface_tag,
            operator='jimames',
            timestamp=_dt.datetime.now().isoformat(),
            reason='operator manually sidelined this',
            first_seen_in='TEST', last_seen_in='TEST',
            last_seen_at=_dt.datetime.now().isoformat(),
            source_proposal='TEST',
            children_tags_fingerprint='',
            value_patterns_fingerprint='',
            naming_tokens_fingerprint=f'op, {unique}',
            status='open',  # Phase 2 operator-driven
        )
        write_sideline_entry(entry)

        fp = {
            'children_tags_fingerprint': '',
            'value_patterns_fingerprint': '',
            'naming_tokens_fingerprint': f'op, {unique}',
        }
        match = find_deferred_sideline_entry(surface_tag, fp)
        if match is not None:
            return False, (f"operator-sidelined (status=open) entry "
                           f"should NOT match find_deferred")
        return True, ("operator-sidelined entries excluded from "
                      "find_deferred")
    finally:
        _restore_state(snap)


def test_transition_sideline_status_updates_and_appends() -> tuple[bool, str]:
    """transition_sideline_status updates status and appends transition
    note to reason field."""
    snap = _snapshot_state()
    try:
        unique = uuid.uuid4().hex[:8]
        surface_tag = f"TransitionTest_{unique}"
        entry = _make_deferred_entry(surface_tag,
                                       tokens=f"trans, {unique}")
        original_reason = entry.reason

        ok = transition_sideline_status(
            entry.entry_id,
            new_status='pending_triage',
            transition_note='auto-promoted in customerA_proposal')
        if not ok:
            return False, "transition returned False"

        # Reload and verify
        queue = load_sideline_queue()
        loaded = next(e for e in queue if e.entry_id == entry.entry_id)
        if loaded.status != 'pending_triage':
            return False, (f"status not updated: got {loaded.status!r}")
        if 'TRANSITION:' not in loaded.reason:
            return False, ("transition note not appended to reason: "
                           f"{loaded.reason[:200]}")
        if 'customerA_proposal' not in loaded.reason:
            return False, ("transition detail not preserved: "
                           f"{loaded.reason[:200]}")
        return True, "transition updates status AND appends audit note"
    finally:
        _restore_state(snap)


def test_transition_nonexistent_entry_returns_false() -> tuple[bool, str]:
    """transition on a nonexistent entry returns False cleanly."""
    snap = _snapshot_state()
    try:
        ok = transition_sideline_status(
            'sl_nonexistent_xyz', 'pending_triage')
        if ok:
            return False, "transition on missing entry should fail"
        return True, "missing entry handled gracefully"
    finally:
        _restore_state(snap)


# ---------------------------------------------------------------------------
# End-to-end engine integration test
# ---------------------------------------------------------------------------

def test_engine_emits_auto_promoted_category() -> tuple[bool, str]:
    """End-to-end: deferred entry exists, engine sees the surface as
    enabled in a new XML, emits auto_promoted_from_deferred."""
    snap = _snapshot_state()
    try:
        from schema_learner import (
            LearnerConfig, SchemaLearner,
        )
        unique = uuid.uuid4().hex[:8]
        surface_tag = f"PromoTest{unique}"

        # Create a deferred sideline entry matching what we'll later see
        _make_deferred_entry(
            surface_tag,
            tokens=f"promotest{unique.lower()}")

        # Synthesize a XML config where this surface is now ENABLED
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            corpus = td / "corpus"
            corpus.mkdir()
            schema_path = td / "schema.ini"
            schema_path.write_text("; empty schema\n", encoding='utf-8')
            proposals = td / "proposals"
            proposals.mkdir()
            input_xml = td / "input.xml"
            input_xml.write_text(
                f"<?xml version='1.0'?>\n"
                f"<profile><{surface_tag}>1</{surface_tag}></profile>\n",
                encoding='utf-8')

            config = LearnerConfig(
                corpus_dir=corpus,
                existing_schema_path=schema_path,
                proposals_dir=proposals,
                findings_format='both',
                auto_propose_minimum=0.4,
                high_confidence=0.85,
                medium_confidence=0.5,
                top_k_neighbors=10,
                neighbor_minimum_similarity=0.1,
                auto_reuse_threshold=0.85,
                auto_reuse_emit_provenance=True,
                auto_reuse_report_findings=True,
                banned_suppress_threshold=0.8,
                require_operator_approval=True,
                report_unplaceable_findings=True,
                backup_before_merge=True,
            )
            learner = SchemaLearner(config)
            learner.load_existing_schema()
            learner.load_corpus()
            findings = learner.detect_findings(input_xml, "PROMOTEST")

            # Look for the auto_promoted_from_deferred finding
            promoted = [f for f in findings
                         if f.category == 'auto_promoted_from_deferred']
            if not promoted:
                return False, (f"expected auto_promoted finding, got "
                               f"categories: "
                               f"{[f.category for f in findings]}")
            
            f = promoted[0]
            if f.element_tag != surface_tag:
                return False, (f"wrong surface_tag on promoted finding: "
                               f"{f.element_tag}")
            if 'sideline_entry_id' not in f.detail:
                return False, "promoted finding missing sideline_entry_id"
            if 'original_deferral_reason' not in f.detail:
                return False, ("promoted finding missing "
                               "original_deferral_reason")
            if 'PromoTest' not in f.detail.get('sideline_entry_id', ''):
                return False, ("sideline_entry_id doesn't reference "
                               "this surface tag")

        # Verify the sideline entry's status transitioned
        queue = load_sideline_queue()
        matching = [e for e in queue if e.surface_tag == surface_tag]
        if not matching:
            return False, "sideline entry vanished after promotion"
        if matching[0].status != 'pending_triage':
            return False, (f"sideline status not transitioned: "
                           f"{matching[0].status}")
        return True, ("engine emits auto_promoted_from_deferred, "
                      "transitions sideline to pending_triage")
    finally:
        _restore_state(snap)


def test_idempotency_no_re_promotion() -> tuple[bool, str]:
    """Second engine run after auto-promotion does NOT re-promote
    (sideline now in pending_triage, not deferred)."""
    snap = _snapshot_state()
    try:
        from schema_learner import LearnerConfig, SchemaLearner
        unique = uuid.uuid4().hex[:8]
        surface_tag = f"IdempTest{unique}"

        # Deferred entry
        _make_deferred_entry(
            surface_tag,
            tokens=f"idemptest{unique.lower()}")

        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            corpus = td / "corpus"
            corpus.mkdir()
            schema_path = td / "schema.ini"
            schema_path.write_text("; empty\n", encoding='utf-8')
            proposals = td / "proposals"
            proposals.mkdir()
            input_xml = td / "input.xml"
            input_xml.write_text(
                f"<?xml version='1.0'?>\n"
                f"<profile><{surface_tag}>1</{surface_tag}></profile>\n",
                encoding='utf-8')

            config = LearnerConfig(
                corpus_dir=corpus, existing_schema_path=schema_path,
                proposals_dir=proposals, findings_format='both',
                auto_propose_minimum=0.4, high_confidence=0.85,
                medium_confidence=0.5, top_k_neighbors=10,
                neighbor_minimum_similarity=0.1,
                auto_reuse_threshold=0.85,
                auto_reuse_emit_provenance=True,
                auto_reuse_report_findings=True,
                banned_suppress_threshold=0.8,
                require_operator_approval=True,
                report_unplaceable_findings=True,
                backup_before_merge=True,
            )

            # First run: should emit auto_promoted
            learner1 = SchemaLearner(config)
            learner1.load_existing_schema()
            learner1.load_corpus()
            findings1 = learner1.detect_findings(input_xml, "RUN1")
            promoted1 = [f for f in findings1
                          if f.category == 'auto_promoted_from_deferred']
            if not promoted1:
                return False, ("first run should auto-promote, but no "
                               "promoted finding emitted")

            # Second run: same surface, but sideline now in
            # pending_triage. Engine should NOT auto-promote again.
            learner2 = SchemaLearner(config)
            learner2.load_existing_schema()
            learner2.load_corpus()
            findings2 = learner2.detect_findings(input_xml, "RUN2")
            promoted2 = [f for f in findings2
                          if f.category == 'auto_promoted_from_deferred']
            if promoted2:
                return False, (f"second run SHOULD NOT re-promote, "
                               f"but emitted "
                               f"{len(promoted2)} promoted finding(s)")
        return True, ("idempotent: second run does not re-promote "
                      "already-promoted surface")
    finally:
        _restore_state(snap)


def test_disabled_surface_does_not_auto_promote() -> tuple[bool, str]:
    """If the new XML has the surface disabled too, auto-promotion
    should NOT fire — there's no state change worth resurfacing."""
    snap = _snapshot_state()
    try:
        from schema_learner import LearnerConfig, SchemaLearner
        unique = uuid.uuid4().hex[:8]
        surface_tag = f"StillOff{unique}"

        _make_deferred_entry(
            surface_tag,
            tokens=f"stilloff{unique.lower()}")

        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            corpus = td / "corpus"
            corpus.mkdir()
            schema_path = td / "schema.ini"
            schema_path.write_text("; empty\n", encoding='utf-8')
            proposals = td / "proposals"
            proposals.mkdir()
            input_xml = td / "input.xml"
            # Surface present but value=0 (disabled)
            input_xml.write_text(
                f"<?xml version='1.0'?>\n"
                f"<profile><{surface_tag}>0</{surface_tag}></profile>\n",
                encoding='utf-8')

            config = LearnerConfig(
                corpus_dir=corpus, existing_schema_path=schema_path,
                proposals_dir=proposals, findings_format='both',
                auto_propose_minimum=0.4, high_confidence=0.85,
                medium_confidence=0.5, top_k_neighbors=10,
                neighbor_minimum_similarity=0.1,
                auto_reuse_threshold=0.85,
                auto_reuse_emit_provenance=True,
                auto_reuse_report_findings=True,
                banned_suppress_threshold=0.8,
                require_operator_approval=True,
                report_unplaceable_findings=True,
                backup_before_merge=True,
            )
            learner = SchemaLearner(config)
            learner.load_existing_schema()
            learner.load_corpus()
            findings = learner.detect_findings(input_xml, "DISABLED_AGAIN")

            promoted = [f for f in findings
                         if f.category == 'auto_promoted_from_deferred']
            if promoted:
                return False, ("surface still disabled — should NOT "
                               "auto-promote, but did")

        # Sideline entry should still be in deferred status
        queue = load_sideline_queue()
        matching = [e for e in queue if e.surface_tag == surface_tag]
        if not matching:
            return False, "sideline entry vanished"
        if matching[0].status != 'deferred_disabled_in_source':
            return False, (f"sideline status changed unexpectedly: "
                           f"{matching[0].status}")
        return True, ("still-disabled surface correctly stays "
                      "deferred (no spurious promotion)")
    finally:
        _restore_state(snap)


# ---------------------------------------------------------------------------
# Provenance audit
# ---------------------------------------------------------------------------

def test_phase6_5_provenance_audit_clean() -> tuple[bool, str]:
    """Phase 6.5 changes must not break the provenance audit."""
    audit = subprocess.run(
        [sys.executable,
         str(ROOT / 'harness' / 'test_schema_learner_provenance.py')],
        capture_output=True, text=True)
    if audit.returncode != 0:
        return False, (f"provenance audit failed: "
                       f"{audit.stdout[:500]}")
    return True, "provenance audit clean on Phase 6.5 output"


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

TESTS = [
    ("find_deferred_matches_only_deferred_status",
     test_find_deferred_matches_only_deferred_status),
    ("find_deferred_ignores_operator_sideline",
     test_find_deferred_ignores_operator_sideline),
    ("transition_sideline_status_updates_and_appends",
     test_transition_sideline_status_updates_and_appends),
    ("transition_nonexistent_entry_returns_false",
     test_transition_nonexistent_entry_returns_false),
    ("engine_emits_auto_promoted_category",
     test_engine_emits_auto_promoted_category),
    ("idempotency_no_re_promotion", test_idempotency_no_re_promotion),
    ("disabled_surface_does_not_auto_promote",
     test_disabled_surface_does_not_auto_promote),
    ("phase6_5_provenance_audit_clean",
     test_phase6_5_provenance_audit_clean),
]


def main() -> int:
    print("Phase 6.5 — Auto-promotion lifecycle")
    print()
    print(f"{'TEST':<55} {'RESULT':<8} DETAIL")
    print("-" * 95)
    fail = 0
    for name, fn in TESTS:
        try:
            ok, msg = fn()
        except Exception as e:
            ok, msg = False, f"EXC: {type(e).__name__}: {e}"
        status = "PASS" if ok else "FAIL"
        print(f"{name:<55} {status:<8} {msg[:140]}")
        if not ok:
            fail += 1
    print()
    if fail == 0:
        print(f"All {len(TESTS)} Phase 6.5 tests passed.")
        return 0
    print(f"{fail} of {len(TESTS)} Phase 6.5 tests FAILED.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
