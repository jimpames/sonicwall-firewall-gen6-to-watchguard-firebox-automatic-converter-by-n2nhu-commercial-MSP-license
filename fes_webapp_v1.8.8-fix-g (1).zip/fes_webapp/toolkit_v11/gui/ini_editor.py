#!/usr/bin/env python3
"""
ini_editor.py
==============

Schema-driven GUI editor for the toolkit's INI configs.

This editor knows nothing about WatchGuard, SonicWall, or any specific
config. It reads a schema INI and produces type-aware editing widgets.
Add a new config? Add its schema, and this editor handles it.

Usage:
    python3 ini_editor.py [config_path] [--schema schema_path]

If --schema isn't given, the editor looks for <config>.schema.ini next
to the config file.
"""
from __future__ import annotations

import argparse
import configparser
import sys
import tkinter as tk
import tkinter.filedialog as fd
import tkinter.messagebox as mb
import tkinter.ttk as ttk
from pathlib import Path

# Import the schema library — works whether we're run from migration_toolkit/
# or from migration_toolkit/gui/
THIS_DIR = Path(__file__).parent.resolve()
TOOLKIT_DIR = THIS_DIR.parent if THIS_DIR.name == "gui" else THIS_DIR
sys.path.insert(0, str(TOOLKIT_DIR))
from schema_lib import (  # noqa: E402
    Schema, SectionSpec, FieldSpec,
    load_schema, validate_config,
)
from schema_lib import comment_preserving_ini as cpi  # noqa: E402


def _read_ini_preserving_case(path: Path) -> configparser.ConfigParser:
    """Read INI without lowercasing keys (we want exact key preservation)."""
    cp = configparser.ConfigParser(
        interpolation=None,
        inline_comment_prefixes=(";",),
        comment_prefixes=("#",),
    )
    cp.optionxform = str  # preserve case
    cp.read(path, encoding="utf-8")
    return cp


def _write_ini_pretty(cp: configparser.ConfigParser, path: Path) -> None:
    """Write INI with reasonable indentation/spacing."""
    with open(path, "w", encoding="utf-8") as f:
        for sect in cp.sections():
            f.write(f"[{sect}]\n")
            for key in cp[sect]:
                val = cp[sect][key]
                if "\n" in val:
                    # Multi-line value: indent continuations
                    lines = val.split("\n")
                    f.write(f"{key} = {lines[0]}\n")
                    for line in lines[1:]:
                        f.write(f"    {line}\n")
                else:
                    f.write(f"{key} = {val}\n")
            f.write("\n")


# ---------------------------------------------------------------------------
# Widget factory: schema field type -> tkinter widget
# Each widget has a get() returning the current string value and set(s) to update.
# ---------------------------------------------------------------------------


class StringWidget:
    def __init__(self, parent, fspec: FieldSpec):
        self.var = tk.StringVar()
        self.frame = ttk.Frame(parent)
        self.entry = ttk.Entry(self.frame, textvariable=self.var, width=60)
        self.entry.pack(fill="x")

    def widget(self):
        return self.frame

    def get(self):
        return self.var.get()

    def set(self, val):
        self.var.set(val or "")


class MultilineWidget:
    def __init__(self, parent, fspec: FieldSpec):
        self.frame = ttk.Frame(parent)
        self.text = tk.Text(self.frame, height=4, width=60, wrap="word",
                            font=("Helvetica", 10))
        self.text.pack(fill="both", expand=True)

    def widget(self):
        return self.frame

    def get(self):
        return self.text.get("1.0", "end-1c")

    def set(self, val):
        self.text.delete("1.0", "end")
        if val:
            self.text.insert("1.0", val)


class BoolWidget:
    def __init__(self, parent, fspec: FieldSpec):
        self.var = tk.BooleanVar()
        self.frame = ttk.Frame(parent)
        self.cb = ttk.Checkbutton(self.frame, variable=self.var)
        self.cb.pack(anchor="w")

    def widget(self):
        return self.frame

    def get(self):
        return "true" if self.var.get() else "false"

    def set(self, val):
        self.var.set(str(val).strip().lower() in ("true", "1", "yes", "on"))


class IntWidget:
    def __init__(self, parent, fspec: FieldSpec):
        self.var = tk.StringVar()
        self.frame = ttk.Frame(parent)
        self.entry = ttk.Spinbox(self.frame, textvariable=self.var,
                                  from_=int(fspec.raw.get("min", "-99999")),
                                  to=int(fspec.raw.get("max", "99999")),
                                  width=15)
        self.entry.pack(anchor="w")

    def widget(self):
        return self.frame

    def get(self):
        return self.var.get()

    def set(self, val):
        self.var.set(val or "0")


class EnumWidget:
    def __init__(self, parent, fspec: FieldSpec):
        self.var = tk.StringVar()
        self.frame = ttk.Frame(parent)
        values = [v.strip() for v in
                  fspec.raw.get("enum_values", "").split(",") if v.strip()]
        self.combo = ttk.Combobox(self.frame, textvariable=self.var,
                                   values=values, state="readonly", width=30)
        self.combo.pack(anchor="w")

    def widget(self):
        return self.frame

    def get(self):
        return self.var.get()

    def set(self, val):
        self.var.set(val or "")


WIDGET_FACTORIES = {
    "string": StringWidget,
    "multiline_string": MultilineWidget,
    "bool": BoolWidget,
    "int": IntWidget,
    "enum": EnumWidget,
    "csv": MultilineWidget,           # MVP — fancier widgets later
    "regex": StringWidget,
    "xpath": StringWidget,
    "path": StringWidget,
    "kv_list": MultilineWidget,       # MVP — kv-grid editor is a follow-up
}


# ---------------------------------------------------------------------------
# Main editor window
# ---------------------------------------------------------------------------


class EditorApp:
    def __init__(self, root: tk.Tk, config_path: Path, schema_path: Path):
        self.root = root
        self.config_path = config_path
        self.schema_path = schema_path
        self.schema = load_schema(schema_path)
        self.cp = _read_ini_preserving_case(config_path)
        # Parallel comment-preserving document: the source of truth on save.
        # The ConfigParser self.cp drives the UI (existing code); on save
        # we reconcile the cp's state onto self.doc and then write self.doc.
        self.doc = cpi.parse(config_path)
        self.dirty = False
        # widgets: section_name -> {field_name: widget}
        self.widgets: dict[str, dict[str, object]] = {}

        self.root.title(
            f"INI Editor — {config_path.name} (schema: {schema_path.name})"
        )
        self.root.geometry("1100x720")
        self._build_ui()
        self._populate_from_config()
        self._validate_now()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------

    def _build_ui(self):
        # Top toolbar
        toolbar = ttk.Frame(self.root, padding=4)
        toolbar.pack(side="top", fill="x")
        ttk.Button(toolbar, text="Save", command=self._save).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Reload", command=self._reload).pack(side="left", padx=2)
        ttk.Button(toolbar, text="Validate", command=self._validate_now).pack(side="left", padx=2)
        self.status_lbl = ttk.Label(toolbar, text="", anchor="w")
        self.status_lbl.pack(side="left", fill="x", expand=True, padx=8)

        # Main split: left = section list; right = field editors
        paned = ttk.PanedWindow(self.root, orient="horizontal")
        paned.pack(fill="both", expand=True, padx=4, pady=4)

        # Left: section listing
        left_frame = ttk.Frame(paned)
        paned.add(left_frame, weight=1)
        ttk.Label(left_frame, text="Sections", font=("Helvetica", 11, "bold")
                  ).pack(anchor="w")

        self.section_tree = ttk.Treeview(left_frame, columns=("count",),
                                          show="tree headings")
        self.section_tree.heading("#0", text="Section")
        self.section_tree.heading("count", text="Fields")
        self.section_tree.column("count", width=60, anchor="e")
        self.section_tree.pack(fill="both", expand=True)
        self.section_tree.bind("<<TreeviewSelect>>", self._on_section_select)

        btn_row = ttk.Frame(left_frame)
        btn_row.pack(fill="x", pady=4)
        ttk.Button(btn_row, text="Add section", command=self._add_section
                   ).pack(side="left", padx=2)
        ttk.Button(btn_row, text="Remove section", command=self._remove_section
                   ).pack(side="left", padx=2)

        # Right: field editor for currently-selected section
        right_frame = ttk.Frame(paned)
        paned.add(right_frame, weight=3)
        self.section_lbl = ttk.Label(right_frame, text="(no section selected)",
                                      font=("Helvetica", 12, "bold"))
        self.section_lbl.pack(anchor="w")
        self.section_desc = ttk.Label(right_frame, text="", wraplength=720,
                                       foreground="gray30")
        self.section_desc.pack(anchor="w", pady=(0, 8))

        # Scrollable field area
        canvas = tk.Canvas(right_frame, highlightthickness=0)
        scroll = ttk.Scrollbar(right_frame, orient="vertical",
                                command=canvas.yview)
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.fields_frame = ttk.Frame(canvas, padding=8)
        canvas.create_window((0, 0), window=self.fields_frame, anchor="nw")
        self.fields_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        # Mouse wheel scrolling
        canvas.bind_all(
            "<MouseWheel>",
            lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
        )

        # Bottom: validation panel
        val_frame = ttk.LabelFrame(self.root, text="Validation", padding=4)
        val_frame.pack(side="bottom", fill="x", padx=4, pady=4)
        self.val_text = tk.Text(val_frame, height=6, wrap="none",
                                 font=("Courier", 9))
        self.val_text.pack(fill="x")

    # ------------------------------------------------------------------
    # Population from config
    # ------------------------------------------------------------------

    def _populate_from_config(self):
        # Clear tree
        for item in self.section_tree.get_children():
            self.section_tree.delete(item)
        # Add each config section, ordered by their appearance
        for sect_name in self.cp.sections():
            spec = self.schema.find_section(sect_name)
            n_fields = len(self.cp[sect_name])
            label = sect_name
            if spec is None:
                label += " (unknown)"
            self.section_tree.insert("", "end", iid=sect_name, text=label,
                                      values=(n_fields,))

    def _on_section_select(self, event=None):
        sel = self.section_tree.selection()
        if not sel:
            return
        sect_name = sel[0]
        self._render_section(sect_name)

    def _render_section(self, sect_name: str):
        # Persist any pending edits from the previously-displayed section
        self._capture_widgets_to_config()

        # Clear field area
        for child in self.fields_frame.winfo_children():
            child.destroy()
        self.widgets[sect_name] = {}

        spec = self.schema.find_section(sect_name)
        if sect_name in self.cp:
            sect = self.cp[sect_name]
        else:
            return

        self.section_lbl.config(text=f"[{sect_name}]")
        if spec:
            self.section_desc.config(
                text=spec.description + (
                    f"\n(Section accepts dynamic keys: {spec.dynamic_keys_help})"
                    if spec.dynamic_keys else ""
                )
            )
        else:
            self.section_desc.config(
                text="⚠ No schema declaration for this section. "
                     "Editing in fall-back string mode."
            )

        # Render fields. Ordering: schema-declared fields first (in order),
        # then any extra keys present in the config but not in schema.
        rendered = set()
        if spec:
            for fname in spec.field_order:
                if fname not in rendered:
                    self._render_field(sect_name, sect, spec, fname)
                    rendered.add(fname)
        for fname in sect:
            if fname not in rendered:
                self._render_field(sect_name, sect, spec, fname)
                rendered.add(fname)

        # If section has dynamic_keys, offer "add a key" affordance
        if spec and spec.dynamic_keys:
            add_row = ttk.Frame(self.fields_frame, padding=4,
                                 borderwidth=1, relief="groove")
            add_row.pack(fill="x", pady=4)
            ttk.Label(add_row, text="Add dynamic key:",
                      foreground="navy").pack(side="left")
            new_key_var = tk.StringVar()
            ttk.Entry(add_row, textvariable=new_key_var, width=30
                      ).pack(side="left", padx=4)

            def add_key():
                k = new_key_var.get().strip()
                if k and k not in self.cp[sect_name]:
                    self.cp[sect_name][k] = ""
                    self.dirty = True
                    self._render_section(sect_name)

            ttk.Button(add_row, text="Add", command=add_key).pack(side="left")

    def _render_field(self, sect_name: str, sect, spec: SectionSpec | None,
                      fname: str):
        fspec = spec.fields.get(fname) if spec else None
        # If unknown but section has dynamic_keys, build a synthetic FieldSpec
        if fspec is None and spec and spec.dynamic_keys:
            fspec = FieldSpec(
                name=fname, type=spec.dynamic_value_type,
                help=f"(dynamic key) {spec.dynamic_keys_help}"
            )
        if fspec is None:
            fspec = FieldSpec(name=fname, type="string",
                              help="(unknown field — fallback string editor)")

        row = ttk.Frame(self.fields_frame, padding=(0, 4))
        row.pack(fill="x")

        header = ttk.Frame(row)
        header.pack(fill="x")
        label_text = fname
        if fspec.required:
            label_text += " *"
        ttk.Label(header, text=label_text, font=("Helvetica", 10, "bold"),
                  width=32, anchor="w").pack(side="left")
        ttk.Label(header, text=f"[{fspec.type}]",
                  foreground="gray40").pack(side="left", padx=4)

        # If this is a fall-back/dynamic field, show a delete button
        if spec and (spec.dynamic_keys or fspec.name not in spec.fields):
            def del_field(fn=fname):
                if mb.askyesno("Remove field",
                               f"Remove '{fn}' from [{sect_name}]?"):
                    if fn in self.cp[sect_name]:
                        self.cp[sect_name].pop(fn)
                        self.dirty = True
                        self._render_section(sect_name)
            ttk.Button(header, text="✕", width=3,
                       command=del_field).pack(side="right")

        if fspec.help:
            ttk.Label(row, text=fspec.help, wraplength=720,
                      foreground="gray30").pack(anchor="w", pady=(0, 2))

        factory = WIDGET_FACTORIES.get(fspec.type, StringWidget)
        widget = factory(row, fspec)
        widget.set(sect.get(fname, fspec.default or ""))
        widget.widget().pack(fill="x")
        self.widgets[sect_name][fname] = widget

    # ------------------------------------------------------------------
    # Save / load / validate
    # ------------------------------------------------------------------

    def _capture_widgets_to_config(self):
        """Pull current widget values back into self.cp."""
        for sect_name, widgets in self.widgets.items():
            if sect_name not in self.cp:
                continue
            for fname, w in widgets.items():
                new_val = w.get()
                old_val = self.cp[sect_name].get(fname, "")
                if new_val != old_val:
                    self.cp[sect_name][fname] = new_val
                    self.dirty = True

    def _save(self):
        self._capture_widgets_to_config()
        try:
            # Build dict-of-dicts from current ConfigParser state and
            # reconcile it onto the comment-preserving document.
            cp_dict: dict[str, dict[str, str]] = {
                s: dict(self.cp[s]) for s in self.cp.sections()
            }
            cpi.apply_dict(self.doc, cp_dict)
            cpi.write(self.doc, self.config_path)
            self.dirty = False
            self.status_lbl.config(
                text=f"Saved to {self.config_path}  (comments preserved)",
                foreground="green",
            )
            self._validate_now()
        except Exception as e:
            mb.showerror("Save failed", str(e))

    def _reload(self):
        if self.dirty:
            if not mb.askyesno(
                "Discard changes?",
                "You have unsaved changes. Reload anyway?"
            ):
                return
        self.cp = _read_ini_preserving_case(self.config_path)
        self.doc = cpi.parse(self.config_path)
        self.dirty = False
        self._populate_from_config()
        self._validate_now()
        self.status_lbl.config(text="Reloaded", foreground="black")

    def _validate_now(self):
        # Save to a temp string first so validator sees current state
        # (validator reads from disk, so we save first)
        # Simpler: save before validate; this is the GUI flow anyway.
        self._capture_widgets_to_config()
        # Write current state to a tempfile for validation. Use
        # ConfigParser's own writer so multi-line values get the leading
        # indent ConfigParser expects on continuation lines.
        import tempfile
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".ini", delete=False, encoding="utf-8"
        ) as tmp:
            tmp_path = Path(tmp.name)
            self.cp.write(tmp)
        try:
            report = validate_config(tmp_path, self.schema)
        finally:
            tmp_path.unlink(missing_ok=True)

        self.val_text.delete("1.0", "end")
        if report.ok and not report.warnings:
            self.val_text.insert("1.0", "✓ All sections and fields validate cleanly.\n")
            self.val_text.config(foreground="green")
        else:
            self.val_text.insert("1.0", report.format())
            self.val_text.config(foreground="black")

    def _add_section(self):
        # Suggest adding a section_pattern instance, since fixed sections
        # are usually already there.
        from tkinter.simpledialog import askstring
        # Find pattern-style section types
        pattern_specs = [s for s in self.schema.sections if s.is_pattern]
        if not pattern_specs:
            mb.showinfo("No patterns",
                        "This schema has no section patterns; can't suggest "
                        "what to add.")
            return
        names = [s.name for s in pattern_specs]
        choice = askstring(
            "Add section",
            f"Available section patterns: {', '.join(names)}\n\n"
            f"Enter the new section name (e.g. value_map.foo):"
        )
        if not choice:
            return
        if choice in self.cp:
            mb.showerror("Already exists",
                         f"Section [{choice}] already exists.")
            return
        # Verify it matches a pattern
        spec = self.schema.find_section(choice)
        if spec is None:
            if not mb.askyesno("No schema match",
                               f"'{choice}' doesn't match any schema pattern. "
                               "Add anyway?"):
                return
        self.cp[choice] = {}
        self.dirty = True
        self._populate_from_config()
        self.section_tree.selection_set(choice)
        self._render_section(choice)

    def _remove_section(self):
        sel = self.section_tree.selection()
        if not sel:
            return
        sect_name = sel[0]
        if not mb.askyesno("Remove section",
                           f"Remove [{sect_name}] from the config?"):
            return
        if sect_name in self.cp:
            self.cp.remove_section(sect_name)
            self.dirty = True
            self._populate_from_config()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Schema-driven INI editor for the migration toolkit."
    )
    ap.add_argument("config", nargs="?",
                    help="Path to the INI config to edit.")
    ap.add_argument("--schema", help="Path to the schema INI (default: <config>.schema.ini).")
    args = ap.parse_args()

    root = tk.Tk()

    if not args.config:
        path = fd.askopenfilename(
            title="Open INI config to edit",
            filetypes=[("INI files", "*.ini"), ("All files", "*.*")],
        )
        if not path:
            return 0
        args.config = path

    config_path = Path(args.config).resolve()
    if args.schema:
        schema_path = Path(args.schema).resolve()
    else:
        # Look for a sibling .schema.ini
        candidate = config_path.with_suffix(".schema.ini")
        if not candidate.is_file():
            # Try replacing the suffix differently
            candidate = config_path.parent / (config_path.stem + ".schema.ini")
        schema_path = candidate

    if not schema_path.is_file():
        mb.showwarning(
            "No schema",
            f"No schema file found at {schema_path}.\n\n"
            "The editor will run in fall-back mode (no validation, "
            "all fields treated as strings)."
        )

    app = EditorApp(root, config_path, schema_path)
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
