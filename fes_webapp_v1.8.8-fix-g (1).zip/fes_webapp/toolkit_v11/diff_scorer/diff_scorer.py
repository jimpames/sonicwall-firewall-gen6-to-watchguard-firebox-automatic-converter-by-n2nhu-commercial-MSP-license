#!/usr/bin/env python3
"""
diff_scorer.py
================

Multi-dimensional vector-math diff scorer for measuring how close our
emitted WatchGuard XML is to a real reference export from a Firebox.

Each scoring dimension produces a 0.0..1.0 number; the aggregate is a
weighted sum, but the per-dimension breakdown is the more useful output —
it tells the operator WHERE the gap is, not just that one exists.

Dimensions are declared in `diff_score_config.ini`. The engine knows
nothing about WatchGuard. To add a new dimension: add `[dimension.X]`,
optionally implement `_score_<kind>()` if the kind is new.

Run:
    python3 diff_scorer.py --config diff_score_config.ini
    python3 diff_scorer.py --reference path/to/real.xml --candidate path/to/ours.xml
"""
from __future__ import annotations

import argparse
import configparser
import json
import math
import sys
import xml.etree.ElementTree as ET
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# Make schema_lib importable when running from this directory
_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))
from schema_lib import validate_at_startup  # noqa: E402


def _read_ini(path: Path) -> configparser.ConfigParser:
    cp = configparser.ConfigParser(
        interpolation=None,
        inline_comment_prefixes=(";",),
        comment_prefixes=("#",),
    )
    cp.read(path, encoding="utf-8")
    return cp


def _csv(s: str) -> list[str]:
    return [x.strip() for x in s.replace("\n", ",").split(",") if x.strip()]


@dataclass
class Dimension:
    name: str
    kind: str
    weight: float
    description: str
    raw: configparser.SectionProxy


def _all_xpaths(elem: ET.Element, prefix: str = "", depth: int = 0,
                max_depth: int = 99) -> Counter:
    """Walk the tree producing a Counter of XPath -> count.
    XPaths are tag-only (no positional index).
    Depth is measured from the root."""
    out: Counter = Counter()
    if elem is None or depth > max_depth:
        return out
    here = f"{prefix}/{elem.tag}" if prefix else f"/{elem.tag}"
    out[here] += 1
    for child in elem:
        out.update(_all_xpaths(child, here, depth + 1, max_depth))
    return out


def _all_field_names_per_type(elem: ET.Element,
                              max_per_type: int = 5
                              ) -> dict[str, set[str]]:
    """For each XPath element-type, collect the union of immediate-child
    field names used across instances of that type."""
    fields: dict[str, set[str]] = {}
    counts_seen: dict[str, int] = {}

    def walk(e: ET.Element, path: str):
        # Collect immediate child tags as "fields" of this element type
        for c in e:
            child_path = f"{path}/{c.tag}"
            counts_seen.setdefault(path, 0)
            if counts_seen[path] < max_per_type:
                fields.setdefault(path, set()).add(c.tag)
            walk(c, child_path)
        counts_seen[path] = counts_seen.get(path, 0) + 1

    walk(elem, f"/{elem.tag}")
    return fields


# ============================================================================
# Scoring engines — one per dimension `kind`.
# Each takes (reference_root, candidate_root, dimension_spec) and returns
# (score, details_dict).
# ============================================================================


def _score_xpath_set_jaccard(ref: ET.Element, cand: ET.Element,
                             dim: Dimension) -> tuple[float, dict]:
    depth = int(dim.raw.get("xpath_depth", "3"))
    ignore_prefixes = _csv(dim.raw.get("ignore_xpath_prefixes", ""))

    ref_paths = set(_all_xpaths(ref, max_depth=depth).keys())
    cand_paths = set(_all_xpaths(cand, max_depth=depth).keys())

    def keep(p: str) -> bool:
        return not any(p.startswith(pre) for pre in ignore_prefixes)

    ref_paths = {p for p in ref_paths if keep(p)}
    cand_paths = {p for p in cand_paths if keep(p)}

    intersection = ref_paths & cand_paths
    union = ref_paths | cand_paths
    score = len(intersection) / len(union) if union else 1.0
    return score, {
        "depth": depth,
        "ref_xpath_count": len(ref_paths),
        "candidate_xpath_count": len(cand_paths),
        "in_both": len(intersection),
        "ref_only": sorted(ref_paths - cand_paths)[:20],
        "candidate_only": sorted(cand_paths - ref_paths)[:20],
    }


def _score_xpath_count_ratio(ref: ET.Element, cand: ET.Element,
                             dim: Dimension) -> tuple[float, dict]:
    depth = int(dim.raw.get("xpath_depth", "2"))
    excluded = set(_csv(dim.raw.get("exclude_xpaths", "")))

    ref_counts = _all_xpaths(ref, max_depth=depth)
    cand_counts = _all_xpaths(cand, max_depth=depth)

    common = (set(ref_counts.keys()) & set(cand_counts.keys())) - excluded
    if not common:
        return 0.0, {"reason": "no common xpaths to compare"}

    ratios = []
    per_xpath = []
    for x in sorted(common):
        r = ref_counts[x]
        c = cand_counts[x]
        if r == 0 and c == 0:
            continue
        ratio = min(r, c) / max(r, c)
        ratios.append(ratio)
        per_xpath.append({"xpath": x, "ref": r, "candidate": c, "ratio": ratio})

    score = sum(ratios) / len(ratios) if ratios else 0.0
    # Show worst-scoring 10 for the operator's eye
    per_xpath.sort(key=lambda d: d["ratio"])
    return score, {
        "common_xpath_count": len(ratios),
        "worst_10": per_xpath[:10],
        "best_10": per_xpath[-10:],
    }


def _score_field_overlap(ref: ET.Element, cand: ET.Element,
                         dim: Dimension) -> tuple[float, dict]:
    sample_size = int(dim.raw.get("sample_size", "5"))
    ref_fields = _all_field_names_per_type(ref, max_per_type=sample_size)
    cand_fields = _all_field_names_per_type(cand, max_per_type=sample_size)

    common = set(ref_fields) & set(cand_fields)
    if not common:
        return 0.0, {"reason": "no common element types"}

    per_type = []
    overall_ratios = []
    for elem_type in sorted(common):
        rfields = ref_fields[elem_type]
        cfields = cand_fields[elem_type]
        if not rfields:
            continue
        present = rfields & cfields
        missing = rfields - cfields
        ratio = len(present) / len(rfields)
        overall_ratios.append(ratio)
        per_type.append({
            "element": elem_type,
            "ref_fields": len(rfields),
            "candidate_fields": len(cfields),
            "ratio": ratio,
            "missing_in_candidate": sorted(missing)[:10],
        })

    score = sum(overall_ratios) / len(overall_ratios) if overall_ratios else 0.0
    per_type.sort(key=lambda d: d["ratio"])
    return score, {
        "elements_compared": len(overall_ratios),
        "worst_10": per_type[:10],
    }


def _score_reference_resolution(ref: ET.Element, cand: ET.Element,
                                dim: Dimension,
                                cp: configparser.ConfigParser
                                ) -> tuple[float, dict]:
    rule_names = _csv(dim.raw.get("reference_rules", ""))
    if not rule_names:
        return 1.0, {"reason": "no reference rules configured"}

    per_rule = []
    total_resolved = 0
    total_refs = 0
    sample_size = int(cp["report"].get("include_unresolved_refs_sample", "10")
                      if "report" in cp else "10")
    unresolved_samples: list[dict] = []

    for rule_name in rule_names:
        sect_key = f"reference_rule.{rule_name}"
        if sect_key not in cp:
            continue
        rule = cp[sect_key]
        ref_xpath = rule.get("ref_xpath", "").strip()
        target_xpath = rule.get("target_xpath", "").strip()
        if not ref_xpath or not target_xpath:
            continue

        # Collect all reference values from candidate
        refs = [(e.text or "").strip() for e in cand.findall(ref_xpath)
                if e.text and e.text.strip()]
        # Collect all target names from candidate
        targets = {(e.text or "").strip() for e in cand.findall(target_xpath)
                   if e.text and e.text.strip()}

        n_refs = len(refs)
        n_resolved = sum(1 for r in refs if r in targets)
        n_unresolved = n_refs - n_resolved

        per_rule.append({
            "rule": rule_name,
            "references": n_refs,
            "resolved": n_resolved,
            "unresolved": n_unresolved,
            "rate": n_resolved / n_refs if n_refs else 1.0,
        })
        total_refs += n_refs
        total_resolved += n_resolved

        # Sample some unresolved
        if n_unresolved and len(unresolved_samples) < sample_size:
            unresolved_set = set(refs) - targets
            for u in sorted(unresolved_set)[:sample_size]:
                if len(unresolved_samples) >= sample_size:
                    break
                unresolved_samples.append({"rule": rule_name, "ref": u})

    score = total_resolved / total_refs if total_refs else 1.0
    return score, {
        "total_references": total_refs,
        "total_resolved": total_resolved,
        "per_rule": per_rule,
        "unresolved_samples": unresolved_samples,
    }


def _score_value_histogram(ref: ET.Element, cand: ET.Element,
                           dim: Dimension,
                           cp: configparser.ConfigParser
                           ) -> tuple[float, dict]:
    field_names = _csv(dim.raw.get("fields", ""))
    if not field_names:
        return 1.0, {"reason": "no fields configured"}

    per_field = []
    similarities = []
    for fname in field_names:
        sect_key = f"value_field.{fname}"
        if sect_key not in cp:
            continue
        xpath = cp[sect_key].get("xpath", "").strip()
        if not xpath:
            continue
        ref_vals = Counter((e.text or "").strip() for e in ref.findall(xpath)
                           if e.text)
        cand_vals = Counter((e.text or "").strip() for e in cand.findall(xpath)
                            if e.text)

        # Cosine similarity over the value histograms
        all_vals = set(ref_vals) | set(cand_vals)
        if not all_vals:
            continue
        dot = sum(ref_vals[v] * cand_vals[v] for v in all_vals)
        ref_mag = math.sqrt(sum(c * c for c in ref_vals.values()))
        cand_mag = math.sqrt(sum(c * c for c in cand_vals.values()))
        if ref_mag == 0 or cand_mag == 0:
            sim = 0.0
        else:
            sim = dot / (ref_mag * cand_mag)
        similarities.append(sim)
        per_field.append({
            "field": fname,
            "ref_unique_values": len(ref_vals),
            "candidate_unique_values": len(cand_vals),
            "ref_total": sum(ref_vals.values()),
            "candidate_total": sum(cand_vals.values()),
            "cosine_similarity": sim,
        })

    score = sum(similarities) / len(similarities) if similarities else 1.0
    return score, {"per_field": per_field}


# ============================================================================
# Engine
# ============================================================================


class DiffScorer:
    SCORERS = {
        "xpath_set_jaccard": _score_xpath_set_jaccard,
        "xpath_count_ratio": _score_xpath_count_ratio,
        "field_overlap": _score_field_overlap,
        "reference_resolution": lambda r, c, d, cp=None: _score_reference_resolution(r, c, d, cp),
        "value_histogram": lambda r, c, d, cp=None: _score_value_histogram(r, c, d, cp),
    }

    def __init__(self, config_path: Path,
                 reference_xml: Path | None = None,
                 candidate_xml: Path | None = None):
        self.cp = _read_ini(config_path)
        io = self.cp["io"]
        self.ref_path = reference_xml or (
            config_path.parent / io["reference_xml"]).resolve()
        self.cand_path = candidate_xml or (
            config_path.parent / io["candidate_xml"]).resolve()
        self.report_path = (config_path.parent / io["output_report"]).resolve()
        self.summary_path = (config_path.parent / io["output_summary"]).resolve()

        self.dimensions: list[Dimension] = []
        for sect_name in self.cp.sections():
            if sect_name.startswith("dimension."):
                short = sect_name.split(".", 1)[1]
                sect = self.cp[sect_name]
                self.dimensions.append(Dimension(
                    name=short,
                    kind=sect.get("kind", "").strip(),
                    weight=float(sect.get("weight", "0.0")),
                    description=sect.get("description", "").strip(),
                    raw=sect,
                ))

    def run(self) -> dict:
        ref = ET.parse(self.ref_path).getroot()
        cand = ET.parse(self.cand_path).getroot()

        per_dim_scores = []
        per_dim_details = {}

        for dim in self.dimensions:
            scorer = self.SCORERS.get(dim.kind)
            if scorer is None:
                per_dim_scores.append({
                    "name": dim.name, "kind": dim.kind,
                    "score": 0.0, "weight": dim.weight,
                    "error": f"unknown kind {dim.kind!r}"
                })
                continue
            try:
                # Some scorers need cp for nested config sections
                if dim.kind in ("reference_resolution", "value_histogram"):
                    score, details = scorer(ref, cand, dim, self.cp)
                else:
                    score, details = scorer(ref, cand, dim)
            except Exception as e:
                per_dim_scores.append({
                    "name": dim.name, "kind": dim.kind,
                    "score": 0.0, "weight": dim.weight,
                    "error": str(e),
                })
                continue
            per_dim_scores.append({
                "name": dim.name, "kind": dim.kind,
                "score": round(score, 4), "weight": dim.weight,
                "description": dim.description,
            })
            per_dim_details[dim.name] = details

        # Aggregate score = sum(weight * score) / sum(weight)
        total_weight = sum(d["weight"] for d in per_dim_scores)
        weighted = sum(d["score"] * d["weight"] for d in per_dim_scores)
        aggregate = weighted / total_weight if total_weight else 0.0

        report = {
            "reference": str(self.ref_path),
            "candidate": str(self.cand_path),
            "aggregate_score": round(aggregate, 4),
            "dimensions": per_dim_scores,
            "details": per_dim_details,
        }

        # Write outputs
        self.report_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
            f.write("\n")
        self._write_summary(report)
        return report

    def _write_summary(self, report: dict) -> None:
        lines = []
        lines.append("=" * 72)
        lines.append("WatchGuard XML Diff Score")
        lines.append("=" * 72)
        lines.append(f"Reference:   {report['reference']}")
        lines.append(f"Candidate:   {report['candidate']}")
        lines.append("")
        lines.append(f"{'AGGREGATE SCORE':<30}  {report['aggregate_score']:.4f}  "
                     f"{self._render_bar(report['aggregate_score'])}")
        lines.append("")
        lines.append("Per-dimension breakdown:")
        for d in report["dimensions"]:
            line = (f"  {d['name']:<26}  {d['score']:.4f}  "
                    f"(weight {d['weight']:.2f})  "
                    f"{self._render_bar(d['score'])}")
            lines.append(line)

        # Selected actionable details — what's the worst?
        lines.append("")
        lines.append("Actionable: where to focus next")
        lines.append("-" * 40)
        details = report.get("details", {})

        # Element count gaps
        ec = details.get("element_counts", {})
        if "worst_10" in ec:
            lines.append("\nElement-count gaps (worst 5):")
            for x in ec["worst_10"][:5]:
                lines.append(f"  {x['xpath']:<55} ref={x['ref']:>4} ours={x['candidate']:>4}  ratio={x['ratio']:.2f}")

        # Field completeness gaps
        fc = details.get("field_completeness", {})
        if "worst_10" in fc:
            lines.append("\nField-completeness gaps (worst 5):")
            for x in fc["worst_10"][:5]:
                lines.append(f"  {x['element']:<55} ratio={x['ratio']:.2f}")
                if x.get("missing_in_candidate"):
                    miss = ", ".join(x["missing_in_candidate"][:5])
                    lines.append(f"      missing fields: {miss}")

        # Cross-ref unresolved
        cr = details.get("cross_reference", {})
        if cr.get("unresolved_samples"):
            lines.append("\nUnresolved references (sample):")
            for u in cr["unresolved_samples"][:5]:
                lines.append(f"  [{u['rule']}] -> '{u['ref']}'")

        with open(self.summary_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

    @staticmethod
    def _render_bar(score: float, width: int = 30) -> str:
        filled = int(round(score * width))
        return "[" + "#" * filled + "·" * (width - filled) + "]"


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Score how close a candidate WatchGuard XML is to a reference."
    )
    ap.add_argument("--config", default="diff_score_config.ini")
    ap.add_argument("--reference", help="Override reference XML path")
    ap.add_argument("--candidate", help="Override candidate XML path")
    ap.add_argument("--strict", action="store_true",
                    help="Exit non-zero if schema validation finds errors")
    ap.add_argument("--no-validate", action="store_true",
                    help="Skip schema validation entirely")
    args = ap.parse_args()

    cfg = Path(args.config).resolve()
    if not cfg.is_file():
        print(f"ERROR: config not found: {cfg}", file=sys.stderr)
        return 2

    if not args.no_validate:
        report = validate_at_startup(cfg, engine_name="diff_scorer")
        if report is not None and not report.ok and args.strict:
            print("ERROR: --strict and schema validation failed; "
                  "aborting before scoring.", file=sys.stderr)
            return 3

    scorer = DiffScorer(
        cfg,
        reference_xml=Path(args.reference).resolve() if args.reference else None,
        candidate_xml=Path(args.candidate).resolve() if args.candidate else None,
    )
    report = scorer.run()

    # Print summary inline too
    with open(scorer.summary_path) as f:
        sys.stdout.write(f.read())

    return 0


if __name__ == "__main__":
    sys.exit(main())
