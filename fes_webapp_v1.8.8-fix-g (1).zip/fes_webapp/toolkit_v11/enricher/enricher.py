#!/usr/bin/env python3
"""
enricher.py
=============

Phase 1.5 of the migration pipeline. Sits between the parser and the XML
emitter. Reads canonical JSON, applies INI-declared enrichment passes,
writes enriched JSON.

Three pass kinds:

    pivot   - reshape an array of strings into a structured dict
              (e.g. "ike encryption 3des" -> phase1.encryption=3des)

    derive  - synthesize NEW entries from existing ones
              (e.g. interfaces.json -> implicit_address_objects.json)

    audit   - walk entries, apply a severity table, emit findings
              (e.g. crypto_findings on each VPN policy)

Like every other component in this toolkit, the engine knows nothing
about SonicWall, WatchGuard, IKE, or any other domain. It reads the INI,
applies the declared transformations, writes JSON. Add a new kind of
enrichment by adding a new [pass.X] section, never by editing this code.

Algebraic-design model:

    Entry × Pass = EnrichedEntry

    Entry  = a JSON dict from Phase 1
    Pass   = a transformation declared in enrich_config.ini
    Result = the same entry with new fields added (or new entries derived)

Run:
    python3 enricher.py --config enrich_config.ini
"""
from __future__ import annotations

import argparse
import configparser
import datetime as _dt
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# Make schema_lib importable when running from this directory
_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))
from schema_lib import validate_at_startup  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _as_bool(s: str) -> bool:
    return str(s).strip().lower() in ("true", "yes", "1", "on")


def _read_ini(path: Path) -> configparser.ConfigParser:
    cp = configparser.ConfigParser(
        interpolation=None,
        inline_comment_prefixes=(";",),
        comment_prefixes=("#",),
    )
    cp.read(path, encoding="utf-8")
    return cp


def _load_entries(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    if isinstance(d, dict) and "entries" in d:
        return d["entries"]
    if isinstance(d, list):
        return d
    return []


def _load_meta(path: Path) -> dict:
    if not path.is_file():
        return {}
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    if isinstance(d, dict):
        return d.get("_meta", {})
    return {}


def _write_entries(path: Path, entries: list[dict], meta: dict, indent: int = 2) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"entries": entries, "_meta": meta}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=indent, ensure_ascii=False)
        f.write("\n")


def _set_dotted(d: dict, dotted: str, value: Any) -> None:
    """Set a dotted-path key on a dict, creating intermediate dicts."""
    parts = dotted.split(".")
    cur = d
    for p in parts[:-1]:
        if p not in cur or not isinstance(cur[p], dict):
            cur[p] = {}
        cur = cur[p]
    cur[parts[-1]] = value


def _get_dotted(d: dict, dotted: str) -> Any:
    """Get a dotted-path key from a dict (None if missing)."""
    cur: Any = d
    for p in dotted.split("."):
        if not isinstance(cur, dict) or p not in cur:
            return None
        cur = cur[p]
    return cur


def _parse_kv_lines(value: str) -> list[tuple[str, str]]:
    """Parse a multi-line ini value of `KEY = VALUE` lines into pairs.

    The configparser already concatenates continuation lines with '\n'.
    We split on newlines, then split each line on the first '=' OUTSIDE quotes.
    """
    pairs: list[tuple[str, str]] = []
    for raw in value.split("\n"):
        line = raw.strip()
        if not line:
            continue
        # Find the '=' that's not inside double quotes
        depth_q = False
        eq = -1
        for i, ch in enumerate(line):
            if ch == '"':
                depth_q = not depth_q
            elif ch == "=" and not depth_q:
                eq = i
                break
        if eq < 0:
            continue
        key = line[:eq].strip()
        val = line[eq + 1:].strip()
        # Strip wrapping quotes from the key
        if len(key) >= 2 and key[0] == '"' and key[-1] == '"':
            key = key[1:-1]
        pairs.append((key, val))
    return pairs


# ---------------------------------------------------------------------------
# Concept map loader
# ---------------------------------------------------------------------------
class ConceptMap:
    """Loads concept_map.ini and exposes the audit / upgrade tables."""

    def __init__(self, path: Path):
        self.cp = _read_ini(path)
        self.path = path

    def audit_table(self, field_dotted: str) -> dict[str, str]:
        """Return the audit table for a field like 'phase1.encryption'.

        Tries [crypto_audit.encryption], then [crypto_audit.<last_part>].
        """
        last = field_dotted.split(".")[-1]
        # Map common synonyms to table names
        synonym = {
            "encryption": "encryption",
            "authentication": "hash",
            "dh_group": "dh_group",
            "pfs": "pfs",
        }.get(last, last)
        section_name = f"crypto_audit.{synonym}"
        if section_name not in self.cp:
            return {}
        return {k: v.strip() for k, v in self.cp[section_name].items()
                if k != "description"}

    def upgrade_recommendation(self) -> dict[str, str]:
        """Return the flat upgrade recommendation table."""
        if "crypto_upgrade_recommendation" not in self.cp:
            return {}
        return {k: v.strip()
                for k, v in self.cp["crypto_upgrade_recommendation"].items()
                if k != "description"}

    def lifetime_max(self, kind: str) -> int | None:
        """Return ike_max_seconds or ipsec_max_seconds."""
        s = self.cp.get("crypto_audit.lifetime", f"{kind}_max_seconds",
                        fallback=None)
        return int(s) if s is not None else None

    def pfs_required(self) -> bool:
        s = self.cp.get("crypto_audit.pfs", "required", fallback="false")
        return _as_bool(s)


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------
@dataclass
class PassSpec:
    name: str
    description: str
    kind: str
    input_file: str
    output_file: str
    enabled: bool
    raw: configparser.SectionProxy

    @classmethod
    def from_section(cls, name: str, sect: configparser.SectionProxy) -> PassSpec:
        return cls(
            name=name,
            description=sect.get("description", "").strip(),
            kind=sect.get("kind", "").strip(),
            input_file=sect.get("input_file", "").strip(),
            output_file=sect.get("output_file", "").strip(),
            enabled=_as_bool(sect.get("enabled", "true")),
            raw=sect,
        )


class Enricher:
    def __init__(self, config_path: Path):
        self.cp = _read_ini(config_path)
        io = self.cp["io"]
        self.parser_dir = (config_path.parent / io["parser_output_dir"]).resolve()
        self.out_dir = (config_path.parent / io["enricher_output_dir"]).resolve()
        self.cm = ConceptMap((config_path.parent / io["concept_map_path"]).resolve())

        self.passes: list[PassSpec] = []
        for sect_name in self.cp.sections():
            if sect_name.startswith("pass."):
                short = sect_name.split(".", 1)[1]
                self.passes.append(
                    PassSpec.from_section(short, self.cp[sect_name])
                )

        # Working set: section_name -> entries (loaded lazily, written at end)
        self.work: dict[str, list[dict]] = {}
        self.work_meta: dict[str, dict] = {}
        # Track which output files we've produced
        self.outputs_written: dict[str, int] = {}

    # -- working-set accessors -------------------------------------------
    def _load(self, fname: str) -> list[dict]:
        # Prefer in-memory state from a previous pass that wrote to this same
        # filename. Otherwise load from parser output.
        if fname in self.work:
            return self.work[fname]
        path = self.parser_dir / fname
        entries = _load_entries(path)
        meta = _load_meta(path)
        self.work[fname] = entries
        self.work_meta[fname] = meta
        return entries

    def _save_to_workset(self, fname: str, entries: list[dict],
                        meta: dict | None = None) -> None:
        self.work[fname] = entries
        if meta is not None:
            self.work_meta[fname] = meta

    # -- pass dispatchers ------------------------------------------------
    def run(self) -> dict:
        report: dict[str, Any] = {"passes": []}
        for ps in self.passes:
            if not ps.enabled:
                report["passes"].append(
                    {"name": ps.name, "kind": ps.kind, "status": "disabled"}
                )
                continue
            try:
                if ps.kind == "pivot":
                    n_changed = self._run_pivot(ps)
                elif ps.kind == "derive":
                    n_changed = self._run_derive(ps)
                elif ps.kind == "audit":
                    n_changed = self._run_audit(ps)
                elif ps.kind == "transform":
                    n_changed = self._run_transform(ps)
                elif ps.kind == "merge":
                    n_changed = self._run_merge(ps)
                elif ps.kind == "expand_schedule":
                    n_changed = self._run_expand_schedule(ps)
                elif ps.kind == "filter":
                    n_changed = self._run_filter(ps)
                else:
                    raise ValueError(f"unknown pass kind: {ps.kind}")
                report["passes"].append({
                    "name": ps.name, "kind": ps.kind, "status": "ok",
                    "changed": n_changed,
                    "input": ps.input_file, "output": ps.output_file,
                })
            except Exception as e:
                report["passes"].append({
                    "name": ps.name, "kind": ps.kind,
                    "status": "error", "error": str(e),
                })
                print(f"  ERROR in pass.{ps.name}: {e}", file=sys.stderr)

        # Write everything in the workset to disk
        for fname, entries in self.work.items():
            outpath = self.out_dir / fname
            meta = dict(self.work_meta.get(fname, {}))
            meta["enriched_at"] = _dt.datetime.now().isoformat(timespec="seconds")
            meta["enricher_passes"] = [
                p["name"] for p in report["passes"]
                if p.get("status") == "ok" and (
                    p.get("input") == fname or p.get("output") == fname
                )
            ]
            _write_entries(outpath, entries, meta)
            self.outputs_written[fname] = len(entries)

        # Write a manifest
        report["outputs"] = self.outputs_written
        report["generated_at"] = _dt.datetime.now().isoformat(timespec="seconds")
        with open(self.out_dir / "_enrichment_manifest.json", "w",
                  encoding="utf-8") as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
            f.write("\n")
        return report

    # -- pivot --------------------------------------------------------
    def _run_pivot(self, ps: PassSpec) -> int:
        entries = list(self._load(ps.input_file))
        rules = _parse_kv_lines(ps.raw.get("pivot_rules", ""))
        array_field = ps.raw.get("pivot_array", "").strip()
        keep_raw = _as_bool(ps.raw.get("pivot_keep_raw", "true"))

        if not array_field or not rules:
            return 0

        compiled = []
        for pattern_str, assignment in rules:
            # Split the pattern on <placeholder> tokens; escape literal parts;
            # turn each placeholder into a named capture group.
            parts = re.split(r"(<[a-z][a-z0-9_]*>)", pattern_str)
            regex_pieces: list[str] = []
            for piece in parts:
                if piece.startswith("<") and piece.endswith(">") and len(piece) > 2:
                    gname = piece[1:-1]
                    regex_pieces.append(f"(?P<{gname}>\\S+)")
                else:
                    regex_pieces.append(re.escape(piece))
            compiled.append((re.compile(f"^{''.join(regex_pieces)}\\s*$"), assignment))

        n_changed = 0
        for entry in entries:
            arr = entry.get(array_field)
            if not isinstance(arr, list):
                continue
            applied_any = False
            for item in arr:
                if not isinstance(item, str):
                    continue
                for pat, assignment in compiled:
                    m = pat.match(item.strip())
                    if not m:
                        continue
                    # assignment is "field.path=<v>" or "field.path=true"
                    if "=" not in assignment:
                        continue
                    target, raw_value = assignment.split("=", 1)
                    target = target.strip()
                    raw_value = raw_value.strip()
                    # Substitute capture groups
                    final_value: Any = raw_value
                    for gname, gval in m.groupdict().items():
                        final_value = final_value.replace(f"<{gname}>", gval)
                    # Coerce simple scalars
                    if final_value in ("true", "True"):
                        final_value = True
                    elif final_value in ("false", "False"):
                        final_value = False
                    elif isinstance(final_value, str) and final_value.isdigit():
                        final_value = int(final_value)
                    _set_dotted(entry, target, final_value)
                    applied_any = True
                    break
            if applied_any:
                n_changed += 1
                if keep_raw:
                    entry[f"_raw_{array_field}"] = arr

        self._save_to_workset(ps.output_file, entries)
        return n_changed

    # -- derive --------------------------------------------------------
    def _run_derive(self, ps: PassSpec) -> int:
        src = list(self._load(ps.input_file))
        templates = _parse_kv_lines(ps.raw.get("derive_template", ""))
        if not templates:
            return 0

        out_entries: list[dict] = list(self._load(ps.output_file))
        # Index existing derived entries to allow re-runs without dupes
        existing_ids = {e.get("_id") or e.get("name") for e in out_entries}

        n_added = 0
        for entry in src:
            ctx = self._derive_context(entry)
            for name_template, body_template_json in templates:
                # Substitute placeholders in the name AND the body
                resolved_name = self._substitute(name_template, ctx)
                if resolved_name is None:
                    continue
                resolved_body_str = self._substitute(body_template_json, ctx)
                if resolved_body_str is None:
                    continue
                try:
                    body = json.loads(resolved_body_str)
                except json.JSONDecodeError as e:
                    raise ValueError(
                        f"derive_template JSON parse error for "
                        f"'{name_template}' on entry {entry.get('_id', '?')}: {e}"
                    )
                # Skip if any placeholder in body remains unresolved (None)
                if self._has_unresolved(body):
                    continue
                if resolved_name in existing_ids:
                    continue
                # Add envelope
                body.setdefault("_section", "implicit_address_objects")
                body.setdefault("_id", resolved_name)
                body.setdefault("_source_lines", entry.get("_source_lines", [0, 0]))
                body.setdefault("_implicit", True)
                out_entries.append(body)
                existing_ids.add(resolved_name)
                n_added += 1

        self._save_to_workset(ps.output_file, out_entries)
        return n_added

    @staticmethod
    def _derive_context(entry: dict) -> dict[str, Any]:
        """Build a flat name->value lookup for placeholder substitution.

        Pulls top-level fields and a few well-known nested ones used by
        SonicWall interface entries.
        """
        ctx: dict[str, Any] = {}
        for k, v in entry.items():
            if isinstance(v, (str, int, float, bool)):
                ctx[k] = v
        # Pull from ip-assignment sub-block. Field name + subfield list
        # declared in sw_field_extractors.ini, NOT hardcoded here.
        # (Local import to avoid circular import at module load.)
        from sw_field_extractor import extract as _sw_extract
        ip_block = _sw_extract(entry, 'interface_ip_block')
        if isinstance(ip_block, dict):
            if ip_block.get('_zone'):
                ctx.setdefault('zone', ip_block['_zone'])
            for k in ('ip', 'netmask', 'gateway'):
                if k in ip_block:
                    ctx[k] = ip_block[k]
            # Compute network address from ip + netmask (best-effort)
            ip = ip_block.get('ip')
            mask = ip_block.get('netmask')
            if isinstance(ip, str) and isinstance(mask, str):
                ctx['network'] = Enricher._compute_network(ip, mask)
        return ctx

    @staticmethod
    def _compute_network(ip: str, netmask: str) -> str | None:
        """Compute the network IP from an IPv4 + netmask. Best effort."""
        try:
            ip_parts = [int(p) for p in ip.split(".")]
            mask_parts = [int(p) for p in netmask.split(".")]
            if len(ip_parts) != 4 or len(mask_parts) != 4:
                return None
            net = [a & b for a, b in zip(ip_parts, mask_parts)]
            return ".".join(str(p) for p in net)
        except (ValueError, AttributeError):
            return None

    @staticmethod
    def _substitute(template: str, ctx: dict[str, Any]) -> str | None:
        """Replace <name> placeholders. Returns None if any required
        placeholder is missing or its value is False/None/empty."""
        result = template
        for ph in re.findall(r"<([a-z][a-z0-9_]*)>", template):
            if ph not in ctx or ctx[ph] in (None, False, ""):
                return None
            result = result.replace(f"<{ph}>", str(ctx[ph]))
        return result

    @staticmethod
    def _has_unresolved(obj: Any) -> bool:
        if isinstance(obj, str):
            return bool(re.search(r"<[a-z][a-z0-9_]*>", obj))
        if isinstance(obj, dict):
            return any(Enricher._has_unresolved(v) for v in obj.values())
        if isinstance(obj, list):
            return any(Enricher._has_unresolved(v) for v in obj)
        return False

    # -- transform -----------------------------------------------------
    def _run_transform(self, ps: PassSpec) -> int:
        """Apply a regex find/replace across specified fields of each entry.

        Used to normalize raw values (e.g. strip "ipv4 \"Name\"" -> "Name").
        Field values can be strings (transformed in place) or arrays of
        strings (each element transformed). Other types are skipped.
        """
        entries = list(self._load(ps.input_file))
        fields = self._csv(ps.raw.get("transform_fields", ""))
        pattern_str = ps.raw.get("transform_pattern", "").strip()
        replacement = ps.raw.get("transform_replacement", "").strip()

        if not fields or not pattern_str:
            return 0

        try:
            pat = re.compile(pattern_str)
        except re.error as e:
            raise ValueError(f"transform_pattern compile failed: {e}")

        n_changed = 0
        for entry in entries:
            entry_changed = False
            for field in fields:
                if field not in entry:
                    continue
                val = entry[field]
                if isinstance(val, str):
                    new_val = pat.sub(replacement, val)
                    if new_val != val:
                        entry[field] = new_val
                        entry_changed = True
                elif isinstance(val, list):
                    new_list = []
                    list_changed = False
                    for item in val:
                        if isinstance(item, str):
                            new_item = pat.sub(replacement, item)
                            if new_item != item:
                                list_changed = True
                            new_list.append(new_item)
                        else:
                            new_list.append(item)
                    if list_changed:
                        entry[field] = new_list
                        entry_changed = True
            if entry_changed:
                n_changed += 1

        self._save_to_workset(ps.output_file, entries)
        return n_changed

    @staticmethod
    def _csv(s: str) -> list[str]:
        return [x.strip() for x in s.replace("\n", ",").split(",") if x.strip()]

    # -- merge --------------------------------------------------------
    def _run_merge(self, ps: PassSpec) -> int:
        """Merge multiple entries into one canonical 'parent' entry.

        Two strategies declared in INI:

        strategy = name_pattern
            Group entries whose names match `name_pattern` regex.
            Capture group 1 supplies the merged-entry name.
            Used for TCP/UDP twin merge:
                name_pattern = ^(.+)\\s+(TCP|UDP)$
                -> 'DNS (Name Service) TCP' + 'DNS (Name Service) UDP'
                -> 'DNS (Name Service)' with two members.

        strategy = recursive_expand
            For each input entry, recursively walk a list-field tree
            (members may reference other entries in this file OR a leaf file)
            and emit one merged entry holding all flattened leaves.
            Used for service-group expansion.

        For both strategies, `members_field` names where to put the
        flattened/merged member list on the output entry.
        """
        entries = list(self._load(ps.input_file))
        strategy = ps.raw.get("strategy", "name_pattern").strip()
        members_field = ps.raw.get("members_field", "members").strip()
        output_replaces_input = _as_bool(
            ps.raw.get("output_replaces_input", "true")
        )

        if strategy == "name_pattern":
            new_entries = self._merge_by_name_pattern(ps, entries, members_field)
        elif strategy == "recursive_expand":
            new_entries = self._merge_by_recursive_expand(
                ps, entries, members_field
            )
        else:
            raise ValueError(f"unknown merge strategy: {strategy}")

        if output_replaces_input:
            self._save_to_workset(ps.output_file, new_entries)
        else:
            # Append the merge results to whatever's already there
            existing = list(self._load(ps.output_file))
            existing.extend(new_entries)
            self._save_to_workset(ps.output_file, existing)

        return len(new_entries) - len(entries) if output_replaces_input else len(new_entries)

    def _merge_by_name_pattern(
        self, ps: PassSpec, entries: list[dict], members_field: str
    ) -> list[dict]:
        pattern_str = ps.raw.get("name_pattern", "").strip()
        if not pattern_str:
            raise ValueError("merge.name_pattern requires `name_pattern`")
        pat = re.compile(pattern_str)

        # Bucket entries by their captured "merge key" name. Non-matching
        # entries pass through unchanged.
        buckets: dict[str, list[dict]] = {}
        passthrough: list[dict] = []
        for e in entries:
            name = e.get("name", "")
            if not isinstance(name, str):
                passthrough.append(e)
                continue
            m = pat.match(name)
            if not m or m.lastindex is None:
                passthrough.append(e)
                continue
            merged_name = m.group(1).strip()
            buckets.setdefault(merged_name, []).append(e)

        # Build merged entries. If a bucket has only one entry, keep its
        # original name (no point merging a single).
        merged: list[dict] = list(passthrough)
        member_keys = self._csv(ps.raw.get("member_carry_fields", ""))
        for merged_name, group in buckets.items():
            if len(group) == 1:
                merged.append(group[0])
                continue
            # Build merged record. Take first entry's envelope, replace name.
            base = dict(group[0])
            base["name"] = merged_name
            base["_id"] = merged_name
            base["_merged_from"] = [g.get("name") for g in group]
            # Build members list: each member is a small dict of the
            # specified carry fields, sourced from each merged entry.
            # The original name is preserved as `_origin_name` so downstream
            # consumers can trace each member back to its SonicWall source.
            member_list = []
            for g in group:
                member = {"_origin_name": g.get("name")}
                for k in member_keys:
                    if k in g:
                        member[k] = g[k]
                member_list.append(member)
            base[members_field] = member_list
            # Remove the now-redundant top-level fields that moved into members
            for k in member_keys:
                base.pop(k, None)
            merged.append(base)
        return merged

    def _merge_by_recursive_expand(
        self, ps: PassSpec, entries: list[dict], members_field: str
    ) -> list[dict]:
        """Each entry has fields listing references to other entries in the
        same file AND/OR references to entries in a 'leaves' file. Recursively
        flatten to a list of leaves, attach as members."""
        leaves_file = ps.raw.get("leaves_file", "").strip()
        ref_fields = self._csv(ps.raw.get("reference_fields", ""))
        nested_ref_field = ps.raw.get("nested_reference_field", "").strip()
        member_keys = self._csv(ps.raw.get("member_carry_fields", ""))
        skip_empty = _as_bool(ps.raw.get("skip_empty_groups", "true"))

        leaves: list[dict] = list(self._load(leaves_file)) if leaves_file else []
        leaf_by_name = {l.get("name"): l for l in leaves if l.get("name")}
        entry_by_name = {e.get("name"): e for e in entries if e.get("name")}

        # Build a "merged_from" reverse map so we can resolve references
        # to leaves that got merged away by an earlier merge pass.
        # If service_objects had its TCP/UDP twins merged, then references
        # to "NetBios UDP" should resolve to "NetBios" with the UDP member.
        merged_from_map: dict[str, str] = {}
        for leaf in leaves:
            for orig_name in leaf.get("_merged_from", []) or []:
                merged_from_map[orig_name] = leaf.get("name", "")

        def expand(group_name: str, seen: set[str]) -> list[dict]:
            if group_name in seen:
                return []
            seen = seen | {group_name}

            # Helper: when we resolve a leaf, if it's a merged-twin (has its
            # own service_members[] inside), inline THOSE members rather than
            # the merged parent itself — so the final member list is flat
            # and every member carries its own protocol/port.
            def _flatten_leaf(leaf: dict) -> list[dict]:
                inner = leaf.get(members_field) or leaf.get("service_members")
                if isinstance(inner, list) and inner:
                    return inner
                return [leaf]

            # If the name is a leaf (in the leaves file), return it directly
            if group_name in leaf_by_name:
                return _flatten_leaf(leaf_by_name[group_name])
            # If the name was merged into another leaf (e.g. "NetBios UDP" ->
            # "NetBios"), return the merged parent's members
            if group_name in merged_from_map:
                merged_parent = leaf_by_name.get(merged_from_map[group_name])
                if merged_parent:
                    # Pick only the matching-protocol member if we can tell.
                    # E.g. "NetBios UDP" -> the UDP member of NetBios.
                    inner = merged_parent.get(members_field) or merged_parent.get("service_members") or []
                    suffix = group_name.split()[-1].upper()  # "UDP" or "TCP"
                    matching = [m for m in inner
                                if str(m.get("protocol", "")).upper() == suffix]
                    if matching:
                        return matching
                    return inner if inner else [merged_parent]
            # If it's another group entry, recurse
            g = entry_by_name.get(group_name)
            if not g:
                # Unknown reference — preserve as a placeholder leaf
                return [{"name": group_name, "_unknown_reference": True}]
            out: list[dict] = []
            # Direct leaf-references (e.g. service-object names)
            for ref_field in ref_fields:
                for ref_name in g.get(ref_field, []) or []:
                    if not isinstance(ref_name, str):
                        continue
                    if ref_name in leaf_by_name:
                        out.extend(_flatten_leaf(leaf_by_name[ref_name]))
                    elif ref_name in merged_from_map:
                        merged_parent = leaf_by_name.get(merged_from_map[ref_name])
                        if merged_parent:
                            inner = merged_parent.get(members_field) or merged_parent.get("service_members") or []
                            suffix = ref_name.split()[-1].upper()
                            matching = [m for m in inner
                                        if str(m.get("protocol", "")).upper() == suffix]
                            if matching:
                                out.extend(matching)
                            else:
                                out.extend(inner if inner else [merged_parent])
                        else:
                            out.append(
                                {"name": ref_name, "_unknown_reference": True}
                            )
                    else:
                        out.append(
                            {"name": ref_name, "_unknown_reference": True}
                        )
            # Nested group references (recurse)
            if nested_ref_field:
                for sub_name in g.get(nested_ref_field, []) or []:
                    if isinstance(sub_name, str):
                        out.extend(expand(sub_name, seen))
            return out

        merged: list[dict] = []
        for e in entries:
            name = e.get("name")
            if not name:
                merged.append(e)
                continue
            flattened = expand(name, set())
            if not flattened and skip_empty:
                # Empty group; either drop or preserve metadata-only
                continue
            base = dict(e)
            base["_id"] = name
            base["_merge_kind"] = "recursive_expand"
            base["_merged_leaf_count"] = len(flattened)
            # Keep envelope-style member records
            member_list = []
            for leaf in flattened:
                member = {"name": leaf.get("name")}
                for k in member_keys:
                    if k in leaf:
                        member[k] = leaf[k]
                if leaf.get("_unknown_reference"):
                    member["_unknown_reference"] = True
                member_list.append(member)
            # Remove the original nested ref fields — they're now expanded
            for k in ref_fields:
                base.pop(k, None)
            if nested_ref_field:
                base.pop(nested_ref_field, None)
            base[members_field] = member_list
            merged.append(base)
        return merged

    # -- expand_schedule ------------------------------------------------
    def _run_expand_schedule(self, ps: PassSpec) -> int:
        """Expand SonicWall 'recurring' schedule strings into WG day-of-week
        member records.

        SonicWall format (one entry can have one OR a list):
            "HH:MM HH:MM <day-token...>"
        Examples:
            "08:00 17:00 mon tue wed thu fri"
            ["00:00 24:00 sun sat", "17:00 24:00 mon tue wed thu fri"]
            "00:00 24:00 all"

        Output structure attached to entry:
            wg_schedule = [
                {"day_of_week": 1, "periods": [{"from_h":8, "from_m":0,
                                                 "to_h":17, "to_m":0}]},
                ...
            ]
            wg_schedule_type = "always_on" | "recurring"
        """
        entries = list(self._load(ps.input_file))
        source_field = ps.raw.get("source_field", "occurs.recurring").strip()
        output_field = ps.raw.get("output_field", "wg_schedule").strip()
        type_field = ps.raw.get("emit_type_field", "wg_schedule_type").strip()
        day_token_pairs = self._parse_kv_list(ps.raw.get("day_tokens", ""))
        day_map = {k: int(v) for k, v in day_token_pairs}

        n_changed = 0
        for entry in entries:
            raw = _get_dotted(entry, source_field)
            if raw is None:
                continue
            # Normalize to list of strings
            lines = [raw] if isinstance(raw, str) else (
                raw if isinstance(raw, list) else []
            )

            # Build day_of_week -> [periods] dict (ordered by day index)
            # WG day_of_week range is 0-6 (Sun-Sat). The token 'all' uses
            # the -1 sentinel internally to mean "every day" — expanded
            # to 0..6 below. Updated 2026-06-04 after lab T-30 12.5.9 import
            # error: "The element 'day-of-week' has a value of '7' which
            # is greater than the maximum value allowed of '6'."
            day_periods: dict[int, list[dict]] = {}
            is_always_on = False
            for line in lines:
                if not isinstance(line, str):
                    continue
                period, days_used = self._parse_recurring_line(line, day_map)
                if period is None:
                    continue
                # Detect "all-day every-day" pattern (always-on equivalent)
                if (period["from_h"] == 0 and period["from_m"] == 0
                        and period["to_h"] == 24 and period["to_m"] == 0
                        and -1 in days_used):
                    is_always_on = True
                # -1 sentinel means 'every day' — expand to 0..6 (WG range)
                if -1 in days_used and len(days_used) == 1:
                    for dx in range(0, 7):
                        day_periods.setdefault(dx, []).append(period)
                else:
                    for d in days_used:
                        if d == -1:  # 'all' alongside specific days = expand
                            for dx in range(0, 7):
                                day_periods.setdefault(dx, []).append(period)
                        else:
                            day_periods.setdefault(d, []).append(period)

            if not day_periods:
                continue

            # Sort by day key; output as a list of {day_of_week, periods}
            wg_schedule = []
            for d in sorted(day_periods.keys()):
                wg_schedule.append({
                    "day_of_week": d,
                    "periods": day_periods[d],
                })
            entry[output_field] = wg_schedule
            entry[type_field] = "always_on" if is_always_on else "recurring"
            n_changed += 1

        self._save_to_workset(ps.output_file, entries)
        return n_changed

    @staticmethod
    def _parse_recurring_line(line: str, day_map: dict[str, int]
                              ) -> tuple[dict | None, list[int]]:
        """Parse 'HH:MM HH:MM token1 token2 ...' into a period dict and
        a list of day indices.

        Minutes are snapped to WG's quarter-hour enum {0, 15, 30, 45}
        (rounding UP to ensure the schedule window covers at least the
        requested duration). Verified against lab T-30 12.5.9 import
        error line 4036:
          "Element 'to-min': [facet 'enumeration'] The value '1' is
           not an element of the set {'-1', '0', '15', '30', '45'}."
        SonicWall allows free-integer minutes; WG snaps to 15-min
        boundaries. Rounding UP for to-min and DOWN for from-min
        ensures the resulting window includes the requested time.
        """
        parts = line.strip().split()
        if len(parts) < 3:
            return None, []
        try:
            from_h, from_m_raw = [int(p) for p in parts[0].split(":")]
            to_h, to_m_raw = [int(p) for p in parts[1].split(":")]
        except (ValueError, IndexError):
            return None, []

        # Snap from-min DOWN to nearest quarter-hour (don't shrink window)
        from_m = (from_m_raw // 15) * 15
        # Snap to-min UP to nearest quarter-hour
        if to_m_raw == 0:
            to_m = 0
        else:
            to_m = ((to_m_raw + 14) // 15) * 15
            if to_m == 60:
                to_m = 0
                to_h += 1

        period = {
            "from_h": from_h, "from_m": from_m,
            "to_h": to_h, "to_m": to_m,
        }
        days = []
        for tok in parts[2:]:
            t = tok.lower().strip(",")
            if t in day_map:
                days.append(day_map[t])
        # Deduplicate while preserving order
        seen = set()
        uniq_days = [d for d in days if not (d in seen or seen.add(d))]
        return period, uniq_days

    @staticmethod
    def _parse_kv_list(value: str) -> list[tuple[str, str]]:
        """Parse comma/newline separated 'k=v' pairs."""
        out = []
        for piece in value.replace("\n", ",").split(","):
            piece = piece.strip()
            if "=" not in piece:
                continue
            k, v = piece.split("=", 1)
            out.append((k.strip(), v.strip()))
        return out

    # -- audit ----------------------------------------------------------
    def _run_audit(self, ps: PassSpec) -> int:
        entries = list(self._load(ps.input_file))
        targets = [t.strip() for t in ps.raw.get("audit_target", "")
                   .replace("\n", ",").split(",") if t.strip()]
        findings_field = ps.raw.get("findings_field", "crypto_findings").strip()
        upgrade_field = ps.raw.get("upgrade_field", "upgrade_recommendation").strip()
        upgrade_table = self.cm.upgrade_recommendation()
        ike_max = self.cm.lifetime_max("ike")
        ipsec_max = self.cm.lifetime_max("ipsec")
        pfs_required = self.cm.pfs_required()

        n_changed = 0
        for entry in entries:
            findings: list[dict] = []
            recs: dict[str, str] = {}

            for tgt in targets:
                actual = _get_dotted(entry, tgt)
                if actual is None:
                    continue
                # Special handling for pfs (boolean, not in audit table)
                if tgt.endswith(".pfs"):
                    if actual is False and pfs_required:
                        findings.append({
                            "severity": "weak",
                            "field": tgt,
                            "value": False,
                            "reason": "Perfect Forward Secrecy disabled. "
                                      "Enabling protects past sessions if "
                                      "long-term keys are compromised.",
                        })
                        recs[tgt] = "true"
                    continue
                # Special handling for lifetime fields
                if tgt.endswith(".lifetime_seconds"):
                    try:
                        secs = int(actual)
                    except (ValueError, TypeError):
                        continue
                    if "phase1" in tgt and ike_max and secs > ike_max:
                        findings.append({
                            "severity": "advisory",
                            "field": tgt, "value": secs,
                            "reason": f"IKE Phase 1 SA lifetime exceeds "
                                      f"recommended max ({ike_max}s).",
                        })
                    if "phase2" in tgt and ipsec_max and secs > ipsec_max:
                        findings.append({
                            "severity": "advisory",
                            "field": tgt, "value": secs,
                            "reason": f"IPsec Phase 2 SA lifetime exceeds "
                                      f"recommended max ({ipsec_max}s).",
                        })
                    continue
                # Look up in the audit table for this field's last component
                table = self.cm.audit_table(tgt)
                # Normalize the actual value via the same canonicalization
                # the value-maps would do. For now: lowercase string match.
                actual_key = self._canon_value(tgt, actual)
                severity = table.get(actual_key, "unknown")
                if severity in ("deprecated", "weak", "breaking"):
                    findings.append({
                        "severity": severity,
                        "field": tgt,
                        "value": actual,
                        "reason": self._reason_text(tgt, actual_key, severity),
                    })
                    rec = upgrade_table.get(f"{tgt.split('.')[-1]}.{actual_key}")
                    if rec is None:
                        rec = upgrade_table.get(
                            f"{self._audit_table_name(tgt)}.{actual_key}"
                        )
                    if rec:
                        recs[tgt] = rec

            if findings or recs:
                if findings:
                    entry[findings_field] = findings
                if recs:
                    entry[upgrade_field] = recs
                n_changed += 1

        self._save_to_workset(ps.output_file, entries)
        return n_changed

    @staticmethod
    def _audit_table_name(tgt: str) -> str:
        last = tgt.split(".")[-1]
        return {"authentication": "hash"}.get(last, last)

    @staticmethod
    def _canon_value(tgt: str, val: Any) -> str:
        """Canonicalize a value for audit-table lookup."""
        s = str(val).lower().strip()
        # Common SonicWall->canonical normalizations (mirror concept_map)
        norm = {
            "triple-des": "3des",
            "aes-128": "aes128",
            "aes-192": "aes192",
            "aes-256": "aes256",
            "aes-128-gcm": "aes128gcm",
            "aes-256-gcm": "aes256gcm",
            "sha-1": "sha1",
            "sha-256": "sha2_256",
            "sha-384": "sha2_384",
            "sha-512": "sha2_512",
            "sha256": "sha2_256",
            "sha384": "sha2_384",
            "sha512": "sha2_512",
        }
        return norm.get(s, s)

    @staticmethod
    def _reason_text(tgt: str, val: str, severity: str) -> str:
        reasons = {
            ("encryption", "des"): "DES is broken (56-bit key).",
            ("encryption", "3des"): "3DES sunset by NIST in 2023; vulnerable to Sweet32.",
            ("encryption", "null"): "NULL encryption provides no confidentiality.",
            ("hash", "md5"): "MD5 is collision-broken.",
            ("hash", "sha1"): "SHA-1 collision-broken (SHAttered, 2017).",
            ("dh_group", "1"): "DH Group 1 (768-bit) is broken.",
            ("dh_group", "2"): "DH Group 2 (1024-bit MODP) weakened by Logjam.",
            ("dh_group", "5"): "DH Group 5 (1536-bit) is marginal.",
        }
        last = tgt.split(".")[-1]
        synonym = {"authentication": "hash"}.get(last, last)
        return reasons.get((synonym, val),
                           f"{tgt}={val} flagged as {severity}.")

    # ------------------------------------------------------------------
    # filter pass — drop records that match all conditions
    # ------------------------------------------------------------------
    def _run_filter(self, ps: PassSpec) -> int:
        """Drop records that match ALL declared conditions (AND-conjunction).

        Conditions are declared in the [pass.X] section as:
            match_<field> = <value>            (exact equality, case-insensitive)
            regex_<field> = <regex>            (re.search on str(value))
            contains_<field> = <substring>     (substring in str(value))

        Dotted field paths are supported for nested values, e.g.
        'auth-method.ike-id'.

        A record is dropped iff every declared condition matches.
        Use this to skip noisy auto-generated records (e.g. SonicWall's
        zone-pair default access rules) before they reach the filler.

        Counts the number of records DROPPED.
        """
        entries = list(self._load(ps.input_file))
        n_input = len(entries)

        # Collect conditions from the section
        match_conds = {}     # field -> expected value (lowercased)
        regex_conds = {}     # field -> compiled regex
        contains_conds = {}  # field -> substring (lowercased)
        empty_fields = []    # fields that must be empty (None / "" / [])
        for key, raw_value in ps.raw.items():
            value = raw_value.strip() if raw_value else ""
            if not value:
                continue
            if key.startswith("match_"):
                match_conds[key[len("match_"):]] = value.lower()
            elif key.startswith("regex_"):
                try:
                    regex_conds[key[len("regex_"):]] = re.compile(value)
                except re.error as exc:
                    raise ValueError(
                        f"bad regex in pass {ps.name!r} key {key!r}: {exc}"
                    )
            elif key.startswith("contains_"):
                contains_conds[key[len("contains_"):]] = value.lower()
            elif key.startswith("empty_"):
                # empty_FIELD = true   -> require field to be empty
                # empty_FIELD = false  -> ignore (not a useful condition)
                if value.lower() in ("true", "1", "yes"):
                    empty_fields.append(key[len("empty_"):])
            # standard keys (description, kind, input_file, output_file,
            # enabled) are ignored

        def _val_for(entry, field):
            v = _get_dotted(entry, field)
            if v is None:
                v = entry.get(field)
            return v

        def _matches(entry):
            for field, expected in match_conds.items():
                actual = _val_for(entry, field)
                if actual is None or str(actual).lower() != expected:
                    return False
            for field, pat in regex_conds.items():
                actual = _val_for(entry, field)
                if actual is None or not pat.search(str(actual)):
                    return False
            for field, sub in contains_conds.items():
                actual = _val_for(entry, field)
                if actual is None or sub not in str(actual).lower():
                    return False
            for field in empty_fields:
                actual = _val_for(entry, field)
                # "empty" = None, empty string, empty list/dict, or
                # missing entirely. Used for SonicWall factory entries
                # that exist as named placeholders with no content.
                if actual not in (None, "", [], {}):
                    return False
            return True

        kept = [e for e in entries if not _matches(e)]
        n_dropped = n_input - len(kept)

        if n_dropped:
            # _load already populated self.work_meta if it loaded the
            # file fresh. Reuse that meta on the output.
            out_name = ps.output_file or ps.input_file
            meta = self.work_meta.get(ps.input_file) \
                    or self.work_meta.get(out_name) \
                    or {}
            self._save_to_workset(out_name, kept, meta)
        return n_dropped


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(
        description="Phase 1.5 enrichment: pivot, derive, audit."
    )
    ap.add_argument("--config", default="enrich_config.ini",
                    help="Path to enrich_config.ini.")
    ap.add_argument("--strict", action="store_true",
                    help="Exit non-zero if schema validation finds errors")
    ap.add_argument("--no-validate", action="store_true",
                    help="Skip schema validation entirely")
    args = ap.parse_args()

    cfg_path = Path(args.config).resolve()
    if not cfg_path.is_file():
        print(f"ERROR: config not found: {cfg_path}", file=sys.stderr)
        return 2

    if not args.no_validate:
        report = validate_at_startup(cfg_path, engine_name="enricher")
        if report is not None and not report.ok and args.strict:
            print("ERROR: --strict and schema validation failed; "
                  "aborting before enrichment.", file=sys.stderr)
            return 3

    enricher = Enricher(cfg_path)
    print(f"Config:   {cfg_path}")
    print(f"In:       {enricher.parser_dir}")
    print(f"Out:      {enricher.out_dir}")
    print(f"Passes:   {len(enricher.passes)}\n")

    report = enricher.run()
    print("Pass results:")
    for p in report["passes"]:
        if p["status"] == "ok":
            print(f"  [{p['kind']:<6}] {p['name']:<32} changed={p['changed']:>4}")
        elif p["status"] == "disabled":
            print(f"  [{p['kind']:<6}] {p['name']:<32} (disabled)")
        else:
            print(f"  [{p['kind']:<6}] {p['name']:<32} ERROR: {p['error']}")

    print(f"\nOutputs:")
    for fname, n in report["outputs"].items():
        print(f"  {n:>5}  {fname}")
    print(f"\nManifest: {enricher.out_dir / '_enrichment_manifest.json'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
