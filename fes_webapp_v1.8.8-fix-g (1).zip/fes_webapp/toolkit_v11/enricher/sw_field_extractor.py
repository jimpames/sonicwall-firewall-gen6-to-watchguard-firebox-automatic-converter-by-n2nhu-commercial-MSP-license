#!/usr/bin/env python3
"""
sw_field_extractor.py — generic SonicOS field extractor.

Reads sw_field_extractors.ini and exposes:

    extract(record, extractor_name) -> Any
        Apply a named extractor to a parsed-SW record.
        Returns:
          - list-of-strings + match_prefix → list[str] of captured values
            (one per matching item, possibly empty)
          - dict + subfields → dict[str, value] containing the requested
            subfields; also includes _zone_from_args if requested
          - scalar → the field value as-is (or None)
        Returns None when the source_field is missing.

    extract_first(record, extractor_name) -> str | None
        Same as extract() but returns the first captured string (most
        common case), or None on miss.

    has_token(token, extractor_name) -> bool
        Does this token match the prefix rule for the given extractor?
        Used by callers that walk a list themselves but want INI-driven
        prefix matching.

    after_prefix(token, extractor_name) -> str | None
        Strip the extractor's prefix from a token. Returns None if the
        token doesn't match the prefix.

PROVENANCE
   Patterns declared in sw_field_extractors.ini (next to this file).
   NO SonicOS token strings hardcoded in this module or in callers.
"""
from __future__ import annotations

import configparser
from pathlib import Path
from typing import Any

_INI_PATH = Path(__file__).resolve().parent / 'sw_field_extractors.ini'
_CACHE: dict[str, dict] | None = None


def _load() -> dict[str, dict]:
    """{extractor_name: {source_field, source_kind, match_prefix, ...}}"""
    global _CACHE
    if _CACHE is not None:
        return _CACHE
    if not _INI_PATH.is_file():
        raise FileNotFoundError(
            f'sw_field_extractor: sw_field_extractors.ini not found at '
            f'{_INI_PATH}'
        )
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp.read(_INI_PATH, encoding='utf-8')
    out: dict[str, dict] = {}
    for section in cp.sections():
        if not section.startswith('extractor.'):
            continue
        name = section[len('extractor.'):]
        out[name] = {k: v.strip() for k, v in cp.items(section)}
    _CACHE = out
    return out


def _get_field(record: dict, path: str) -> Any:
    """Walk a dotted-path through a parsed-SW record."""
    if not record or not isinstance(record, dict):
        return None
    cur: Any = record
    for part in path.split('.'):
        if not isinstance(cur, dict):
            return None
        cur = cur.get(part)
        if cur is None:
            return None
    return cur


def _spec(name: str) -> dict:
    table = _load()
    if name not in table:
        raise KeyError(
            f'sw_field_extractor: extractor {name!r} not declared. '
            f'Available: {sorted(table)}'
        )
    return table[name]


def has_token(token: str, extractor_name: str) -> bool:
    """True if `token` is a string starting with the prefix for the
    named extractor. Caller is walking a list itself; this is the
    'INI-driven startswith' check."""
    spec = _spec(extractor_name)
    prefix = spec.get('match_prefix', '')
    if not prefix or not isinstance(token, str):
        return False
    return token.startswith(prefix + ' ')


def after_prefix(token: str, extractor_name: str) -> str | None:
    """Return the substring of `token` after the named extractor's
    prefix (plus its trailing space). None if not a match."""
    spec = _spec(extractor_name)
    prefix = spec.get('match_prefix', '')
    if not prefix or not isinstance(token, str):
        return None
    full = prefix + ' '
    if not token.startswith(full):
        return None
    return token[len(full):].strip().strip('"')


def extract(record: dict, extractor_name: str) -> Any:
    """Apply the named extractor to a record. Returns extracted value
    appropriate for the extractor's source_kind."""
    spec = _spec(extractor_name)
    src_field = spec.get('source_field', '')
    src_kind = spec.get('source_kind', '')
    if not src_field:
        return None
    value = _get_field(record, src_field)
    if value is None:
        return None

    if src_kind == 'list-of-strings':
        if not isinstance(value, list):
            return []
        out_list: list[str] = []
        for item in value:
            captured = after_prefix(item, extractor_name) if isinstance(item, str) else None
            if captured is not None:
                out_list.append(captured)
        return out_list

    if src_kind == 'dict':
        if not isinstance(value, dict):
            return None
        subs_raw = spec.get('subfields', '')
        subs = [s.strip() for s in subs_raw.split(',') if s.strip()]
        result: dict[str, Any] = {}
        for s in subs:
            if s in value:
                result[s] = value[s]
        if spec.get('zone_from_args', '').lower() == 'true':
            args = value.get('_args', '')
            if isinstance(args, str) and args:
                result['_zone'] = args.split()[0]
        return result

    if src_kind == 'scalar':
        return value

    return value


def extract_first(record: dict, extractor_name: str) -> str | None:
    """Return the first captured string for a list-of-strings extractor,
    or None on miss. Convenience for the common 'one match expected' case."""
    result = extract(record, extractor_name)
    if isinstance(result, list) and result:
        return result[0]
    return None


def all_extractors() -> list[str]:
    """List declared extractor names (for diagnostics)."""
    return sorted(_load())
