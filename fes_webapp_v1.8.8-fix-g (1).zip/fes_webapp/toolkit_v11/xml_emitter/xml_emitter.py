#!/usr/bin/env python3
"""
xml_emitter.py
================

Phase 2 of the migration pipeline. Reads canonical (and enriched) JSON
and emits a WatchGuard configuration.xml. Plus a migration_notes.md for
anything that doesn't translate cleanly.

Like every other component in this toolkit, the engine is generic. It
knows nothing about WatchGuard, SonicWall, or any specific element name.
All such knowledge lives in xml_emit_config.ini and concept_map.ini.

Algebraic-design model:

    JSON Entry × Emit Rule = XML Element

    JSON Entry  = a dict from Phase 1.5 enriched output
    Emit Rule   = an [emit.X] section in xml_emit_config.ini
    XML Element = ElementTree node placed at the rule's xml_parent_xpath

Status conventions in the emit config:
    confirmed     - schema verified; emit fully
    todo          - schema unknown; emit a stub <!-- TODO --> comment
    partial       - basics work; edges may need T-30 export validation
    advisory_only - no XML; appends to migration_notes.md

Run:
    python3 xml_emitter.py --config xml_emit_config.ini
"""
from __future__ import annotations

import argparse
import configparser
import datetime as _dt
import json
import re
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# Make schema_lib importable when running from this directory
_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))
from schema_lib import validate_at_startup  # noqa: E402


# ---------------------------------------------------------------------------
# Shared helpers (same dialect as enricher.py)
# ---------------------------------------------------------------------------
def _read_ini(path: Path) -> configparser.ConfigParser:
    cp = configparser.ConfigParser(
        interpolation=None,
        inline_comment_prefixes=(";",),
        comment_prefixes=("#",),
    )
    cp.read(path, encoding="utf-8")
    return cp


def _as_bool(s: Any) -> bool:
    return str(s).strip().lower() in ("true", "yes", "1", "on")


def _load_entries(path: Path) -> list[dict]:
    if not path.is_file():
        return []
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    if isinstance(d, dict) and "entries" in d:
        return d["entries"]
    if isinstance(d, list):
        return d
    return []


def _get_dotted(d: dict, dotted: str) -> Any:
    cur: Any = d
    for p in dotted.split("."):
        if not isinstance(cur, dict) or p not in cur:
            return None
        cur = cur[p]
    return cur


def _parse_kv_lines(value: str) -> list[tuple[str, str]]:
    """Same parser as enricher: handles multi-line `KEY = VALUE` blocks
    and quoted keys."""
    pairs: list[tuple[str, str]] = []
    for raw in value.split("\n"):
        line = raw.strip()
        if not line:
            continue
        in_q = False
        eq = -1
        for i, ch in enumerate(line):
            if ch == '"':
                in_q = not in_q
            elif ch == "=" and not in_q:
                eq = i
                break
        if eq < 0:
            continue
        key = line[:eq].strip()
        val = line[eq + 1:].strip()
        if len(key) >= 2 and key[0] == '"' and key[-1] == '"':
            key = key[1:-1]
        pairs.append((key, val))
    return pairs


# ---------------------------------------------------------------------------
# Concept map — value-map lookups
# ---------------------------------------------------------------------------
class ConceptMap:
    def __init__(self, path: Path):
        self.cp = _read_ini(path)

    def value_map(self, name: str) -> dict[str, str]:
        """Return canonical_to_watchguard map as a dict."""
        section_name = f"value_map.{name}"
        if section_name not in self.cp:
            return {}
        raw = self.cp[section_name].get("canonical_to_watchguard", "")
        out: dict[str, str] = {}
        # Format: "k1=v1, k2=v2, ..." (may span lines via continuation)
        for piece in raw.replace("\n", ",").split(","):
            piece = piece.strip()
            if not piece or "=" not in piece:
                continue
            k, v = piece.split("=", 1)
            out[k.strip()] = v.strip()
        return out

    def sonicwall_to_canonical(self, name: str) -> dict[str, str]:
        section_name = f"value_map.{name}"
        if section_name not in self.cp:
            return {}
        raw = self.cp[section_name].get("sonicwall_to_canonical", "")
        out: dict[str, str] = {}
        for piece in raw.replace("\n", ",").split(","):
            piece = piece.strip()
            if not piece or "=" not in piece:
                continue
            k, v = piece.split("=", 1)
            out[k.strip()] = v.strip()
        return out


# ---------------------------------------------------------------------------
# Emit rule definition
# ---------------------------------------------------------------------------
@dataclass
class EmitRule:
    name: str
    description: str
    status: str
    input_file: str
    input_filter: str
    xml_parent_xpath: str
    xml_element_name: str
    name_attribute: str
    name_template: str
    child_map: list[tuple[str, str]]
    conditional_children: list[tuple[str, str]]
    static_children: list[tuple[str, str]]
    value_maps: list[str]
    merge_implicit: bool
    # When set, comma-separated list of regex patterns. Any entry whose
    # `name` field matches any pattern is dropped (with a migration note).
    # Used to filter SonicWall-only constructs that have no WG meaning,
    # like auto-generated IPv6 system aliases.
    skip_name_patterns: list[str]
    skip_note_category: str
    # When set to "<child-tag>", the engine resolves the entry's
    # final_name first, then looks under xml_parent_xpath for an
    # existing <xml_element_name> child whose <child-tag>'s text matches
    # the final_name. If found: child_map and static_children are applied
    # to that EXISTING element instead of creating a new one. If not found:
    # behavior falls back to creating new (same as today).
    #
    # Used when the master_skeleton has pre-populated structural
    # elements (like <interface> entries with proper if-dev-name) and
    # the source-side data needs to update specific dynamic fields
    # rather than create duplicate entries. In this mode, child_map
    # OVERWRITES target text rather than appending siblings.
    merge_into_existing_by: str
    # Pre-emit transformation: for each entry, take the first
    # whitespace-token of the named field and store it as `zone`.
    # Used for SonicWall ip-assignment._args = "LAN static" -> zone="LAN".
    # Generic value_map can then map zone -> WG canonical interface name.
    derive_zone_from_first_token: str
    # For advisory_only rules: optional preamble + per-entry template.
    # When set, _emit_advisory uses this template (with {field}
    # substitutions from the entry) instead of the default GVC-specific
    # rendering. Each line of the template is rendered per matched entry,
    # with empty lines preserved. Use advisory_preamble for the
    # rule-wide intro text (rendered once at the top).
    advisory_preamble: str
    advisory_template: str
    # Single-level list expansion: emit one repeated element per item in
    # entry[list_expand_field], using list_expand_child_map to map
    # member-fields to subpaths under list_expand_subpath.
    list_expand_field: str
    list_expand_subpath: str
    list_expand_child_map: list[tuple[str, str]]
    list_expand_static: list[tuple[str, str]]
    # Two-level list expansion: outer array of {key + inner array}.
    # Used for schedules: wg_schedule[] -> day -> periods[].
    nested_list_expand_field: str
    nested_list_expand_subpath: str
    nested_list_expand_child_map: list[tuple[str, str]]
    nested_list_inner_field: str
    nested_list_inner_subpath: str
    nested_list_inner_child_map: list[tuple[str, str]]
    nested_list_inner_static: list[tuple[str, str]]
    raw: configparser.SectionProxy

    @classmethod
    def from_section(cls, name: str, sect: configparser.SectionProxy) -> EmitRule:
        return cls(
            name=name,
            description=sect.get("description", "").strip(),
            status=sect.get("status", "todo").strip(),
            input_file=sect.get("input_file", "").strip(),
            input_filter=sect.get("input_filter", "").strip(),
            xml_parent_xpath=sect.get("xml_parent_xpath", "").strip(),
            xml_element_name=sect.get("xml_element_name", "").strip(),
            name_attribute=sect.get("name_attribute", "").strip(),
            name_template=sect.get("name_template", "").strip(),
            child_map=_parse_kv_lines(sect.get("child_map", "")),
            conditional_children=_parse_kv_lines(
                sect.get("conditional_children", "")
            ),
            static_children=_parse_kv_lines(sect.get("static_children", "")),
            value_maps=[v.strip() for v in
                        sect.get("value_maps", "").replace("\n", ",").split(",")
                        if v.strip()],
            merge_implicit=_as_bool(sect.get("merge_implicit_addresses", "false")),
            skip_name_patterns=[v.strip() for v in
                        sect.get("skip_name_patterns", "").replace("\n", ",").split(",")
                        if v.strip()],
            skip_note_category=sect.get("skip_note_category", "").strip(),
            merge_into_existing_by=sect.get("merge_into_existing_by", "").strip(),
            derive_zone_from_first_token=sect.get(
                "derive_zone_from_first_token", "").strip(),
            advisory_preamble=sect.get("advisory_preamble", ""),
            advisory_template=sect.get("advisory_template", ""),
            list_expand_field=sect.get("list_expand_field", "").strip(),
            list_expand_subpath=sect.get("list_expand_subpath", "").strip(),
            list_expand_child_map=_parse_kv_lines(sect.get("list_expand_child_map", "")),
            list_expand_static=_parse_kv_lines(sect.get("list_expand_static", "")),
            nested_list_expand_field=sect.get("nested_list_expand_field", "").strip(),
            nested_list_expand_subpath=sect.get("nested_list_expand_subpath", "").strip(),
            nested_list_expand_child_map=_parse_kv_lines(
                sect.get("nested_list_expand_child_map", "")
            ),
            nested_list_inner_field=sect.get("nested_list_inner_field", "").strip(),
            nested_list_inner_subpath=sect.get("nested_list_inner_subpath", "").strip(),
            nested_list_inner_child_map=_parse_kv_lines(
                sect.get("nested_list_inner_child_map", "")
            ),
            nested_list_inner_static=_parse_kv_lines(
                sect.get("nested_list_inner_static", "")
            ),
            raw=sect,
        )


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------
class XmlEmitter:
    def __init__(self, config_path: Path):
        self.cp = _read_ini(config_path)
        io = self.cp["io"]
        self.enricher_dir = (config_path.parent / io["enricher_output_dir"]).resolve()
        self.parser_dir = (config_path.parent / io["parser_output_dir"]).resolve()
        self.out_dir = (config_path.parent / io["output_dir"]).resolve()
        self.cm = ConceptMap((config_path.parent / io["concept_map_path"]).resolve())
        self.root_element = io.get("root_element", "configuration")

        self.rules: list[EmitRule] = [
            EmitRule.from_section(s.split(".", 1)[1], self.cp[s])
            for s in self.cp.sections() if s.startswith("emit.")
        ]

        # Load skeleton as starting tree if configured; otherwise empty root.
        skeleton_path_str = io.get("skeleton_path", "").strip()
        self.skeleton_used = False
        if skeleton_path_str:
            sk_path = (config_path.parent / skeleton_path_str).resolve()
            if sk_path.is_file():
                tree = ET.parse(sk_path)
                self.root = tree.getroot()
                self.skeleton_used = True
            else:
                print(f"  WARN: skeleton not found at {sk_path}; using empty root",
                      file=sys.stderr)
                self.root = ET.Element(self.root_element)
        else:
            self.root = ET.Element(self.root_element)

        self.advisories: list[str] = []
        self.report: dict[str, Any] = {
            "rules": [],
            "advisories": 0,
            "skeleton_used": self.skeleton_used,
        }

        # Phase 9 — cache freshness check.
        # If the enricher and parser caches disagree on which source
        # file they were built from, the emit will mix data from
        # different SonicWall configs (e.g. interface IPs from one,
        # access rules from another). This bit us repeatedly tonight
        # because harness/run_all.py silently re-parses
        # slimmed-sonicwallconfig.txt during test_wg_validator, then
        # an interactive emit reads stale data. We warn loudly here
        # so the operator sees the disagreement before importing
        # something garbage onto a real Firebox.
        self._check_cache_freshness()

    def _check_cache_freshness(self) -> None:
        """Verify enricher and parser caches are aligned and not stale.

        Parser side: read `_meta.source_file` from `_manifest.json`.
        Enricher side: enricher doesn't currently record its source in
        manifest, so we use mtime comparison — enricher outputs must be
        newer than parser outputs OR they may carry stale data from a
        previous parse of a different SonicWall config.

        Warnings go to stderr; the report records the state but does
        not abort the emit (operator may have valid reasons to proceed,
        e.g. testing with a known-stale cache)."""
        parser_meta = self.parser_dir / "_manifest.json"
        enricher_meta = self.enricher_dir / "_enrichment_manifest.json"

        parser_src = None
        if parser_meta.is_file():
            try:
                with open(parser_meta, encoding="utf-8") as f:
                    data = json.load(f)
                    parser_src = data.get("_meta", {}).get("source_file") \
                                 or data.get("source_file")
            except (OSError, json.JSONDecodeError):
                pass

        # If parser hasn't run, there's nothing to validate against
        if parser_src is None:
            print("  WARN: parser output empty/unreadable; emit will produce a "
                  "skeleton-only file. Run the SonicWall parser first.",
                  file=sys.stderr)
            self.report["cache_freshness"] = {"status": "parser_empty"}
            return

        # mtime-based freshness check for enricher
        # If enricher_manifest is older than parser_manifest, enricher
        # is stale (parser re-ran after enricher).
        stale_enricher = False
        if parser_meta.is_file() and enricher_meta.is_file():
            if enricher_meta.stat().st_mtime < parser_meta.stat().st_mtime:
                stale_enricher = True
        elif not enricher_meta.is_file():
            print("  WARN: enricher output empty; emit will use raw parser "
                  "data without enrichment. Run the enricher first.",
                  file=sys.stderr)
            self.report["cache_freshness"] = {"status": "enricher_empty"}
            return

        if stale_enricher:
            print(f"  WARN: cache freshness mismatch!", file=sys.stderr)
            print(f"        parser   source: {parser_src}", file=sys.stderr)
            print(f"        enricher manifest is OLDER than parser manifest",
                  file=sys.stderr)
            print(f"        — enricher likely contains data from a previous "
                  f"parse.", file=sys.stderr)
            print(f"        Run `python3 enricher/enricher.py` from the "
                  f"enricher/ directory to align caches.", file=sys.stderr)
            self.report["cache_freshness"] = {
                "status": "stale_enricher",
                "parser_source": parser_src,
                "parser_manifest_mtime": parser_meta.stat().st_mtime,
                "enricher_manifest_mtime": enricher_meta.stat().st_mtime
                    if enricher_meta.is_file() else None,
            }
        else:
            self.report["cache_freshness"] = {
                "status": "aligned",
                "source": parser_src,
            }

    # ------------------------------------------------------------------
    # Entry loading (prefer enricher dir, fall back to parser dir)
    # ------------------------------------------------------------------
    def _load(self, fname: str) -> list[dict]:
        a = self.enricher_dir / fname
        b = self.parser_dir / fname
        if a.is_file():
            return _load_entries(a)
        if b.is_file():
            return _load_entries(b)
        return []

    # ------------------------------------------------------------------
    # XPath navigation: find or create the parent element chain
    # ------------------------------------------------------------------
    def _ensure_path(self, xpath: str) -> ET.Element:
        """Walk /configuration/... ; create elements as needed."""
        parts = [p for p in xpath.split("/") if p]
        if not parts or parts[0] != self.root_element:
            raise ValueError(
                f"xml_parent_xpath must start with /{self.root_element}: {xpath}"
            )
        cur = self.root
        for tag in parts[1:]:
            child = cur.find(tag)
            if child is None:
                child = ET.SubElement(cur, tag)
            cur = child
        return cur

    @staticmethod
    def _ensure_subpath(parent: ET.Element, subpath: str,
                          position_hint: int | None = None) -> ET.Element:
        """Walk a sub-path inside an element, creating along the way.
        
        position_hint: if provided AND a leaf child is being newly created,
        insert it at that position in the parent (0 = first). Used for
        WatchGuard's order-sensitive XSD-sequence elements where
        <type> must precede payload children. The hint applies only
        to the LAST segment of the path; intermediate ancestors are
        always passthrough (find-or-append default).
        
        Existing leaves are returned in place — the hint is honored
        only when the leaf is being newly created.
        """
        cur = parent
        parts = [t for t in subpath.split("/") if t]
        for i, tag in enumerate(parts):
            child = cur.find(tag)
            if child is None:
                is_leaf = (i == len(parts) - 1)
                if is_leaf and position_hint is not None:
                    child = ET.Element(tag)
                    cur.insert(position_hint, child)
                else:
                    child = ET.SubElement(cur, tag)
            cur = child
        return cur

    # ------------------------------------------------------------------
    # Filter evaluation (very small expression subset for safety)
    # ------------------------------------------------------------------
    @staticmethod
    def _passes_filter(entry: dict, expr: str) -> bool:
        """Tiny expression evaluator. Supports:
            field == "value"     equality
            field != "value"     inequality
            field =~ "regex"     regex search (substring or full)
            field !~ "regex"     negated regex search
        Anything more complex returns False (safe default)."""
        if not expr:
            return True
        m = re.match(r'^\s*([a-zA-Z_][a-zA-Z0-9_.\-]*)\s*(==|!=|=~|!~)\s*"([^"]*)"\s*$',
                     expr)
        if not m:
            return False
        field, op, val = m.groups()
        actual = _get_dotted(entry, field)
        actual_str = str(actual) if actual is not None and actual is not False else ""
        if op == "==":
            return actual_str == val
        if op == "!=":
            return actual_str != val
        if op == "=~":
            try:
                return bool(re.search(val, actual_str))
            except re.error:
                return False
        if op == "!~":
            try:
                return not bool(re.search(val, actual_str))
            except re.error:
                return False
        return False

    @staticmethod
    def _match_skip_pattern(name: str, patterns: list[str]) -> str | None:
        """Return the first regex pattern matching `name`, or None.

        Used by the skip_name_patterns directive to drop SonicWall-only
        entries that have no WatchGuard equivalent. Patterns are
        anchored implicitly via re.search (NOT re.match) so a pattern
        like `IPv6.*Address` matches names containing that substring.
        Anchored patterns are also fine: ^X[0-9].*Subnet$.
        """
        for pat in patterns:
            try:
                if re.search(pat, name):
                    return pat
            except re.error:
                continue
        return None

    # ------------------------------------------------------------------
    # Value-map application
    # ------------------------------------------------------------------
    # SonicWall CLI value-string wrappers that need to be stripped to
    # bare names. Examples:
    #   'name "Apple Bonjour"'        -> 'Apple Bonjour'
    #   'group "DMZ Subnets"'         -> 'DMZ Subnets'
    #   'service name "HTTP"'         -> 'HTTP'
    #   'address group "LAN Subnets"' -> 'LAN Subnets'
    # The relevance_filter has the canonical implementation; this is the
    # minimal regex needed for emit-time normalization. Found post-Phase-8
    # when validator's cross-reference check flagged 'name "Apple Bonjour"'
    # not resolving to any service-list entry.
    _SW_NAME_WRAPPER_PATTERNS = [
        re.compile(r'(?:^|.*\s)(?:address\s+)?group\s+"([^"]+)"$'),
        re.compile(r'(?:^|.*\s)(?:service\s+)?name\s+"([^"]+)"$'),
        re.compile(r'(?:^|.*\s)name\s+([^\s"]+)$'),
    ]

    @classmethod
    def _strip_sw_name_wrapper(cls, value: str) -> str:
        """Strip SonicWall CLI wrappers like `name "X"` or `group "X"` to
        bare `X`. Returns input unchanged if no wrapper detected."""
        if not isinstance(value, str) or '"' not in value and ' ' not in value:
            return value
        for pat in cls._SW_NAME_WRAPPER_PATTERNS:
            m = pat.match(value)
            if m:
                return m.group(1)
        return value

    def _apply_value_maps(self, value: Any, map_names: list[str],
                          rule_value_maps: list[str]) -> Any:
        """Apply a chain of value maps. map_names are the ones referenced
        in the child_map directive (e.g. "ike_encryption"); rule_value_maps
        are the rule-wide list (currently informational)."""
        # First strip SonicWall name-wrappers (`name "X"` -> `X`).
        result = self._strip_sw_name_wrapper(str(value))
        # Then normalize via sonicwall->canonical (handles "triple-des"->"3des")
        for m_name in map_names:
            s2c = self.cm.sonicwall_to_canonical(m_name)
            if result in s2c:
                result = s2c[result]
            c2w = self.cm.value_map(m_name)
            if result in c2w:
                result = c2w[result]
        return result

    # ------------------------------------------------------------------
    # Child-map directive parsing
    # ------------------------------------------------------------------
    @staticmethod
    def _parse_directive(rhs: str) -> tuple[str, list[str], str]:
        """Parse a child_map RHS: 'subpath/element[@attr] | map1, map2'.

        Returns (subpath_with_target, value_maps_list, mode).
        mode: 'text' | 'attribute'
        """
        maps: list[str] = []
        if "|" in rhs:
            target, raw_maps = rhs.split("|", 1)
            maps = [m.strip() for m in raw_maps.split(",") if m.strip()]
            target = target.strip()
        else:
            target = rhs.strip()
        if "@" in target:
            return target, maps, "attribute"
        return target, maps, "text"

    # ------------------------------------------------------------------
    # Per-rule emit
    # ------------------------------------------------------------------
    def emit_all(self) -> None:
        for rule in self.rules:
            try:
                self._emit_rule(rule)
            except Exception as e:
                self.report["rules"].append({
                    "rule": rule.name, "status": rule.status,
                    "result": "error", "error": str(e),
                })
                print(f"  ERROR in emit.{rule.name}: {e}", file=sys.stderr)

    def _emit_rule(self, rule: EmitRule) -> None:
        if rule.status == "advisory_only":
            self._emit_advisory(rule)
            return

        # Stub TODO rules with a comment marker (still write the parent shell
        # so the structure is visible)
        if rule.status == "todo":
            parent = self._ensure_path(rule.xml_parent_xpath)
            entries = self._gather_entries(rule)
            kept = [e for e in entries if self._passes_filter(e, rule.input_filter)]
            n = len(kept)
            comment = ET.Comment(
                f" TODO: emit.{rule.name} — schema unconfirmed. "
                f"{n} input entries waiting for T-30 export. {rule.description.split(chr(10))[0]} "
            )
            parent.append(comment)
            self.report["rules"].append({
                "rule": rule.name, "status": rule.status,
                "result": "stubbed", "todo_inputs": n,
            })
            return

        entries = self._gather_entries(rule)

        # Pre-emit: derive zone field if requested. Splits the named
        # field's value on whitespace and stores the first token as
        # `zone`. Used for SonicWall ip-assignment._args = "LAN static"
        # → zone="LAN". A subsequent value_map can then map LAN to
        # the WG canonical interface name (Trusted, External, etc.).
        #
        # Robust to two SonicWall parser shapes:
        #   * dict: {'_args': 'LAN static', 'ip': ..., ...}
        #   * string: 'LAN portshield X0'  (when no body)
        # And tolerant of False/None values (entries without an IPv4
        # assignment; those will get filtered downstream).
        if rule.derive_zone_from_first_token:
            src_path = rule.derive_zone_from_first_token
            for entry in entries:
                val = (_get_dotted(entry, src_path) if "." in src_path
                       else entry.get(src_path, ""))
                # If src_path missed (e.g., flat string at parent level),
                # fall back to the parent path's raw value.
                if val in (None, "", False) and "." in src_path:
                    parent_path = src_path.rsplit(".", 1)[0]
                    parent_val = entry.get(parent_path)
                    if isinstance(parent_val, str):
                        val = parent_val
                if isinstance(val, str) and val.split():
                    entry['zone'] = val.split()[0]

        parent = self._ensure_path(rule.xml_parent_xpath)
        emitted = 0
        merged = 0
        skipped_by_pattern: list[tuple[str, str]] = []  # (entry_name, matched_pattern)
        skipped_no_name: list[str] = []   # entries with no resolvable name
        merge_collisions: list[tuple[str, str, str]] = []  # (entry_id, target_name, kept_winner)
        already_merged: set[int] = set()  # id() of existing elements we've already merged into
        seen_names: dict[str, int] = {}  # final_name -> emission count
        for entry in entries:
            if not self._passes_filter(entry, rule.input_filter):
                continue

            # Skip-name-patterns: drop entries whose `name` field matches
            # any configured regex. Used to filter SonicWall-only
            # constructs (like auto-generated IPv6 system aliases) that
            # have no WG meaning. Each skipped entry is logged to
            # migration_notes.md so the operator can see what was dropped.
            if rule.skip_name_patterns:
                entry_name = str(entry.get('name') or '')
                matched = self._match_skip_pattern(entry_name,
                                                   rule.skip_name_patterns)
                if matched is not None:
                    skipped_by_pattern.append((entry_name, matched))
                    continue

            # Resolve final_name BEFORE element creation. Required for
            # merge-into-existing mode (we need the name to find the
            # existing element). For backward compatibility, if no
            # name_attribute is set, skip the resolution.
            final_name: str | None = None
            if rule.name_attribute:
                if rule.name_template:
                    final_name = self._substitute_fields(rule.name_template, entry)
                else:
                    final_name = entry.get(rule.name_attribute)
                if final_name is not None and final_name is not False:
                    final_name = str(final_name)
                    # Apply value_maps to the resolved name. This lets the
                    # rule e.g. map zone "LAN" -> "Trusted" via a value_map
                    # listed in the rule's value_maps.
                    if rule.value_maps:
                        final_name = str(self._apply_value_maps(
                            final_name, rule.value_maps, []))
                else:
                    final_name = None

            # In merge-into-existing mode, an entry with no final_name
            # is unrouteable — skip it with a migration note. Common
            # for SonicWall interfaces with no IPv4 zone (IPv6-only).
            if rule.merge_into_existing_by and not final_name:
                entry_id = str(entry.get('id') or entry.get('name')
                               or entry.get('uuid') or '?')
                skipped_no_name.append(entry_id)
                continue

            # Decide: merge into existing element or create new?
            elem = None
            is_merged = False
            if rule.merge_into_existing_by and final_name:
                key_tag = rule.merge_into_existing_by
                for existing in parent.findall(rule.xml_element_name):
                    key_el = existing.find(key_tag)
                    if (key_el is not None
                            and (key_el.text or '').strip() == final_name):
                        # First-wins for collisions: if we've already merged
                        # something into this element this run, don't override.
                        # Records the loser as a migration concern.
                        if id(existing) in already_merged:
                            entry_id = str(entry.get('id')
                                           or entry.get('name') or '?')
                            merge_collisions.append(
                                (entry_id, final_name, '(already populated)'))
                            elem = None  # Skip this entry entirely
                            is_merged = False
                            break
                        elem = existing
                        is_merged = True
                        already_merged.add(id(existing))
                        merged += 1
                        break
                # If merge-mode set but final_name didn't resolve to any
                # existing element, fall through to create new (e.g. zones
                # we don't have skeleton coverage for — Optional-4 etc.)
            if elem is None and rule.merge_into_existing_by and final_name and merge_collisions:
                # Last collision was for this entry — already accounted for, skip
                if merge_collisions[-1][0] == str(entry.get('id') or entry.get('name') or '?'):
                    continue
            if elem is None:
                elem = ET.SubElement(parent, rule.xml_element_name)

            # Set the <name> child if we created a new element AND
            # name_attribute is set. For merge mode the existing element
            # already has its <name>, don't touch it.
            if not is_merged and rule.name_attribute and final_name is not None:
                if final_name in seen_names:
                    seen_names[final_name] += 1
                    suffix = str(
                        entry.get("uuid") or entry.get("_id")
                        or seen_names[final_name]
                    )
                    final_name = f"{final_name}-{suffix}"
                else:
                    seen_names[final_name] = 1
                name_el = ET.SubElement(elem, "name")
                name_el.text = final_name

            # child_map: each pair maps a JSON field path -> XML subpath
            for json_field, directive in rule.child_map:
                value = _get_dotted(entry, json_field) if "." in json_field \
                        else entry.get(json_field)
                if value is None or value is False or value == "":
                    continue
                subpath, maps, mode = self._parse_directive(directive)
                if mode == "attribute":
                    sub, attr = subpath.split("@", 1)
                    target_el = self._ensure_subpath(elem, sub) if sub else elem
                    target_el.set(attr, str(self._apply_value_maps(value, maps, [])))
                else:
                    target_el = self._ensure_subpath(elem, subpath)
                    # If target element already has children/text, append a sibling.
                    # EXCEPT in merge-into-existing mode, where the target's
                    # existing text is a skeleton placeholder we want to
                    # OVERWRITE with source data.
                    if (target_el.text or len(target_el) > 0) and not is_merged:
                        # Create a sibling with the same final tag
                        parent_of_target = self._ensure_subpath(
                            elem, "/".join(subpath.split("/")[:-1])
                        ) if "/" in subpath else elem
                        target_el = ET.SubElement(
                            parent_of_target, subpath.split("/")[-1]
                        )
                    if isinstance(value, list):
                        # Repeat the leaf for each list item
                        text_first = str(self._apply_value_maps(value[0], maps, []))
                        target_el.text = text_first
                        sib_parent = list(elem.iter())  # not used
                        for extra in value[1:]:
                            # find the immediate parent of target_el
                            p = self._find_parent(elem, target_el)
                            if p is not None:
                                sib = ET.SubElement(p, subpath.split("/")[-1])
                                sib.text = str(self._apply_value_maps(extra, maps, []))
                    else:
                        target_el.text = str(self._apply_value_maps(value, maps, []))

            # conditional_children: emit only if condition holds
            for cond, defn in rule.conditional_children:
                if self._cond_holds(entry, cond):
                    self._apply_conditional_defn(elem, entry, defn)

            # list_expand: emit one repeated child per item in the array.
            # Used for multi-protocol services where service_members[] becomes
            # multiple <service-item><member> entries.
            if rule.list_expand_field:
                items = entry.get(rule.list_expand_field) or []
                if isinstance(items, list):
                    self._apply_list_expand(elem, items, rule)

            # nested_list_expand: two-level expansion. Outer array of
            # {key + inner-array}. Used for schedules where wg_schedule[]
            # becomes <member>s, each carrying a <period>/<member> inner list.
            if rule.nested_list_expand_field:
                outer = entry.get(rule.nested_list_expand_field) or []
                if isinstance(outer, list):
                    self._apply_nested_list_expand(elem, outer, rule)

            # static_children: always emit, regardless of input. Used for
            # WG XML defaults that every element needs (property=16, version=2,
            # vpn-type=1, etc.). Subpath syntax: "subpath/leaf = literal_value"
            # Values may contain {field} placeholders which substitute from
            # the source entry (used for fan-out cross-references like
            # "{name}.1.from").
            #
            # An empty value (e.g. `forward-traffic-mgmt =`) emits an empty
            # element <forward-traffic-mgmt></forward-traffic-mgmt>, which
            # matches WatchGuard's default-shape for a number of fields
            # whose presence (but not content) matters.
            #
            # POSITION HINT (Phase 9 polymorphic-type fix): if the subpath
            # ends with `@first`, the leaf is inserted at position 0 of its
            # parent — required for WatchGuard's order-sensitive XSD-sequence
            # elements like <member> where <type> must precede <protocol>.
            for subpath, value in rule.static_children:
                if not subpath:
                    continue
                # Parse @first suffix
                position_hint = None
                if subpath.endswith("@first"):
                    subpath = subpath[:-len("@first")].rstrip("/")
                    position_hint = 0
                resolved_value = self._substitute_fields(value, entry)
                target = self._ensure_subpath(elem, subpath,
                                              position_hint=position_hint)
                # If target already exists with content from child_map,
                # don't overwrite — child_map wins.
                if target.text or len(target) > 0:
                    continue
                target.text = resolved_value

            emitted += 1

        # Log filtered entries to migration_notes.md if any were skipped
        if skipped_by_pattern:
            category = rule.skip_note_category or rule.name
            note_lines = [
                f"### Filtered entries — emit.{rule.name}",
                "",
                f"Category: **{category}**",
                "",
                f"{len(skipped_by_pattern)} entr"
                f"{'y' if len(skipped_by_pattern)==1 else 'ies'} from "
                f"`{rule.input_file}` matched a skip_name_patterns regex "
                f"and were not emitted to `{rule.xml_parent_xpath}`. "
                "These are typically SonicWall-only constructs with no "
                "WatchGuard equivalent.",
                "",
                "| Skipped entry | Matched pattern |",
                "|---|---|",
            ]
            for name, pat in skipped_by_pattern:
                note_lines.append(f"| `{name}` | `{pat}` |")
            self.advisories.append("\n".join(note_lines))

        if skipped_no_name:
            note_lines = [
                f"### Skipped entries (no resolvable name) — emit.{rule.name}",
                "",
                f"{len(skipped_no_name)} entr"
                f"{'y' if len(skipped_no_name)==1 else 'ies'} from "
                f"`{rule.input_file}` could not be merged into the "
                f"target schema because no name resolved (often: "
                f"SonicWall interface with no IPv4 zone configured).",
                "",
                "Skipped IDs: " + ", ".join(f"`{x}`" for x in skipped_no_name),
            ]
            self.advisories.append("\n".join(note_lines))

        if merge_collisions:
            note_lines = [
                f"### Merge collisions — emit.{rule.name}",
                "",
                f"Multiple source entries mapped to the same target "
                f"element. SonicWall allows multiple physical interfaces "
                f"in the same zone, but WatchGuard's canonical interfaces "
                f"are 1:1 (one Trusted, one External, etc.). The first "
                f"matching entry won; subsequent ones were dropped:",
                "",
                "| Source ID | Target | Result |",
                "|---|---|---|",
            ]
            for src_id, target, kept in merge_collisions:
                note_lines.append(f"| `{src_id}` | `{target}` | {kept} |")
            note_lines.append("")
            note_lines.append(
                "Review: extra interfaces in this zone may need to be "
                "remapped to Optional-N slots manually, or the SonicWall "
                "physical layout may need consolidation.")
            self.advisories.append("\n".join(note_lines))

        self.report["rules"].append({
            "rule": rule.name, "status": rule.status,
            "result": "emitted", "count": emitted,
            "merged_into_existing": merged,
            "skipped_by_pattern": len(skipped_by_pattern),
            "skipped_no_name": len(skipped_no_name),
            "merge_collisions": len(merge_collisions),
            "xpath": rule.xml_parent_xpath,
        })

    @staticmethod
    def _substitute_fields(template: str, entry: dict) -> str:
        """Replace {field} or {field1|field2|...} placeholders in template.

        Used by name_template and by static_children values.

        Single field: {name} -> entry["name"] (left as-is if missing/falsy).
        Fallback chain: {name|comment|uuid} -> first field in chain that
            resolves to a truthy non-empty value. Useful when SonicWall
            rules have `no name` (parsed as False) — fall back to comment
            or uuid for a more readable identifier.
        """
        result = template
        # Allow letters, digits, underscores, hyphens, and dots in field names
        # (hyphens for SonicWall fields like 'ip-assignment'; dots for
        # nested paths like 'ip-assignment.ip')
        for ph in re.findall(r"\{([a-zA-Z_][a-zA-Z0-9_.\-|]*)\}", template):
            chain = ph.split("|")
            resolved = None
            for fname in chain:
                # Support dotted paths via _get_dotted; falls back to
                # entry.get for plain field names.
                v = (_get_dotted(entry, fname) if "." in fname
                     else entry.get(fname))
                if v is None or v is False or v == "":
                    continue
                resolved = v
                break
            if resolved is not None:
                result = result.replace(f"{{{ph}}}", str(resolved))
        return result

    @staticmethod
    def _find_parent(root: ET.Element, target: ET.Element) -> ET.Element | None:
        for p in root.iter():
            for c in list(p):
                if c is target:
                    return p
        return None

    def _apply_list_expand(self, elem: ET.Element,
                           items: list[dict], rule: EmitRule) -> None:
        """Single-level list expansion: emit one repeated child per item.

        For each member item, create a fresh element at list_expand_subpath
        (NOT shared — every item gets its own subtree). Apply
        list_expand_child_map to populate the element's children from the
        item's fields, with optional value-map translation.

        Used by services with multiple protocol/port pairs (TCP+UDP merged
        twins, expanded service-groups). The first item replaces the
        existing subpath element if any; subsequent items create siblings
        at the same parent path.
        """
        if not rule.list_expand_subpath or not items:
            return
        # Locate (or create) the parent of the repeated leaf-element.
        # subpath is e.g. "service-item/member" — the *parent* path is
        # "service-item" and the repeated tag is "member".
        parts = rule.list_expand_subpath.strip("/").split("/")
        parent_path, leaf_tag = "/".join(parts[:-1]), parts[-1]
        parent = self._ensure_subpath(elem, parent_path) if parent_path else elem

        # Remove any existing leaf-tag children from a singleton child_map
        # pass so we don't double up. (Multi-member entries shouldn't have
        # singleton fields populated, but defensive.)
        for existing in list(parent.findall(leaf_tag)):
            parent.remove(existing)

        for item in items:
            if not isinstance(item, dict):
                continue
            new_member = ET.SubElement(parent, leaf_tag)
            for src_field, dest_path_with_map in rule.list_expand_child_map:
                # dest_path_with_map: "subpath" or "subpath | value_map"
                pieces = [p.strip() for p in dest_path_with_map.split("|")]
                dest_path = pieces[0]
                vmap_name = pieces[1] if len(pieces) > 1 else None
                raw = item.get(src_field)
                if raw is None or raw is False or raw == "":
                    continue
                val = str(raw)
                if vmap_name:
                    val = str(self._apply_value_maps(
                        val, [vmap_name], rule.value_maps))
                target = self._ensure_subpath(new_member, dest_path) \
                    if dest_path else new_member
                target.text = val
            # Static defaults applied to EVERY expanded member.
            # Same @first semantics as static_children — when WatchGuard's
            # order-sensitive XSD wants <type> before payload, declare the
            # path with `path@first` in list_expand_static.
            for dest_path, value in rule.list_expand_static:
                if not dest_path:
                    continue
                position_hint = None
                if dest_path.endswith("@first"):
                    dest_path = dest_path[:-len("@first")].rstrip("/")
                    position_hint = 0
                target = self._ensure_subpath(new_member, dest_path,
                                              position_hint=position_hint) \
                    if dest_path else new_member
                if not target.text:
                    target.text = value

    def _apply_nested_list_expand(self, elem: ET.Element,
                                  outer_items: list[dict],
                                  rule: EmitRule) -> None:
        """Two-level list expansion: outer items each carry an inner array.

        Schedules use this: wg_schedule[] has one record per active day,
        each holding periods[] (one or more time-windows that day).

        For each outer item: create one element at nested_list_expand_subpath,
        populate it via nested_list_expand_child_map, then walk the item's
        nested_list_inner_field list and create one element at
        nested_list_inner_subpath per inner item.
        """
        if not rule.nested_list_expand_subpath or not outer_items:
            return
        outer_parts = rule.nested_list_expand_subpath.strip("/").split("/")
        outer_parent_path = "/".join(outer_parts[:-1])
        outer_tag = outer_parts[-1]
        outer_parent = (self._ensure_subpath(elem, outer_parent_path)
                        if outer_parent_path else elem)

        # Wipe any pre-existing repeated children
        for existing in list(outer_parent.findall(outer_tag)):
            outer_parent.remove(existing)

        for outer_item in outer_items:
            if not isinstance(outer_item, dict):
                continue
            outer_el = ET.SubElement(outer_parent, outer_tag)
            # Apply outer child_map
            for src_field, dest_path in rule.nested_list_expand_child_map:
                raw = outer_item.get(src_field)
                if raw is None or raw is False or raw == "":
                    continue
                target = self._ensure_subpath(outer_el, dest_path) \
                    if dest_path else outer_el
                target.text = str(raw)
            # Apply inner expansion
            inner_items = outer_item.get(rule.nested_list_inner_field) or []
            if not isinstance(inner_items, list):
                continue
            inner_parts = rule.nested_list_inner_subpath.strip("/").split("/")
            inner_parent_path = "/".join(inner_parts[:-1])
            inner_tag = inner_parts[-1]
            inner_parent = (self._ensure_subpath(outer_el, inner_parent_path)
                            if inner_parent_path else outer_el)
            for inner_item in inner_items:
                if not isinstance(inner_item, dict):
                    continue
                inner_el = ET.SubElement(inner_parent, inner_tag)
                # Apply inner child_map
                for src_field, dest_path in rule.nested_list_inner_child_map:
                    raw = inner_item.get(src_field)
                    if raw is None or raw is False:
                        continue
                    target = self._ensure_subpath(inner_el, dest_path) \
                        if dest_path else inner_el
                    target.text = str(raw)
                # Apply inner static defaults
                for dest_path, value in rule.nested_list_inner_static:
                    if not dest_path:
                        continue
                    target = self._ensure_subpath(inner_el, dest_path)
                    if not target.text:
                        target.text = value

    def _gather_entries(self, rule: EmitRule) -> list[dict]:
        if not rule.input_file:
            return []
        entries = list(self._load(rule.input_file))
        if rule.merge_implicit:
            entries.extend(self._load("implicit_address_objects.json"))
        return entries

    @staticmethod
    def _cond_holds(entry: dict, cond: str) -> bool:
        """Tiny condition evaluator for conditional_children."""
        # Recognized conditions:
        #   host_present, network_present, range_present, fqdn_present
        if cond == "host_present":
            return bool(entry.get("host"))
        if cond == "network_present":
            return bool(entry.get("network"))
        if cond == "range_present":
            return bool(entry.get("range"))
        if cond == "fqdn_present":
            return bool(entry.get("fqdn"))
        # Generic field truthiness
        if cond.endswith("_present"):
            return bool(entry.get(cond[:-len("_present")]))
        return False

    def _apply_conditional_defn(self, parent: ET.Element, entry: dict,
                                 defn: str) -> None:
        """defn is a `;` separated list of `subpath=<value_template>` items."""
        for piece in defn.split(";"):
            piece = piece.strip()
            if not piece or "=" not in piece:
                continue
            sub, tmpl = piece.split("=", 1)
            sub = sub.strip()
            tmpl = tmpl.strip()
            value = self._resolve_template(tmpl, entry)
            if value is None:
                continue
            target = self._ensure_subpath(parent, sub)
            if target.text or len(target) > 0:
                # Append sibling
                sub_parts = sub.split("/")
                p = self._ensure_subpath(parent, "/".join(sub_parts[:-1])) \
                    if len(sub_parts) > 1 else parent
                target = ET.SubElement(p, sub_parts[-1])
            target.text = str(value)

    @staticmethod
    def _resolve_template(tmpl: str, entry: dict) -> Any:
        """Resolve <name> placeholders in a value template.

        Supported placeholders:
          <host>, <network>, <netmask>, <range_start>, <range_end>, <fqdn>,
          <network_ip>, <network_mask>  (split a "10.0.0.0 255.255.255.0" pair)
        """
        result = tmpl
        # Special: split network value into ip + mask
        net = entry.get("network")
        if isinstance(net, str) and " " in net:
            net_ip, net_mask = net.split(None, 1)
            result = result.replace("<network_ip>", net_ip)
            result = result.replace("<network_mask>", net_mask)
        else:
            result = result.replace("<network_ip>", str(net) if net else "")
            result = result.replace("<network_mask>", "")
        # Range may be "10.0.0.10 10.0.0.20"
        rng = entry.get("range")
        if isinstance(rng, str) and " " in rng:
            r_lo, r_hi = rng.split(None, 1)
            result = result.replace("<range_start>", r_lo)
            result = result.replace("<range_end>", r_hi)
        # Plain field placeholders
        for ph in re.findall(r"<([a-z][a-z0-9_]*)>", result):
            v = entry.get(ph)
            if v is None or v is False:
                return None
            result = result.replace(f"<{ph}>", str(v))
        return result

    # ------------------------------------------------------------------
    # Advisory generation
    # ------------------------------------------------------------------
    def _emit_advisory(self, rule: EmitRule) -> None:
        entries = self._gather_entries(rule)
        kept = [e for e in entries if self._passes_filter(e, rule.input_filter)]
        n = len(kept)
        if n == 0:
            self.report["rules"].append({
                "rule": rule.name, "status": rule.status,
                "result": "advisory_skipped", "count": 0,
            })
            return

        # Template-based rendering (preferred for new rules) — uses
        # advisory_preamble (rendered once) + advisory_template
        # (rendered per matched entry with {field} substitution).
        # Falls back to legacy GVC-specific rendering when not configured.
        if rule.advisory_template:
            lines = [
                f"## {rule.name}",
                "",
                rule.description.strip(),
                "",
                f"**Affected entries: {n}**",
                "",
            ]
            if rule.advisory_preamble:
                lines.append(rule.advisory_preamble.strip())
                lines.append("")
            for e in kept:
                rendered = self._substitute_fields(rule.advisory_template, e)
                lines.append(rendered)
            lines.append("")
        else:
            # Legacy GVC-specific rendering
            lines = [
                f"## {rule.name}",
                "",
                rule.description.strip(),
                "",
                f"**Affected entries: {n}**",
                "",
            ]
            for e in kept:
                name = e.get("name", e.get("_id", "?"))
                vt = e.get("vpn_type", "?")
                findings = e.get("crypto_findings", [])
                lines.append(f"- `{name}` ({vt})")
                for f in findings:
                    lines.append(
                        f"    - {f.get('severity', '?'):<11} "
                        f"{f.get('field', '?')} = `{f.get('value', '?')}` — "
                        f"{f.get('reason', '')}"
                    )
            lines.append("")

        self.advisories.append("\n".join(lines))
        self.report["advisories"] += n
        self.report["rules"].append({
            "rule": rule.name, "status": rule.status,
            "result": "advisory_written", "count": n,
        })

    # Phase 9 — uniqueness-constraint paths. Mirrors the validator's
    # UNIQUENESS_CONSTRAINTS table. Each list is post-emit deduped:
    # within the named list, only the first <child> with each unique
    # <name> survives; subsequent duplicates are removed. Prevents
    # WatchGuard 400 "Duplicate key-sequence" import rejection.
    #
    # The dedup ordering matters: first-emitted wins. Our emit rule
    # ordering means service-objects (richer data) win over
    # service-groups (synthesized from member list), which is the
    # correct preference.
    UNIQUENESS_LISTS = [
        # (list_tag, child_tag, name_child_tag)
        ('service-list', 'service', 'name'),
        ('address-group-list', 'address-group', 'name'),
        ('alias-list', 'alias', 'name'),
    ]

    def _dedupe_unique_lists(self) -> None:
        """Drop duplicate-named entries from uniqueness-constrained lists.
        First entry wins; later duplicates are removed and recorded in
        the report. WatchGuard XSD enforces these constraints; without
        this dedupe pass, the importer rejects with 400 errors.
        
        Verified against lab T-30 12.5.9 which rejected:
          "Element 'service': Duplicate key-sequence ['Terminal Services']
           in key identity-constraint 'Service-Name'."
        """
        dedupe_report: list[dict] = []
        for list_tag, child_tag, name_tag in self.UNIQUENESS_LISTS:
            list_elem = self.root.find(list_tag)
            if list_elem is None:
                continue
            seen_names: set[str] = set()
            removed: list[str] = []
            for child in list(list_elem.findall(child_tag)):
                name_elem = child.find(name_tag)
                if name_elem is None or not name_elem.text:
                    continue
                name = name_elem.text.strip()
                if name in seen_names:
                    list_elem.remove(child)
                    removed.append(name)
                else:
                    seen_names.add(name)
            if removed:
                dedupe_report.append({
                    'list': list_tag,
                    'duplicates_removed': len(removed),
                    'names': removed,
                })
        if dedupe_report:
            self.report['uniqueness_dedupe'] = dedupe_report

    # Phase 9 — Element tags whose children we reorder at emit-time to
    # match jpa.xml's canonical sequence ordering. WatchGuard XSD uses
    # xs:sequence so child order is part of the schema. Without this
    # reorder pass, the Firebox rejects with 400 errors like:
    #   line 3360: "Element 'property': not expected.
    #               Expected ( version, enabled, use-vif )."
    # which means our <property> appeared at a position where the
    # next expected element was <version>/<enabled>/<use-vif>.
    REORDER_TARGET_TAGS = frozenset([
        'service', 'address-group', 'alias', 'interface',
        'abs-policy', 'policy',
        'ipsec-action', 'ipsec-proposal',
        'ike-action', 'ike-policy',
        'nat', 'schedule',
        # Sub-elements of ike-policy that have ordered xs:sequence children
        # and our emit can produce out-of-order. Per jpa.xml, <local-cert>
        # canonical order is: rsa-cert, rsa-id, rsa-id-type, dsa-cert,
        # dsa-id-type, ec-cert, ec-id-type, gen-cert-id, psk, psk-hex,
        # local-id-type, local-id-data, local-if. Wrong order causes
        # the Firebox to walk past the required-one-of group and reject
        # with "Missing child element(s). Expected is one of ( rsa-cert,
        # dsa-cert, ... )" — verified against lab T-30 line 3619.
        'local-cert',
    ])

    def _build_canonical_order_from_reference(self) -> dict:
        """Build a per-tag canonical child ordering from jpa.xml.

        Algorithm: collect pairwise before/after constraints from every
        instance, then topologically sort. If instance A has children
        [name, description, property], that gives constraints
        name<description, description<property, name<property. If
        instance B has [name, property] (no description), it doesn't
        contradict A's constraints. Merging A+B's constraints and
        topo-sorting yields [name, description, property] — which is
        what we want.

        The naive 'first observed wins' alternative misplaces a tag
        when an earlier instance lacks it: by the time we see it in a
        later instance, all preceding positions are filled, so it gets
        appended at the end — wrong order. Verified against lab T-30
        12.5.9 import error line 3375 where 'first observed wins' put
        <description> at position 13 (after <enabled>) when bovpntunnel.1
        has it at position 1 (after <name>)."""
        canonical: dict = {}
        ref_path = (Path(__file__).parent.parent
                    / "schema_learner" / "corpus" / "T30jpa1.xml")
        if not ref_path.is_file():
            return canonical
        try:
            ref_root = ET.parse(ref_path).getroot()
        except ET.ParseError:
            return canonical

        for tag in self.REORDER_TARGET_TAGS:
            # Collect pairwise constraints across all instances:
            #   precedes[a] = set of tags that have appeared AFTER a
            #                 in at least one instance
            # Plus tracking first-appearance instance to break ties.
            precedes: dict[str, set[str]] = {}
            seen_tags: set[str] = set()
            for inst in ref_root.iter(tag):
                child_tags = [c.tag for c in inst]
                seen_tags.update(child_tags)
                for i, t1 in enumerate(child_tags):
                    precedes.setdefault(t1, set())
                    for t2 in child_tags[i+1:]:
                        precedes[t1].add(t2)
            if not seen_tags:
                continue

            # Topo-sort. Kahn's algorithm with tie-break by alphabetical
            # for determinism (input child sets are small enough that
            # the determinism cost is negligible and reproducibility
            # is worth more than micro-optimal ordering).
            # in_degree[t] = number of tags that precede t in any instance
            in_degree: dict[str, int] = {t: 0 for t in seen_tags}
            for t1, succs in precedes.items():
                for t2 in succs:
                    if t2 in in_degree:
                        in_degree[t2] += 1
            available = sorted(t for t in seen_tags if in_degree[t] == 0)
            ordered: list[str] = []
            while available:
                t = available.pop(0)
                ordered.append(t)
                for succ in sorted(precedes.get(t, set())):
                    in_degree[succ] -= 1
                    if in_degree[succ] == 0:
                        # Insert maintaining alphabetical order in available
                        import bisect
                        bisect.insort(available, succ)
            # Any remaining tags had cyclic constraints (shouldn't happen
            # for valid XSD-sequence elements, but defensive):
            for t in sorted(seen_tags):
                if t not in ordered:
                    ordered.append(t)
            canonical[tag] = ordered
        return canonical

    def _reorder_children_per_reference(self) -> None:
        """Walk our tree; for EVERY parent tag jpa.xml has a canonical
        order for, reorder children to match. This is the systematic
        version of the per-parent reorder — instead of curating which
        parent tags to reorder, we reorder every one jpa.xml shows.
        
        Children whose tags don't appear in canonical (toolkit
        extensions or new customer-emit fields) are kept in their
        existing relative order AFTER the canonical-ordered set."""
        canonical_order = self._build_canonical_order_from_reference_ALL()
        if not canonical_order:
            return
        reordered_count = 0
        for elem in self.root.iter():
            if elem.tag not in canonical_order:
                continue
            canonical = canonical_order[elem.tag]
            canonical_pos = {t: i for i, t in enumerate(canonical)}
            children = list(elem)
            if len(children) < 2:
                continue
            def sort_key(c, _children=children):
                pos = canonical_pos.get(c.tag)
                if pos is not None:
                    return (0, pos)
                return (1, _children.index(c))
            new_order = sorted(children, key=sort_key)
            if new_order != children:
                for c in children:
                    elem.remove(c)
                for c in new_order:
                    elem.append(c)
                reordered_count += 1
        if reordered_count > 0:
            self.report['canonical_reorder'] = {
                'elements_reordered': reordered_count,
                'parent_tags_with_canonical': len(canonical_order),
            }

    def _build_canonical_order_from_reference_ALL(self) -> dict:
        """Build canonical child order for EVERY parent element type in
        jpa.xml that has children. No curation gate — let the reference
        be authoritative for everything it has shape for.

        Algorithm: first-observed-wins union across all instances. This
        matches what jpa.xml literally shows (which the Firebox accepts),
        and matches the diff tool's algorithm so the toolkit's reorder
        and validation reach the same canonical order."""
        canonical: dict = {}
        ref_path = (Path(__file__).parent.parent
                    / "schema_learner" / "corpus" / "T30jpa1.xml")
        if not ref_path.is_file():
            return canonical
        try:
            ref_root = ET.parse(ref_path).getroot()
        except ET.ParseError:
            return canonical

        all_parent_tags: set[str] = set()
        for elem in ref_root.iter():
            if list(elem):
                all_parent_tags.add(elem.tag)

        for tag in all_parent_tags:
            seen: set[str] = set()
            order: list[str] = []
            for inst in ref_root.iter(tag):
                for child in inst:
                    if child.tag not in seen:
                        seen.add(child.tag)
                        order.append(child.tag)
            if order:
                canonical[tag] = order
        return canonical

    # ------------------------------------------------------------------
    # Output
    # ------------------------------------------------------------------
    def write(self) -> dict:
        self.out_dir.mkdir(parents=True, exist_ok=True)

        # Phase 9 — dedupe uniqueness-constrained lists before pretty-print.
        self._dedupe_unique_lists()
        # Phase 9 — reorder children to match jpa.xml canonical order.
        # Must run AFTER dedupe (so we don't reorder doomed children).
        self._reorder_children_per_reference()

        # Pretty-print the XML
        xml_str = self._pretty(self.root)

        xml_path = self.out_dir / "configuration.xml"
        with open(xml_path, "w", encoding="utf-8") as f:
            f.write('<?xml version="1.0" encoding="UTF-8"?>\n')
            # Note: Captain's Test 1 (with these comments) got far into
            # restore before failing on a schema rule. Test 2 (without
            # them) failed with immediate 502. Comments here are
            # apparently fine. Keep them for traceability.
            f.write(f"<!-- Generated by xml_emitter.py at "
                    f"{_dt.datetime.now().isoformat(timespec='seconds')} -->\n")
            f.write(xml_str)

        notes_path = self.out_dir / "migration_notes.md"
        with open(notes_path, "w", encoding="utf-8") as f:
            f.write("# Migration Notes\n\n")
            f.write(f"Generated: {_dt.datetime.now().isoformat(timespec='seconds')}\n\n")
            if not self.advisories:
                f.write("_No advisory entries generated._\n")
            else:
                f.write("\n\n".join(self.advisories))
                f.write("\n")

        manifest_path = self.out_dir / "_emit_manifest.json"
        self.report["xml_file"] = str(xml_path.relative_to(self.out_dir.parent))
        self.report["notes_file"] = str(notes_path.relative_to(self.out_dir.parent))
        self.report["generated_at"] = _dt.datetime.now().isoformat(timespec="seconds")
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(self.report, f, indent=2, ensure_ascii=False)
            f.write("\n")
        return self.report

    @staticmethod
    def _pretty(elem: ET.Element, level: int = 0) -> str:
        """Indent an ElementTree (Python 3.9+ has ET.indent; we DIY for portability)."""
        try:
            ET.indent(elem, space="  ")
        except AttributeError:
            pass
        return ET.tostring(elem, encoding="unicode")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def _run_post_emit_validation(
    out_dir: Path, cfg_path: Path,
    cp: configparser.ConfigParser,
    cli_no_validate: bool, cli_strict: bool,
) -> int:
    """Run wg_validator on the just-emitted XML, print a summary, save
    reports next to the XML, and return the exit-code contribution.

    Returns:
        0 if validation is disabled, passed, or under threshold
        4 if validation errors exceed the configured fail_on threshold
            (we use 4, not 2/3, to distinguish from config-validation
             errors that already use those codes)
    """
    # Skip if CLI override
    if cli_no_validate:
        return 0

    # Read config flags
    if 'validation' not in cp:
        # No validation section configured — skip silently
        return 0
    val_sect = cp['validation']
    enabled = val_sect.get('enabled', 'true').strip().lower() in (
        'true', '1', 'yes', 'on')
    if not enabled:
        return 0

    schema_path_str = val_sect.get('schema_path', '').strip()
    if not schema_path_str:
        print("[xml_emitter] validation enabled but no schema_path; "
              "skipping output validation", file=sys.stderr)
        return 0

    schema_path = Path(schema_path_str)
    if not schema_path.is_absolute():
        schema_path = (cfg_path.parent / schema_path).resolve()
    if not schema_path.is_file():
        print(f"[xml_emitter] validation schema not found: {schema_path}; "
              "skipping output validation", file=sys.stderr)
        return 0

    candidate_xml = out_dir / 'configuration.xml'
    if not candidate_xml.is_file():
        print(f"[xml_emitter] candidate XML not found: {candidate_xml}; "
              "skipping output validation", file=sys.stderr)
        return 0

    # Import wg_validator from the toolkit. This works because the
    # emitter has already added _TOOLKIT_ROOT to sys.path at module
    # load time.
    try:
        from wg_validator.wg_validator import (
            load_wg_schema, load_wg_references,
            WgValidator, render_summary
        )
    except ImportError as e:
        print(f"[xml_emitter] could not import wg_validator: {e}; "
              "skipping output validation", file=sys.stderr)
        return 0

    print()
    print("=" * 72)
    print("Post-emit validation")
    print("=" * 72)

    schema = load_wg_schema(schema_path)

    # Optional: cross-reference rules
    references = []
    builtins = {}
    references_path_str = val_sect.get('references_path', '').strip()
    if references_path_str:
        references_path = Path(references_path_str)
        if not references_path.is_absolute():
            references_path = (cfg_path.parent / references_path).resolve()
        if references_path.is_file():
            references, builtins = load_wg_references(references_path)

    # Phase 9 — load the jpa.xml reference for bidirectional structural
    # diff (forward-diff: child ordering matches reference). Path is
    # `reference_xml_path` in [validation], with sensible fallback to
    # schema_learner/corpus/T30jpa1.xml which we know exists.
    reference_xml_path: Path | None = None
    ref_path_str = val_sect.get('reference_xml_path', '').strip()
    if ref_path_str:
        ref_p = Path(ref_path_str)
        if not ref_p.is_absolute():
            ref_p = (cfg_path.parent / ref_p).resolve()
        if ref_p.is_file():
            reference_xml_path = ref_p
    if reference_xml_path is None:
        # Fallback: the canonical jpa.xml in schema_learner/corpus/
        fallback = (cfg_path.parent.parent
                    / "schema_learner" / "corpus" / "T30jpa1.xml")
        if fallback.is_file():
            reference_xml_path = fallback

    unknown_sev = val_sect.get('unknown_element_severity', 'warning').strip()
    validator = WgValidator(schema, schema_path,
                            unknown_element_severity=unknown_sev,
                            references=references,
                            builtins=builtins,
                            reference_xml_path=reference_xml_path)
    val_report = validator.validate(candidate_xml)

    n_err = len(val_report.errors)
    n_warn = len(val_report.warnings)
    n_info = len(val_report.infos)
    print(f"Schema:           {schema_path.name}  "
          f"({len(schema)} element rules)")
    if references:
        print(f"References:       {len(references)} cross-reference rule(s), "
              f"{len(builtins)} built-in categor(ies)")
    print(f"Elements checked: {val_report.elements_checked}")
    print(f"Unknown elements: {val_report.elements_unknown}")
    print(f"Errors:           {n_err}")
    print(f"Warnings:         {n_warn}")
    print(f"Info notes:       {n_info}")

    # Save the report alongside the emit output
    report_dir = out_dir
    json_path = report_dir / 'validation_report.json'
    txt_path = report_dir / 'validation_report.txt'

    import json as _json
    from dataclasses import asdict
    json_path.write_text(_json.dumps({
        'candidate_path': val_report.candidate_path,
        'schema_path': val_report.schema_path,
        'elements_checked': val_report.elements_checked,
        'elements_unknown': val_report.elements_unknown,
        'errors': n_err,
        'warnings': n_warn,
        'infos': n_info,
        'issues': [asdict(i) for i in val_report.issues],
    }, indent=2), encoding='utf-8')
    txt_path.write_text(render_summary(val_report), encoding='utf-8')
    print(f"Report (JSON):    {json_path}")
    print(f"Report (text):    {txt_path}")

    # Show a few errors inline so the operator notices them
    if n_err:
        print()
        print(f"  First {min(5, n_err)} error(s):")
        for issue in val_report.errors[:5]:
            print(f"    [{issue.rule}] {issue.xpath}")
            print(f"      {issue.message}")
        if n_err > 5:
            print(f"    ... and {n_err - 5} more (see report)")

    # Decide whether to fail
    fail_on = val_sect.get('fail_on', 'never').strip().lower()
    if cli_strict:
        # CLI override: --strict-output means treat errors as fatal,
        # regardless of config setting.
        fail_on = 'error'

    if fail_on == 'never':
        # Explicit opt-out: no severity ever triggers a non-zero exit
        return 0

    # Severity ranks: smaller = worse. We fail when the actual worst
    # severity present is at-or-worse-than the configured threshold.
    severity_rank = {'error': 0, 'warning': 1, 'info': 2}
    threshold = severity_rank.get(fail_on)
    if threshold is None:
        # Unknown fail_on value — treat as 'never' to be safe
        return 0

    worst = None
    if n_err: worst = 0
    elif n_warn: worst = 1
    elif n_info: worst = 2

    if worst is not None and worst <= threshold:
        print()
        print(f"VERDICT: validation findings reached fail_on={fail_on} "
              f"threshold; emitter will exit non-zero")
        return 4

    return 0


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Phase 2 XML emitter: canonical JSON -> WatchGuard configuration.xml"
    )
    ap.add_argument("--config", default="xml_emit_config.ini")
    ap.add_argument("--strict", action="store_true",
                    help="Exit non-zero if engine config schema validation finds errors")
    ap.add_argument("--no-validate", action="store_true",
                    help="Skip engine config schema validation")
    ap.add_argument("--no-validate-output", action="store_true",
                    help="Skip post-emit XML validation against wg_xml_schema")
    ap.add_argument("--strict-output", action="store_true",
                    help="Treat post-emit XML validation errors as fatal "
                         "(overrides fail_on in [validation] section of config)")
    args = ap.parse_args()

    cfg_path = Path(args.config).resolve()
    if not cfg_path.is_file():
        print(f"ERROR: config not found: {cfg_path}", file=sys.stderr)
        return 2

    if not args.no_validate:
        report = validate_at_startup(cfg_path, engine_name="xml_emitter")
        if report is not None and not report.ok and args.strict:
            print("ERROR: --strict and schema validation failed; "
                  "aborting before emit.", file=sys.stderr)
            return 3

    em = XmlEmitter(cfg_path)
    print(f"Config:    {cfg_path}")
    print(f"In (Ph1.5):{em.enricher_dir}")
    print(f"In (Ph1):  {em.parser_dir}")
    print(f"Out:       {em.out_dir}")
    print(f"Rules:     {len(em.rules)}\n")

    em.emit_all()
    report = em.write()

    print("Rule results:")
    for r in report["rules"]:
        s = r["status"]
        result = r["result"]
        if result == "emitted":
            line = f"  [{s:<10}] {r['rule']:<32} emitted={r.get('count', 0):>4}"
            mg = r.get('merged_into_existing', 0)
            if mg:
                line += f"  merged={mg}"
            sk = r.get('skipped_by_pattern', 0)
            if sk:
                line += f"  skipped={sk}"
            print(line)
        elif result == "stubbed":
            print(f"  [{s:<10}] {r['rule']:<32} STUBBED ({r.get('todo_inputs', 0)} inputs await schema)")
        elif result == "advisory_written":
            print(f"  [{s:<10}] {r['rule']:<32} advisory_for={r.get('count', 0)}")
        elif result == "advisory_skipped":
            print(f"  [{s:<10}] {r['rule']:<32} (no entries)")
        else:
            print(f"  [{s:<10}] {r['rule']:<32} ERROR: {r.get('error', '?')}")

    print(f"\nXML:       {em.out_dir / 'configuration.xml'}")
    print(f"Notes:     {em.out_dir / 'migration_notes.md'}")
    print(f"Manifest:  {em.out_dir / '_emit_manifest.json'}")

    # Post-emit XML validation against wg_xml_schema. Returns 0 on
    # success or when validation is disabled; returns 4 only if errors
    # exceed the configured fail_on threshold.
    cp_for_validation = _read_ini(cfg_path)
    val_rc = _run_post_emit_validation(
        em.out_dir, cfg_path, cp_for_validation,
        cli_no_validate=args.no_validate_output,
        cli_strict=args.strict_output,
    )
    return val_rc


if __name__ == "__main__":
    sys.exit(main())
