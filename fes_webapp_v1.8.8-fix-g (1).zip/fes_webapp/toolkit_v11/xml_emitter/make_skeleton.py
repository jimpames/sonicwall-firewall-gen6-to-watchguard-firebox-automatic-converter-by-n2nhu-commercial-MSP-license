#!/usr/bin/env python3
"""
make_skeleton.py
==================

Take a real WatchGuard <profile> XML export and produce a reusable
skeleton: same structure, same device defaults, but with all
user-defined content emptied and all secrets redacted.

Run ONCE per Firebox model (TZ/T-series, M-series, XTM, etc.).
The output is a checked-in artifact in docs/skeletons/.

The Phase 2 emitter loads this skeleton as its starting tree, so its
output is a fully-formed Firebox-importable profile instead of a
fragment missing the device-default lists (proxy actions, alarm
actions, DLP sensors, signature update markers, etc.).

Algebraic-design model:
    Profile element × Scrub rule = Skeleton element
The scrub rules live in skeleton_config.ini. The engine knows nothing
about WatchGuard list names.

Run:
    python3 make_skeleton.py --config skeleton_config.ini
"""
from __future__ import annotations

import argparse
import configparser
import datetime as _dt
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

# Make schema_lib importable when running from this directory
_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))
from schema_lib import validate_at_startup  # noqa: E402


def _read_ini(path: Path) -> configparser.ConfigParser:
    cp = configparser.ConfigParser(
        interpolation=None,
        inline_comment_prefixes=(";",),
        comment_prefixes=("#",),
    )
    cp.read(path, encoding="utf-8")
    return cp


def _csv(s: str) -> list[str]:
    return [x.strip() for x in s.replace("\n", ",").split(",") if x.strip()]


class Scrubber:
    # Phase-2 sentinel format. wg_validator.py looks for this exact prefix
    # and refuses to validate any XML still containing it. The format also
    # makes operator search-and-replace trivial: search for the literal
    # __OPERATOR_REPLACE__ and you find every spot that needs attention.
    SENTINEL_PREFIX = "__OPERATOR_REPLACE__"

    def __init__(self, config_path: Path,
                 invariant_overrides: dict[str, str] | None = None):
        self.cp = _read_ini(config_path)
        io = self.cp["io"]
        self.input_path = (config_path.parent / io["input_export"]).resolve()
        self.output_path = (config_path.parent / io["output_skeleton"]).resolve()
        self.audit_path = (config_path.parent / io["output_audit"]).resolve()

        # CLI overrides for device invariants. Keys are tag names
        # (e.g., "for-version"), values are explicit replacement strings.
        # When provided, the named element gets the explicit value
        # instead of a sentinel. Element names not in the dict still
        # get sentinels — partial overrides are fine.
        self.invariant_overrides: dict[str, str] = invariant_overrides or {}

        # Mode 1 — Lists whose children get nuked entirely
        self.empty_tags: set[str] = set()
        for key, val in self.cp["empty_lists"].items():
            if key == "description":
                continue
            self.empty_tags.update(_csv(val))
        if "empty_lists_secondary" in self.cp:
            for key, val in self.cp["empty_lists_secondary"].items():
                if key == "description":
                    continue
                self.empty_tags.update(_csv(val))

        # Mode 2 — Additive lists: keep only entries whose <name> is in the
        # keep_names CSV; scrub the rest. {tag: set_of_keep_names}
        self.additive: dict[str, set[str]] = {}
        for sect_name in self.cp.sections():
            if not sect_name.startswith("additive_lists."):
                continue
            tag = sect_name.split(".", 1)[1]
            keep = set(_csv(self.cp[sect_name].get("keep_names", "")))
            if keep:
                self.additive[tag] = keep

        # Redaction rules: list of (xpath, replacement_text)
        self.redactions: list[tuple[str, str]] = []
        if "redact" in self.cp:
            redact = self.cp["redact"]
            seen_keys = set()
            for key in redact:
                if key in seen_keys or key == "description":
                    continue
                if key.endswith("_replacement"):
                    continue
                xpath = redact[key].strip()
                replacement = redact.get(f"{key}_replacement", "").strip()
                if xpath:
                    self.redactions.append((xpath, replacement))
                    seen_keys.add(key)

        # Device-identity xpaths to clear text on
        self.identity_xpaths: list[str] = []
        if "device_identity_redact" in self.cp:
            self.identity_xpaths = _csv(
                self.cp["device_identity_redact"].get("xpaths", "")
            )

        # Fix A — Device invariants: tags whose text gets replaced with a
        # sentinel (or with an explicit override from --for-version etc).
        self.device_invariants: list[str] = []
        if "preserve_lists" in self.cp:
            self.device_invariants = _csv(
                self.cp["preserve_lists"].get("device_invariants", "")
            )

        # Fix C-scaffolding — Preserve scaffolding configs.
        self.scaffolding_verbatim: list[str] = []
        self.scaffolding_fresh_stamp: list[str] = []
        if "preserve_scaffolding" in self.cp:
            ps = self.cp["preserve_scaffolding"]
            self.scaffolding_verbatim = _csv(
                ps.get("verbatim_from_reference", ""))
            self.scaffolding_fresh_stamp = _csv(
                ps.get("fresh_stamp", ""))

        # Tags marked verbatim must NOT be in empty_tags — that would be
        # contradictory. Defensive removal so config-author confusion
        # doesn't silently flatten what should be preserved.
        for tag in self.scaffolding_verbatim:
            if tag in self.empty_tags:
                self.empty_tags.discard(tag)
        for tag in self.scaffolding_fresh_stamp:
            if tag in self.empty_tags:
                self.empty_tags.discard(tag)

        # Output formatting
        out = self.cp["output"] if "output" in self.cp else {}
        self.xml_decl = out.get(
            "xml_declaration", '<?xml version="1.0" encoding="UTF-8"?>'
        ).strip()
        self.header_comment = out.get("header_comment", "").strip().replace("\n", " ")

        self.audit: dict = {
            "input": str(self.input_path),
            "scrubbed_at": _dt.datetime.now().isoformat(timespec="seconds"),
            "lists_emptied": [],
            "lists_filtered_additive": [],
            "elements_redacted": [],
            "device_identity_cleared": [],
            # Fix A audit
            "device_invariants_processed": [],
            # Fix C audit
            "scaffolding_preserved_verbatim": [],
            "scaffolding_fresh_stamped": [],
        }

    def run(self) -> None:
        if not self.input_path.is_file():
            raise FileNotFoundError(f"Input not found: {self.input_path}")

        tree = ET.parse(self.input_path)
        root = tree.getroot()

        # 1. Empty migration-replaceable lists
        for child in list(root):
            if child.tag in self.empty_tags:
                n = len(child)
                # Remove all sub-elements but keep the tag itself
                for sub in list(child):
                    child.remove(sub)
                child.text = None
                child.tail = "\n  "  # tidy
                if n > 0:
                    self.audit["lists_emptied"].append({
                        "tag": child.tag, "removed_children": n
                    })

        # 1b. Additive lists: keep only entries whose <name> child text is
        #     in the keep set; remove the rest.
        for child in list(root):
            if child.tag not in self.additive:
                continue
            keep = self.additive[child.tag]
            removed = 0
            kept = 0
            for entry in list(child):
                name_el = entry.find("name")
                entry_name = (name_el.text or "").strip() if name_el is not None else ""
                if entry_name in keep:
                    kept += 1
                else:
                    child.remove(entry)
                    removed += 1
            self.audit["lists_filtered_additive"].append({
                "tag": child.tag, "kept": kept, "removed": removed,
            })

        # 1.5 — Device invariants (Fix A, post-friend-review).
        # These elements carry device-specific values that MUST be replaced
        # per-target-Firebox. Default behavior: emit a sentinel string the
        # operator must search-and-replace before importing. If the operator
        # provided explicit values via CLI flags (--for-version etc.), use
        # those instead. The sentinel format matches what wg_validator looks
        # for so an un-replaced sentinel will fail validation loudly.
        invariants_seen: list[str] = []
        for child in list(root):
            if child.tag not in self.device_invariants:
                continue
            original_text = (child.text or "").strip()
            override = self.invariant_overrides.get(child.tag)
            if override is not None:
                new_text = override
                replacement_kind = "explicit_override"
            else:
                new_text = f"{self.SENTINEL_PREFIX}{child.tag}__"
                replacement_kind = "sentinel"
            child.text = new_text
            # Remove any sub-elements (these elements are scalar by contract)
            for sub in list(child):
                child.remove(sub)
            invariants_seen.append(child.tag)
            self.audit["device_invariants_processed"].append({
                "tag": child.tag,
                "original_value": original_text,
                "new_value": new_text,
                "kind": replacement_kind,
            })
        # Insert a guidance comment ABOVE the first invariant if any were
        # processed AND any of them carry a sentinel. The comment helps the
        # operator find the things they need to replace.
        if invariants_seen and any(
            entry["kind"] == "sentinel"
            for entry in self.audit["device_invariants_processed"]
        ):
            # Find the index of the first invariant child to insert before
            first_idx = None
            for i, child in enumerate(list(root)):
                if child.tag in invariants_seen:
                    first_idx = i
                    break
            if first_idx is not None:
                guidance = ET.Comment(
                    " ====================================================== "
                    "OPERATOR ACTION REQUIRED: any element below containing "
                    "__OPERATOR_REPLACE__<tag>__ must be replaced with "
                    "values from a 'Get Configuration' XML export of the "
                    "TARGET Firebox before import. Search this file for "
                    "OPERATOR_REPLACE to find every placeholder. "
                    "wg_validator will fail validation if any sentinel "
                    "remains. ====================================================== "
                )
                root.insert(first_idx, guidance)

        # 1.6 — Preserve scaffolding verbatim (Fix C-scaffolding).
        # These tags were defensively removed from empty_tags in __init__,
        # so they already pass through this method untouched. We just record
        # the audit entry so the operator can see what was preserved.
        for child in root:
            if child.tag in self.scaffolding_verbatim:
                # Count children for the audit
                child_count = sum(1 for _ in child.iter()) - 1  # minus self
                self.audit["scaffolding_preserved_verbatim"].append({
                    "tag": child.tag,
                    "children_preserved": child_count,
                })

        # 1.7 — Fresh-stamp scaffolding (Fix C-revision).
        # Clear contents and replace with a single toolkit-stamped entry.
        # Used for revision-history so the importer sees a valid revision
        # record. The entry carries:
        #   <module-id>n2nhu lab migration toolkit</module-id>
        #   <time>UNIX_TIMESTAMP</time>
        #   <comment>Skeleton generated by n2nhu lab migration toolkit</comment>
        now_ts = int(_dt.datetime.now().timestamp())
        for child in list(root):
            if child.tag not in self.scaffolding_fresh_stamp:
                continue
            n = len(child)
            for sub in list(child):
                child.remove(sub)
            child.text = None
            # Build the fresh entry. We emit <revision> for revision-history;
            # other fresh_stamp targets would need their own shape, but
            # revision-history is the only one configured today.
            if child.tag == "revision-history":
                rev = ET.SubElement(child, "revision")
                module = ET.SubElement(rev, "module-id")
                module.text = "n2nhu lab migration toolkit"
                t = ET.SubElement(rev, "time")
                t.text = str(now_ts)
                cmt = ET.SubElement(rev, "comment")
                cmt.text = (
                    "Skeleton generated by n2nhu lab migration toolkit. "
                    "Operator must verify device_invariants are replaced "
                    "before importing onto a Firebox."
                )
                self.audit["scaffolding_fresh_stamped"].append({
                    "tag": child.tag,
                    "cleared_children": n,
                    "stamped_time": now_ts,
                })

        # 2. Redact sensitive values matched by xpath
        for xpath, replacement in self.redactions:
            for el in root.findall(xpath):
                if el.text and el.text.strip():
                    self.audit["elements_redacted"].append({
                        "tag": el.tag, "xpath": xpath,
                        "before_chars": len(el.text),
                    })
                el.text = replacement if replacement else None

        # 3. Clear device-identifying text inside otherwise-preserved elements
        for xpath in self.identity_xpaths:
            for el in root.findall(xpath):
                if el.text and el.text.strip():
                    self.audit["device_identity_cleared"].append({
                        "tag": el.tag, "xpath": xpath,
                    })
                el.text = None

        # 4. Pretty-print
        try:
            ET.indent(root, space="  ")
        except AttributeError:
            pass

        # 5. Write output
        self.output_path.parent.mkdir(parents=True, exist_ok=True)
        body = ET.tostring(root, encoding="unicode")
        # Fix B (post-friend-review): Python's ElementTree renders empty
        # elements as "<tag />" with a space. The reference jpa.xml uses
        # "<tag/>" without a space, and operators doing visual diffs see
        # the space as noise. Normalize.
        body = re.sub(r'<([a-zA-Z][a-zA-Z0-9_-]*) />', r'<\1/>', body)
        with open(self.output_path, "w", encoding="utf-8") as f:
            f.write(self.xml_decl + "\n")
            if self.header_comment:
                f.write(f"<!-- {self.header_comment} -->\n")
                f.write(f"<!-- Generated: {self.audit['scrubbed_at']} -->\n")
            f.write(body)
            if not body.endswith("\n"):
                f.write("\n")

        # 6. Audit log
        self.audit_path.parent.mkdir(parents=True, exist_ok=True)
        self.audit["output"] = str(self.output_path)
        self.audit["bytes_in"] = self.input_path.stat().st_size
        self.audit["bytes_out"] = self.output_path.stat().st_size
        with open(self.audit_path, "w", encoding="utf-8") as f:
            json.dump(self.audit, f, indent=2)
            f.write("\n")


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Scrub a WatchGuard XML export into a reusable skeleton."
    )
    ap.add_argument("--config", default="skeleton_config.ini")
    ap.add_argument("--strict", action="store_true",
                    help="Exit non-zero if schema validation finds errors")
    ap.add_argument("--no-validate", action="store_true",
                    help="Skip schema validation entirely")

    # Fix A (post-friend-review): operator can inject explicit values for
    # the device invariants. When provided, the matching <element> in the
    # skeleton gets the explicit value instead of a __OPERATOR_REPLACE__
    # sentinel. Unprovided invariants still get sentinels — partial
    # override is fine.
    inv = ap.add_argument_group(
        "device invariants (override sentinel defaults)",
        "These values are device-specific; if known for the target Firebox, "
        "pass them here. Otherwise the skeleton emits __OPERATOR_REPLACE__ "
        "sentinels that the operator must replace before import.")
    inv.add_argument("--for-version", default=None,
                     help="Target Firebox firmware version, e.g. 12.10.2")
    inv.add_argument("--rs-version", default=None,
                     help="Firmware build integer (rs-version)")
    inv.add_argument("--product-grade", default=None,
                     help="Product grade (typically 2 for T-series)")
    inv.add_argument("--xml-purpose", default=None,
                     help="XML purpose (typically 2)")
    inv.add_argument("--using-cpm-profile", default=None,
                     help="0 unless cloud-managed (CPM)")
    inv.add_argument("--base-model", default=None,
                     help="Firebox base-model identifier (typically empty)")

    args = ap.parse_args()

    cfg_path = Path(args.config).resolve()
    if not cfg_path.is_file():
        print(f"ERROR: config not found: {cfg_path}", file=sys.stderr)
        return 2

    if not args.no_validate:
        report = validate_at_startup(cfg_path, engine_name="make_skeleton")
        if report is not None and not report.ok and args.strict:
            print("ERROR: --strict and schema validation failed; "
                  "aborting before scrub.", file=sys.stderr)
            return 3

    # Build invariant overrides from CLI flags
    overrides: dict[str, str] = {}
    if args.for_version is not None:
        overrides["for-version"] = args.for_version
    if args.rs_version is not None:
        overrides["rs-version"] = args.rs_version
    if args.product_grade is not None:
        overrides["product-grade"] = args.product_grade
    if args.xml_purpose is not None:
        overrides["xml-purpose"] = args.xml_purpose
    if args.using_cpm_profile is not None:
        overrides["using-cpm-profile"] = args.using_cpm_profile
    if args.base_model is not None:
        overrides["base-model"] = args.base_model

    s = Scrubber(cfg_path, invariant_overrides=overrides)
    print(f"Input:    {s.input_path}")
    print(f"Output:   {s.output_path}")
    print(f"Audit:    {s.audit_path}")
    print(f"Empty:    {len(s.empty_tags)} lists")
    print(f"Redact:   {len(s.redactions)} rules")
    print(f"Identity: {len(s.identity_xpaths)} xpaths")
    print(f"Invariants: {len(s.device_invariants)} elements "
          f"({len(overrides)} CLI overrides)")
    print(f"Scaffolding verbatim: {len(s.scaffolding_verbatim)} containers")
    print(f"Scaffolding fresh-stamped: {len(s.scaffolding_fresh_stamp)} containers")
    print()
    s.run()

    print(f"Lists emptied:  {len(s.audit['lists_emptied'])}")
    for item in s.audit["lists_emptied"]:
        print(f"  - {item['tag']:<35} removed {item['removed_children']:>4} children")
    print(f"Lists filtered (additive): {len(s.audit['lists_filtered_additive'])}")
    for item in s.audit["lists_filtered_additive"]:
        print(f"  - {item['tag']:<35} kept {item['kept']:>3}  removed {item['removed']:>4}")
    print(f"Values redacted: {len(s.audit['elements_redacted'])}")
    redacted_by_tag: dict = {}
    for r in s.audit["elements_redacted"]:
        redacted_by_tag[r["tag"]] = redacted_by_tag.get(r["tag"], 0) + 1
    for tag, n in sorted(redacted_by_tag.items()):
        print(f"  - {tag:<35} {n:>4} occurrences")
    print(f"Identity fields cleared: {len(s.audit['device_identity_cleared'])}")

    # Fix A summary
    if s.audit.get("device_invariants_processed"):
        print(f"Device invariants processed: "
              f"{len(s.audit['device_invariants_processed'])}")
        for item in s.audit["device_invariants_processed"]:
            kind = item["kind"]
            tag = item["tag"]
            val = item["new_value"]
            print(f"  - {tag:<35} [{kind}]  -> {val}")

    # Fix C summary
    if s.audit.get("scaffolding_preserved_verbatim"):
        print(f"Scaffolding preserved verbatim: "
              f"{len(s.audit['scaffolding_preserved_verbatim'])}")
        for item in s.audit["scaffolding_preserved_verbatim"]:
            print(f"  - {item['tag']:<35} "
                  f"({item['children_preserved']} inner elements kept)")
    if s.audit.get("scaffolding_fresh_stamped"):
        print(f"Scaffolding fresh-stamped: "
              f"{len(s.audit['scaffolding_fresh_stamped'])}")
        for item in s.audit["scaffolding_fresh_stamped"]:
            print(f"  - {item['tag']:<35} "
                  f"cleared {item['cleared_children']} children, stamped "
                  f"@ {item['stamped_time']}")

    print()
    print(f"Compression: {s.audit['bytes_in']:,} -> {s.audit['bytes_out']:,} bytes "
          f"({s.audit['bytes_out']*100/s.audit['bytes_in']:.0f}%)")

    # Warn loudly if any sentinels remain (i.e., not all overridden)
    sentinel_count = sum(
        1 for item in s.audit.get("device_invariants_processed", [])
        if item["kind"] == "sentinel"
    )
    if sentinel_count > 0:
        print()
        print(f"!!! {sentinel_count} __OPERATOR_REPLACE__ sentinel(s) remain in "
              f"the output. Replace before importing to a Firebox.", file=sys.stderr)
        print(f"!!! wg_validator will fail validation while sentinels remain.",
              file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
