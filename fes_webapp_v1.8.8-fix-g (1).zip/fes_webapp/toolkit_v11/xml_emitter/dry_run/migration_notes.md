# Migration Notes

Generated: 2026-06-04T05:48:14

### Filtered entries — emit.aliases

Category: **SonicWall IPv6 system aliases (no WG equivalent)**

47 entries from `address_groups.json` matched a skip_name_patterns regex and were not emitted to `/profile/alias-list`. These are typically SonicWall-only constructs with no WatchGuard equivalent.

| Skipped entry | Matched pattern |
|---|---|
| `LAN IPv6 Subnets` | `.* IPv6 Subnets$` |
| `LAN Interface IPv6 Addresses` | `.* IPv6 Addresses$` |
| `WAN IPv6 Subnets` | `.* IPv6 Subnets$` |
| `WAN Interface IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X0 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X1 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X2 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X3 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X4 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X5 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X6 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X7 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X8 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X9 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X10 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X11 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X12 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X13 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X14 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X15 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X16 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X17 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `MGMT IPv6 Addresses` | `.* IPv6 Addresses$` |
| `U0 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `U1 IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X0 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `Default Geo-IP and Botnet Exclusion Group` | `^Default Geo-IP and Botnet Exclusion Group$` |
| `X2 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X3 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X4 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X5 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X6 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X7 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X8 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X9 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X10 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X11 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X12 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X13 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X14 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X15 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X16 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X17 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `MGMT Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `U0 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `U1 Management IPv6 Addresses` | `.* IPv6 Addresses$` |
| `X1 Management IPv6 Addresses` | `.* IPv6 Addresses$` |

### Filtered entries — emit.service_groups

Category: **SonicWall ICMP/IGMP vendor-builtin service groups**

17 entries from `service_groups.json` matched a skip_name_patterns regex and were not emitted to `/profile/service-list`. These are typically SonicWall-only constructs with no WatchGuard equivalent.

| Skipped entry | Matched pattern |
|---|---|
| `ICMP` | `^(?:ICMP|Ping|ICMPv6|Ping6|IGMP)$` |
| `Ping` | `^(?:ICMP|Ping|ICMPv6|Ping6|IGMP)$` |
| `IGMP` | `^(?:ICMP|Ping|ICMPv6|Ping6|IGMP)$` |
| `ICMPv6` | `^(?:ICMP|Ping|ICMPv6|Ping6|IGMP)$` |
| `Neighbor Discovery` | `^Neighbor Discovery$` |
| `Ping6` | `^(?:ICMP|Ping|ICMPv6|Ping6|IGMP)$` |
| `Management Services` | `^Management Services$` |
| `Destination Unreachable Group` | `.*(?:Destination Unreachable|Redirect|Time Exceeded|Parameter Problem|Router Renumbering|ICMP Node Information).*\s+Group$` |
| `Redirect Group` | `.*(?:Destination Unreachable|Redirect|Time Exceeded|Parameter Problem|Router Renumbering|ICMP Node Information).*\s+Group$` |
| `Time Exceeded Group` | `.*(?:Destination Unreachable|Redirect|Time Exceeded|Parameter Problem|Router Renumbering|ICMP Node Information).*\s+Group$` |
| `Parameter Problem Group` | `.*(?:Destination Unreachable|Redirect|Time Exceeded|Parameter Problem|Router Renumbering|ICMP Node Information).*\s+Group$` |
| `Destination Unreachable (IPv6) Group` | `.*(?:Destination Unreachable|Redirect|Time Exceeded|Parameter Problem|Router Renumbering|ICMP Node Information).*\s+Group$` |
| `Time Exceeded (IPv6) Group` | `.*(?:Destination Unreachable|Redirect|Time Exceeded|Parameter Problem|Router Renumbering|ICMP Node Information).*\s+Group$` |
| `Parameter Problem (IPv6) Group` | `.*(?:Destination Unreachable|Redirect|Time Exceeded|Parameter Problem|Router Renumbering|ICMP Node Information).*\s+Group$` |
| `Router Renumbering (IPv6) Group` | `.*(?:Destination Unreachable|Redirect|Time Exceeded|Parameter Problem|Router Renumbering|ICMP Node Information).*\s+Group$` |
| `ICMP Node Information Query (IPv6) Group` | `.*(?:Destination Unreachable|Redirect|Time Exceeded|Parameter Problem|Router Renumbering|ICMP Node Information).*\s+Group$` |
| `ICMP Node Information Response (IPv6) Group` | `.*(?:Destination Unreachable|Redirect|Time Exceeded|Parameter Problem|Router Renumbering|ICMP Node Information).*\s+Group$` |

### Skipped entries (no resolvable name) — emit.interfaces

16 entries from `interfaces.json` could not be merged into the target schema because no name resolved (often: SonicWall interface with no IPv4 zone configured).

Skipped IDs: `X2`, `X3`, `X4`, `X5`, `X6`, `X7`, `X8`, `X9`, `X10`, `X11`, `X12`, `X13`, `X14`, `X15`, `X16`, `X17`

## gvc_migration_advisory

Migration advisory: SonicWall GVC clients cannot connect
to a Firebox. Generates migration_notes.md listing every
GVC user and recommending WG IKEv2 client adoption.

**Affected entries: 2**

- `WAN GroupVPN` (group-vpn)
    - deprecated  phase1.encryption = `triple-des` — 3DES sunset by NIST in 2023; vulnerable to Sweet32.
    - deprecated  phase1.authentication = `sha-1` — SHA-1 collision-broken (SHAttered, 2017).
    - deprecated  phase1.dh_group = `2` — DH Group 2 (1024-bit MODP) weakened by Logjam.
    - deprecated  phase2.encryption = `triple-des` — 3DES sunset by NIST in 2023; vulnerable to Sweet32.
    - deprecated  phase2.authentication = `sha-1` — SHA-1 collision-broken (SHAttered, 2017).
- `WLAN GroupVPN` (group-vpn)
    - deprecated  phase1.encryption = `triple-des` — 3DES sunset by NIST in 2023; vulnerable to Sweet32.
    - deprecated  phase1.authentication = `sha-1` — SHA-1 collision-broken (SHAttered, 2017).
    - deprecated  phase1.dh_group = `2` — DH Group 2 (1024-bit MODP) weakened by Logjam.
    - deprecated  phase2.encryption = `triple-des` — 3DES sunset by NIST in 2023; vulnerable to Sweet32.
    - deprecated  phase2.authentication = `sha-1` — SHA-1 collision-broken (SHAttered, 2017).

