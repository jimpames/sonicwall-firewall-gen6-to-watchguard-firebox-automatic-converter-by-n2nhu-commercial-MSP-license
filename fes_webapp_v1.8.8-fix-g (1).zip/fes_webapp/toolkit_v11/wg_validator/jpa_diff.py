#!/usr/bin/env python3
"""
jpa_diff.py — bidirectional structural diff between a candidate WG
configuration.xml and the jpa.xml reference.

Run this BEFORE pushing to a Firebox. It does what no per-rule validator
can do: walks every leaf and every parent in BOTH the candidate and the
reference, and reports every difference that has Firebox-rejection
potential.

Three diff layers, all bidirectional:

LAYER 1 — leaf value domains (forward + backward)
  Forward: for every (tag, parent-path), does jpa.xml have a closed
    value set that the candidate violates?
  Backward: are there candidate (tag, parent-path) pairs with values
    that jpa.xml NEVER shows? (potential schema violations)

LAYER 2 — child sequence (forward + backward)
  Forward: for every parent element type in jpa.xml, does the candidate
    use the same child ordering?
  Backward: does the candidate emit children that jpa.xml NEVER has at
    that path? (potential unknown elements)

LAYER 3 — required-and-missing
  Forward: which child tags does jpa.xml ALWAYS have at a path but the
    candidate is missing?
  Backward: which child tags does the candidate always have but jpa.xml
    never does? (likely SonicWall pass-through bugs)

USAGE
    python3 jpa_diff.py <candidate.xml> [--reference jpa.xml]

OUTPUT
    Text report grouped by severity. Lines marked [HARD] are nearly
    certain Firebox rejections. [SOFT] are suspicious but might be
    legitimate (e.g. customer-specific extensions).

This is the comparator the toolkit needs as its $1 oracle — it learns
from jpa.xml as ground truth, no hand-curation.
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict, Counter
from pathlib import Path
import xml.etree.ElementTree as ET


# ----------------------------------------------------------------------------
# Path utilities
# ----------------------------------------------------------------------------

def parent_path(elem: ET.Element, parent_map: dict) -> str:
    """Return the / -delimited path from root to elem's parent."""
    parts = []
    cur = parent_map.get(id(elem))
    while cur is not None:
        parts.append(cur.tag)
        cur = parent_map.get(id(cur))
    return '/' + '/'.join(reversed(parts))


def build_parent_map(root: ET.Element) -> dict:
    return {id(c): p for p in root.iter() for c in p}


# ----------------------------------------------------------------------------
# Layer 1 — leaf value domains
# ----------------------------------------------------------------------------

def profile_leaf_values(root: ET.Element) -> dict:
    """Build {(tag, parent_path): {'numeric': Counter, 'strings': Counter,
                                     'empty': int, 'total': int}}."""
    pm = build_parent_map(root)
    profile = defaultdict(lambda: {'numeric': Counter(),
                                    'strings': Counter(),
                                    'empty': 0, 'total': 0})
    for elem in root.iter():
        if list(elem):
            continue  # not a leaf
        ppath = parent_path(elem, pm)
        key = (elem.tag, ppath)
        profile[key]['total'] += 1
        text = (elem.text or '').strip()
        if not text:
            profile[key]['empty'] += 1
            continue
        try:
            n = int(text)
            profile[key]['numeric'][n] += 1
        except ValueError:
            profile[key]['strings'][text] += 1
    return profile


def diff_leaf_domains(jpa_profile: dict, our_profile: dict) -> list:
    """Return list of (severity, tag, path, msg) tuples.
    severity: 'HARD' likely Firebox rejection, 'SOFT' suspicious."""
    findings = []
    # Forward: for each (tag, path) jpa.xml shows, does the candidate
    # have values outside the reference set?
    for key, jpa_prof in jpa_profile.items():
        tag, ppath = key
        our_prof = our_profile.get(key)
        if our_prof is None:
            continue
        # Pure-numeric in jpa: candidate values out of range?
        jpa_nums = set(jpa_prof['numeric'].keys())
        our_nums = set(our_prof['numeric'].keys())
        if jpa_nums and not jpa_prof['strings']:
            # Treat as closed numeric set if jpa has dense sampling
            lo, hi = min(jpa_nums), max(jpa_nums)
            jpa_total = jpa_prof['total']
            distinct = len(jpa_nums)
            # Two confidence tests
            saturated = distinct == (hi - lo + 1)
            well_sampled = jpa_total >= 2 * (hi - lo + 1)
            if (saturated or well_sampled) and distinct >= 3:
                out_of_range = our_nums - jpa_nums
                if out_of_range:
                    findings.append((
                        'SOFT', tag, ppath,
                        f'numeric values {sorted(out_of_range)} not in '
                        f'jpa observed set {sorted(jpa_nums)} '
                        f'(range [{lo},{hi}], {jpa_total} samples).'
                    ))
            # Even without confidence: if jpa never showed a specific
            # value and the candidate has lots of it, flag it
            else:
                novel = our_nums - jpa_nums
                if novel:
                    findings.append((
                        'SOFT', tag, ppath,
                        f'numeric values {sorted(novel)} not seen in jpa '
                        f'(jpa range [{lo},{hi}], {jpa_total} samples). '
                        f'Sample may be too sparse; could be benign.'
                    ))
        # Pure-string in jpa: candidate strings not in jpa's set?
        jpa_strs = set(jpa_prof['strings'].keys())
        our_strs = set(our_prof['strings'].keys())
        if jpa_strs and not jpa_prof['numeric']:
            novel_strs = our_strs - jpa_strs
            if novel_strs and len(jpa_strs) <= 10 and jpa_prof['total'] >= 3:
                # Small closed-looking enum
                findings.append((
                    'SOFT', tag, ppath,
                    f'string values {sorted(list(novel_strs))[:5]} not in '
                    f'jpa observed set {sorted(jpa_strs)}.'
                ))
        # Mixed type in candidate but jpa is pure-numeric: HARD violation
        if jpa_nums and not jpa_prof['strings'] and our_prof['strings']:
            findings.append((
                'HARD', tag, ppath,
                f'jpa shows only numeric values, candidate has strings: '
                f'{sorted(list(our_prof["strings"].keys()))[:5]}'
            ))
    # Backward: candidate has (tag, path) jpa never shows at all
    for key, our_prof in our_profile.items():
        if key in jpa_profile:
            continue
        tag, ppath = key
        # Only worth reporting if it has actual content (not just an empty)
        if our_prof['numeric'] or our_prof['strings']:
            count = our_prof['total']
            findings.append((
                'SOFT', tag, ppath,
                f'tag+path appears {count}x in candidate but never in '
                f'jpa. Could be a SonicWall pass-through that WG doesn\'t '
                f'recognize.'
            ))
    return findings


# ----------------------------------------------------------------------------
# Layer 2 — child sequence ordering
# ----------------------------------------------------------------------------

def profile_child_sequences(root: ET.Element) -> dict:
    """For each (parent_tag, parent_path), collect observed child-sequences.
    Path-aware: the SAME tag at different paths can have different
    canonical orderings (proxy-action has different sub-structure than
    http inside proxy-action, etc). Returns {(tag, path): [seqs...]}."""
    pm = build_parent_map(root)
    profile = defaultdict(list)
    for elem in root.iter():
        children = [c.tag for c in elem]
        if not children:
            continue
        ppath = parent_path(elem, pm)
        # Key by (tag, parent_path) — distinguishes <log> at
        # /policy-list/policy/log vs /alarm-action-list/.../log etc.
        key = (elem.tag, ppath)
        profile[key].append(tuple(children))
    return profile


def merge_canonical_order(sequences: list) -> list:
    """Given many observed sequences from instances of the same parent,
    return a 'first-observed-wins' canonical order. Each child tag
    appears exactly once."""
    seen = set()
    canon = []
    for seq in sequences:
        for tag in seq:
            if tag not in seen:
                seen.add(tag)
                canon.append(tag)
    return canon


def diff_child_sequences(jpa_seqs: dict, our_seqs: dict) -> list:
    """Path-aware comparison with conflict tolerance.

    jpa.xml at a given (parent_tag, path) may have MANY different child
    orderings across its instances (xs:all elements, optional children).
    The Firebox accepts all of them. So we only flag a candidate
    ordering if it CONFLICTS with EVERY jpa instance's ordering — i.e.
    no jpa instance at that path orders things the way the candidate
    does. That means it's a genuine new pattern jpa doesn't have, which
    is the only confident HARD ordering violation.

    Approach: for each parent (tag, path), build the set of pairwise
    'A before B' constraints observed across ALL jpa instances. If
    EVERY jpa instance puts A before B, that's a hard constraint. Flag
    candidates that violate any hard constraint.
    """
    findings = []
    for key, jpa_seq_list in jpa_seqs.items():
        parent_tag, parent_path_str = key
        our_seq_list = our_seqs.get(key)
        if not our_seq_list:
            continue
        # Build all 'A before B' pairs observed in jpa, and all 'A after B'
        before = defaultdict(set)  # before[A] = set of B's such that A<B in some instance
        after = defaultdict(set)   # after[A] = set of B's such that A>B in some instance
        all_tags = set()
        for seq in jpa_seq_list:
            all_tags.update(seq)
            for i, a in enumerate(seq):
                for b in seq[i+1:]:
                    before[a].add(b)
                    after[a].add(b)  # b appears after a in this instance => after[b] adds a
                    # Actually let's track it correctly:
        # Rebuild after correctly
        after = defaultdict(set)
        for seq in jpa_seq_list:
            for i, a in enumerate(seq):
                for b in seq[i+1:]:
                    after[b].add(a)  # a is after b? no, a is BEFORE b => b is after a
        # Easier: hard constraint "A always before B" means
        #   B never appears before A in ANY jpa instance
        hard_before = {}  # hard_before[A] = set of B's that A is ALWAYS before
        for a in all_tags:
            for b in all_tags:
                if a == b:
                    continue
                # Check: in every jpa instance containing both, a comes before b
                always = True
                ever = False
                for seq in jpa_seq_list:
                    if a in seq and b in seq:
                        ever = True
                        if seq.index(a) > seq.index(b):
                            always = False
                            break
                if ever and always:
                    hard_before.setdefault(a, set()).add(b)

        # Check candidate instances for hard-constraint violations
        violations = []
        for our_seq in our_seq_list:
            for a, befores in hard_before.items():
                if a not in our_seq:
                    continue
                idx_a = our_seq.index(a)
                for b in befores:
                    if b in our_seq and our_seq.index(b) < idx_a:
                        violations.append((our_seq, a, b))
                        break
                if violations and violations[-1][0] == our_seq:
                    break
        if violations:
            sample = violations[0]
            findings.append((
                'HARD', parent_tag, parent_path_str,
                f'{len(violations)} instance(s) have <{sample[1]}> after '
                f'<{sample[2]}>, but jpa ALWAYS has <{sample[1]}> before '
                f'<{sample[2]}> at this path. Sample our sequence: '
                f'{list(sample[0])}'
            ))
        # Unknown children
        all_canon = all_tags
        for our_seq in our_seq_list:
            unknown = [t for t in our_seq if t not in all_canon]
            if unknown:
                findings.append((
                    'SOFT', parent_tag, parent_path_str,
                    f'instance has children jpa never has at this path '
                    f'under <{parent_tag}>: {sorted(set(unknown))}'
                ))
                break
    return findings


# ----------------------------------------------------------------------------
# Layer 3 — required and missing
# ----------------------------------------------------------------------------

def profile_required_children(root: ET.Element) -> dict:
    """Path-aware: return {(parent_tag, parent_path): (ratios, n_inst)}."""
    pm = build_parent_map(root)
    parent_instances = defaultdict(list)
    for elem in root.iter():
        if list(elem):
            ppath = parent_path(elem, pm)
            parent_instances[(elem.tag, ppath)].append({c.tag for c in elem})
    result = {}
    for key, instances in parent_instances.items():
        if not instances:
            continue
        all_children = set()
        for kids in instances:
            all_children |= kids
        ratios = {}
        for ctag in all_children:
            present = sum(1 for kids in instances if ctag in kids)
            ratios[ctag] = present / len(instances)
        result[key] = (ratios, len(instances))
    return result


# Empirically-verified exceptions: (parent_tag, parent_path) keys for
# which jpa-derived "always-present" requirements should be skipped
# when the candidate matches a known WG-valid alternative shape.
#
# Format: {(parent_tag, parent_path): predicate(our_kids) -> bool}
# Predicate returns True if the candidate's kids represent a known
# WG-valid alternative; the required-children check is then skipped.
JPA_DIFF_REQ_EXCEPTIONS = {
    # peer-auth in ike-policy: when FQDN-form (has <domain-name>),
    # <ip-addr> is NOT required. Provenance:
    # golden_pair/wg_reference.xml lines 2977-2981 show
    # <peer-auth><peer-auth-mask>4</peer-auth-mask>
    # <domain-name>...</domain-name></peer-auth> — NO <ip-addr>.
    # Lab T-30 12.5.9 loaded this shape correctly.
    ('peer-auth', '/profile/ike-policy-list/ike-policy'):
        lambda kids: 'domain-name' in kids,
}


def diff_required_children(jpa_req: dict, our_seqs: dict) -> list:
    """Path-aware: for each (parent_tag, path) in jpa, find children that
    ALWAYS appear (ratio == 1.0) and verify candidate has them at the
    same path."""
    findings = []
    for key, (ratios, n_jpa) in jpa_req.items():
        parent_tag, parent_path_str = key
        if n_jpa < 2:
            continue
        always = {c for c, r in ratios.items() if r == 1.0}
        if not always or key not in our_seqs:
            continue
        # Check empirically-verified exceptions
        exc = JPA_DIFF_REQ_EXCEPTIONS.get(key)
        for our_seq in our_seqs[key]:
            our_kids = set(our_seq)
            # Apply exception predicate if registered
            if exc is not None:
                try:
                    if exc(our_kids):
                        continue  # skip this instance
                except Exception:
                    pass
            missing = always - our_kids
            if missing:
                findings.append((
                    'HARD', parent_tag, parent_path_str,
                    f'instance is missing children that jpa ALWAYS '
                    f'shows: {sorted(missing)} (jpa: {n_jpa} instances, '
                    f'100% have these).'
                ))
                break
    return findings


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------

def run_diff(candidate_path: Path, reference_path: Path) -> int:
    try:
        jpa_root = ET.parse(reference_path).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: could not parse reference {reference_path}: {e}',
              file=sys.stderr)
        return 2
    try:
        our_root = ET.parse(candidate_path).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: could not parse candidate {candidate_path}: {e}',
              file=sys.stderr)
        return 2

    print(f'jpa_diff comparing:')
    print(f'  candidate:  {candidate_path}')
    print(f'  reference:  {reference_path}')
    print('=' * 72)

    # Layer 1
    jpa_leaf = profile_leaf_values(jpa_root)
    our_leaf = profile_leaf_values(our_root)
    l1_findings = diff_leaf_domains(jpa_leaf, our_leaf)

    # Layer 2
    jpa_seqs = profile_child_sequences(jpa_root)
    our_seqs = profile_child_sequences(our_root)
    l2_findings = diff_child_sequences(jpa_seqs, our_seqs)

    # Layer 3
    jpa_req = profile_required_children(jpa_root)
    l3_findings = diff_required_children(jpa_req, our_seqs)

    all_findings = (
        [('Layer 1: leaf value domain', f) for f in l1_findings]
        + [('Layer 2: child sequence ordering', f) for f in l2_findings]
        + [('Layer 3: required children missing', f) for f in l3_findings]
    )

    hard = [f for f in all_findings if f[1][0] == 'HARD']
    soft = [f for f in all_findings if f[1][0] == 'SOFT']

    print(f'\nHARD findings (likely Firebox rejection): {len(hard)}')
    print(f'SOFT findings (suspicious, may be benign): {len(soft)}')
    print()

    if hard:
        print('=' * 72)
        print('HARD findings:')
        print('=' * 72)
        for layer, (sev, tag, path, msg) in hard:
            print(f'\n  [{layer}]')
            print(f'  <{tag}> at {path}')
            print(f'  {msg}')

    if soft:
        print()
        print('=' * 72)
        print(f'SOFT findings (first 20 of {len(soft)}):')
        print('=' * 72)
        for layer, (sev, tag, path, msg) in soft[:20]:
            print(f'\n  [{layer}]')
            print(f'  <{tag}> at {path}')
            print(f'  {msg}')

    return 0 if not hard else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('candidate', type=Path,
                   help='candidate XML (the file being prepared for import)')
    p.add_argument('--reference', type=Path,
                   default=Path(__file__).parent.parent
                          / 'schema_learner' / 'corpus' / 'T30jpa1.xml',
                   help='jpa.xml reference (default: T30jpa1.xml)')
    args = p.parse_args()
    return run_diff(args.candidate, args.reference)


if __name__ == '__main__':
    sys.exit(main())
