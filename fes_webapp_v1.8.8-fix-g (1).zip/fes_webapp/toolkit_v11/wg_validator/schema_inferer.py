#!/usr/bin/env python3
"""
schema_inferer.py
==================

Bootstrap a wg_xml_schema.ini from one or more reference WatchGuard XML
exports. The output is a starting-point schema that the operator
hand-curates: adding value constraints, cross-reference declarations,
and tightening cardinalities based on domain knowledge.

What it learns automatically:

    * The set of element-tag names in use, with their xpath contexts
    * For each element type:
        - sub-element names that ever appear (the "allowed_fields" set)
        - sub-elements that ALWAYS appear (the "required_fields" set —
          conservative inference; can be relaxed in curation)
        - per-field cardinality (does it appear once or many times in
          the parent element?)
        - the set of distinct text values seen (small sets become
          enum candidates)
    * Container vs. record vs. leaf classification
    * Empty-allowed: whether the element ever appears empty

What the operator must add manually post-inference:

    * Cross-reference rules (which xpath holds a name that resolves
      to which other xpath's name)
    * Tightened value constraints (regex patterns for IP addresses,
      enum values from external knowledge, integer ranges)
    * Comments documenting what each element means
    * Removing required-fields that were always-present coincidentally

Usage:
    python3 schema_inferer.py \\
        --reference path/to/reference.xml [path/to/reference2.xml ...] \\
        --output wg_xml_schema.ini
"""
from __future__ import annotations

import argparse
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict, Counter
from dataclasses import dataclass, field
from pathlib import Path


# Heuristics for kind-detection
ENUM_VALUE_LIMIT = 12       # if <= N distinct text values, treat as enum candidate
ENUM_TEXT_MAX_LEN = 30      # short-string tells us it's likely an enum, not free text
REQUIRED_FIELDS_MIN_SAMPLE = 5
                            # Don't infer required_fields from < N instances —
                            # a field that's "always present" with only 1-2
                            # instances is more likely coincidence than rule.
ENUM_MIN_DISTINCT_RATIO = 0.6
                            # If distinct values / total observations is BELOW
                            # this, the field looks like a true enum (lots of
                            # repetition). Above this, it's free-text.

# Free-text patterns: when leaf values match these, don't enumerate them.
import re as _re
_IP4_RE = _re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(/\d{1,2})?$')
_IP6_RE = _re.compile(r'^[0-9a-fA-F:]+(/\d{1,3})?$')
_UUID_RE = _re.compile(r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-'
                       r'[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$')
_HOSTNAME_RE = _re.compile(r'^[a-zA-Z][a-zA-Z0-9._-]*\.[a-zA-Z]{2,}$')


def looks_like_freetext(values: list[str]) -> bool:
    """Return True if these values look like free-text / addresses / IDs that
    shouldn't be enumerated even if there are few of them."""
    if not values:
        return False
    # If ANY value matches an IP/UUID/hostname pattern, treat as free-text
    for v in values:
        if (_IP4_RE.match(v) or _IP6_RE.match(v) or _UUID_RE.match(v)
                or _HOSTNAME_RE.match(v)):
            return True
    # If average value length > 16 chars, probably free-text
    if values and sum(len(v) for v in values) / len(values) > 16:
        return True
    return False


@dataclass
class ElementProfile:
    """What we learned about one element type."""
    tag: str
    occurrence_count: int = 0
    # Per-instance: what fields appeared in that instance
    field_occurrences: list[set[str]] = field(default_factory=list)
    # All values ever seen as text content (for enum inference)
    text_values: Counter = field(default_factory=Counter)
    # If element has children, we DON'T track text values — it's a container
    has_children_count: int = 0
    has_text_count: int = 0
    is_empty_count: int = 0
    # Per-field cardinality within instances
    field_cardinality: dict[str, Counter] = field(default_factory=lambda: defaultdict(Counter))
    # If this element appears as a list item under a parent, track that
    parent_tags: Counter = field(default_factory=Counter)


def profile_xml(root: ET.Element) -> dict[str, ElementProfile]:
    """Walk the XML, collecting one ElementProfile per distinct tag."""
    profiles: dict[str, ElementProfile] = defaultdict(lambda: ElementProfile(tag=''))

    # Build parent map for parent-tracking
    parent_map = {c: p for p in root.iter() for c in p}

    for elem in root.iter():
        tag = elem.tag
        prof = profiles[tag]
        prof.tag = tag
        prof.occurrence_count += 1

        # Parent tracking
        parent = parent_map.get(elem)
        if parent is not None:
            prof.parent_tags[parent.tag] += 1

        # What fields did THIS instance have?
        children = list(elem)
        if children:
            prof.has_children_count += 1
            instance_fields = set()
            instance_field_count = Counter()
            for c in children:
                instance_fields.add(c.tag)
                instance_field_count[c.tag] += 1
            prof.field_occurrences.append(instance_fields)
            for fname, fcount in instance_field_count.items():
                prof.field_cardinality[fname][fcount] += 1
        else:
            text = (elem.text or '').strip()
            if text:
                prof.has_text_count += 1
                # Only track values that look enum-able
                if len(text) <= ENUM_TEXT_MAX_LEN:
                    prof.text_values[text] += 1
            else:
                prof.is_empty_count += 1
            prof.field_occurrences.append(set())  # empty field-set

    return profiles


def classify_kind(prof: ElementProfile) -> str:
    """Decide if element is leaf / container / record / ambiguous.

    When an element is observed with BOTH leaf shape (text only) AND
    container/record shape (with children), we return 'ambiguous' so
    the validator allows either form. The operator can later split
    such tags into context-keyed rules (parent-tag prefix) for stricter
    validation.
    """
    if prof.has_children_count == 0:
        return 'leaf'

    # Mixed shapes: element seen as both leaf and container/record
    if prof.has_text_count > 0 and prof.has_children_count > 0:
        return 'ambiguous'

    # Pure container / record path
    if not prof.field_occurrences:
        return 'leaf'
    all_fields: set[str] = set()
    for fset in prof.field_occurrences:
        all_fields.update(fset)
    if not all_fields:
        return 'leaf'
    if len(all_fields) == 1:
        return 'container'
    return 'record'


def required_fields(prof: ElementProfile) -> list[str]:
    """A field is 'required' if it appears in EVERY non-empty instance.

    Conservative inference, made even more conservative by requiring a
    minimum sample size. With fewer than REQUIRED_FIELDS_MIN_SAMPLE
    instances, we can't tell rule from coincidence — so we don't infer
    any required fields at all. The operator can hand-curate when they
    have domain knowledge to assert it.
    """
    instances = [s for s in prof.field_occurrences if s]
    if len(instances) < REQUIRED_FIELDS_MIN_SAMPLE:
        return []
    common = set(instances[0])
    for s in instances[1:]:
        common &= s
    return sorted(common)


def allowed_fields(prof: ElementProfile) -> list[str]:
    """Union of all fields ever seen in any instance."""
    all_fields: set[str] = set()
    for s in prof.field_occurrences:
        all_fields.update(s)
    return sorted(all_fields)


def field_appears_many(prof: ElementProfile, fname: str) -> bool:
    """Does fname appear MORE than once in any single instance?"""
    counts = prof.field_cardinality.get(fname, Counter())
    return any(c > 1 for c in counts.keys())


def enum_values(prof: ElementProfile) -> list[str] | None:
    """If this element has a small set of short text values that look like
    a real enum (not free-text or IDs), return them.

    Suppresses enumeration when:
        * Values look like IPs / UUIDs / hostnames
        * Distinct/total ratio is too high (looks like free-text)
        * Cardinality exceeds ENUM_VALUE_LIMIT
    """
    if prof.has_children_count > 0:
        return None
    if not prof.text_values:
        return None
    distinct = list(prof.text_values.keys())
    if len(distinct) > ENUM_VALUE_LIMIT:
        return None
    if looks_like_freetext(distinct):
        return None
    # Distinct/total ratio: enums repeat heavily, free-text doesn't
    total = sum(prof.text_values.values())
    if total > 0 and len(distinct) / total > ENUM_MIN_DISTINCT_RATIO:
        # Too unique-looking; might be free-text
        return None
    return sorted(distinct)


def write_schema_ini(profiles: dict[str, ElementProfile],
                     output: Path,
                     reference_paths: list[Path]) -> None:
    """Render a wg_xml_schema.ini from learned profiles."""
    lines: list[str] = []
    lines.append("# " + "=" * 76)
    lines.append("# wg_xml_schema.ini")
    lines.append("#")
    lines.append("# Schema for the WatchGuard XML configuration profile.")
    lines.append("# Auto-bootstrapped from reference exports; hand-curated for")
    lines.append("# value constraints, cross-references, and cardinality refinements.")
    lines.append("#")
    lines.append(f"# Bootstrapped from: {', '.join(p.name for p in reference_paths)}")
    lines.append("# " + "=" * 76)
    lines.append("")
    lines.append("[meta]")
    lines.append("name        = wg_xml_schema")
    lines.append("version     = 1.0.0")
    lines.append("description = WatchGuard XML element-shape rules.")
    lines.append("              Each [element.X] section declares the validation")
    lines.append("              rules for one element type (any element with tag X).")
    lines.append("")

    # Sort: profile first (root), then alphabetical
    sorted_tags = sorted(profiles.keys(),
                         key=lambda t: (0 if t == 'profile' else 1, t))

    for tag in sorted_tags:
        prof = profiles[tag]
        kind = classify_kind(prof)
        section_id = tag

        lines.append("# " + "-" * 76)
        if prof.parent_tags:
            top_parents = ', '.join(t for t, _ in prof.parent_tags.most_common(3))
            lines.append(f"# {tag}  (occurs in: {top_parents})")
        else:
            lines.append(f"# {tag}")
        lines.append("# " + "-" * 76)
        lines.append(f"[element.{section_id}]")
        lines.append(f"kind        = {kind}")

        # Cardinality stats — useful documentation
        lines.append(f"# learned: {prof.occurrence_count} instance(s) in reference")

        if kind == 'container':
            # The single child-tag type
            sample_field = allowed_fields(prof)
            if sample_field:
                lines.append(f"item_element = {sample_field[0]}")
            empty_seen = prof.is_empty_count > 0
            lines.append(f"allow_empty  = {'true' if empty_seen else 'false'}")
        elif kind == 'record':
            req = required_fields(prof)
            allowed = allowed_fields(prof)
            if req:
                lines.append(f"required_fields = {', '.join(req)}")
            if allowed:
                lines.append(f"allowed_fields  = {', '.join(allowed)}")
            # Multi-occurrence fields
            many = [f for f in allowed if field_appears_many(prof, f)]
            if many:
                lines.append(f"repeating_fields = {', '.join(many)}")
        elif kind == 'leaf':
            ev = enum_values(prof)
            if ev:
                # If all values look like integers, mark as int with allowed_values
                if all(v.isdigit() or (v.startswith('-') and v[1:].isdigit())
                       for v in ev if v):
                    lines.append(f"value_type      = int")
                else:
                    lines.append(f"value_type      = string")
                lines.append(f"allowed_values  = {', '.join(ev)}")
            else:
                # Free-text
                lines.append(f"value_type      = string")
            empty_seen = prof.is_empty_count > 0
            lines.append(f"allow_empty     = {'true' if empty_seen else 'false'}")

        lines.append("")

    output.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Bootstrap wg_xml_schema.ini from reference WG XML exports."
    )
    ap.add_argument("--reference", nargs="+", required=True,
                    help="One or more reference WG XML files")
    ap.add_argument("--output", required=True,
                    help="Output schema INI file path")
    args = ap.parse_args()

    refs = [Path(p) for p in args.reference]
    for r in refs:
        if not r.is_file():
            print(f"ERROR: reference not found: {r}", file=sys.stderr)
            return 2

    # Aggregate profiles across all references
    aggregated: dict[str, ElementProfile] = {}
    for r in refs:
        root = ET.parse(r).getroot()
        local = profile_xml(root)
        if not aggregated:
            aggregated = local
        else:
            for tag, prof in local.items():
                if tag not in aggregated:
                    aggregated[tag] = prof
                else:
                    a = aggregated[tag]
                    a.occurrence_count += prof.occurrence_count
                    a.field_occurrences.extend(prof.field_occurrences)
                    a.text_values.update(prof.text_values)
                    a.has_children_count += prof.has_children_count
                    a.has_text_count += prof.has_text_count
                    a.is_empty_count += prof.is_empty_count
                    a.parent_tags.update(prof.parent_tags)
                    for fname, ccounter in prof.field_cardinality.items():
                        a.field_cardinality[fname].update(ccounter)

    out = Path(args.output)
    write_schema_ini(aggregated, out, refs)
    print(f"Wrote {out}")
    print(f"  {len(aggregated)} element types profiled")
    return 0


if __name__ == "__main__":
    sys.exit(main())
