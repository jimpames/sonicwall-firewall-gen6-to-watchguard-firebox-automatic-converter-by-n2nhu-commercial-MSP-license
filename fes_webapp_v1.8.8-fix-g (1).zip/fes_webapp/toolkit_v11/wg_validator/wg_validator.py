#!/usr/bin/env python3
"""
wg_validator.py
================

Standalone WatchGuard XML schema validator. Reads a wg_xml_schema.ini
(the WG element-shape rules) and validates a candidate XML file against
those rules. Produces a categorized report (errors / warnings / info)
and exits with a code reflecting the worst severity found.

This engine does NOT need a real Firebox device. It validates by
applying schema rules learned from reference exports plus hand-curated
constraints. Useful as:

    * A CI gate for the migration toolkit (emit then validate)
    * A standalone import-pre-check tool
    * A sanity check when hand-editing WG XML

Validation phases:

    1. element-type    every element's tag is recognized in the schema
    2. kind-shape      element's structure matches its declared kind
                       (leaf=text only; container=homogeneous children;
                       record=heterogeneous children)
    3. required-fields every required_field is present in record kind
    4. allowed-fields  no extra fields beyond allowed_fields
    5. value-domain    leaf text matches value_type / allowed_values
    6. empty-allowed   leaf text presence matches allow_empty

Exit codes:
    0 = clean (no errors, no warnings)
    1 = warnings only
    2 = errors found

Usage:
    python3 wg_validator.py \\
        --config wg_validator_config.ini \\
        --candidate path/to/configuration.xml
"""
from __future__ import annotations

import argparse
import configparser
import json
import re
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

# Make schema_lib importable
_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))
from schema_lib import validate_at_startup  # noqa: E402


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------
@dataclass
class ElementRule:
    """Validation rules for one element type, as declared in wg_xml_schema.ini.

    All fields are optional except `kind` and `tag`. An unset list means
    'no constraint declared'; the validator treats this as 'allow anything'.
    """
    tag: str
    kind: str                          # leaf | container | record
    # For container kind:
    item_element: str = ''
    # For record kind:
    required_fields: list[str] = field(default_factory=list)
    allowed_fields: list[str] = field(default_factory=list)
    repeating_fields: list[str] = field(default_factory=list)
    # For leaf kind:
    value_type: str = 'string'         # string | int
    allowed_values: list[str] = field(default_factory=list)
    value_pattern: str = ''
    allow_empty: bool = True


@dataclass
class ReferenceRule:
    """One cross-reference rule from wg_xml_references.ini."""
    name: str
    from_xpath: str
    to_xpath: str
    to_field: str
    allow_empty: bool = True
    allow_builtin: str = ''     # name of [builtin.X] section
    severity: str = 'warning'   # error | warning | info
    description: str = ''


@dataclass
class BuiltinNames:
    """One [builtin.X] block from wg_xml_references.ini."""
    name: str
    names: set[str]
    description: str = ''


@dataclass
class Issue:
    severity: str            # error | warning | info
    rule: str                # which schema rule triggered this
    xpath: str               # xpath to the element with the issue
    element_tag: str         # tag of the element
    field_name: str = ''     # field within the element (if applicable)
    expected: str = ''
    actual: str = ''
    message: str = ''


@dataclass
class ValidationReport:
    candidate_path: str
    schema_path: str
    issues: list[Issue] = field(default_factory=list)
    elements_checked: int = 0
    elements_unknown: int = 0

    @property
    def errors(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == 'error']

    @property
    def warnings(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == 'warning']

    @property
    def infos(self) -> list[Issue]:
        return [i for i in self.issues if i.severity == 'info']

    @property
    def ok(self) -> bool:
        return not self.errors

    def exit_code(self) -> int:
        if self.errors:
            return 2
        if self.warnings:
            return 1
        return 0


# ---------------------------------------------------------------------------
# Schema loading
# ---------------------------------------------------------------------------
def _csv(s: str) -> list[str]:
    """Comma-separated parser, trims whitespace, drops empties."""
    if not s.strip():
        return []
    return [t.strip() for t in s.split(',') if t.strip()]


def _bool(s: str) -> bool:
    return s.strip().lower() in ('true', 'yes', '1', 'on')


def load_wg_schema(schema_path: Path) -> dict[str, ElementRule]:
    """Read wg_xml_schema.ini and return tag → ElementRule mapping."""
    cp = configparser.ConfigParser(
        interpolation=None,
        inline_comment_prefixes=(';',),
        comment_prefixes=('#',),
    )
    cp.optionxform = str
    cp.read(schema_path, encoding='utf-8')

    rules: dict[str, ElementRule] = {}
    for sect_name in cp.sections():
        if not sect_name.startswith('element.'):
            continue
        tag = sect_name[len('element.'):]
        sect = cp[sect_name]
        rules[tag] = ElementRule(
            tag=tag,
            kind=sect.get('kind', 'record').strip(),
            item_element=sect.get('item_element', '').strip(),
            required_fields=_csv(sect.get('required_fields', '')),
            allowed_fields=_csv(sect.get('allowed_fields', '')),
            repeating_fields=_csv(sect.get('repeating_fields', '')),
            value_type=sect.get('value_type', 'string').strip(),
            allowed_values=_csv(sect.get('allowed_values', '')),
            value_pattern=sect.get('value_pattern', '').strip(),
            allow_empty=_bool(sect.get('allow_empty', 'true')),
        )
    return rules


def load_wg_references(references_path: Path
                       ) -> tuple[list[ReferenceRule], dict[str, BuiltinNames]]:
    """Read wg_xml_references.ini and return ([rules], {builtin_name: BuiltinNames}).

    Returns ([], {}) if the file is missing — validator handles that case
    by skipping the cross-reference phase.
    """
    if not references_path.is_file():
        return [], {}

    cp = configparser.ConfigParser(
        interpolation=None,
        inline_comment_prefixes=(';',),
        comment_prefixes=('#',),
    )
    cp.optionxform = str
    cp.read(references_path, encoding='utf-8')

    rules: list[ReferenceRule] = []
    builtins: dict[str, BuiltinNames] = {}

    for sect_name in cp.sections():
        sect = cp[sect_name]
        if sect_name.startswith('reference.'):
            rule_id = sect_name[len('reference.'):]
            rules.append(ReferenceRule(
                name=rule_id,
                from_xpath=sect.get('from_xpath', '').strip(),
                to_xpath=sect.get('to_xpath', '').strip(),
                to_field=sect.get('to_field', 'name').strip(),
                allow_empty=_bool(sect.get('allow_empty', 'true')),
                allow_builtin=sect.get('allow_builtin', '').strip(),
                severity=sect.get('severity', 'warning').strip(),
                description=sect.get('description', '').strip(),
            ))
        elif sect_name.startswith('builtin.'):
            cat = sect_name[len('builtin.'):]
            names_csv = sect.get('names', '')
            names = set(_csv(names_csv))
            builtins[cat] = BuiltinNames(
                name=cat,
                names=names,
                description=sect.get('description', '').strip(),
            )

    return rules, builtins


# ---------------------------------------------------------------------------
# Validator engine
# ---------------------------------------------------------------------------
class WgValidator:
    """Walks a candidate XML tree, applying schema rules to each element."""

    def __init__(self, schema: dict[str, ElementRule],
                 schema_path: Path,
                 unknown_element_severity: str = 'warning',
                 references: list[ReferenceRule] | None = None,
                 builtins: dict[str, BuiltinNames] | None = None,
                 reference_xml_path: Path | None = None):
        self.schema = schema
        self.schema_path = schema_path
        self.unknown_element_severity = unknown_element_severity
        self.references = references or []
        self.builtins = builtins or {}
        # Phase 9 — bidirectional structural diff. When a reference jpa.xml
        # is loaded, the validator can compare our output's child-tag
        # ORDERING against canonical orderings observed in the reference.
        # This catches the forward-diff class of bug ("output has X at
        # position N, but jpa.xml has Y there").
        self.reference_root: ET.Element | None = None
        self.reference_xml_path: Path | None = reference_xml_path
        if reference_xml_path is not None and reference_xml_path.is_file():
            try:
                self.reference_root = ET.parse(reference_xml_path).getroot()
            except ET.ParseError:
                pass

    # Phase 8 Fix D — operator sentinels left from make_skeleton.py.
    # When the operator runs make_skeleton without --for-version etc., the
    # skeleton carries __OPERATOR_REPLACE__<tagname>__ placeholders that
    # MUST be replaced before importing onto a Firebox. The validator's
    # job is to refuse to bless any XML still carrying these sentinels.
    SENTINEL_PREFIX = "__OPERATOR_REPLACE__"

    def validate(self, candidate_path: Path) -> ValidationReport:
        report = ValidationReport(
            candidate_path=str(candidate_path),
            schema_path=str(self.schema_path),
        )

        # Fix D — check for unreplaced operator sentinels FIRST, before any
        # other validation. This catches the common error of running
        # make_skeleton.py without the CLI flags and forgetting to do
        # search-and-replace before import. The check is line-based and
        # works even on XML that wouldn't parse cleanly otherwise.
        try:
            raw_text = candidate_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as e:
            report.issues.append(Issue(
                severity='error', rule='sentinel-scan',
                xpath='/', element_tag='',
                message=f'Could not read candidate for sentinel scan: {e}',
            ))
            return report
        sentinel_findings: list[tuple[int, str]] = []
        for lineno, line in enumerate(raw_text.splitlines(), start=1):
            if self.SENTINEL_PREFIX in line:
                # Extract the specific tag(s) on this line for the message
                import re as _re_inline
                for m in _re_inline.finditer(
                    rf'{_re_inline.escape(self.SENTINEL_PREFIX)}'
                    r'([A-Za-z0-9_-]+)__', line
                ):
                    sentinel_findings.append((lineno, m.group(1)))
        if sentinel_findings:
            for lineno, tagname in sentinel_findings:
                report.issues.append(Issue(
                    severity='error', rule='operator-sentinel',
                    xpath=f'(line {lineno})', element_tag=tagname,
                    message=(
                        f'Operator sentinel {self.SENTINEL_PREFIX}{tagname}__ '
                        f'still present on line {lineno}. Replace with the '
                        f'value from a Get-Configuration export of the '
                        f'target Firebox before importing.'
                    ),
                ))
            # Sentinels are a hard stop — don't continue validation. The
            # operator needs to fix this first; downstream checks would
            # add noise.
            return report

        try:
            tree = ET.parse(candidate_path)
        except ET.ParseError as e:
            report.issues.append(Issue(
                severity='error', rule='xml-parse',
                xpath='/', element_tag='',
                message=f'XML parse failed: {e}',
            ))
            return report

        root = tree.getroot()
        # Phase: element-by-element walk (kinds, fields, values)
        self._walk(root, '/' + root.tag, report)
        # Phase: cross-references — name resolution
        if self.references:
            self._check_cross_references(root, report)
        # Phase 9 — polymorphic <type> discriminator check.
        # WatchGuard uses <type> as a polymorphic discriminator on a set
        # of element types (member, alias-member, abs-policy, ipsec-proposal,
        # nat, schedule, ...). These elements MUST have <type> as their
        # first child, BEFORE any payload children. Catches the class of
        # bug that hit the toolkit on lab T-30 imports during Phase 9.
        self._check_polymorphic_discriminators(root, report)
        # Phase 9 — path-aware value-type check. Catches non-numeric
        # values in contexts where the schema requires numeric (e.g.
        # <protocol>IPCOMP</protocol> in /service-item/member/).
        self._check_path_aware_value_types(root, report)
        # Phase 9 — path-aware allowed-values enum check. Catches
        # enumeration-facet violations. Verified against lab T-30
        # 12.5.9 line 4036:
        #   "Element 'to-min': [facet 'enumeration'] The value '1' is
        #    not an element of the set {'-1', '0', '15', '30', '45'}."
        self._check_path_aware_allowed_values(root, report)
        # Phase 9 — structural-kind check. Catches the class of bug
        # where structured-content (children) appears in a simpleType
        # context, or text-only appears in a complexType context.
        # Verified against lab T-30 12.5.9 line 3369:
        #   "Element 'local-addr': Element content is not allowed,
        #    because the type definition is simple."
        self._check_structural_kind(root, report)
        # Detect "validating reference against itself" — used to skip
        # rules that flag legitimate variations within the reference
        # (which is by definition ground truth).
        is_reference_self_validation = False
        if self.reference_xml_path is not None:
            try:
                is_reference_self_validation = (
                    Path(candidate_path).resolve()
                    == self.reference_xml_path.resolve()
                )
            except (OSError, ValueError):
                pass
        # Phase 9 — required-elements-by-path. Catches missing children
        # that runtime XSD requires even when jpa.xml stubs don't show
        # them. Verified against lab T-30 12.5.9 line 3375:
        #   "Element 'description': not expected. Expected ( use-vif )."
        self._check_required_elements_by_path(
            root, report,
            is_reference_self_validation=is_reference_self_validation
        )
        # Phase 9 — mutex-children check. Catches the class of bug where
        # our output writes BOTH of two mutually-exclusive xs:choice
        # children. Verified against lab T-30 12.5.9 line 3368:
        #   "Element 'ike-policy-group': not expected. Expected one of
        #    ( pfs, dh-group, ipsec-proposal, version, enabled, use-vif )."
        # which fires because <ike-policy> already preceded it and the
        # XSD state machine doesn't allow the alternative discriminator.
        self._check_mutex_children(root, report)
        # Phase 9 — required-one-of-children check. Catches the class of
        # bug where a complex element exists but contains only optional
        # children, missing the required xs:choice payload. Verified
        # against lab T-30 12.5.9 line 3619:
        #   "Element 'local-cert': Missing child element(s).
        #    Expected is one of ( rsa-cert, dsa-cert, ...)"
        self._check_required_one_of_children(root, report)
        # Phase 9 — automatic reference-value-domain learning + check.
        # The "real comparator" — learns observed numeric domains from
        # jpa.xml at validate time and flags candidate values outside.
        # Catches the class of bug where source-format values pass
        # through without translation (e.g. SonicWall day-of-week 1-7
        # vs WG 0-6). Verified against lab T-30 12.5.9:
        #   "The element 'day-of-week' has a value of '7' which is
        #    greater than the maximum value allowed of '6'."
        # Skip when validating the reference itself (it IS the domain).
        if self.reference_root is not None and not is_reference_self_validation:
            self._check_reference_value_domains(root, report)
        # Phase 9 — uniqueness constraint check. WatchGuard's XSD declares
        # key-identity constraints on certain lists (Service-Name on
        # service-list, Alias-Name on alias-list, etc.). Duplicates cause
        # 400 errors at import. Catches the class of bug that hit
        # lab T-30 12.5.9 with:
        #   "Element 'service': Duplicate key-sequence ['Terminal Services']
        #    in key identity-constraint 'Service-Name'."
        self._check_name_uniqueness(root, report)
        # Phase 9 — bidirectional structural diff against jpa.xml reference.
        # The forward-diff direction: for every named element type also
        # present in jpa.xml, compare the child-tag ordering of our
        # output against the reference's canonical orderings. WG's XSD
        # uses xs:sequence — child ORDER is part of the schema, not
        # just child presence. The Firebox rejects out-of-order children
        # with messages like:
        #   "Element 'property': not expected. Expected ( version,
        #    enabled, use-vif )."
        # which means "given the children you've shown me so far, I
        # was about to see one of these, but got <property> instead."
        # Catches the class of bug that hit lab T-30 12.5.9 line 3360.
        # Skip when validating the reference against itself.
        if self.reference_root is not None and not is_reference_self_validation:
            self._check_child_ordering_vs_reference(root, report)
        return report

    # Phase 9 — XSD key-identity constraints inferred from jpa.xml + Firebox
    # error messages. Each entry: (parent_list_tag, child_element_tag,
    # name_subpath, constraint_name).
    #
    # WatchGuard XSD declares uniqueness on names within list-containers.
    # The Firebox importer rejects duplicates with messages like:
    #   "Element 'service': Duplicate key-sequence ['X'] in key
    #    identity-constraint 'Service-Name'."
    #
    # Catching duplicates LOCALLY is much cheaper than catching them
    # at Firebox import time — that's the $1/$100 principle.
    UNIQUENESS_CONSTRAINTS = [
        # (list_xpath, child_tag, name_subpath, constraint_name)
        ('service-list', 'service', 'name', 'Service-Name'),
        ('address-group-list', 'address-group', 'name', 'Address-Group-Name'),
        ('alias-list', 'alias', 'name', 'Alias-Name'),
        ('interface-list', 'interface', 'name', 'Interface-Name'),
        ('schedule-list', 'schedule', 'name', 'Schedule-Name'),
        ('nat-list', 'nat', 'name', 'NAT-Name'),
        ('abs-policy-list', 'abs-policy', 'name', 'Policy-Name'),
        ('policy-list', 'policy', 'name', 'Runtime-Policy-Name'),
        ('ipsec-proposal-list', 'ipsec-proposal', 'name', 'IPsec-Proposal-Name'),
        ('ike-policy-list', 'ike-policy', 'name', 'IKE-Policy-Name'),
    ]

    def _check_name_uniqueness(
        self, root: ET.Element, report: ValidationReport
    ) -> None:
        """For every uniqueness constraint, find duplicates and report
        them as errors. Catches the Firebox 400 class:
          'Element X: Duplicate key-sequence [N] in key identity-constraint'
        """
        for list_tag, child_tag, name_path, constraint_name in self.UNIQUENESS_CONSTRAINTS:
            list_elem = root.find(list_tag)
            if list_elem is None:
                continue
            name_to_count: dict[str, int] = {}
            name_to_first_xpath: dict[str, str] = {}
            for i, child in enumerate(list_elem.findall(child_tag)):
                name_elem = child.find(name_path)
                if name_elem is None or not name_elem.text:
                    continue
                name = name_elem.text.strip()
                if not name:
                    continue
                if name in name_to_count:
                    name_to_count[name] += 1
                    # Report on every duplicate beyond the first
                    report.issues.append(Issue(
                        severity='error',
                        rule='uniqueness-duplicate',
                        xpath=f'/{root.tag}/{list_tag}/{child_tag}[{i+1}]',
                        element_tag=child_tag,
                        message=(
                            f'<{child_tag}> name={name!r} duplicates an '
                            f'earlier entry (first seen at '
                            f'{name_to_first_xpath[name]}). '
                            f'WatchGuard XSD constraint {constraint_name!r} '
                            f'requires unique names within /{list_tag}. '
                            f'Firebox import will reject with '
                            f'"Duplicate key-sequence [{name!r}] in '
                            f'key identity-constraint {constraint_name!r}."'
                        ),
                    ))
                else:
                    name_to_count[name] = 1
                    name_to_first_xpath[name] = \
                        f'/{root.tag}/{list_tag}/{child_tag}[{i+1}]'

    # Phase 9 — Bidirectional structural diff against jpa.xml reference.
    # Element tags whose child ordering matters (XSD xs:sequence) and
    # whose canonical ordering we cross-check against the reference.
    #
    # The Firebox XSD enforces sequence order — child[i] in our output
    # must appear at-or-after the same tag's position in reference's
    # canonical order. This catches the class of bug where the toolkit's
    # emit assembled the right children in the wrong order.
    #
    # Tags listed here are those where:
    #   1. The element is also present in jpa.xml reference
    #   2. Multiple children exist (ordering is meaningful)
    #   3. We've seen 400 errors related to this element's ordering
    #
    # Add tags as more 400-ordering errors surface.
    ORDERING_CHECKED_TAGS = frozenset([
        'ipsec-action',     # line 3360: <property> at wrong position
        'ipsec-proposal',
        'ike-action',
        'ike-policy',
        'abs-policy',
        'policy',
        'service',
        'address-group',
        'alias',
        'interface',
        'nat',
        'schedule',
        # Phase 9, line 3619: <local-cert> children out of order causes
        # XSD parser to walk past required-one-of group, then complain
        # with "Missing child element(s)" even though the element is
        # present (just at wrong position in the sequence).
        'local-cert',
    ])

    def _check_child_ordering_vs_reference(
        self, root: ET.Element, report: ValidationReport
    ) -> None:
        """Forward-diff: for each ORDERING_CHECKED_TAGS element in our
        output, find the canonical child ordering in jpa.xml and report
        any out-of-order children.

        Skipped when validating the reference against itself — the
        reference is ground truth and the "first-observed-wins" merge
        can over-constrain instances that legitimately use xs:all
        ordering flexibility. (Catches: jpa.xml itself has multiple
        instances of <abs-policy>, <policy>, <service> etc. where
        children appear in different orders across instances; this is
        valid per the XSD even though it can't be represented as a
        single canonical sequence.)
        """
        if self.reference_root is None:
            return
        # Skip if we're validating the reference itself
        if root is self.reference_root:
            return

        # Step 1: build canonical orderings from reference
        canonical_order: dict[str, list[str]] = {}
        for tag in self.ORDERING_CHECKED_TAGS:
            # Collect pairwise before/after constraints across all instances
            # of `tag` in the reference, then topologically sort to get
            # the canonical order. The naive "first observed wins" strategy
            # misplaces tags when an earlier instance lacks them — they
            # get appended at the end instead of being inserted at their
            # correct relative position. See _build_canonical_order_from_reference
            # in xml_emitter.py for the matching algorithm + rationale.
            precedes: dict[str, set[str]] = {}
            seen_tags: set[str] = set()
            for inst in self.reference_root.iter(tag):
                child_tags = [c.tag for c in inst]
                seen_tags.update(child_tags)
                for i, t1 in enumerate(child_tags):
                    precedes.setdefault(t1, set())
                    for t2 in child_tags[i+1:]:
                        precedes[t1].add(t2)
            if not seen_tags:
                continue
            in_degree: dict[str, int] = {t: 0 for t in seen_tags}
            for t1, succs in precedes.items():
                for t2 in succs:
                    if t2 in in_degree:
                        in_degree[t2] += 1
            available = sorted(t for t in seen_tags if in_degree[t] == 0)
            order: list[str] = []
            import bisect
            while available:
                t = available.pop(0)
                order.append(t)
                for succ in sorted(precedes.get(t, set())):
                    in_degree[succ] -= 1
                    if in_degree[succ] == 0:
                        bisect.insort(available, succ)
            for t in sorted(seen_tags):
                if t not in order:
                    order.append(t)
            if order:
                canonical_order[tag] = order

        # Step 2 + 3: check each instance in our output
        parent_map = {id(c): p for p in root.iter() for c in p}

        def xpath_of(elem):
            parts = [elem.tag]
            cur = elem
            while id(cur) in parent_map:
                cur = parent_map[id(cur)]
                parts.append(cur.tag)
            return '/' + '/'.join(reversed(parts))

        for tag, canonical in canonical_order.items():
            canonical_pos = {t: i for i, t in enumerate(canonical)}
            for inst in root.iter(tag):
                our_children = list(inst)
                if len(our_children) < 2:
                    continue  # ordering trivially holds

                # Walk our children left to right; for each one, check
                # that its canonical position is >= the maximum canonical
                # position of any earlier child.
                max_pos_so_far = -1
                last_in_order_tag = None
                for our_child in our_children:
                    pos = canonical_pos.get(our_child.tag)
                    if pos is None:
                        # Child tag not in reference's canonical order —
                        # likely a customer-emitted extension. Skip; the
                        # other validation phases would flag if it were
                        # invalid.
                        continue
                    if pos < max_pos_so_far:
                        # Out of order. Find what reference says should
                        # have come next at this point.
                        expected_next = [
                            canonical[i] for i in range(max_pos_so_far, len(canonical))
                        ][:3]
                        report.issues.append(Issue(
                            severity='error',
                            rule='reference-ordering',
                            xpath=xpath_of(inst),
                            element_tag=tag,
                            message=(
                                f'<{tag}> at {xpath_of(inst)}: child '
                                f'<{our_child.tag}> appears after '
                                f'<{last_in_order_tag}>, but per jpa.xml '
                                f'<{our_child.tag}> should come before '
                                f'<{last_in_order_tag}>. Expected one of '
                                f'{expected_next} next per reference '
                                f'canonical order. Firebox import will '
                                f'reject with "Element {our_child.tag!r}: '
                                f'not expected. Expected one of (...)."'
                            ),
                        ))
                        break  # one error per instance is enough
                    else:
                        max_pos_so_far = pos
                        last_in_order_tag = our_child.tag

    # Phase 9 — path-aware value-type rules. Some WatchGuard element tags
    # are overloaded — they appear both as leaf (with text content) and
    # as container (with children), depending on their parent context.
    # The legacy schema marks these as kind='ambiguous' and skips the
    # value check entirely, letting non-numeric strings through to the
    # Firebox where they fire 400 errors. These rules tighten the
    # specific contexts where we KNOW the element must be numeric.
    #
    # Each entry: (tag, path_contains, value_type)
    # Example: <protocol> in /service-item/member/ must be numeric IANA
    # protocol number; <protocol> in /proxy-action/http/request/ is
    # a container element (no text value at all).
    #
    # Grounded in jpa.xml + Firebox 400-error messages:
    #   line 1906: "Element 'protocol': 'IPCOMP' is not a valid value
    #               of the atomic type 'xs:unsignedShort'."
    PATH_AWARE_VALUE_TYPES = [
        ('protocol', '/service-item/member/', 'int'),
        # <enabled> is overloaded in WG XSD — some paths require
        # numeric (0/1), others require boolean text (true/false).
        # The numeric contexts per jpa.xml empirical audit:
        ('enabled', '/ipsec-action-list/ipsec-action', 'int'),
        ('enabled', '/abs-ipsec-action-list/abs-ipsec-action', 'int'),
        ('enabled', '/ike-policy-list/ike-policy', 'int'),
        ('enabled', '/ike-policy-group-list/ike-policy-group', 'int'),
        ('enabled', '/physical-if', 'int'),
        ('enabled', '/multicast-if', 'int'),
        # <pfs> is numeric in IPSec contexts.
        ('pfs', '/ipsec-action-list/', 'int'),
        ('pfs', '/abs-ipsec-action-list/', 'int'),
    ]

    # Phase 9 — path-aware ALLOWED-VALUES rules. Some WG XSD types are
    # not just typed but enumerated — only a specific finite set of
    # values is valid. These constraints can't be learned from jpa.xml
    # alone if jpa's sample doesn't exhaustively cover them; they have
    # to be encoded from Firebox error messages or vendor docs.
    #
    # Each entry: (tag, path_contains, frozenset_of_allowed_values, hint)
    # Values stored as strings (matches XML text); validator compares
    # against str(elem.text).
    PATH_AWARE_ALLOWED_VALUES = [
        # <to-min> and <from-min> are quarter-hour enums per WG XSD.
        # Verified against lab T-30 12.5.9 import error line 4036:
        #   "Element 'to-min': [facet 'enumeration'] The value '1' is
        #    not an element of the set {'-1', '0', '15', '30', '45'}."
        # Note: jpa.xml only ever shows '0' (sample doesn't exhaust),
        # so this can't be learned by auto-comparator alone.
        ('to-min', '/schedule-list/',
         frozenset(['-1', '0', '15', '30', '45']),
         'Schedule end-minute must be quarter-hour aligned. Enricher '
         'snaps free-integer minutes to nearest 15-minute boundary.'),
        ('from-min', '/schedule-list/',
         frozenset(['0', '15', '30', '45']),
         'Schedule start-minute must be quarter-hour aligned. Enricher '
         'snaps free-integer minutes DOWN to nearest 15-minute boundary.'),
    ]

    def _check_path_aware_allowed_values(
        self, root: ET.Element, report: ValidationReport
    ) -> None:
        """For elements with enumerated allowed-value sets, verify the
        actual value falls in the set. Catches:
          line 4036: 'Element to-min: [facet enumeration] The value 1
                      is not an element of the set {-1, 0, 15, 30, 45}'
        """
        parent_map = {id(c): p for p in root.iter() for c in p}

        def xpath_of(elem):
            parts = [elem.tag]
            cur = elem
            while id(cur) in parent_map:
                cur = parent_map[id(cur)]
                parts.append(cur.tag)
            return '/' + '/'.join(reversed(parts))

        for tag, path_match, allowed, hint in self.PATH_AWARE_ALLOWED_VALUES:
            for elem in root.iter(tag):
                xp = xpath_of(elem)
                if path_match not in xp:
                    continue
                text = (elem.text or '').strip()
                if not text:
                    continue
                if text not in allowed:
                    report.issues.append(Issue(
                        severity='error',
                        rule='allowed-value-enum',
                        xpath=xp,
                        element_tag=tag,
                        message=(
                            f'<{tag}> at {xp} has value {text!r}, but WG '
                            f'schema enum allows only {sorted(allowed)}. '
                            f'Firebox will reject with "[facet '
                            f'enumeration] The value {text!r} is not an '
                            f'element of the set." Fix: {hint}'
                        ),
                    ))

    def _check_path_aware_value_types(
        self, root: ET.Element, report: ValidationReport
    ) -> None:
        """Catch context-dependent type violations the legacy schema's
        kind='ambiguous' lets through."""
        parent_map = {id(c): p for p in root.iter() for c in p}

        def xpath_of(elem):
            parts = [elem.tag]
            cur = elem
            while id(cur) in parent_map:
                cur = parent_map[id(cur)]
                parts.append(cur.tag)
            return '/' + '/'.join(reversed(parts))

        for tag, path_match, vtype in self.PATH_AWARE_VALUE_TYPES:
            for elem in root.iter(tag):
                xp = xpath_of(elem)
                if path_match not in xp:
                    continue
                text = (elem.text or '').strip()
                if not text:
                    continue
                if vtype == 'int':
                    try:
                        int(text)
                    except ValueError:
                        report.issues.append(Issue(
                            severity='error',
                            rule='path-aware-value-type',
                            xpath=xp,
                            element_tag=tag,
                            message=(
                                f'<{tag}> at {xp} must be {vtype}-typed in '
                                f'this context, got {text!r}. WatchGuard '
                                f'schema atomic type is xs:unsignedShort '
                                f'(or similar). Firebox import will reject '
                                f'with "not a valid value of the atomic type."'
                            ),
                        ))

    # Phase 9 — polymorphic <type> discriminator rules, anchored in
    # T30jpa1.xml reference patterns. Every rule below was cross-checked
    # against jpa.xml: a tag+path combination only appears here if
    # the reference shows <type> consistently present in that context.
    #
    # Each entry: (parent_tag, path_contains_substring, mode)
    #   mode='first' = <type> required AND must be first child
    #   mode='required' = <type> required, position not enforced
    #
    # The path_contains_substring is checked against the element's
    # full xpath. Empty string means "any context for this tag".
    # The MOST SPECIFIC (longest) matching path wins.
    POLYMORPHIC_RULES = [
        # <member> — context-dependent (only required in service-item
        # and addr-group-member contexts; esp-transform/ike-transform/
        # schedule/nat-item/ike-policy-group members do NOT have type
        # per jpa.xml reference).
        ('member', '/service-item/', 'first'),
        ('member', '/addr-group-member/', 'first'),
        # <alias-member> always type-first per jpa.xml (62 of 62 instances).
        ('alias-member', '', 'first'),
        # <local-addr> / <remote-addr> — DUAL SHAPE per jpa.xml:
        #   - In /ipsec-action-list/ipsec-action/: SIMPLE leaf (text-only
        #     name reference to an entry defined elsewhere)
        #   - In /abs-ipsec-action-list/abs-ipsec-action/: STRUCTURED
        #     record with <type> + <value> children
        # The validator's polymorphic check only applies in the
        # structured-form context. Verified against lab T-30 12.5.9
        # import error line 3369:
        #   "Element 'local-addr': Element content is not allowed,
        #    because the type definition is simple."
        # (the error fires when we put structured form in the simple-leaf
        # context).
        ('local-addr', '/abs-ipsec-action-list/', 'first'),
        ('remote-addr', '/abs-ipsec-action-list/', 'first'),
        # <source>/<destination> — type-first per jpa.xml.
        ('source', '', 'first'),
        ('destination', '', 'first'),
        # Required-but-not-first (15 abs-policy in jpa.xml, all with type).
        ('abs-policy', '/abs-policy-list/', 'required'),
        # <ipsec-proposal> in /ipsec-proposal-list/ always has type;
        # references inside /ipsec-action-list/ do NOT (they're
        # name-references, not actual proposal definitions).
        ('ipsec-proposal', '/ipsec-proposal-list/', 'required'),
        # <nat> in /nat-list/ has type for type=3 (snat) and type=7
        # (1-to-1). Empty <nat/> stubs preserved from skeleton are
        # not required to carry it.
        ('nat', '/nat-list/', 'required'),
        # <auth-domain> in /auth-domain-list/ has type=0.
        ('auth-domain', '/auth-domain-list/', 'required'),
    ]

    # Phase 9 — mutually-exclusive children. Some WatchGuard XSD types
    # use xs:choice to allow exactly ONE of a set of children. When our
    # output writes both, the importer's parser state machine accepts
    # the first but rejects the second with messages like:
    #   line 3368: "Element 'ike-policy-group': not expected.
    #               Expected one of (pfs, dh-group, ipsec-proposal,
    #               version, enabled, use-vif)."
    # The expected-list is the schema state AFTER processing
    # <ike-policy> — the next legal elements. <ike-policy-group> is
    # excluded because xs:choice already fired on <ike-policy>.
    #
    # Each entry: (parent_tag, path_match, frozenset_of_mutex_children,
    #              hint)
    MUTEX_CHILD_GROUPS = [
        # <ike-policy> vs <ike-policy-group> in <ipsec-action>:
        # - WG IKEv2 MVPN (mobile-vpn): uses <ike-policy>
        # - bovpntunnel.1 (BOVPN site-to-site): uses <ike-policy-group>
        # SonicWall GroupVPN migrates to MVPN pattern -> <ike-policy>.
        ('ipsec-action', '/ipsec-action-list/',
         frozenset(['ike-policy', 'ike-policy-group']),
         'WG XSD allows only ONE: <ike-policy> for mobile-VPN (IKEv2 '
         'MVPN), <ike-policy-group> for BOVPN site-to-site. SonicWall '
         'GroupVPN migrates to mobile-VPN, so emit <ike-policy> only.'),
    ]

    # Phase 9 — required-one-of-children. Some WatchGuard XSD types
    # use xs:choice with minOccurs=1 — the element MUST contain AT
    # LEAST ONE of a set of children. Our emit sometimes produces
    # complex elements with only OPTIONAL children, triggering:
    #   line 3619: "Element 'local-cert': Missing child element(s).
    #               Expected is one of ( rsa-cert, dsa-cert, ...)"
    #
    # Each entry: (parent_tag, path_match, frozenset_of_options, hint)
    REQUIRED_ONE_OF_CHILDREN = [
        # <local-cert> requires at least one of these per WG 12.5.9 XSD.
        # Per jpa.xml: all real instances carry empty <psk>, <rsa-cert>,
        # <dsa-cert>, <local-id-data> placeholders.
        ('local-cert', '/ike-policy-list/',
         frozenset(['rsa-cert', 'dsa-cert', 'dsa-id', 'ec-cert',
                    'ec-id', 'ec-id-type', 'gen-cert-id', 'psk',
                    'local-id-data', 'local-if-ip']),
         'Add empty <psk></psk> and <local-id-data></local-id-data> '
         'placeholders to satisfy xs:choice. Operator fills PSK via '
         'sidecar secrets.ini.'),
    ]

    # Phase 9 — automatic value-domain learning from jpa.xml.
    # For every leaf element in the reference, record the observed
    # set of values. When validating a candidate, flag any leaf whose
    # value is OUTSIDE the reference's observed domain — but only for
    # elements where the reference has enough instances to give us
    # confidence in the domain (default: >=3 instances and all-numeric).
    #
    # This is the "real comparator" Captain asked for — learn from
    # jpa.xml automatically instead of hand-curating one rule per
    # Firebox error. Catches things like:
    #   line ????: "The element 'day-of-week' has a value of '7' which
    #               is greater than the maximum value allowed of '6'."
    # — because jpa.xml only ever shows day-of-week 0-6.
    #
    # Tunable thresholds:
    #   MIN_INSTANCES_FOR_DOMAIN: skip tags with too few examples
    #   MAX_DOMAIN_GAP: skip if the observed values have huge gaps
    #     (suggests open-ended numeric, not enum/range)
    REFERENCE_DOMAIN_MIN_INSTANCES = 3
    REFERENCE_DOMAIN_MAX_GAP = 100  # observed values shouldn't span >100x

    def _learn_value_domains_from_reference(self) -> dict:
        """Walk the reference jpa.xml and build per-tag value domains.
        Returns {tag: {'kind': 'numeric_range', 'min': int, 'max': int,
                       'observed': frozenset, 'instance_count': int,
                       'density': float}}.

        Only includes tags where:
          1. We have >= MIN_INSTANCES_FOR_DOMAIN samples
          2. The observed value set is "dense" — i.e., the number of
             distinct values observed is at least a meaningful fraction
             of the implied range. Sparse samples from a broad range
             (e.g., 6 samples of hour-of-day showing only 0-7) get
             skipped because we can't know whether the hole at 8-23
             is "schema forbids" or "jpa happens not to have these".

        Density heuristic: distinct_values / (max - min + 1) >= 0.5
        For day-of-week, observed 0-5 (6 distinct) and range 0-5:
          6 / 6 = 1.0  → dense, trust the range
        For from-hour, observed 0,4,5,6,7 (5 distinct) and range 0-7:
          5 / 8 = 0.625 → above threshold; but range 8-23 is unsampled
          so we'd still over-constrain. Need a different test.

        Better: require the sample-count to be >= 2x the implied range
        size, OR the distinct-value-count to equal the implied range
        size (fully-saturated enum). Use either as proxy for "we've
        seen enough to claim the range is closed."
        """
        if self.reference_root is None:
            return {}
        from collections import defaultdict
        raw_profile = defaultdict(lambda: {'numeric': [], 'string': set(),
                                            'count': 0})
        for elem in self.reference_root.iter():
            if list(elem):
                continue
            text = (elem.text or '').strip()
            if not text:
                continue
            raw_profile[elem.tag]['count'] += 1
            try:
                raw_profile[elem.tag]['numeric'].append(int(text))
            except ValueError:
                raw_profile[elem.tag]['string'].add(text)

        domains = {}
        for tag, prof in raw_profile.items():
            if prof['count'] < self.REFERENCE_DOMAIN_MIN_INSTANCES:
                continue
            nums = prof['numeric']
            strs = prof['string']
            if strs or not nums:
                continue
            lo, hi = min(nums), max(nums)
            distinct = len(set(nums))
            implied_range_size = hi - lo + 1
            total_samples = len(nums)
            # Two confidence tests, EITHER suffices:
            #   (a) "saturated enum": distinct == implied_range_size
            #       (every value in [lo, hi] is observed at least once)
            #   (b) "well-sampled": samples >= 2x implied range size
            saturated = distinct == implied_range_size
            well_sampled = total_samples >= 2 * implied_range_size
            # Additional sanity: don't infer closed-enum from tiny domains.
            # If we observed only 1-2 distinct values, the "range" is
            # almost certainly just a constant or near-constant in our
            # sample, not the real schema's allowed set. day-of-week has
            # 6 distinct values → safe. to-min has 1 distinct → unsafe
            # (real WG to-min is 0-59).
            if distinct < 3:
                continue
            if not (saturated or well_sampled):
                continue
            domains[tag] = {
                'kind': 'numeric_range',
                'min': lo, 'max': hi,
                'observed': frozenset(nums),
                'instance_count': prof['count'],
                'distinct_values': distinct,
                'saturated': saturated,
            }
        return domains

    def _check_reference_value_domains(
        self, root: ET.Element, report: ValidationReport
    ) -> None:
        """For every leaf in candidate, if we have a learned numeric
        domain from the reference, verify the candidate value falls
        within it. Reports out-of-range values as errors with the
        observed range from jpa.xml.

        This is the "real comparator" — learns automatically, no
        hand-curated tables required."""
        if not hasattr(self, '_reference_domains'):
            self._reference_domains = (
                self._learn_value_domains_from_reference()
            )
        if not self._reference_domains:
            return

        parent_map = {id(c): p for p in root.iter() for c in p}

        def xpath_of(elem):
            parts = [elem.tag]
            cur = elem
            while id(cur) in parent_map:
                cur = parent_map[id(cur)]
                parts.append(cur.tag)
            return '/' + '/'.join(reversed(parts))

        for elem in root.iter():
            if list(elem):
                continue
            domain = self._reference_domains.get(elem.tag)
            if domain is None:
                continue
            text = (elem.text or '').strip()
            if not text:
                continue
            try:
                n = int(text)
            except ValueError:
                continue
            if domain['kind'] == 'numeric_range':
                lo, hi = domain['min'], domain['max']
                if n < lo or n > hi:
                    # WARNING severity, not error: jpa.xml's observed
                    # domain is suggestive but may under-represent the
                    # real schema. For example, day-of-week shows 0-5
                    # in jpa (no Saturday samples) but the schema does
                    # accept 6. Treating these as warnings lets the
                    # operator investigate without blocking emit.
                    report.issues.append(Issue(
                        severity='warning',
                        rule='reference-value-out-of-range',
                        xpath=xpath_of(elem),
                        element_tag=elem.tag,
                        message=(
                            f'<{elem.tag}> has value {n}, outside jpa.xml '
                            f'observed range [{lo}, {hi}] '
                            f'({domain["instance_count"]} instances). '
                            f'May or may not be a real schema violation '
                            f'— jpa.xml domain is suggestive, not '
                            f'authoritative. Investigate if Firebox '
                            f'import rejects with "value out of range".'
                        ),
                    ))

    def _check_required_one_of_children(
        self, root: ET.Element, report: ValidationReport
    ) -> None:
        """Verify that elements with xs:choice (minOccurs=1) constraints
        contain at least one of the required alternatives. Catches the
        class of bug where our emit produces a parent with only
        optional children, missing the required xs:choice payload."""
        parent_map = {id(c): p for p in root.iter() for c in p}

        def xpath_of(elem):
            parts = [elem.tag]
            cur = elem
            while id(cur) in parent_map:
                cur = parent_map[id(cur)]
                parts.append(cur.tag)
            return '/' + '/'.join(reversed(parts))

        for parent_tag, path_match, options, hint in self.REQUIRED_ONE_OF_CHILDREN:
            for elem in root.iter(parent_tag):
                xp = xpath_of(elem)
                if path_match not in xp:
                    continue
                # Skip if the element is empty (likely scaffolding)
                if len(list(elem)) == 0:
                    continue
                present = {c.tag for c in elem}
                if not (present & options):
                    report.issues.append(Issue(
                        severity='error',
                        rule='required-one-of-missing',
                        xpath=xp,
                        element_tag=parent_tag,
                        message=(
                            f'<{parent_tag}> at {xp} must contain at least '
                            f'one of {sorted(options)} per WG XSD xs:choice. '
                            f'Current children: {sorted(present)}. '
                            f'Firebox will reject with "Element '
                            f'{parent_tag!r}: Missing child element(s). '
                            f'Expected is one of (...)." Fix: {hint}'
                        ),
                    ))

    def _check_mutex_children(
        self, root: ET.Element, report: ValidationReport
    ) -> None:
        """Verify that mutually-exclusive child elements don't both
        appear within the same parent. Each MUTEX_CHILD_GROUPS entry
        names a set of children that are mutually exclusive in the
        target schema (xs:choice). If more than one appears, report
        the conflict with hint text."""
        parent_map = {id(c): p for p in root.iter() for c in p}

        def xpath_of(elem):
            parts = [elem.tag]
            cur = elem
            while id(cur) in parent_map:
                cur = parent_map[id(cur)]
                parts.append(cur.tag)
            return '/' + '/'.join(reversed(parts))

        for parent_tag, path_match, mutex_set, hint in self.MUTEX_CHILD_GROUPS:
            for elem in root.iter(parent_tag):
                xp = xpath_of(elem)
                if path_match not in xp:
                    continue
                present = [c.tag for c in elem if c.tag in mutex_set]
                if len(present) > 1:
                    report.issues.append(Issue(
                        severity='error',
                        rule='mutex-children',
                        xpath=xp,
                        element_tag=parent_tag,
                        message=(
                            f'<{parent_tag}> at {xp} has multiple mutex '
                            f'children {present}. WatchGuard XSD uses '
                            f'xs:choice here — only ONE of '
                            f'{sorted(mutex_set)} may appear. {hint}'
                        ),
                    ))

    # Phase 9 — required-elements-by-path. Some elements are REQUIRED
    # in specific path contexts even if they aren't in jpa.xml reference
    # (e.g., the reference's stub entries may not exercise the required
    # element, but the runtime XSD demands it). Catches:
    #   line 3375: "Element 'description': not expected. Expected ( use-vif )."
    # which means our output reached a point in the parent's schema
    # where <use-vif> was the next required element, but we omitted it.
    #
    # Each entry: (parent_tag, parent_path_contains, required_child_tag,
    #              hint_note)
    REQUIRED_ELEMENTS_BY_PATH = [
        # WG 12.5.9 XSD requires <use-vif> in <ipsec-action> at end of
        # the version/enabled/use-vif group. Bovpn-vif is the WG feature
        # this toggles; value 0 = not using virtual-interface mode.
        ('ipsec-action', '/ipsec-action-list/', 'use-vif',
         'Add `use-vif = 0` to static_children of [emit.ipsec_action]. '
         'Value 0 = no BOVPN virtual-interface (matches group-vpn shape).'),
    ]

    def _check_required_elements_by_path(
        self, root: ET.Element, report: ValidationReport,
        is_reference_self_validation: bool = False
    ) -> None:
        """For elements in specific path contexts, verify required
        children are present per the WG runtime XSD (which may be
        stricter than jpa.xml reference shapes).

        Skipped when validating the reference itself — by definition
        the reference is what the source Firebox emitted, and we treat
        it as ground truth even when newer importing-Firebox firmware
        added required elements after the reference was exported."""
        if is_reference_self_validation:
            return
        parent_map = {id(c): p for p in root.iter() for c in p}

        def xpath_of(elem):
            parts = [elem.tag]
            cur = elem
            while id(cur) in parent_map:
                cur = parent_map[id(cur)]
                parts.append(cur.tag)
            return '/' + '/'.join(reversed(parts))

        for parent_tag, path_match, required_tag, hint in self.REQUIRED_ELEMENTS_BY_PATH:
            for elem in root.iter(parent_tag):
                xp = xpath_of(elem)
                if path_match not in xp:
                    continue
                # Skip stub entries — fewer than 3 children means this
                # element is scaffolding, not an active definition.
                # Active <ipsec-action> entries have 10+ children with
                # crypto config; stubs have just <name> + <property>.
                # The Firebox accepts stubs without use-vif (per jpa.xml,
                # which has 2 stub ipsec-action entries with no use-vif).
                if len(list(elem)) < 3:
                    continue
                if elem.find(required_tag) is None:
                    report.issues.append(Issue(
                        severity='error',
                        rule='required-element-by-path',
                        xpath=xp,
                        element_tag=parent_tag,
                        message=(
                            f'<{parent_tag}> at {xp} is missing required '
                            f'<{required_tag}> child. WatchGuard 12.5.9 '
                            f'XSD enforces this; Firebox import will reject '
                            f'with "Element X: not expected. Expected '
                            f'( {required_tag} )." Fix: {hint}'
                        ),
                    ))

    # Phase 9 — path-aware structural-kind rules. Some element tags have
    # different XSD types in different parent contexts (simple vs complex).
    # Catches the class of bug where structured-form content is placed in
    # a simpleType context.
    #
    # Each entry: (tag, path_contains, expected_kind)
    #   expected_kind='simple' = element must be text-only (no children)
    #   expected_kind='complex' = element must have children (or be empty)
    #
    # Grounded in jpa.xml + Firebox 400-error messages.
    STRUCTURAL_KIND_RULES = [
        # <local-addr>/<remote-addr> in /ipsec-action-list/ are leaf-text
        # references; structured form lives in /abs-ipsec-action-list/.
        # Verified 2026-06-03 against lab T-30 12.5.9, line 3369.
        ('local-addr', '/ipsec-action-list/', 'simple'),
        ('remote-addr', '/ipsec-action-list/', 'simple'),
    ]

    def _check_structural_kind(
        self, root: ET.Element, report: ValidationReport
    ) -> None:
        """Verify elements use the correct structural shape (simple-leaf
        vs complex-record) for their context. Catches the class of bug
        where the toolkit produces a record where a leaf is expected
        (or vice versa). Firebox rejects with:
          'Element X: Element content is not allowed, because the type
           definition is simple.'
        """
        parent_map = {id(c): p for p in root.iter() for c in p}

        def xpath_of(elem):
            parts = [elem.tag]
            cur = elem
            while id(cur) in parent_map:
                cur = parent_map[id(cur)]
                parts.append(cur.tag)
            return '/' + '/'.join(reversed(parts))

        for tag, path_match, expected_kind in self.STRUCTURAL_KIND_RULES:
            for elem in root.iter(tag):
                xp = xpath_of(elem)
                if path_match not in xp:
                    continue
                has_children = len(list(elem)) > 0
                if expected_kind == 'simple' and has_children:
                    child_tags = [c.tag for c in elem]
                    report.issues.append(Issue(
                        severity='error',
                        rule='structural-kind-mismatch',
                        xpath=xp,
                        element_tag=tag,
                        message=(
                            f'<{tag}> at {xp} must be simpleType (text-only) '
                            f'in this context per jpa.xml reference, but has '
                            f'child elements {child_tags}. Firebox will '
                            f'reject with "Element {tag!r}: Element content '
                            f'is not allowed, because the type definition '
                            f'is simple." Move structured form to the '
                            f'/abs-{tag.replace("-addr","")}.../ path instead.'
                        ),
                    ))
                elif expected_kind == 'complex' and not has_children:
                    report.issues.append(Issue(
                        severity='error',
                        rule='structural-kind-mismatch',
                        xpath=xp,
                        element_tag=tag,
                        message=(
                            f'<{tag}> at {xp} must be complexType (with '
                            f'children) in this context per jpa.xml '
                            f'reference, but is a text-only leaf.'
                        ),
                    ))

    def _check_polymorphic_discriminators(
        self, root: ET.Element, report: ValidationReport
    ) -> None:
        """Walk every element and apply POLYMORPHIC_RULES to determine
        whether <type> is required (and if so, whether it must be first).
        Matches by tag-name + path-contains-substring, so we can be
        context-aware (e.g. <member> requires <type> inside service-item
        but not inside esp-transform).
        
        ALSO checks payload-required rules: <member type=1> inside
        service-item must carry one of {icmp-type, server-port,
        start-server-port}. <member type=2> must carry start-server-port
        + end-server-port. <member type=1> inside addr-group-member
        must carry host-ip-addr. <member type=2> inside addr-group-member
        must carry ip-network-addr + ip-mask. Each rule grounded in
        jpa.xml + Firebox 400-error messages."""
        # Build a parent map so we can compute xpath-ish locators
        parent_map = {id(c): p for p in root.iter() for c in p}

        def xpath_of(elem: ET.Element) -> str:
            parts = [elem.tag]
            cur = elem
            while id(cur) in parent_map:
                parent = parent_map[id(cur)]
                parts.append(parent.tag)
                cur = parent
            return '/' + '/'.join(reversed(parts))

        # Build a per-tag rule index for efficiency
        rules_by_tag: dict[str, list[tuple[str, str]]] = {}
        for tag, path_match, mode in self.POLYMORPHIC_RULES:
            rules_by_tag.setdefault(tag, []).append((path_match, mode))

        for elem in root.iter():
            tag_rules = rules_by_tag.get(elem.tag)
            if not tag_rules:
                continue
            children = list(elem)
            if not children:
                continue  # empty element; skip
            xpath = xpath_of(elem)
            # Pick the most specific matching rule (longest path_match wins)
            applicable = [(pm, m) for pm, m in tag_rules
                          if (not pm) or (pm in xpath)]
            if not applicable:
                continue
            applicable.sort(key=lambda x: -len(x[0]))
            _, mode = applicable[0]

            type_child = elem.find('type')
            if mode in ('first', 'required') and type_child is None:
                report.issues.append(Issue(
                    severity='error',
                    rule='polymorphic-type-missing',
                    xpath=xpath,
                    element_tag=elem.tag,
                    message=(
                        f'<{elem.tag}> at {xpath} requires a <type> child '
                        f'(per jpa.xml reference patterns). Missing <type> '
                        f'causes WatchGuard import to reject with '
                        f'"Element X: not expected. Expected ( type )."'
                    ),
                ))
                continue
            if mode == 'first' and type_child is not None:
                if children[0] is not type_child:
                    actual_first = children[0].tag
                    report.issues.append(Issue(
                        severity='error',
                        rule='polymorphic-type-wrong-position',
                        xpath=xpath,
                        element_tag=elem.tag,
                        message=(
                            f'<{elem.tag}> at {xpath} has <type>, but it is '
                            f'not the first child (first is <{actual_first}>). '
                            f'WatchGuard schema requires <type> first here. '
                            f'Use `@first` suffix in static_children to fix.'
                        ),
                    ))

        # Phase 9 — payload-required rules for <member> elements.
        # Anchored in lab T-30 12.5.9 import error messages + jpa.xml.
        self._check_member_payloads(root, report, parent_map, xpath_of)

    def _check_member_payloads(self, root, report, parent_map, xpath_of):
        """Verify <member> elements carry the payload children their
        <type> declares. Catches the class of error:
          'Element member: Missing child element(s). Expected is one
           of ( icmp-type, server-port, start-server-port )'
        """
        # Rules: (path_contains, type_value, required_one_of, hint_msg)
        # required_one_of: tuple of acceptable child-tag combinations.
        # Each inner tuple represents one valid shape — at least one tag
        # from at least one combo must be present.
        member_payload_rules = [
            ('/service-item/', '1',
             [('icmp-type',), ('server-port',), ('start-server-port',)],
             'service <member type=1> needs one of icmp-type, server-port, or start-server-port'),
            ('/service-item/', '2',
             [('start-server-port', 'end-server-port')],
             'service <member type=2> needs start-server-port + end-server-port'),
            ('/addr-group-member/', '1',
             [('host-ip-addr',), ('fqdn',)],
             'address <member type=1> needs host-ip-addr or fqdn'),
            ('/addr-group-member/', '2',
             [('ip-network-addr', 'ip-mask')],
             'address <member type=2> needs ip-network-addr + ip-mask'),
        ]

        for elem in root.iter('member'):
            type_child = elem.find('type')
            if type_child is None or not type_child.text:
                continue
            type_val = type_child.text.strip()
            xpath = xpath_of(elem)
            present_tags = {c.tag for c in elem}

            for path_match, expected_type, combos, hint in member_payload_rules:
                if path_match not in xpath:
                    continue
                if type_val != expected_type:
                    continue
                # At least one combo's tags must all be present
                if any(all(t in present_tags for t in combo) for combo in combos):
                    break
                # No combo satisfied — error
                report.issues.append(Issue(
                    severity='error',
                    rule='member-payload-missing',
                    xpath=xpath,
                    element_tag='member',
                    message=(
                        f'<member type={type_val}> at {xpath} is missing '
                        f'required payload. {hint}. Present children: '
                        f'{sorted(present_tags - {"type"})}. WatchGuard '
                        f'import will reject with "Element member: Missing '
                        f'child element(s)."'
                    ),
                ))
                break

    def _check_cross_references(self, root: ET.Element,
                                  report: ValidationReport) -> None:
        """Check every ReferenceRule: text at from_xpath must equal a
        name child of an element at to_xpath, or be in the named
        builtin allowance list, or be empty (if allow_empty=true).
        """
        for rule in self.references:
            if not rule.from_xpath or not rule.to_xpath:
                continue

            # Build the set of defined names: from each definition element
            # at to_xpath, collect the to_field child's text.
            defined: set[str] = set()
            try:
                for def_elem in root.findall(rule.to_xpath):
                    name_el = def_elem.find(rule.to_field)
                    if name_el is not None and name_el.text:
                        defined.add(name_el.text.strip())
            except SyntaxError:
                report.issues.append(Issue(
                    severity='error', rule='cross-reference',
                    xpath=rule.to_xpath, element_tag='',
                    message=f'reference rule {rule.name!r} has invalid '
                            f'to_xpath: {rule.to_xpath}',
                ))
                continue

            # Built-in allowance (if declared)
            allowed_builtins: set[str] = set()
            if rule.allow_builtin and rule.allow_builtin in self.builtins:
                allowed_builtins = self.builtins[rule.allow_builtin].names

            # Find every reference and check it
            try:
                ref_elements = list(root.findall(rule.from_xpath))
            except SyntaxError:
                report.issues.append(Issue(
                    severity='error', rule='cross-reference',
                    xpath=rule.from_xpath, element_tag='',
                    message=f'reference rule {rule.name!r} has invalid '
                            f'from_xpath: {rule.from_xpath}',
                ))
                continue

            # Reconstruct an xpath-with-index for each element to make
            # error messages locator-useful
            for idx, ref_elem in enumerate(ref_elements, start=1):
                ref_text = (ref_elem.text or '').strip()
                if not ref_text:
                    if not rule.allow_empty:
                        report.issues.append(Issue(
                            severity=rule.severity,
                            rule='cross-reference',
                            xpath=f'{rule.from_xpath}[{idx}]',
                            element_tag=ref_elem.tag,
                            message=f'rule {rule.name!r}: empty reference, '
                                    f'allow_empty=false',
                        ))
                    continue
                if ref_text in defined:
                    continue
                if ref_text in allowed_builtins:
                    continue
                # Dangling reference
                preview = sorted(defined)[:5]
                preview_str = ', '.join(preview) + (
                    f' (+{len(defined)-5} more)' if len(defined) > 5 else '')
                report.issues.append(Issue(
                    severity=rule.severity,
                    rule='cross-reference',
                    xpath=f'{rule.from_xpath}[{idx}]',
                    element_tag=ref_elem.tag,
                    expected=f'name from {rule.to_xpath}: '
                             f'{preview_str if defined else "(no defs)"}',
                    actual=ref_text,
                    message=f'rule {rule.name!r}: reference {ref_text!r} '
                            f'does not resolve to any '
                            f'{rule.to_xpath}/{rule.to_field}',
                ))

    def _walk(self, elem: ET.Element, xpath: str,
              report: ValidationReport) -> None:
        report.elements_checked += 1
        rule = self.schema.get(elem.tag)
        if rule is None:
            report.elements_unknown += 1
            report.issues.append(Issue(
                severity=self.unknown_element_severity,
                rule='element-type',
                xpath=xpath, element_tag=elem.tag,
                message=f'element <{elem.tag}> is not declared in the schema',
            ))
        else:
            self._check_element(elem, xpath, rule, report)

        # Recurse with positional indexing for siblings of same tag
        sibling_index: dict[str, int] = {}
        for child in elem:
            sibling_index.setdefault(child.tag, 0)
            sibling_index[child.tag] += 1
            count = sibling_index[child.tag]
            child_xpath = f"{xpath}/{child.tag}[{count}]"
            self._walk(child, child_xpath, report)

    def _check_element(self, elem: ET.Element, xpath: str,
                        rule: ElementRule, report: ValidationReport) -> None:
        children = list(elem)
        text = (elem.text or '').strip()

        # kind=ambiguous: tag is observed in both leaf and record shapes.
        # Skip kind-shape and required-fields phases. Other phases
        # (value-domain, allowed-fields, etc.) still apply when relevant.
        if rule.kind == 'ambiguous':
            return

        # Phase: kind-shape
        if rule.kind == 'leaf':
            if children:
                report.issues.append(Issue(
                    severity='error', rule='kind-shape',
                    xpath=xpath, element_tag=elem.tag,
                    expected='no children (leaf)',
                    actual=f'{len(children)} child element(s)',
                    message=f'<{elem.tag}> declared kind=leaf but has children',
                ))
                return  # cascading errors not useful
            # Phase: empty-allowed
            if not text and not rule.allow_empty:
                report.issues.append(Issue(
                    severity='error', rule='empty-allowed',
                    xpath=xpath, element_tag=elem.tag,
                    expected='non-empty text',
                    actual='empty',
                    message=f'<{elem.tag}> requires non-empty text content',
                ))
            # Phase: value-domain
            if text:
                if rule.allowed_values and text not in rule.allowed_values:
                    report.issues.append(Issue(
                        severity='warning', rule='value-domain',
                        xpath=xpath, element_tag=elem.tag,
                        expected=f"one of: {', '.join(rule.allowed_values[:8])}"
                                 + ('...' if len(rule.allowed_values) > 8 else ''),
                        actual=text,
                        message=f'<{elem.tag}> value not in declared enum',
                    ))
                if rule.value_type == 'int' and text:
                    try:
                        int(text)
                    except ValueError:
                        report.issues.append(Issue(
                            severity='error', rule='value-domain',
                            xpath=xpath, element_tag=elem.tag,
                            expected='int', actual=text,
                            message=f'<{elem.tag}> value_type=int but got non-integer',
                        ))
                if rule.value_pattern:
                    if not re.match(rule.value_pattern, text):
                        report.issues.append(Issue(
                            severity='warning', rule='value-domain',
                            xpath=xpath, element_tag=elem.tag,
                            expected=f'pattern: {rule.value_pattern}',
                            actual=text,
                            message=f'<{elem.tag}> text does not match required pattern',
                        ))

        elif rule.kind == 'container':
            if text:
                report.issues.append(Issue(
                    severity='warning', rule='kind-shape',
                    xpath=xpath, element_tag=elem.tag,
                    expected='no text content (container)',
                    actual=f'text: {text[:30]!r}',
                    message=f'<{elem.tag}> declared kind=container but has text',
                ))
            if children and rule.item_element:
                wrong = [c.tag for c in children if c.tag != rule.item_element]
                if wrong:
                    distinct = sorted(set(wrong))
                    report.issues.append(Issue(
                        severity='warning', rule='kind-shape',
                        xpath=xpath, element_tag=elem.tag,
                        expected=f'all children are <{rule.item_element}>',
                        actual=f"unexpected child tags: {', '.join(distinct[:5])}",
                        message=f'<{elem.tag}> declared item_element={rule.item_element} but has other children',
                    ))

        elif rule.kind == 'record':
            child_tags = {c.tag for c in children}
            child_tag_counts: dict[str, int] = {}
            for c in children:
                child_tag_counts[c.tag] = child_tag_counts.get(c.tag, 0) + 1

            # Phase: required-fields
            if rule.required_fields:
                missing = [f for f in rule.required_fields if f not in child_tags]
                if missing:
                    report.issues.append(Issue(
                        severity='warning',  # required is conservative; warn not error
                        rule='required-fields',
                        xpath=xpath, element_tag=elem.tag,
                        expected=f'required: {", ".join(missing)}',
                        actual='missing',
                        message=f'<{elem.tag}> missing required field(s): {", ".join(missing)}',
                    ))

            # Phase: allowed-fields
            if rule.allowed_fields:
                extra = sorted(child_tags - set(rule.allowed_fields))
                if extra:
                    report.issues.append(Issue(
                        severity='warning', rule='allowed-fields',
                        xpath=xpath, element_tag=elem.tag,
                        expected=f"allowed: {', '.join(rule.allowed_fields[:6])}"
                                 + ('...' if len(rule.allowed_fields) > 6 else ''),
                        actual=f"unexpected: {', '.join(extra)}",
                        message=f'<{elem.tag}> has unexpected field(s): {", ".join(extra)}',
                    ))

            # Phase: repeating-fields (cardinality)
            for fname, count in child_tag_counts.items():
                if count > 1 and fname in (rule.allowed_fields or [fname]):
                    if rule.repeating_fields and fname not in rule.repeating_fields:
                        report.issues.append(Issue(
                            severity='info', rule='cardinality',
                            xpath=xpath, element_tag=elem.tag,
                            field_name=fname,
                            expected='at most one',
                            actual=f'appears {count} times',
                            message=f'<{elem.tag}>/<{fname}> repeats unexpectedly',
                        ))


# ---------------------------------------------------------------------------
# Output rendering
# ---------------------------------------------------------------------------
def render_summary(report: ValidationReport) -> str:
    """Render a human-readable text summary."""
    lines: list[str] = []
    lines.append('=' * 72)
    lines.append('WatchGuard XML Validation Report')
    lines.append('=' * 72)
    lines.append(f'Candidate: {report.candidate_path}')
    lines.append(f'Schema:    {report.schema_path}')
    lines.append('')
    lines.append(f'Elements checked: {report.elements_checked}')
    lines.append(f'Unknown elements: {report.elements_unknown}')
    lines.append(f'Errors:           {len(report.errors)}')
    lines.append(f'Warnings:         {len(report.warnings)}')
    lines.append(f'Info notes:       {len(report.infos)}')
    lines.append('')

    if not report.issues:
        lines.append('No issues found. Configuration validates cleanly.')
        return '\n'.join(lines)

    # Group by severity, then by rule
    for severity in ('error', 'warning', 'info'):
        bucket = [i for i in report.issues if i.severity == severity]
        if not bucket:
            continue
        lines.append('-' * 72)
        lines.append(f'{severity.upper()}S ({len(bucket)})')
        lines.append('-' * 72)

        # Group by rule for compactness
        by_rule: dict[str, list[Issue]] = {}
        for issue in bucket:
            by_rule.setdefault(issue.rule, []).append(issue)

        for rule_name, items in sorted(by_rule.items()):
            lines.append(f'\n  [{rule_name}]  {len(items)} occurrence(s)')
            # Show up to 8 examples
            shown = items[:8]
            for issue in shown:
                msg = issue.message or '(no message)'
                lines.append(f'    {issue.xpath}')
                lines.append(f'      {msg}')
                if issue.expected and issue.actual:
                    lines.append(
                        f'      expected: {issue.expected[:80]}'
                    )
                    lines.append(
                        f'      actual:   {issue.actual[:80]}'
                    )
            if len(items) > 8:
                lines.append(f'    ... and {len(items) - 8} more')

    lines.append('')
    lines.append('=' * 72)
    if report.errors:
        lines.append('VERDICT: errors found — config likely will not import')
    elif report.warnings:
        lines.append('VERDICT: warnings only — config probably imports but '
                     'has shape divergences')
    else:
        lines.append('VERDICT: clean (info notes only)')

    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def _read_ini(path: Path) -> configparser.ConfigParser:
    cp = configparser.ConfigParser(
        interpolation=None,
        inline_comment_prefixes=(';',),
        comment_prefixes=('#',),
    )
    cp.optionxform = str
    cp.read(path, encoding='utf-8')
    return cp


def main() -> int:
    ap = argparse.ArgumentParser(
        description='Validate a WatchGuard XML configuration against a schema.'
    )
    ap.add_argument('--config', default='wg_validator_config.ini',
                    help='Path to wg_validator_config.ini')
    ap.add_argument('--candidate',
                    help='Override candidate XML path from config')
    ap.add_argument('--schema',
                    help='Override wg_xml_schema.ini path from config')
    ap.add_argument('--strict', action='store_true',
                    help='Exit non-zero if engine config schema validation fails')
    ap.add_argument('--no-validate', action='store_true',
                    help='Skip engine config schema validation')
    args = ap.parse_args()

    cfg_path = Path(args.config).resolve()
    if not cfg_path.is_file():
        print(f'ERROR: config not found: {cfg_path}', file=sys.stderr)
        return 2

    if not args.no_validate:
        report = validate_at_startup(cfg_path, engine_name='wg_validator')
        if report is not None and not report.ok and args.strict:
            print('ERROR: --strict and engine config validation failed.',
                  file=sys.stderr)
            return 3

    cp = _read_ini(cfg_path)
    io = cp['io']
    schema_path = Path(args.schema or io['schema_path'])
    candidate_path = Path(args.candidate or io['candidate_xml'])
    references_path_str = io.get('references_path', '').strip()
    if not schema_path.is_absolute():
        schema_path = (cfg_path.parent / schema_path).resolve()
    if not candidate_path.is_absolute():
        candidate_path = (cfg_path.parent / candidate_path).resolve()

    if not schema_path.is_file():
        print(f'ERROR: schema not found: {schema_path}', file=sys.stderr)
        return 2
    if not candidate_path.is_file():
        print(f'ERROR: candidate XML not found: {candidate_path}',
              file=sys.stderr)
        return 2

    references: list[ReferenceRule] = []
    builtins: dict[str, BuiltinNames] = {}
    if references_path_str:
        references_path = Path(references_path_str)
        if not references_path.is_absolute():
            references_path = (cfg_path.parent / references_path).resolve()
        if references_path.is_file():
            references, builtins = load_wg_references(references_path)

    settings = cp.get('engine', 'unknown_element_severity', fallback='warning')

    # Phase 9 — load reference jpa.xml for bidirectional structural diff
    reference_xml_path = None
    ref_path_str = cp.get('engine', 'reference_xml_path', fallback='').strip()
    if ref_path_str:
        ref_p = Path(ref_path_str)
        if not ref_p.is_absolute():
            ref_p = (cfg_path.parent / ref_p).resolve()
        if ref_p.is_file():
            reference_xml_path = ref_p
    if reference_xml_path is None:
        fallback = (cfg_path.parent.parent
                    / "schema_learner" / "corpus" / "T30jpa1.xml")
        if fallback.is_file():
            reference_xml_path = fallback

    schema = load_wg_schema(schema_path)
    print(f'Schema:    {schema_path}  ({len(schema)} element rules)')
    if references:
        print(f'References: {len(references)} cross-reference rule(s), '
              f'{len(builtins)} built-in categor(ies)')
    if reference_xml_path is not None:
        print(f'Reference: {reference_xml_path}')
    print(f'Candidate: {candidate_path}')

    validator = WgValidator(schema, schema_path,
                            unknown_element_severity=settings,
                            references=references,
                            builtins=builtins,
                            reference_xml_path=reference_xml_path)
    val_report = validator.validate(candidate_path)

    # Write outputs
    output_dir = Path(io.get('output_dir',
                              str(cfg_path.parent / 'output')))
    if not output_dir.is_absolute():
        output_dir = (cfg_path.parent / output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    json_path = output_dir / io.get('output_json', 'validation_report.json')
    txt_path = output_dir / io.get('output_summary', 'validation_report.txt')

    json_path.write_text(json.dumps({
        'candidate_path': val_report.candidate_path,
        'schema_path': val_report.schema_path,
        'elements_checked': val_report.elements_checked,
        'elements_unknown': val_report.elements_unknown,
        'errors': len(val_report.errors),
        'warnings': len(val_report.warnings),
        'infos': len(val_report.infos),
        'issues': [asdict(i) for i in val_report.issues],
    }, indent=2), encoding='utf-8')

    summary = render_summary(val_report)
    txt_path.write_text(summary, encoding='utf-8')
    print('')
    print(summary)
    print('')
    print(f'Report (JSON): {json_path}')
    print(f'Report (text): {txt_path}')

    return val_report.exit_code()


if __name__ == '__main__':
    sys.exit(main())
