#!/usr/bin/env python3
"""
run_pipeline.py — one-shot driver for the full SonicWall → WatchGuard
migration pipeline.

Runs all four phases against either the bundled sample or your own
SonicWall CLI export. Each phase is the same script you'd invoke
manually; this just wires them together with sensible defaults.

Usage:
    python3 run_pipeline.py
        --> Runs against sonicwall_parser/input/slimmed-sonicwallconfig.txt

    python3 run_pipeline.py --input /path/to/your-firewall.txt
        --> Runs against your own config

    python3 run_pipeline.py --skip-validate
        --> Run pipeline without the auto-validation step at the end
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

DEFAULT_INPUT = (
    ROOT / "sonicwall_parser" / "input" / "slimmed-sonicwallconfig.txt"
)


def run_step(label: str, cmd: list[str], allow_fail: bool = False) -> bool:
    """Run a subprocess. Print its tail. Return True on success."""
    print(f"\n{'='*70}")
    print(f"  {label}")
    print(f"{'='*70}")
    print(f"  $ {' '.join(cmd)}")
    print()
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    # Show last 8 lines of stdout
    tail = r.stdout.strip().splitlines()[-8:]
    for ln in tail:
        print(f"  {ln}")
    if r.returncode != 0:
        print(f"\n  STDERR:\n{r.stderr}")
        if not allow_fail:
            print(f"\n  ✗ Step failed with exit code {r.returncode}")
            return False
    print(f"\n  ✓ {label}")
    return True


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--input", type=Path, default=DEFAULT_INPUT,
                    help=f"SonicWall CLI .txt file (default: {DEFAULT_INPUT})")
    ap.add_argument("--skip-validate", action="store_true",
                    help="Skip the standalone validator step at the end")
    args = ap.parse_args()

    if not args.input.is_file():
        print(f"ERROR: input file not found: {args.input}")
        return 1

    print(f"\n  SonicWall → WatchGuard Migration Pipeline")
    print(f"  Source: {args.input}")
    print(f"  Toolkit: {ROOT}")

    # Phase 1: Parser
    if not run_step(
        "Phase 1 — Parser (SonicWall CLI → per-section JSON)",
        ["python3", "sonicwall_parser/sonicwall_parser.py",
         "--config", "sonicwall_parser/parser_config.ini",
         "--input", str(args.input)],
    ):
        return 1

    # Phase 1.5: Enricher
    if not run_step(
        "Phase 1.5 — Enricher (pivot / derive / audit)",
        ["python3", "enricher/enricher.py",
         "--config", "enricher/enrich_config.ini"],
    ):
        return 1

    # Phase 2: XML Emitter (includes inline validation)
    if not run_step(
        "Phase 2 — XML Emitter (JSON → WatchGuard configuration.xml)",
        ["python3", "xml_emitter/xml_emitter.py",
         "--config", "xml_emitter/xml_emit_config.ini"],
    ):
        return 1

    # Optional: standalone validator on the emitted XML
    if not args.skip_validate:
        candidate_xml = (ROOT / "xml_emitter" / "dry_run" /
                         "configuration.xml").resolve()
        validator_config = (ROOT / "wg_validator" /
                            "wg_validator_config.ini").resolve()
        if not run_step(
            "Validation — run wg_validator on the emit output",
            ["python3", "wg_validator/wg_validator.py",
             "--config", str(validator_config),
             "--candidate", str(candidate_xml)],
        ):
            return 1

    # Final summary
    out_xml = ROOT / "xml_emitter" / "dry_run" / "configuration.xml"
    out_notes = ROOT / "xml_emitter" / "dry_run" / "migration_notes.md"
    print(f"\n{'='*70}")
    print(f"  Pipeline complete!")
    print(f"{'='*70}")
    print(f"  WatchGuard XML:   {out_xml}")
    print(f"  Migration notes:  {out_notes}")
    print()
    print(f"  Next: read migration_notes.md cover-to-cover.")
    print(f"  Then test configuration.xml on a lab Firebox.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
