#!/usr/bin/env python3
"""
diff_engine.py — comprehensive structural diff between two WG XML configs.

Produces a complete report covering:

   1. ROOT TAGS:    which top-level elements exist in A vs B
   2. CARDINALITY:  for each list, count of entries in A vs B
   3. CONTENT:      for each list, set diff of entries by <name>
                    (only-in-A, only-in-B, in-both)
   4. SHAPE DIFF:   for each (parent, child) pair: which one has it
   5. LEAF VALUES:  for FROZEN scalars, value drift

The goal: in one report, tell you EXACTLY what's structurally different
between any two configs. Use cases:
   - emitted file vs jpa (catches structural drift from ground truth)
   - emitted file vs another emit (catches regression)
   - jpa vs jpa-from-different-firmware (catches schema changes)

USAGE
   python3 diff_engine.py <fileA.xml> <fileB.xml>
                          [--output diff_report.txt]
                          [--json diff_report.json]

   Labels A and B can be overridden:
   python3 diff_engine.py emit.xml jpa.xml --label-a EMIT --label-b JPA
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET


def index_lists_by_name(root: ET.Element) -> dict[str, dict]:
    """For each top-level list element, return:
       { 'list_tag': {
            'count': int,
            'names': set[str],
            'children_tags': Counter,
       }}"""
    out = {}
    for top in root:
        kids = list(top)
        names = set()
        child_tags = Counter()
        for k in kids:
            n = k.find('name')
            if n is not None and n.text and n.text.strip():
                names.add(n.text.strip())
            child_tags[k.tag] += 1
        out[top.tag] = {
            'count': len(kids),
            'names': names,
            'child_tags': dict(child_tags),
            'is_scalar': len(kids) == 0 and (top.text or '').strip() != '',
            'scalar_value': (top.text or '').strip() if len(kids) == 0 else None,
        }
    return out


def parent_child_pairs(root: ET.Element) -> dict[tuple[str, str], int]:
    pairs: dict = defaultdict(int)
    for parent in root.iter():
        for child in parent:
            pairs[(parent.tag, child.tag)] += 1
    return dict(pairs)


def diff(path_a: Path, path_b: Path, label_a='A', label_b='B') -> dict:
    try:
        root_a = ET.parse(path_a).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: parse failed for {path_a}: {e}', file=sys.stderr)
        sys.exit(2)
    try:
        root_b = ET.parse(path_b).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: parse failed for {path_b}: {e}', file=sys.stderr)
        sys.exit(2)

    a = index_lists_by_name(root_a)
    b = index_lists_by_name(root_b)

    report = {
        'label_a': label_a,
        'label_b': label_b,
        'file_a': str(path_a),
        'file_b': str(path_b),
        'sections': {},
    }

    all_tags = sorted(set(a) | set(b))
    for tag in all_tags:
        ai = a.get(tag, {'count': 0, 'names': set(),
                          'is_scalar': False, 'scalar_value': None})
        bi = b.get(tag, {'count': 0, 'names': set(),
                          'is_scalar': False, 'scalar_value': None})
        section = {
            'in_a':    tag in a,
            'in_b':    tag in b,
            'count_a': ai['count'],
            'count_b': bi['count'],
            'count_diff': ai['count'] - bi['count'],
        }
        if ai.get('is_scalar') or bi.get('is_scalar'):
            section['scalar_a'] = ai.get('scalar_value')
            section['scalar_b'] = bi.get('scalar_value')
            section['scalar_match'] = (
                ai.get('scalar_value') == bi.get('scalar_value')
            )
        names_a = ai['names']
        names_b = bi['names']
        only_a = names_a - names_b
        only_b = names_b - names_a
        in_both = names_a & names_b
        section['names'] = {
            f'only_in_{label_a}': sorted(only_a),
            f'only_in_{label_b}': sorted(only_b),
            'in_both':            len(in_both),
            f'total_{label_a}':   len(names_a),
            f'total_{label_b}':   len(names_b),
        }
        report['sections'][tag] = section

    # Shape diff (parent, child) tag pairs
    pa = parent_child_pairs(root_a)
    pb = parent_child_pairs(root_b)
    shape_only_a = sorted(set(pa) - set(pb))
    shape_only_b = sorted(set(pb) - set(pa))
    report['shape_diff'] = {
        f'pairs_only_in_{label_a}': [list(p) for p in shape_only_a],
        f'pairs_only_in_{label_b}': [list(p) for p in shape_only_b],
        f'total_pairs_{label_a}': len(pa),
        f'total_pairs_{label_b}': len(pb),
    }

    return report


def render_text(report: dict) -> str:
    """Human-readable text report."""
    la, lb = report['label_a'], report['label_b']
    lines = []
    lines.append('=' * 72)
    lines.append(f'DIFF: {la} ({report["file_a"]})  vs  {lb} ({report["file_b"]})')
    lines.append('=' * 72)
    lines.append('')
    lines.append(f'{"section":<32} {la:>9} {lb:>9}   diff   notes')
    lines.append('-' * 72)
    for tag, s in report['sections'].items():
        ca, cb = s['count_a'], s['count_b']
        diff_val = s['count_diff']
        marker = '✓' if diff_val == 0 and s['in_a'] and s['in_b'] else \
                 ('A-only' if s['in_a'] and not s['in_b'] else \
                  ('B-only' if s['in_b'] and not s['in_a'] else
                   f'{diff_val:+d}'))
        if 'scalar_a' in s:
            scal = '' if s['scalar_match'] else \
                f'  scalar: {la}={s["scalar_a"]!r} {lb}={s["scalar_b"]!r}'
            lines.append(f'{tag:<32} {"leaf":>9} {"leaf":>9}   '
                          f'{"✓" if s["scalar_match"] else "✗":<6} {scal}')
        else:
            lines.append(f'{tag:<32} {ca:>9} {cb:>9}   {marker}')

    # Detailed name-set diffs
    lines.append('')
    lines.append('=' * 72)
    lines.append('NAME-SET DIFFERENCES (entries by <name>)')
    lines.append('=' * 72)
    for tag, s in report['sections'].items():
        only_a = s.get('names', {}).get(f'only_in_{la}', [])
        only_b = s.get('names', {}).get(f'only_in_{lb}', [])
        if not only_a and not only_b:
            continue
        lines.append('')
        lines.append(f'<{tag}>:')
        if only_a:
            lines.append(f'  only in {la} ({len(only_a)}):')
            for n in only_a[:20]:
                lines.append(f'      {n}')
            if len(only_a) > 20:
                lines.append(f'      ... +{len(only_a)-20} more')
        if only_b:
            lines.append(f'  only in {lb} ({len(only_b)}):')
            for n in only_b[:20]:
                lines.append(f'      {n}')
            if len(only_b) > 20:
                lines.append(f'      ... +{len(only_b)-20} more')

    # Shape diff
    sd = report['shape_diff']
    lines.append('')
    lines.append('=' * 72)
    lines.append('SHAPE DIFFERENCES (parent->child tag pairs)')
    lines.append('=' * 72)
    pa = sd[f'pairs_only_in_{la}']
    pb = sd[f'pairs_only_in_{lb}']
    if pa:
        lines.append(f'\nPairs only in {la}:')
        for parent, child in pa[:30]:
            lines.append(f'   <{parent}><{child}>')
        if len(pa) > 30:
            lines.append(f'   ... +{len(pa)-30} more')
    if pb:
        lines.append(f'\nPairs only in {lb}:')
        for parent, child in pb[:30]:
            lines.append(f'   <{parent}><{child}>')
        if len(pb) > 30:
            lines.append(f'   ... +{len(pb)-30} more')
    if not pa and not pb:
        lines.append('  (no shape differences — every parent/child '
                     'combo in one occurs in the other)')

    return '\n'.join(lines)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('file_a', type=Path)
    p.add_argument('file_b', type=Path)
    p.add_argument('--label-a', default='A')
    p.add_argument('--label-b', default='B')
    p.add_argument('--output', type=Path, default=None,
                   help='Save text report to this path (default stdout)')
    p.add_argument('--json', type=Path, default=None,
                   help='Save JSON report to this path')
    args = p.parse_args()

    report = diff(args.file_a, args.file_b, args.label_a, args.label_b)
    text = render_text(report)

    if args.output:
        args.output.write_text(text, encoding='utf-8')
        print(f'wrote text report -> {args.output}')
    else:
        print(text)

    if args.json:
        # Convert sets to lists for JSON
        def _clean(obj):
            if isinstance(obj, set):
                return sorted(obj)
            if isinstance(obj, dict):
                return {k: _clean(v) for k, v in obj.items()}
            if isinstance(obj, list):
                return [_clean(x) for x in obj]
            return obj
        args.json.write_text(json.dumps(_clean(report), indent=2),
                              encoding='utf-8')
        print(f'wrote JSON report -> {args.json}')

    # Exit code: 0 if no name-set or shape differences; 1 otherwise
    any_diff = any(
        s.get('names', {}).get(f'only_in_{args.label_a}')
        or s.get('names', {}).get(f'only_in_{args.label_b}')
        for s in report['sections'].values()
    ) or report['shape_diff'][f'pairs_only_in_{args.label_a}'] \
      or report['shape_diff'][f'pairs_only_in_{args.label_b}']
    return 1 if any_diff else 0


if __name__ == '__main__':
    sys.exit(main())
