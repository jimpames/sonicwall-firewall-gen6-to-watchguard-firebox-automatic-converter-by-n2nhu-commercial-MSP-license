# SonicWall → WatchGuard Migration Toolkit

A vendor-neutral, INI-driven, three-phase migration pipeline. Every engine
is generic; all vendor knowledge lives in INI files. Add a new vendor by
adding new INIs, never by editing code.

```
SonicWall .txt config
   │
   ▼
┌──────────────────────────┐
│ PHASE 1 — Parser          │  parser_config.ini  +  parser_schema.ini
│ (sonicwall_parser/)       │  Pattern matrix; one [section.X] per logical area
└──────────────────────────┘
   │  one canonical JSON per logical area
   ▼
┌──────────────────────────┐
│ PHASE 1.5 — Enricher      │  enrich_config.ini  +  enrich_schema.ini
│ (enricher/)               │  Three pass kinds: pivot, derive, audit
└──────────────────────────┘
   │  enriched JSONs
   ▼
┌──────────────────────────┐
│ PHASE 2 — XML Emitter     │  xml_emit_config.ini  +  xml_emit_schema.ini
│ (xml_emitter/)            │  Generic XML tree builder
│                           │  Merges into a master skeleton ◄────┐
└──────────────────────────┘                                       │
   │                                                                │
   ▼                                                                │
WatchGuard <profile>.xml  +  migration_notes.md                     │
                                                                    │
       ┌──── master_skeleton.xml ◄──── make_skeleton.py ◄───────────┤
       │     (device defaults +                       │             │
       │      empty migration lists)                  │             │
       │                                              │             │
       │                            real Firebox XML export ────────┘
       │                            (one per Firebox model)

           ↑                              ↑
           │                              │
   concept_map.ini  ─── the durable Rosetta Stone ──┐
   (vendor-neutral terminology + value-maps + crypto audit tables +
    WatchGuard numeric-enum decodings)
```

## Algebraic-design philosophy

The whole toolkit applies one pattern recursively:

> **Object × Verb = Action**

In each phase:

| Phase    | Object                  | Verb                               | Action                  |
|----------|-------------------------|------------------------------------|-------------------------|
| 1        | A SonicWall config line | A `[section.X]` regex match        | A canonical JSON entry  |
| 1.5      | A canonical JSON entry  | A `[pass.X]` (pivot/derive/audit)  | An enriched entry       |
| 2        | An enriched entry       | An `[emit.X]` rule                 | An XML element merged into skeleton |
| Skeleton | A profile element       | An `[empty/preserve/redact]` rule  | A scrubbed skeleton element |
| Concept  | A vendor's term         | A concept_map lookup               | A vendor-neutral name   |

Each phase is data-driven by an INI; each INI has a schema (a second INI)
that drives a GUI for editing it.

## Current status (Apr 2026)

| Component                          | Status                                             |
|------------------------------------|----------------------------------------------------|
| Phase 1 — parser                   | **Working.** 100% line coverage on slim sample.   |
| Phase 1.5 — enricher               | **Working.** Pivot/derive/audit all firing.       |
| Phase 2 — emitter                  | **Working** for: routes, address-groups, aliases, services, firewall policies, interfaces, IKE actions/policies, IPsec proposals/actions, abs-muvpn. |
| Phase 2 — TBD                      | NAT/DNAT (schema known, slim sample has 0 entries); service-group-list (need T-30 hand-built example to confirm WG's composition model). |
| Skeleton scrubber                  | **Working.** Turns a real T-30 export into a reusable skeleton (656KB → 508KB, 0 secret leaks). |
| Concept map                        | Includes WatchGuard numeric-enum decodings cracked from real T-30 export. |
| Round-trip harness                 | **Working.** `watchparse.py` validates emitted XML. |

## The skeleton-merge pattern

A WatchGuard `<profile>` has 56+ top-level lists. Most are device defaults
(proxy-action-list with 33 shipped templates, alarm-action-list, DLP sensors,
WebBlocker exceptions, signature-update markers) that aren't migrated FROM
SonicWall but MUST be present for a Firebox to accept the import.

The skeleton-merge pattern handles this in two steps:

1. **Run `make_skeleton.py` once** per Firebox model. It takes a real
   `<profile>` export from your lab box, scrubs migration-replaceable lists
   empty, redacts all secrets (PSKs, certificates, RADIUS keys, account
   passwords), strips device-identifying info, and writes a checked-in
   `master_skeleton.xml`.

2. **Phase 2 emit loads the skeleton** as its starting tree (instead of
   building from an empty `<profile>`). Each `[emit.X]` rule's `xml_parent_xpath`
   FINDS an existing element in the skeleton (which is empty for migration
   lists) and adds children to it. Device-default lists pass through
   untouched.

Result: the Phase 2 output is a structurally-complete Firebox profile,
not a fragment. Importable shape, 581KB output.

## The vocabulary trap (read this before editing anything)

WatchGuard and SonicWall **swap the meaning** of two terms:

| Concept                          | SonicWall term      | WatchGuard term        |
|----------------------------------|---------------------|------------------------|
| Concrete: a host/network/range   | `address-object`    | `address-group` ⚠️     |
| Collection: refs to other things | `address-group`     | `alias` ⚠️             |

This is encoded in `concept_map/concept_map.ini` and applied automatically.
Always consult the concept map when editing emit rules.

## Running the pipeline

From the toolkit root:

```bash
# (One-time, when you have a new Firebox model) — make a skeleton from a real export
cd xml_emitter
python3 make_skeleton.py --config skeleton_config.ini

# Phase 1
cd ../sonicwall_parser
python3 sonicwall_parser.py --config parser_config.ini --input input/<your-config>.txt
python3 sanity_check.py     --config parser_config.ini --input input/<your-config>.txt --output output/

# Phase 1.5
cd ../enricher
python3 enricher.py --config enrich_config.ini

# Phase 2 (uses the skeleton)
cd ../xml_emitter
python3 xml_emitter.py --config xml_emit_config.ini

# Round-trip verify
cd ../harness
python3 watchparse.py ../xml_emitter/dry_run/configuration.xml
```

## Repository layout

```
migration_toolkit/
├── README.md                   ← this file
├── sonicwall_parser/
│   ├── parser_config.ini       ← patterns
│   ├── parser_schema.ini       ← schema for the patterns
│   ├── sonicwall_parser.py     ← engine
│   ├── sanity_check.py         ← regression harness
│   ├── input/
│   └── output/                 ← Phase 1 JSONs
├── enricher/
│   ├── enrich_config.ini
│   ├── enrich_schema.ini
│   ├── enricher.py
│   └── output/                 ← Phase 1.5 enriched JSONs
├── xml_emitter/
│   ├── xml_emit_config.ini     ← emit rules
│   ├── xml_emit_schema.ini
│   ├── xml_emitter.py          ← engine
│   ├── skeleton_config.ini     ← scrubber rules
│   ├── make_skeleton.py        ← scrubber
│   └── dry_run/                ← Phase 2 XML + advisory
├── concept_map/
│   ├── concept_map.ini         ← the Rosetta Stone (durable artifact)
│   └── concept_map_schema.ini
├── harness/
│   └── watchparse.py           ← reverse-engineering tool, repurposed as harness
└── docs/
    ├── PHASE2_TODO.md
    ├── reference_exports/
    │   └── T30jpa1__1_.xml     ← real WG export, schema source of truth
    └── skeletons/
        ├── master_skeleton.xml ← scrubbed, secret-free, reusable
        └── _skeleton_audit.json
```

## What this toolkit does not do (by design)

- **Does not decrypt SonicWall shared secrets.** A sidecar `secrets.ini` is
  the operator's responsibility during migration review.
- **Does not auto-upload to a Firebox.** All XML output goes to
  `xml_emitter/dry_run/`. Review, validate, upload manually.
- **Does not force upgrade of deprecated crypto.** The enricher flags weak
  algorithms and recommends replacements; the generated XML preserves
  original choices for lift-and-shift compatibility. The advisory in
  `migration_notes.md` is for the operator to decide.
- **Does not (yet) produce import-ready XML for a Firebox.** Schema is right,
  shape is right, but the import-validation gap closes through the
  baseline-vs-feature diff loop on a real T-30. See `docs/PHASE2_TODO.md`.

## Next milestones

1. **Baseline-vs-feature diff loop on T-30** — hand-build one BOVPN, export,
   diff against blank baseline. The diff *is* the import-correctness spec.
   Encode any missing fields into `child_map` in `xml_emit_config.ini`.
2. **TZ-300 6.2.3 dialect investigation** — different SonicOS version may
   need a `parser_config.sonicos_6_2.ini` variant. Send a head-of-export
   sample to confirm.
3. **NSA-3600 export** — likely 6.5+ matching slim sample's grammar; will
   surface real shapes (NAT, BOVPN, VLAN-on-VLAN) the slim sample lacks.
4. **Polish cosmetics** as needed (alias member-name normalization,
   route-policy address-reference resolution, etc.) — all INI work.

Each is INI work, not engine work. The architecture has earned that.

## Current status (Apr 2026)

| Component                          | Status                                             |
|------------------------------------|----------------------------------------------------|
| Phase 1 — parser                   | **Working.** 100% line coverage on slim sample.   |
| Phase 1.5 — enricher               | **Working.** Pivot/derive/audit all firing.       |
| Phase 2 — emitter (confirmed)      | **Working** for: routes, address-groups (concrete + alias), services, service-groups (partial), firewall policies, interfaces, IKE actions/policies, IPsec proposals/actions, abs-muvpn (Mobile VPN with IKEv2). |
| Phase 2 — emitter (TBD)            | NAT and DNAT rules — schema known but the slim sample has 0 entries to drive them. |
| Concept map                        | Includes all WatchGuard numeric-enum decodings cracked from a real T-30 export. |
| Round-trip harness                 | **Working.** `watchparse.py` validates emitted XML. |

## Running the pipeline

From the toolkit root:

```bash
# Phase 1
cd sonicwall_parser
python3 sonicwall_parser.py --config parser_config.ini --input input/<your-config>.txt
python3 sanity_check.py     --config parser_config.ini --input input/<your-config>.txt --output output/

# Phase 1.5
cd ../enricher
python3 enricher.py --config enrich_config.ini

# Phase 2
cd ../xml_emitter
python3 xml_emitter.py --config xml_emit_config.ini

# Round-trip verify
cd ../harness
python3 watchparse.py ../xml_emitter/dry_run/configuration.xml
```

## The vocabulary trap (read this before editing anything)

WatchGuard and SonicWall **swap the meaning** of two terms:

| Concept                          | SonicWall term      | WatchGuard term        |
|----------------------------------|---------------------|------------------------|
| Concrete: a host/network/range   | `address-object`    | `address-group` ⚠️     |
| Collection: refs to other things | `address-group`     | `alias` ⚠️             |

This is encoded in `concept_map/concept_map.ini` and applied automatically
by Phase 2. If you write new emit rules and intuitively match SonicWall
"address-group" → WatchGuard "address-group" you will silently produce
wrong output. Always consult the concept map.

## Filling in the Phase 2 TODO sections

When you have access to a Firebox (e.g. T-30), the workflow:

1. Hand-build a working example of the missing feature (a BOVPN tunnel,
   an MVPN-IKEv2 setup, a NAT policy) on the box.
2. Export `configuration.xml` from the Firebox.
3. Diff against an empty-baseline export. The diff shows you the exact
   element/attribute names WatchGuard uses for that feature.
4. Encode those into the `[emit.X]` rule's `child_map` in
   `xml_emitter/xml_emit_config.ini`. Change `status = todo` to
   `status = confirmed`.
5. Re-run Phase 2 and round-trip-verify.

Total per feature: typically 30 minutes once you have lab access.

## What this toolkit does not do (by design)

- **Does not decrypt SonicWall shared secrets.** They're stored as
  `4,<hex>` reversible cipher in the source config; we preserve them
  verbatim. A sidecar `secrets.ini` is the operator's responsibility
  to fill with cleartext PSKs during migration review.
- **Does not auto-upload to a Firebox.** All XML output goes to
  `xml_emitter/dry_run/`. You review, validate, and upload manually.
- **Does not force upgrade of deprecated crypto.** The enricher flags
  weak/deprecated algorithms and recommends replacements, but the
  generated XML preserves the original choices for lift-and-shift
  compatibility. The advisory in `migration_notes.md` is for the
  operator to decide.

## Repository layout

```
migration_toolkit/
├── README.md                   ← this file
├── sonicwall_parser/
│   ├── parser_config.ini       ← patterns
│   ├── parser_schema.ini       ← schema for the patterns
│   ├── sonicwall_parser.py     ← engine
│   ├── sanity_check.py         ← regression harness
│   ├── input/
│   └── output/                 ← Phase 1 JSONs
├── enricher/
│   ├── enrich_config.ini
│   ├── enrich_schema.ini
│   ├── enricher.py
│   └── output/                 ← Phase 1.5 enriched JSONs
├── xml_emitter/
│   ├── xml_emit_config.ini
│   ├── xml_emit_schema.ini
│   ├── xml_emitter.py
│   └── dry_run/                ← Phase 2 XML + advisory
├── concept_map/
│   ├── concept_map.ini         ← the Rosetta Stone (durable artifact)
│   └── concept_map_schema.ini
├── harness/
│   └── watchparse.py           ← reverse-engineering tool, repurposed as harness
└── docs/
    └── PHASE2_TODO.md
```

## Next milestones

1. T-30 hand-built BOVPN export → fill bovpn_gateway and bovpn_tunnel emit
   rules → re-run pipeline → round-trip verify against original SonicWall
   tunnel behavior.
2. T-30 MVPN-IKEv2 export → fill mobile_vpn_ikev2 emit rule.
3. Run Phase 1 against full 23 MB SonicWall config → identify any new
   shapes in `_unparsed.json` → refine `parser_config.ini`.
4. Polish cosmetics: alias member-name normalization (strip `ipv4`/`ipv6`
   prefix), route-policy address-reference resolution, interface XPath
   alignment with watchparse.

Each is INI work, not engine work. The architecture has earned that.
