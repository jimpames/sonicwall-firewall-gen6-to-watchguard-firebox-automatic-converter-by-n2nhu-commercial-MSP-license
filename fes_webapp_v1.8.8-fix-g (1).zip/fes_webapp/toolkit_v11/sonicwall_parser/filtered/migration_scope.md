# Migration Scope Report

**Source:** nsa3600-lab
**Generated:** 2026-06-03T00:43:11.849284
**Builtin registry:** `builtin_objects.ini` (SonicOS 6.5.x)

---

## Summary

Total classified entries: **367**

| Bucket | Count | % of total |
|---|---:|---:|
| 🟢 **customer_defined** (translator workload) | 5 | 1.4% |
| 🔵 vendor_builtin (passthrough) | 313 | 85.3% |
| ⚪ dead_unreferenced (skip) | 47 | 12.8% |
| 🟡 disabled_in_source (defer) | 2 | 0.5% |

**Translator workload reduction: 98.6%** (362 of 367 entries do not need operator triage)

## Per-section breakdown

| Section | Total | Customer | Builtin | Dead | Disabled |
|---|---:|---:|---:|---:|---:|
| `access_rules` | 25 | 1 | 24 | 0 | 0 |
| `address_groups` | 47 | 0 | 0 | 47 | 0 |
| `address_objects` | 1 | 1 | 0 | 0 | 0 |
| `nat_policies` | 1 | 1 | 0 | 0 | 0 |
| `schedules` | 8 | 0 | 8 | 0 | 0 |
| `service_groups` | 50 | 0 | 50 | 0 | 0 |
| `service_objects` | 224 | 0 | 224 | 0 | 0 |
| `vpn_policies` | 3 | 1 | 0 | 0 | 2 |
| `zones` | 8 | 1 | 7 | 0 | 0 |

## Next steps

1. Translator runs against `filtered/customer_defined.json` (5 entries)
2. Vendor built-ins pass through with 1:1 WatchGuard mapping (313 entries)
3. 47 dead entries logged but not migrated (see `filtered/dead_unreferenced.json`)
4. 2 disabled entries deferred — auto-promote if future config has them enabled (Phase 6.5 semantics)

---

*Operator override always available: if a classification is wrong, edit the entry in the appropriate `filtered/*.json` or update `builtin_objects.ini` and re-run.*