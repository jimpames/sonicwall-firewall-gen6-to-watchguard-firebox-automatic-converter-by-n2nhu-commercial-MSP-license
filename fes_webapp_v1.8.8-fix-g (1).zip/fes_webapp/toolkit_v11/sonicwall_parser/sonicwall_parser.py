#!/usr/bin/env python3
"""
sonicwall_parser.py
====================

A fully data-driven parser for SonicOS Enhanced configuration text.

This file contains ONLY the engine. It contains NO knowledge of SonicWall
keywords, address-objects, policies, interfaces, or any other domain concept.
All such knowledge lives in `parser_config.ini`. Add a new SonicWall section
type by adding a new `[section.<name>]` to that INI file — never by editing
this code.

Algebraic-design model (J P Ames):

    Object × Verb = Action

    Object     = a logical config category (declared in parser_config.ini)
    Verb       = a parser action (match-start, capture-field, close-block,
                                  emit-entry, write-json)
    Action     = the resulting JSON entry written to the output directory

The engine is a tiny indent-aware state machine:

    1. Read the input line by line, tracking indent depth.
    2. At depth 0, test every section regex (in declaration order).
       First match wins. Extract named-group captures into the entry.
    3. If the section is `block`, recursively parse the indented body until
       a matching `exit` (or a blank line followed by another column-0 line).
    4. If the section is `single_line`, emit the entry immediately.
    5. Body lines are parsed as one of:
          `key value...`        → key=value (or appended if repeated)
          `no key`              → key=false
          `keyword args`        → opens a sub-block (nested)
    6. Lines at column 0 that match nothing go to `unparsed.json`.

Run:
    python3 sonicwall_parser.py \
        --config parser_config.ini \
        --input input/slimmed-sonicwallconfig.txt
"""

from __future__ import annotations

import argparse
import configparser
import datetime as _dt
import json
import os
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Make schema_lib importable when running from this directory
_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))
from schema_lib import validate_at_startup  # noqa: E402


# ---------------------------------------------------------------------------
# Section definition (one per [section.<name>] in the INI)
# ---------------------------------------------------------------------------
@dataclass
class SectionDef:
    name: str
    description: str
    pattern: re.Pattern
    form: str                       # 'block' | 'single_line' | 'block_or_single'
    output_file: str
    key_field: str | None = None
    list_fields: set[str] = field(default_factory=set)
    ignore_fields: set[str] = field(default_factory=set)
    priority: int = 100


# ---------------------------------------------------------------------------
# A captured entry in flight
# ---------------------------------------------------------------------------
@dataclass
class Entry:
    section_name: str
    start_line: int
    end_line: int = 0
    captures: dict[str, Any] = field(default_factory=dict)
    body: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Parser engine
# ---------------------------------------------------------------------------
class SonicWallParser:
    def __init__(self, config_path: Path):
        self.config_path = config_path
        self.cp = configparser.ConfigParser(
            interpolation=None,                # keep `%` raw
            inline_comment_prefixes=(";",),    # ; ends a value; # only at line start
            comment_prefixes=("#",),
        )
        self.cp.read(config_path, encoding="utf-8")

        self.parser_settings = self._load_parser_settings()
        self.output_settings = self._load_output_settings()
        self.sections: list[SectionDef] = self._load_section_defs()

        # in-memory output: section_name -> list[Entry]
        self.entries: dict[str, list[Entry]] = {s.name: [] for s in self.sections}
        self.entries["_unparsed"] = []

        self.indent_unit = " " * int(self.parser_settings["indent_size"])
        self.block_terminator = self.parser_settings["block_terminator"]
        self.strip_quotes = self.parser_settings["strip_quotes"]
        self.parse_no_negation = self.parser_settings["parse_no_negation"]
        self.auto_collect_repeated = self.parser_settings["auto_collect_repeated"]
        self.unmatched_body_action = self.parser_settings["unmatched_body_action"]
        self.body_comment_prefix = self.parser_settings["body_comment_prefix"]

        # Optional version-router hook. When set by the caller (typically
        # main() after detecting the SonicOS branch from the input), this
        # callable is consulted on every body-line PLAIN-VALUE field (NOT
        # sub-blocks, NOT 'no <key>' negations). The signature is:
        #     handler(head: str, rest: str) -> dict | None
        # When the handler returns a dict, EACH key in the dict is stored
        # as a separate field in the block body, and the baseline single-
        # field store is skipped. When None, baseline behavior runs.
        #
        # This is the integration point for INI-driven SonicOS-version
        # exceptions (see sonicwall_parser/version_exceptions.ini and
        # sonicos_version_router.py). The parser itself stays generic;
        # all version-specific logic lives in the router and its INIs.
        self.field_value_handler = None

    # -- INI loaders ---------------------------------------------------------
    def _bool(self, v: str) -> bool:
        return v.strip().lower() in ("true", "yes", "1", "on")

    def _load_parser_settings(self) -> dict[str, Any]:
        s = self.cp["parser"]
        return {
            "block_terminator":      s.get("block_terminator", "exit").strip(),
            "indent_style":          s.get("indent_style", "spaces").strip(),
            "indent_size":           int(s.get("indent_size", "4")),
            "strip_quotes":          self._bool(s.get("strip_quotes", "true")),
            "parse_no_negation":     self._bool(s.get("parse_no_negation", "true")),
            "auto_collect_repeated": self._bool(s.get("auto_collect_repeated", "true")),
            "unmatched_body_action": s.get("unmatched_body_action", "preserve").strip(),
            "body_comment_prefix":   s.get("body_comment_prefix", "#").strip(),
        }

    def _load_output_settings(self) -> dict[str, Any]:
        s = self.cp["output"]
        return {
            "directory":            s.get("directory", "output").strip(),
            "indent_json":          int(s.get("indent_json", "2")),
            "envelope_id_field":    s.get("envelope_id_field", "_id").strip(),
            "envelope_source_lines": s.get("envelope_source_lines", "_source_lines").strip(),
            "envelope_section_name": s.get("envelope_section_name", "_section").strip(),
            "list_wrapper_key":     s.get("list_wrapper_key", "entries").strip(),
            "include_run_metadata": self._bool(s.get("include_run_metadata", "true")),
        }

    def _load_section_defs(self) -> list[SectionDef]:
        defs: list[SectionDef] = []
        for sect_name in self.cp.sections():
            if not sect_name.startswith("section."):
                continue
            short = sect_name.split(".", 1)[1]
            cfg = self.cp[sect_name]

            # multi-line values (configparser folds continuation lines with '\n')
            raw_regex = cfg.get("match_regex", "").replace("\n", "")
            if not raw_regex:
                print(f"  WARN: [{sect_name}] has no match_regex — skipped",
                      file=sys.stderr)
                continue
            try:
                pat = re.compile(raw_regex)
            except re.error as e:
                print(f"  WARN: [{sect_name}] bad regex: {e} — skipped",
                      file=sys.stderr)
                continue

            list_fields = self._csv(cfg.get("list_fields", ""))
            ignore_fields = self._csv(cfg.get("ignore_fields", ""))

            defs.append(SectionDef(
                name=short,
                description=cfg.get("description", "").strip().replace("\n", " "),
                pattern=pat,
                form=cfg.get("form", "block").strip(),
                output_file=cfg.get("output_file", f"{short}.json").strip(),
                key_field=cfg.get("key_field", "").strip() or None,
                list_fields=list_fields,
                ignore_fields=ignore_fields,
                priority=int(cfg.get("priority", "100")),
            ))
        return defs

    @staticmethod
    def _csv(s: str) -> set[str]:
        return {x.strip() for x in s.replace("\n", " ").split(",") if x.strip()}

    def apply_section_regex_overrides(self, override_lookup,
                                      form_override_lookup=None) -> int:
        """Walk self.sections and re-compile any section's pattern when
        the override_lookup(section_name) returns a replacement regex
        string. Optionally also override the section's form (block /
        single_line / block_or_single) when form_override_lookup is
        supplied and returns a non-None value for the section.

        override_lookup:      callable (section_name) -> str | None
        form_override_lookup: callable (section_name) -> str | None
                              When provided AND returns non-None for a
                              section, sect.form is replaced with the
                              returned value.

        Used by main() AFTER instantiating the router so that
        version-specific section regexes (e.g. SonicOS 6.2's bare
        'access-rule from' form, or its inline 'address-object ... host ...'
        form) replace the baseline rules from parser_config.ini before
        parsing begins.

        Returns the number of sections whose regex was overridden.
        """
        if override_lookup is None:
            return 0
        n_overridden = 0
        for sect in self.sections:
            new_rx = override_lookup(sect.name)
            if not new_rx:
                continue
            new_rx = new_rx.replace("\n", "").strip()
            if not new_rx:
                continue
            try:
                sect.pattern = re.compile(new_rx)
                n_overridden += 1
                # Form override (optional companion). Only logged if the
                # form actually changes from the baseline.
                if form_override_lookup is not None:
                    new_form = form_override_lookup(sect.name)
                    if new_form and new_form != sect.form:
                        old_form = sect.form
                        sect.form = new_form
                        print(
                            f"  [version-router] section-form override "
                            f"applied: [{sect.name}] {old_form} -> "
                            f"{new_form}",
                            file=sys.stderr,
                        )
                print(
                    f"  [version-router] section-regex override "
                    f"applied: [{sect.name}]",
                    file=sys.stderr,
                )
            except re.error as e:
                print(
                    f"  WARN: section-regex override for [{sect.name}] "
                    f"failed to compile: {e}; baseline regex retained.",
                    file=sys.stderr,
                )
        return n_overridden

    # -- Helpers -------------------------------------------------------------
    def _strip_quotes(self, v: str) -> str:
        if not self.strip_quotes:
            return v
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in ("\"", "'"):
            return v[1:-1]
        return v

    def _normalize_value(self, v: str) -> Any:
        v = self._strip_quotes(v.strip())
        # Try to coerce common scalars
        if v == "":
            return ""
        if v.isdigit():
            try:
                return int(v)
            except ValueError:
                return v
        return v

    def _depth(self, line: str) -> int:
        """Count leading spaces in indent units. Tabs count as one indent unit."""
        n = 0
        for ch in line:
            if ch == " ":
                n += 1
            elif ch == "\t":
                n += int(self.parser_settings["indent_size"])
            else:
                break
        return n // int(self.parser_settings["indent_size"])

    def _add_field(self, target: dict, key: str, value: Any, force_list: bool):
        """Set target[key]=value, accumulating into a list if needed."""
        if force_list:
            target.setdefault(key, [])
            if isinstance(target[key], list):
                target[key].append(value)
            else:                                # someone made it scalar earlier
                target[key] = [target[key], value]
            return
        if key in target:
            if not self.auto_collect_repeated:
                target[key] = value              # last-wins
                return
            if isinstance(target[key], list):
                target[key].append(value)
            else:
                target[key] = [target[key], value]
        else:
            target[key] = value

    # -- Body parsing (recursive, indent-aware) ------------------------------
    def _parse_body(
        self,
        lines: list[str],
        idx: int,
        target_depth: int,
        section: SectionDef | None,
    ) -> tuple[dict, int]:
        """Parse a block at exactly target_depth. Return (body_dict, next_idx).

        Stops on:
          - a line at depth < target_depth (caller handles it)
          - the block_terminator at any depth >= target_depth-1
          - end of file
        """
        body: dict[str, Any] = {}
        n = len(lines)

        while idx < n:
            raw = lines[idx]
            stripped = raw.strip()
            if stripped == "":
                idx += 1
                continue

            # Skip in-source comment lines (e.g. `# Error: Invalid command: ...`)
            if self.body_comment_prefix and stripped.startswith(self.body_comment_prefix):
                idx += 1
                continue

            d = self._depth(raw)

            # block_terminator at our depth (or shallower) closes this block
            if stripped == self.block_terminator and d <= target_depth:
                idx += 1
                return body, idx

            if d < target_depth:
                # someone else's territory — let caller handle it
                return body, idx

            if d > target_depth:
                # over-indented orphan (rare); preserve verbatim
                if self.unmatched_body_action == "preserve":
                    body.setdefault("_unparsed_lines", []).append(stripped)
                idx += 1
                continue

            # d == target_depth: normal body line
            tokens = stripped.split(None, 1)
            head = tokens[0]
            rest = tokens[1] if len(tokens) > 1 else ""

            # 'no <key> [args]' → false (or remove)
            if head == "no" and self.parse_no_negation and rest:
                neg_tokens = rest.split(None, 1)
                neg_key = neg_tokens[0]
                if section and neg_key in section.ignore_fields:
                    idx += 1
                    continue
                # If the negated form has further args, store false but record args
                if len(neg_tokens) > 1:
                    self._add_field(body, neg_key, {"_disabled": True,
                                                    "_args": neg_tokens[1]},
                                    force_list=section is not None
                                    and neg_key in section.list_fields)
                else:
                    self._add_field(body, neg_key, False,
                                    force_list=section is not None
                                    and neg_key in section.list_fields)
                idx += 1
                continue

            # Check: does the next non-blank line have greater depth?
            # If so, this line opens a sub-block.
            next_idx = idx + 1
            while next_idx < n and lines[next_idx].strip() == "":
                next_idx += 1
            opens_block = (
                next_idx < n
                and self._depth(lines[next_idx]) > target_depth
                and lines[next_idx].strip() != self.block_terminator
            )

            if section and head in section.ignore_fields:
                # skip silently; if it opens a block, skip the block too
                if opens_block:
                    _, idx = self._parse_body(lines, next_idx, target_depth + 1, None)
                else:
                    idx += 1
                continue

            if opens_block:
                # Sub-block. The 'rest' is the sub-block's args.
                sub_body, idx = self._parse_body(
                    lines, next_idx, target_depth + 1, None
                )
                sub_obj: dict[str, Any] = {}
                if rest:
                    sub_obj["_args"] = self._normalize_value(rest)
                sub_obj.update(sub_body)
                force = section is not None and head in section.list_fields
                self._add_field(body, head, sub_obj, force_list=force)
            else:
                # Plain key/value line.
                # First consult the optional version-router field-value
                # handler. When the active SonicOS branch declares an
                # exception that matches (head, rest), it returns a
                # named-group dict and EACH key gets stored as its own
                # field — so combined-form values like
                #     ip 192.168.168.168 netmask 255.255.255.0
                # land as TWO fields (ip, netmask), not one freetext blob.
                # When the handler returns None (default branch, or no
                # matching rule), baseline single-field behavior runs.
                if rest and self.field_value_handler is not None:
                    split_result = self.field_value_handler(head, rest)
                    if split_result is not None:
                        for k, v in split_result.items():
                            if v is None or v == "":
                                continue
                            sub_force = (
                                section is not None
                                and k in section.list_fields
                            )
                            self._add_field(
                                body, k, self._normalize_value(v),
                                force_list=sub_force,
                            )
                        idx += 1
                        continue
                # Baseline behavior: store whole rest under head.
                value: Any = self._normalize_value(rest) if rest else True
                force = section is not None and head in section.list_fields
                self._add_field(body, head, value, force_list=force)
                idx += 1

        return body, idx

    # -- Top-level walk ------------------------------------------------------
    def parse_file(self, input_path: Path) -> None:
        with open(input_path, encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()

        n = len(lines)
        idx = 0

        while idx < n:
            raw = lines[idx]
            stripped = raw.strip()
            if stripped == "":
                idx += 1
                continue

            d = self._depth(raw)
            if d != 0:
                # orphan indented line at top level — record and continue
                self.entries["_unparsed"].append(Entry(
                    section_name="_unparsed",
                    start_line=idx + 1,
                    end_line=idx + 1,
                    captures={"line": stripped, "kind": "orphan_indented"},
                ))
                idx += 1
                continue

            # Try every section's regex in declaration order
            matched_section: SectionDef | None = None
            match: re.Match | None = None
            for sect in self.sections:
                m = sect.pattern.match(stripped)
                if m:
                    matched_section = sect
                    match = m
                    break

            if matched_section is None:
                # Unknown top-level statement. Decide if it's a single line or a block.
                next_idx = idx + 1
                while next_idx < n and lines[next_idx].strip() == "":
                    next_idx += 1
                if next_idx < n and self._depth(lines[next_idx]) > 0:
                    body, end_idx = self._parse_body(lines, next_idx, 1, None)
                    self.entries["_unparsed"].append(Entry(
                        section_name="_unparsed",
                        start_line=idx + 1,
                        end_line=end_idx,
                        captures={
                            "line": stripped,
                            "kind": "unknown_block",
                            "body": body,
                        },
                    ))
                    idx = end_idx
                else:
                    self.entries["_unparsed"].append(Entry(
                        section_name="_unparsed",
                        start_line=idx + 1,
                        end_line=idx + 1,
                        captures={"line": stripped, "kind": "unknown_statement"},
                    ))
                    idx += 1
                continue

            # We have a section match. Build the entry.
            captures = {
                k: self._normalize_value(v)
                for k, v in match.groupdict(default="").items()
                if v is not None
            }
            entry = Entry(
                section_name=matched_section.name,
                start_line=idx + 1,
                captures=captures,
            )

            if matched_section.form == "single_line":
                entry.end_line = idx + 1
                idx += 1
            else:
                # block (or block_or_single — treat as block since col-0 line is the start)
                next_idx = idx + 1
                while next_idx < n and lines[next_idx].strip() == "":
                    next_idx += 1
                if matched_section.form == "block_or_single" \
                        and (next_idx >= n or self._depth(lines[next_idx]) == 0):
                    entry.end_line = idx + 1
                    idx += 1
                else:
                    body, end_idx = self._parse_body(
                        lines, next_idx, 1, matched_section
                    )
                    entry.body = body
                    entry.end_line = end_idx
                    idx = end_idx

            self.entries[matched_section.name].append(entry)

    # -- Output --------------------------------------------------------------
    def _entry_to_json(self, e: Entry, sect: SectionDef | None) -> dict:
        out: dict[str, Any] = {}

        # Envelope
        if self.output_settings["envelope_section_name"]:
            out[self.output_settings["envelope_section_name"]] = e.section_name
        if self.output_settings["envelope_id_field"]:
            id_value = self._derive_id(e, sect)
            out[self.output_settings["envelope_id_field"]] = id_value
        if self.output_settings["envelope_source_lines"]:
            out[self.output_settings["envelope_source_lines"]] = [
                e.start_line, e.end_line
            ]

        # Captures from the start-line regex
        for k, v in e.captures.items():
            out[k] = v

        # Body fields
        for k, v in e.body.items():
            out[k] = v

        return out

    def _derive_id(self, e: Entry, sect: SectionDef | None) -> str:
        if sect and sect.key_field:
            kf = sect.key_field
            if kf in e.captures:
                return str(e.captures[kf])
            if kf in e.body:
                return str(e.body[kf])
        # Fallbacks: name, uuid, or first capture group, or line-number based
        for k in ("name", "uuid", "id"):
            if k in e.captures:
                return str(e.captures[k])
            if k in e.body:
                return str(e.body[k])
        if e.captures:
            return next(iter(e.captures.values()))
        return f"L{e.start_line}"

    def write_outputs(self, output_dir: Path, source_path: Path) -> dict:
        output_dir.mkdir(parents=True, exist_ok=True)
        run_meta = {
            "parser_version": dict(self.cp["meta"]).get("version", "?"),
            "parser_name": dict(self.cp["meta"]).get("name", "?"),
            "source_file": str(source_path),
            "generated_at": _dt.datetime.now().isoformat(timespec="seconds"),
        }
        manifest: dict[str, Any] = {
            "_meta": run_meta,
            "files": {},
            "totals": {},
        }

        # Map section_name -> SectionDef for emit
        sect_by_name = {s.name: s for s in self.sections}

        # Build a separate dict for unparsed (no SectionDef)
        sect_by_name["_unparsed"] = SectionDef(
            name="_unparsed",
            description="Lines and blocks not matched by any [section.*] pattern.",
            pattern=re.compile(""),
            form="single_line",
            output_file="_unparsed.json",
        )

        for sect_name, entries in self.entries.items():
            sect = sect_by_name[sect_name]
            data = [self._entry_to_json(e, sect) for e in entries]

            if self.output_settings["list_wrapper_key"]:
                payload: Any = {
                    self.output_settings["list_wrapper_key"]: data,
                }
                if self.output_settings["include_run_metadata"]:
                    payload["_meta"] = {
                        **run_meta,
                        "section": sect_name,
                        "description": sect.description,
                        "count": len(data),
                    }
            else:
                payload = data

            outfile = output_dir / sect.output_file
            with open(outfile, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=self.output_settings["indent_json"],
                          ensure_ascii=False)
                f.write("\n")

            manifest["files"][sect_name] = sect.output_file
            manifest["totals"][sect_name] = len(data)

        # Write manifest
        with open(output_dir / "_manifest.json", "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=self.output_settings["indent_json"],
                      ensure_ascii=False)
            f.write("\n")

        return manifest


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(
        description="Parse a SonicOS Enhanced config into per-section JSON files."
    )
    ap.add_argument("--config", default="parser_config.ini",
                    help="Path to parser_config.ini (default: parser_config.ini)")
    ap.add_argument("--input", required=True,
                    help="Path to the SonicWall config text file")
    ap.add_argument("--output-dir", default=None,
                    help="Override [output] directory= from the INI")
    ap.add_argument("--strict", action="store_true",
                    help="Exit non-zero if schema validation finds errors")
    ap.add_argument("--no-validate", action="store_true",
                    help="Skip schema validation entirely")
    args = ap.parse_args()

    cfg_path = Path(args.config)
    if not cfg_path.is_file():
        print(f"ERROR: config not found: {cfg_path}", file=sys.stderr)
        return 2

    inp_path = Path(args.input)
    if not inp_path.is_file():
        print(f"ERROR: input not found: {inp_path}", file=sys.stderr)
        return 2

    # Schema validation gate
    if not args.no_validate:
        report = validate_at_startup(cfg_path, engine_name="parser")
        if report is not None and not report.ok and args.strict:
            print("ERROR: --strict and schema validation failed; "
                  "aborting before parse.", file=sys.stderr)
            return 3

    parser = SonicWallParser(cfg_path)

    # SonicOS version detection — non-fatal. The router scans the input
    # for the firmware-version declaration, picks the matching branch
    # (or falls back to the default = 6.5 baseline), and loads any
    # parser-time field-pattern exceptions for that branch from
    # version_exceptions.ini. The parser uses these via the
    # field_value_handler hook on plain key/value body lines.
    try:
        from sonicos_version_router import get_router
        router = get_router(inp_path)
        parser.field_value_handler = router.split_field_value
        # Apply per-section regex overrides for the active branch.
        # E.g. SonicOS 6.2 emits 'access-rule from ...' (no ipv4 keyword)
        # where 6.5 emits 'access-rule ipv4 from ...'. The router's
        # override_section_regex() returns the replacement regex from
        # version_exceptions.ini for the matching section, or None.
        parser.apply_section_regex_overrides(
            router.override_section_regex,
            router.override_section_form,
        )
        version_manifest = router.manifest_record()
    except ImportError as e:
        print(
            f"  WARN: sonicos_version_router not available ({e}); "
            f"running with baseline rules only.",
            file=sys.stderr,
        )
        router = None
        version_manifest = {
            'sonicos_version_branch_used': 'default',
            'reason': 'router_module_not_importable',
        }

    out_dir = Path(args.output_dir) if args.output_dir \
              else (cfg_path.parent / parser.output_settings["directory"])

    print(f"Parser:    {cfg_path}")
    print(f"Input:     {inp_path}")
    print(f"Output:    {out_dir}")
    print(f"Sections:  {len(parser.sections)} declared")
    if router is not None:
        print(
            f"SonicOS:   branch={version_manifest['sonicos_version_branch_used']!r} "
            f"firmware={version_manifest['sonicos_version_detected']!r} "
            f"model={version_manifest['sonicos_model_detected']!r} "
            f"exceptions={len(version_manifest['exception_rules_loaded'])}"
        )
    print()

    parser.parse_file(inp_path)
    manifest = parser.write_outputs(out_dir, inp_path)
    # Attach SonicOS version provenance to the parser manifest for audit,
    # then re-persist the manifest file so the provenance lands on disk.
    if isinstance(manifest, dict):
        manifest['sonicos_version'] = version_manifest
        manifest_path = out_dir / '_manifest.json'
        try:
            import json as _json
            with open(manifest_path, 'w', encoding='utf-8') as _mf:
                _json.dump(
                    manifest, _mf,
                    indent=parser.output_settings.get('indent_json', 2),
                    ensure_ascii=False,
                )
                _mf.write('\n')
        except OSError as e:
            print(
                f"  WARN: failed to update manifest with version info: {e}",
                file=sys.stderr,
            )

    print("Counts:")
    for name in sorted(manifest["totals"], key=lambda n: -manifest["totals"][n]):
        n = manifest["totals"][name]
        print(f"  {n:>6}  {name}")
    print(f"\nManifest: {out_dir}/_manifest.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
