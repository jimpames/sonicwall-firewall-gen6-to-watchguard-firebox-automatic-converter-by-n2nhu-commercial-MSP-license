#!/usr/bin/env python3
"""
relevance_filter.py
====================

Phase 7 (DESIGN_team_scale_addendum.md). Captain J P Ames' insight:

    "we see it's OFF in the html, we actually SKIP that entire
    translation and make a note in our report - could save us weeks
    of aggravation"

Phase 6 applied this on the OUTPUT side (WatchGuard schema-learner
filters surfaces by enabled-status). Phase 7 applies the same logic
on the INPUT side (SonicWall parser output → translator workload).

Mission: classify every parsed SonicWall entry into one of four buckets
so the translator only spends operator-attention on what matters.

Classification taxonomy:

  vendor_builtin     — vendor-defined object (HTTP, LAN zone, default
                       zone-to-zone access rule, etc.). Maps 1:1 to
                       WatchGuard equivalent. No operator decision
                       needed. Translator emits passthrough.

  customer_defined   — operator-named, customer-configured object.
                       This is the actual translation workload.
                       Must go through concept_map + xml_emit.

  dead_unreferenced  — address-object or service-object that no
                       access-rule, NAT, or VPN policy references.
                       Dead config. Translator skips with audit log.

  disabled_in_source — access-rule or policy explicitly disabled
                       (enable=false). Phase 6 same-side: translator
                       can defer with auto-promotion semantics.

Output:

  <output_dir>/filtered/
    customer_defined.json    — entries the translator must process
    vendor_builtin.json      — entries with passthrough hints
    dead_unreferenced.json   — entries to skip (logged)
    disabled_in_source.json  — entries deferred (Phase 6 style)
    migration_scope.md       — operator-facing summary report

The principle binding:

  This module produces STRUCTURAL OBSERVATIONS (counts, classifications)
  only. Operator-vouched curation lives in builtin_objects.ini — the
  module reads it; it does not modify it. Classification is mechanical
  given the curated list; the LIST itself is the operator declaration.

Run:
    python3 relevance_filter.py \\
        --parser-output sonicwall_parser/output \\
        --builtins sonicwall_parser/builtin_objects.ini \\
        --output sonicwall_parser/filtered
"""
from __future__ import annotations

import argparse
import configparser
import datetime as _dt
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Curated built-in registry loader
# ---------------------------------------------------------------------------

@dataclass
class BuiltinRegistry:
    """Operator-vouched lists of vendor built-in objects."""
    services: set[str] = field(default_factory=set)
    service_groups: set[str] = field(default_factory=set)
    zones: set[str] = field(default_factory=set)
    address_objects: set[str] = field(default_factory=set)
    schedules: set[str] = field(default_factory=set)
    # Comment-pattern matching for auto-generated access rules
    access_rule_comment_patterns: set[str] = field(default_factory=set)
    # Where the registry was loaded from (for provenance)
    source_path: str = ""
    sonicos_version: str = ""


def load_builtin_registry(path: Path) -> BuiltinRegistry:
    """Load operator-curated built-in registry from INI."""
    if not path.is_file():
        raise FileNotFoundError(
            f"builtin_objects.ini not found: {path}. "
            f"This file is operator-curated and must exist for "
            f"relevance filtering to run. See "
            f"sonicwall_parser/builtin_objects.ini for the template.")

    cp = configparser.ConfigParser(interpolation=None,
                                    inline_comment_prefixes=(';',))
    cp.optionxform = str  # preserve case in names
    cp.read(path, encoding='utf-8')

    reg = BuiltinRegistry(source_path=str(path))
    reg.sonicos_version = cp.get('meta', 'sonicos_version',
                                  fallback='unknown')

    def _section_keys(section: str) -> set[str]:
        """Return the keys (names) declared as built-in in a section.
        Only entries with value 'true' (case-insensitive) count as
        registered."""
        if not cp.has_section(section):
            return set()
        keys: set[str] = set()
        for key, value in cp.items(section):
            if value.strip().lower() == 'true':
                keys.add(key.strip())
        return keys

    reg.services = _section_keys('services')
    reg.service_groups = _section_keys('service_groups')
    reg.zones = _section_keys('zones')
    reg.address_objects = _section_keys('address_objects')
    reg.schedules = _section_keys('schedules')

    # Access-rule comment patterns — values themselves are the patterns
    if cp.has_section('access_rule_patterns'):
        for key, value in cp.items('access_rule_patterns'):
            v = value.strip()
            if v:
                reg.access_rule_comment_patterns.add(v)

    return reg


# ---------------------------------------------------------------------------
# Reference index
# ---------------------------------------------------------------------------
# To detect dead_unreferenced, we need to know what references what.
# This index is computed once from all parsed JSON, then queried per
# entry. Cheap: a few thousand entries max.

@dataclass
class ReferenceIndex:
    """For each addressable object name, the count of references to it
    from access-rules, NAT, VPN, route, and group definitions.
    
    The address-object 'Proxmox 10.12.140.0' is unreferenced if no
    access-rule, NAT-policy, VPN-policy, route, or address-group
    mentions it.
    """
    # name -> count of references found
    address_refs: dict[str, int] = field(default_factory=dict)
    service_refs: dict[str, int] = field(default_factory=dict)
    
    def bump_address(self, name: str) -> None:
        if name and name != 'any':
            self.address_refs[name] = self.address_refs.get(name, 0) + 1
    
    def bump_service(self, name: str) -> None:
        if name and name != 'any':
            self.service_refs[name] = self.service_refs.get(name, 0) + 1


def build_reference_index(parser_output_dir: Path) -> ReferenceIndex:
    """Walk all parsed JSON outputs and build a reference index.
    
    Counts mentions of address-object and service-object names from
    access-rules, NAT policies, VPN policies, routes, and groups.
    
    SonicWall CLI value-string grammars handled by the tokenizer:
    
      'port name "Apple Bonjour"'           -> Apple Bonjour
      'service name "Apple Bonjour"'        -> Apple Bonjour
      'address group "DMZ Subnets"'         -> DMZ Subnets
      'source group "All Rogue Devices"'    -> All Rogue Devices
      'remote name someremotepeerfake'      -> someremotepeerfake
      'local group "LAN Subnets"'           -> LAN Subnets
      'primary fakeprigwtun'                -> fakeprigwtun
      'secondary fakesecgwtun'              -> fakesecgwtun
      'ipv6 "X0 IPv6 Primary"'              -> X0 IPv6 Primary
      'RPC Services (IANA)'                 -> RPC Services (IANA)
      'zone WAN'                            -> WAN
    
    The tokenizer applies two passes:
    
      1. Quoted-token extraction — anything between double-quotes
         is a name reference (high precision)
      
      2. Keyword-then-bareword extraction — after keywords like
         'name', 'group', 'primary', 'secondary', 'remote', 'local',
         'zone', 'ipv4', 'ipv6', a bare (unquoted) token is a name
    
    For service-group entries that LIST member names directly (as
    plain strings in service-object[] / service-group[] arrays),
    the entire string is the reference.
    """
    idx = ReferenceIndex()

    # Keywords that precede a name reference in SonicWall CLI fragments
    # When we see one of these in a string, the next bareword (or quoted
    # string) is a name reference.
    NAME_KEYWORDS = {
        'name', 'group', 'primary', 'secondary',
        'remote', 'local', 'zone',
    }
    # Family qualifiers that precede a name reference
    FAMILY_KEYWORDS = {'ipv4', 'ipv6'}

    # Quoted-string pattern: "..."
    _QUOTED = re.compile(r'"([^"]+)"')

    def _extract_refs_from_string(s: str) -> list[str]:
        """Extract name references from one CLI value string.
        Returns list of candidate referenced names."""
        refs: list[str] = []
        # Pass 1: every quoted token is a candidate name
        for m in _QUOTED.finditer(s):
            ref = m.group(1).strip()
            if ref:
                refs.append(ref)
        # Pass 2: keyword-then-bareword. Tokenize on whitespace and
        # walk the tokens; when we see a NAME_KEYWORD or FAMILY_KEYWORD,
        # the next token (if bareword, unquoted) is a name reference.
        # We strip the quoted regions first so they don't double-count.
        stripped = _QUOTED.sub(' ', s)
        tokens = stripped.split()
        i = 0
        while i < len(tokens):
            tok = tokens[i].lower()
            if tok in NAME_KEYWORDS or tok in FAMILY_KEYWORDS:
                # Peek the next token
                if i + 1 < len(tokens):
                    candidate = tokens[i + 1]
                    # Skip if next token is also a keyword (e.g.
                    # 'address group "..."' — 'group' is a NAME_KEYWORD
                    # but 'address' came first)
                    if candidate.lower() in NAME_KEYWORDS:
                        i += 1
                        continue
                    # Skip empties and obvious non-names
                    if candidate and candidate not in ('any', 'all'):
                        refs.append(candidate)
            i += 1
        return refs

    def _scan_value(v: Any, idx: ReferenceIndex,
                     is_list_member: bool = False) -> None:
        """Recursively scan a JSON value. List-members (e.g. inside
        service-object[] arrays) are treated as bare-name references
        in their entirety."""
        if isinstance(v, str):
            if is_list_member:
                # Inside a list like service-object[], each string is
                # generally a single name (possibly with qualifier).
                # We still tokenize to handle 'ipv6 "..."' patterns.
                refs = _extract_refs_from_string(v)
                if not refs:
                    # No structured refs found — treat whole string as
                    # a bare name (common case: service_groups members)
                    stripped = v.strip().strip('"').strip("'")
                    if stripped and stripped not in ('any', 'all'):
                        refs = [stripped]
                for ref in refs:
                    idx.bump_address(ref)
                    idx.bump_service(ref)
            else:
                # Plain field value — apply structured extraction
                refs = _extract_refs_from_string(v)
                for ref in refs:
                    idx.bump_address(ref)
                    idx.bump_service(ref)
        elif isinstance(v, dict):
            for sub_v in v.values():
                _scan_value(sub_v, idx, is_list_member=False)
        elif isinstance(v, list):
            for item in v:
                _scan_value(item, idx, is_list_member=True)

    # Sections whose entries reference other objects
    referencing_sections = [
        'access_rules', 'nat_policies', 'vpn_policies',
        'route_policies', 'address_groups', 'service_groups',
    ]

    for section in referencing_sections:
        path = parser_output_dir / f'{section}.json'
        if not path.is_file():
            continue
        data = json.loads(path.read_text(encoding='utf-8'))
        entries = data.get('entries', [])
        for entry in entries:
            for k, v in entry.items():
                # Skip the entry's own identity fields
                if k in ('_section', '_id', '_source_lines',
                         'name', 'uuid', 'family', '_classification'):
                    continue
                _scan_value(v, idx)

    return idx


# ---------------------------------------------------------------------------
# Classification result types
# ---------------------------------------------------------------------------

VALID_BUCKETS = (
    'customer_defined',
    'vendor_builtin',
    'dead_unreferenced',
    'disabled_in_source',
)


@dataclass
class ClassificationResult:
    """Result of classifying one parsed entry."""
    bucket: str
    reason: str  # short string, suitable for audit log + scope report
    # The original entry, augmented with `_classification` metadata
    entry: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Per-section classifiers
# ---------------------------------------------------------------------------

def classify_service_object(
    entry: dict[str, Any],
    registry: BuiltinRegistry,
    refs: ReferenceIndex,
) -> ClassificationResult:
    """Classify a service_objects entry."""
    name = entry.get('name', entry.get('_id', ''))
    if name in registry.services:
        return ClassificationResult(
            bucket='vendor_builtin',
            reason=f'service name {name!r} matches builtin_objects.ini '
                   f'[services] entry',
            entry=entry,
        )
    # Customer-defined service: check reference count
    ref_count = refs.service_refs.get(name, 0)
    if ref_count == 0:
        return ClassificationResult(
            bucket='dead_unreferenced',
            reason=f'service {name!r} not referenced by any '
                   f'access-rule, NAT, VPN, or service-group',
            entry=entry,
        )
    return ClassificationResult(
        bucket='customer_defined',
        reason=f'customer-named service ({ref_count} ref(s) found)',
        entry=entry,
    )


def classify_service_group(
    entry: dict[str, Any],
    registry: BuiltinRegistry,
    refs: ReferenceIndex,
) -> ClassificationResult:
    """Classify a service_groups entry."""
    name = entry.get('name', entry.get('_id', ''))
    if name in registry.service_groups:
        return ClassificationResult(
            bucket='vendor_builtin',
            reason=f'service-group {name!r} matches builtin_objects.ini '
                   f'[service_groups] entry',
            entry=entry,
        )
    ref_count = refs.service_refs.get(name, 0)
    if ref_count == 0:
        return ClassificationResult(
            bucket='dead_unreferenced',
            reason=f'service-group {name!r} not referenced',
            entry=entry,
        )
    return ClassificationResult(
        bucket='customer_defined',
        reason=f'customer-named service-group ({ref_count} ref(s))',
        entry=entry,
    )


def classify_address_object(
    entry: dict[str, Any],
    registry: BuiltinRegistry,
    refs: ReferenceIndex,
) -> ClassificationResult:
    """Classify an address_objects entry."""
    name = entry.get('name', entry.get('_id', ''))
    if name in registry.address_objects:
        return ClassificationResult(
            bucket='vendor_builtin',
            reason=f'address-object {name!r} matches builtin_objects.ini',
            entry=entry,
        )
    ref_count = refs.address_refs.get(name, 0)
    if ref_count == 0:
        return ClassificationResult(
            bucket='dead_unreferenced',
            reason=f'address-object {name!r} not referenced by any '
                   f'access-rule, NAT, VPN, or address-group',
            entry=entry,
        )
    return ClassificationResult(
        bucket='customer_defined',
        reason=f'customer-defined address ({ref_count} ref(s))',
        entry=entry,
    )


def classify_address_group(
    entry: dict[str, Any],
    registry: BuiltinRegistry,
    refs: ReferenceIndex,
) -> ClassificationResult:
    """Classify an address_groups entry. Address-groups are usually
    customer-defined; vendor built-ins are rare."""
    name = entry.get('name', entry.get('_id', ''))
    if name in registry.address_objects:
        # Treat address-group names same as address-objects for builtin
        return ClassificationResult(
            bucket='vendor_builtin',
            reason=f'address-group {name!r} matches builtin registry',
            entry=entry,
        )
    ref_count = refs.address_refs.get(name, 0)
    if ref_count == 0:
        return ClassificationResult(
            bucket='dead_unreferenced',
            reason=f'address-group {name!r} not referenced',
            entry=entry,
        )
    return ClassificationResult(
        bucket='customer_defined',
        reason=f'customer-defined address-group ({ref_count} ref(s))',
        entry=entry,
    )


def classify_access_rule(
    entry: dict[str, Any],
    registry: BuiltinRegistry,
    refs: ReferenceIndex,  # unused for rules but kept for signature parity
) -> ClassificationResult:
    """Classify an access_rules entry.
    
    Three-part check for vendor-builtin (auto-generated default):
      1. No `name` field set (anonymous)
      2. Comment matches one of the registry's auto-generated patterns
      3. Service is 'any' and source/destination are 'any'
    
    All three must be true. If ANY are false → customer-defined.
    Then: if customer-defined AND enable=false → disabled_in_source.
    """
    has_name = bool(entry.get('name')) and entry.get('name') is not False
    comment = entry.get('comment', '')
    service = entry.get('service', '')
    enabled = entry.get('enable', True)  # default to True if missing

    if not has_name:
        if comment in registry.access_rule_comment_patterns:
            if service == 'any':
                return ClassificationResult(
                    bucket='vendor_builtin',
                    reason=f'auto-generated zone-to-zone default '
                           f'({entry.get("from_zone", "?")} → '
                           f'{entry.get("to_zone", "?")} '
                           f'{entry.get("action", "?")})',
                    entry=entry,
                )

    # Customer-defined; check enabled-status (Phase 6 style)
    if enabled is False or enabled == 'false':
        return ClassificationResult(
            bucket='disabled_in_source',
            reason=f'access-rule explicitly disabled (enable=false)',
            entry=entry,
        )

    # Real customer-defined rule
    rule_name = entry.get('name') or entry.get('_id', 'unnamed')
    return ClassificationResult(
        bucket='customer_defined',
        reason=f'customer access-rule {rule_name!r}',
        entry=entry,
    )


def classify_zone(
    entry: dict[str, Any],
    registry: BuiltinRegistry,
    refs: ReferenceIndex,
) -> ClassificationResult:
    """Classify a zones entry."""
    name = entry.get('name', entry.get('_id', ''))
    if name in registry.zones:
        return ClassificationResult(
            bucket='vendor_builtin',
            reason=f'zone {name!r} matches builtin_objects.ini [zones]',
            entry=entry,
        )
    return ClassificationResult(
        bucket='customer_defined',
        reason=f'customer-defined zone {name!r}',
        entry=entry,
    )


def classify_schedule(
    entry: dict[str, Any],
    registry: BuiltinRegistry,
    refs: ReferenceIndex,
) -> ClassificationResult:
    """Classify a schedules entry."""
    name = entry.get('name', entry.get('_id', ''))
    if name in registry.schedules:
        return ClassificationResult(
            bucket='vendor_builtin',
            reason=f'schedule {name!r} matches builtin_objects.ini',
            entry=entry,
        )
    return ClassificationResult(
        bucket='customer_defined',
        reason=f'customer-defined schedule {name!r}',
        entry=entry,
    )


def classify_nat_policy(
    entry: dict[str, Any],
    registry: BuiltinRegistry,
    refs: ReferenceIndex,
) -> ClassificationResult:
    """Classify a nat_policies entry.
    
    SonicWall ships with a small set of default NAT policies (auto-
    generated outbound NAT, loopback NAT, etc). They're typically
    anonymous (no name field) and have auto-generated comment patterns.
    
    Customer-defined NAT policies have an operator-chosen name.
    
    Phase 6 enabled-status: if a NAT policy has enable=false, route
    it to disabled_in_source.
    """
    has_name = bool(entry.get('name')) and entry.get('name') is not False
    comment = entry.get('comment', '')
    enabled = entry.get('enable', True)
    
    # Phase 6 source-side: explicitly disabled → defer
    if enabled is False or enabled == 'false':
        return ClassificationResult(
            bucket='disabled_in_source',
            reason=f'nat-policy explicitly disabled (enable=false)',
            entry=entry,
        )
    
    if not has_name:
        # Anonymous NAT — check for auto-generated comment patterns
        if comment in registry.access_rule_comment_patterns:
            return ClassificationResult(
                bucket='vendor_builtin',
                reason=f'auto-generated NAT policy (comment matches)',
                entry=entry,
            )
        # Anonymous but no auto-pattern: treat conservatively as customer
        return ClassificationResult(
            bucket='customer_defined',
            reason=f'anonymous customer NAT policy '
                   f'(source={entry.get("source","?")[:40]})',
            entry=entry,
        )
    
    # Named NAT policy → customer-defined
    return ClassificationResult(
        bucket='customer_defined',
        reason=f'customer NAT policy {entry.get("name")!r}',
        entry=entry,
    )


def classify_vpn_policy(
    entry: dict[str, Any],
    registry: BuiltinRegistry,
    refs: ReferenceIndex,
) -> ClassificationResult:
    """Classify a vpn_policies entry.
    
    SonicWall ships with two GroupVPN policies (WAN GroupVPN,
    WLAN GroupVPN) that are present in every config but typically
    DISABLED by default. The classification is:
    
      - If enable=false → disabled_in_source (defer; Phase 6.5 lifecycle
        applies if customer enables them later)
      - If vpn_type='group-vpn' AND name is a known builtin GroupVPN
        → vendor_builtin (passes through with 1:1 WG equivalent)
      - Otherwise → customer_defined (operator-configured tunnel)
    
    The two SonicOS built-in GroupVPN policy names are well-known.
    """
    BUILTIN_GROUPVPN_NAMES = {'WAN GroupVPN', 'WLAN GroupVPN'}
    
    name = entry.get('name', entry.get('_id', ''))
    enabled = entry.get('enable', True)
    vpn_type = entry.get('vpn_type', '')
    
    # Phase 6 source-side: explicitly disabled → defer
    if enabled is False or enabled == 'false':
        return ClassificationResult(
            bucket='disabled_in_source',
            reason=f'vpn-policy {name!r} explicitly disabled '
                   f'(type={vpn_type}). Customer may enable later — '
                   f'Phase 6.5 auto-promotion applies.',
            entry=entry,
        )
    
    # Enabled vendor built-in GroupVPN (rare — typically disabled)
    if vpn_type == 'group-vpn' and name in BUILTIN_GROUPVPN_NAMES:
        return ClassificationResult(
            bucket='vendor_builtin',
            reason=f'built-in {name!r} (vendor-shipped GroupVPN), '
                   f'enabled in source',
            entry=entry,
        )
    
    # Customer-configured tunnel (site-to-site, named GroupVPN, etc)
    return ClassificationResult(
        bucket='customer_defined',
        reason=f'customer VPN policy {name!r} '
               f'(type={vpn_type or "unspecified"})',
        entry=entry,
    )


# Dispatch table — maps parser section name to classifier function.
# Sections NOT in this table get passed through unchanged with bucket
# 'customer_defined' (conservative: don't drop what we don't know how
# to classify).
CLASSIFIERS = {
    'service_objects': classify_service_object,
    'service_groups': classify_service_group,
    'address_objects': classify_address_object,
    'address_groups': classify_address_group,
    'access_rules': classify_access_rule,
    'zones': classify_zone,
    'schedules': classify_schedule,
    'nat_policies': classify_nat_policy,
    'vpn_policies': classify_vpn_policy,
}


# ---------------------------------------------------------------------------
# Main classification driver
# ---------------------------------------------------------------------------

@dataclass
class ClassificationStats:
    """Aggregate counts by section and bucket."""
    by_section: dict[str, dict[str, int]] = field(default_factory=dict)
    total_entries: int = 0
    
    def bump(self, section: str, bucket: str) -> None:
        if section not in self.by_section:
            self.by_section[section] = {b: 0 for b in VALID_BUCKETS}
        self.by_section[section][bucket] = (
            self.by_section[section].get(bucket, 0) + 1)
        self.total_entries += 1


@dataclass
class ConservationCheck:
    """Phase 7 hardening: verify entries-in == entries-out per section.
    
    Cardinal failure mode that bit us: parsed entries silently dropped
    between parser output and classified output. This dataclass tracks
    input counts and output counts per section so we can raise an
    error if any drops occur.
    """
    # Per-section: count of entries read from parser output
    input_counts: dict[str, int] = field(default_factory=dict)
    # Per-section: count of entries classified into any bucket
    output_counts: dict[str, int] = field(default_factory=dict)
    # Per-section: count of entries we found but had no classifier for
    unclassified_sections: dict[str, int] = field(default_factory=dict)
    
    def passes(self) -> bool:
        """All sections with a classifier must have in == out."""
        for section, input_n in self.input_counts.items():
            output_n = self.output_counts.get(section, 0)
            if input_n != output_n:
                return False
        return True
    
    def discrepancies(self) -> list[tuple[str, int, int]]:
        """Return [(section, in, out)] for any mismatch."""
        out = []
        for section, input_n in self.input_counts.items():
            output_n = self.output_counts.get(section, 0)
            if input_n != output_n:
                out.append((section, input_n, output_n))
        return out


@dataclass
class StaleOutputCheck:
    """Phase 7 hardening: detect stale parser output.
    
    The parser writes _meta.source_file into every JSON file. If the
    operator forgot to re-run the parser after changing the source,
    we'd silently filter stale data and report wrong classifications.
    
    This check reads source_file from each section's _meta and confirms
    they all agree. If they don't, we have a multi-source mess. If
    they're consistent but the operator didn't pass --expect-source
    confirming the source filename, we warn.
    """
    source_files_seen: set[str] = field(default_factory=set)
    sections_checked: int = 0
    
    def is_consistent(self) -> bool:
        """All section JSON files reference the same parser input."""
        return len(self.source_files_seen) <= 1
    
    @property
    def has_mixed_sources(self) -> bool:
        """Phase 7 hardening: True when parser output references
        multiple distinct source files — a stale-cache mix that
        would cause the filter to classify data from different
        captures together. Operator should re-run the parser.
        """
        return len(self.source_files_seen) > 1
    
    def the_source(self) -> str:
        if not self.source_files_seen:
            return "(none — no _meta.source_file fields found)"
        return next(iter(self.source_files_seen))


def check_parser_output_freshness(
    parser_output_dir: Path,
    expect_source: str | None = None,
) -> StaleOutputCheck:
    """Walk every <section>.json in parser_output_dir and read
    _meta.source_file. Returns aggregated check result."""
    check = StaleOutputCheck()
    for json_path in sorted(parser_output_dir.glob('*.json')):
        if json_path.name.startswith('_'):
            continue
        try:
            data = json.loads(json_path.read_text(encoding='utf-8'))
        except (json.JSONDecodeError, OSError):
            continue
        meta = data.get('_meta', {})
        src = meta.get('source_file', '')
        if src:
            check.source_files_seen.add(src)
            check.sections_checked += 1
    return check


def classify_all(
    parser_output_dir: Path,
    registry: BuiltinRegistry,
) -> tuple[dict[str, dict[str, list[dict]]],
            ClassificationStats,
            ConservationCheck]:
    """Run classification across all parser output sections.
    
    Returns (results, stats, conservation).
    
    The conservation check guarantees that for every section with a
    classifier, the number of input entries equals the number of
    output entries. If a section has no classifier (not in CLASSIFIERS
    dispatch), it's counted in conservation.unclassified_sections.
    """
    refs = build_reference_index(parser_output_dir)
    
    results: dict[str, dict[str, list[dict]]] = {}
    stats = ClassificationStats()
    conservation = ConservationCheck()
    
    # First pass: enumerate every section JSON file the parser produced.
    # This includes sections we don't have classifiers for.
    all_sections: list[tuple[str, Path]] = []
    for json_path in sorted(parser_output_dir.glob('*.json')):
        if json_path.name.startswith('_'):
            continue  # skip _manifest, _unparsed
        section_name = json_path.stem
        all_sections.append((section_name, json_path))
    
    # Second pass: classify the sections we have classifiers for.
    # Track everything else under unclassified_sections.
    for section_name, json_path in all_sections:
        data = json.loads(json_path.read_text(encoding='utf-8'))
        entries = data.get('entries', [])
        
        if section_name not in CLASSIFIERS:
            # No classifier — track for conservation but don't bucket
            if entries:
                conservation.unclassified_sections[section_name] = len(entries)
            continue
        
        classifier = CLASSIFIERS[section_name]
        conservation.input_counts[section_name] = len(entries)
        
        section_results: dict[str, list[dict]] = {
            b: [] for b in VALID_BUCKETS
        }
        out_count = 0
        for entry in entries:
            result = classifier(entry, registry, refs)
            entry_out = dict(entry)
            entry_out['_classification'] = {
                'bucket': result.bucket,
                'reason': result.reason,
                'classified_at': _dt.datetime.now().isoformat(),
            }
            section_results[result.bucket].append(entry_out)
            stats.bump(section_name, result.bucket)
            out_count += 1
        
        conservation.output_counts[section_name] = out_count
        results[section_name] = section_results
    
    return results, stats, conservation


# ---------------------------------------------------------------------------
# Output writers
# ---------------------------------------------------------------------------

def write_filtered_jsons(
    results: dict[str, dict[str, list[dict]]],
    output_dir: Path,
) -> None:
    """Write one JSON per bucket aggregating across sections.
    
    Files written:
      customer_defined.json    — translator workload
      vendor_builtin.json      — passthrough hints
      dead_unreferenced.json   — skip with audit log
      disabled_in_source.json  — defer (Phase 6 style)
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    
    aggregated: dict[str, dict[str, list[dict]]] = {
        b: {} for b in VALID_BUCKETS
    }
    
    for section, section_results in results.items():
        for bucket, entries in section_results.items():
            if entries:
                aggregated[bucket][section] = entries
    
    for bucket, sections in aggregated.items():
        out_path = output_dir / f'{bucket}.json'
        out_data = {
            '_meta': {
                'bucket': bucket,
                'generated_at': _dt.datetime.now().isoformat(),
                'section_count': len(sections),
                'entry_count': sum(len(v) for v in sections.values()),
            },
            'by_section': sections,
        }
        out_path.write_text(
            json.dumps(out_data, indent=2),
            encoding='utf-8',
        )


def write_migration_scope_report(
    stats: ClassificationStats,
    registry: BuiltinRegistry,
    output_dir: Path,
    source_label: str = "source SonicWall config",
) -> Path:
    """Produce the operator-facing migration_scope.md.
    
    This is the high-leverage output Captain wanted: 'here's what you
    need to actually triage; here's what auto-translates; here's what
    you can ignore.' One page, scannable, anchored in real counts.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / 'migration_scope.md'
    
    lines: list[str] = []
    lines.append(f"# Migration Scope Report")
    lines.append("")
    lines.append(f"**Source:** {source_label}")
    lines.append(f"**Generated:** {_dt.datetime.now().isoformat()}")
    lines.append(f"**Builtin registry:** "
                  f"`{Path(registry.source_path).name}` "
                  f"(SonicOS {registry.sonicos_version})")
    lines.append("")
    lines.append("---")
    lines.append("")
    
    # Aggregate stats
    grand_total = stats.total_entries
    by_bucket_total: dict[str, int] = {b: 0 for b in VALID_BUCKETS}
    for section, counts in stats.by_section.items():
        for bucket, count in counts.items():
            by_bucket_total[bucket] = by_bucket_total.get(bucket, 0) + count
    
    lines.append(f"## Summary")
    lines.append("")
    lines.append(f"Total classified entries: **{grand_total}**")
    lines.append("")
    if grand_total > 0:
        customer = by_bucket_total['customer_defined']
        builtin = by_bucket_total['vendor_builtin']
        dead = by_bucket_total['dead_unreferenced']
        disabled = by_bucket_total['disabled_in_source']
        actionable = customer
        non_actionable = builtin + dead + disabled
        pct_saved = (non_actionable / grand_total * 100) if grand_total else 0
        
        lines.append(f"| Bucket | Count | % of total |")
        lines.append(f"|---|---:|---:|")
        lines.append(f"| 🟢 **customer_defined** (translator workload) "
                     f"| {customer} | {customer/grand_total*100:.1f}% |")
        lines.append(f"| 🔵 vendor_builtin (passthrough) "
                     f"| {builtin} | {builtin/grand_total*100:.1f}% |")
        lines.append(f"| ⚪ dead_unreferenced (skip) "
                     f"| {dead} | {dead/grand_total*100:.1f}% |")
        lines.append(f"| 🟡 disabled_in_source (defer) "
                     f"| {disabled} | {disabled/grand_total*100:.1f}% |")
        lines.append("")
        lines.append(f"**Translator workload reduction: "
                     f"{pct_saved:.1f}%** ({non_actionable} of "
                     f"{grand_total} entries do not need operator triage)")
        lines.append("")
    
    # Per-section detail
    lines.append("## Per-section breakdown")
    lines.append("")
    lines.append(f"| Section | Total | Customer | Builtin | Dead | Disabled |")
    lines.append(f"|---|---:|---:|---:|---:|---:|")
    for section in sorted(stats.by_section.keys()):
        counts = stats.by_section[section]
        total = sum(counts.values())
        if total == 0:
            continue
        lines.append(
            f"| `{section}` | {total} "
            f"| {counts.get('customer_defined', 0)} "
            f"| {counts.get('vendor_builtin', 0)} "
            f"| {counts.get('dead_unreferenced', 0)} "
            f"| {counts.get('disabled_in_source', 0)} |"
        )
    lines.append("")
    
    # Next steps
    lines.append("## Next steps")
    lines.append("")
    if by_bucket_total['customer_defined'] > 0:
        lines.append(f"1. Translator runs against "
                     f"`filtered/customer_defined.json` "
                     f"({by_bucket_total['customer_defined']} entries)")
    if by_bucket_total['vendor_builtin'] > 0:
        lines.append(f"2. Vendor built-ins pass through with 1:1 "
                     f"WatchGuard mapping "
                     f"({by_bucket_total['vendor_builtin']} entries)")
    if by_bucket_total['dead_unreferenced'] > 0:
        lines.append(f"3. {by_bucket_total['dead_unreferenced']} dead "
                     f"entries logged but not migrated "
                     f"(see `filtered/dead_unreferenced.json`)")
    if by_bucket_total['disabled_in_source'] > 0:
        lines.append(f"4. {by_bucket_total['disabled_in_source']} "
                     f"disabled entries deferred — auto-promote "
                     f"if future config has them enabled "
                     f"(Phase 6.5 semantics)")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("*Operator override always available: if a "
                  "classification is wrong, edit the entry in the "
                  "appropriate `filtered/*.json` or update "
                  "`builtin_objects.ini` and re-run.*")
    
    report_path.write_text("\n".join(lines), encoding='utf-8')
    return report_path


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter)
    
    here = Path(__file__).resolve().parent
    
    ap.add_argument('--parser-output', type=Path,
                    default=here / 'output',
                    help='Directory containing parser JSON output '
                         '(default: sonicwall_parser/output)')
    ap.add_argument('--builtins', type=Path,
                    default=here / 'builtin_objects.ini',
                    help='Path to operator-curated built-in registry '
                         '(default: sonicwall_parser/builtin_objects.ini)')
    ap.add_argument('--output', type=Path,
                    default=here / 'filtered',
                    help='Output directory for filtered JSON + report '
                         '(default: sonicwall_parser/filtered)')
    ap.add_argument('--source-label', default='',
                    help='Label for the source config (appears in '
                         'migration_scope.md)')
    ap.add_argument('--expect-source', default='',
                    help='Phase 7 hardening: expected parser source '
                         "file (filename or path). If parser output's "
                         '_meta.source_file does NOT match this, the '
                         'filter refuses to run (prevents operating '
                         'on stale parser output).')
    ap.add_argument('--allow-stale', action='store_true',
                    help='Override the freshness check. Use only if '
                         'you have verified the parser output is '
                         'current for your intended source.')
    args = ap.parse_args(argv)

    # Defensive: clear error messages for missing inputs
    if not args.parser_output.is_dir():
        print(f"[relevance_filter] ERROR: parser output dir not found: "
              f"{args.parser_output}",
              file=sys.stderr)
        return 2
    if not args.builtins.is_file():
        print(f"[relevance_filter] ERROR: builtins registry not found: "
              f"{args.builtins}",
              file=sys.stderr)
        return 2

    # Phase 7 hardening — freshness check
    freshness = check_parser_output_freshness(args.parser_output)
    print(f"[relevance_filter] Parser output freshness check:")
    print(f"[relevance_filter]   sections checked: "
          f"{freshness.sections_checked}")
    print(f"[relevance_filter]   source file(s) referenced: "
          f"{freshness.the_source()}")
    if not freshness.is_consistent():
        print(f"[relevance_filter] ERROR: parser output is "
              f"inconsistent — multiple source files referenced: "
              f"{freshness.source_files_seen}",
              file=sys.stderr)
        print(f"[relevance_filter] Re-run the parser against a single "
              f"input to get consistent output.",
              file=sys.stderr)
        if not args.allow_stale:
            return 3
    if args.expect_source:
        observed = freshness.the_source()
        # Match either by filename suffix or exact path
        if not (args.expect_source in observed
                 or observed.endswith(args.expect_source)
                 or Path(observed).name == args.expect_source):
            print(f"[relevance_filter] ERROR: parser output source "
                  f"mismatch", file=sys.stderr)
            print(f"[relevance_filter]   --expect-source: "
                  f"{args.expect_source!r}", file=sys.stderr)
            print(f"[relevance_filter]   parser output references: "
                  f"{observed!r}", file=sys.stderr)
            print(f"[relevance_filter] Re-run the parser against the "
                  f"intended source, or pass --allow-stale to override.",
                  file=sys.stderr)
            if not args.allow_stale:
                return 3
        else:
            print(f"[relevance_filter]   ✓ source matches "
                  f"--expect-source {args.expect_source!r}")

    print(f"[relevance_filter] Loading builtin registry: {args.builtins}")
    registry = load_builtin_registry(args.builtins)
    print(f"[relevance_filter]   {len(registry.services)} services, "
          f"{len(registry.service_groups)} service-groups, "
          f"{len(registry.zones)} zones, "
          f"{len(registry.schedules)} schedules registered")
    
    print(f"[relevance_filter] Classifying entries from: "
          f"{args.parser_output}")
    results, stats, conservation = classify_all(args.parser_output,
                                                  registry)
    
    if stats.total_entries == 0:
        print(f"[relevance_filter] WARNING: 0 entries classified. "
              f"Check that parser output exists at {args.parser_output}")
        return 1
    
    # Phase 7 hardening — conservation check
    if not conservation.passes():
        print(f"[relevance_filter] ERROR: conservation check failed — "
              f"some classified sections lost entries",
              file=sys.stderr)
        for section, in_n, out_n in conservation.discrepancies():
            print(f"[relevance_filter]   {section}: "
                  f"{in_n} in, {out_n} out (LOST {in_n - out_n})",
                  file=sys.stderr)
        return 4
    
    # Unclassified-sections notice (informational, not fatal)
    if conservation.unclassified_sections:
        print(f"[relevance_filter] NOTICE: "
              f"{len(conservation.unclassified_sections)} "
              f"section(s) have no classifier (passed through as "
              f"unclassified):")
        for section, count in sorted(
                conservation.unclassified_sections.items()):
            print(f"[relevance_filter]   {section}: {count} entries")
        print(f"[relevance_filter] These are NOT in the filtered "
              f"output. Add a classifier in relevance_filter.py "
              f"CLASSIFIERS dispatch if migration coverage matters.")
    # Summary to stdout
    print(f"[relevance_filter]   {stats.total_entries} entries "
          f"classified across {len(results)} section(s):")
    for section in sorted(stats.by_section.keys()):
        counts = stats.by_section[section]
        total = sum(counts.values())
        cust = counts.get('customer_defined', 0)
        bi = counts.get('vendor_builtin', 0)
        dead = counts.get('dead_unreferenced', 0)
        dis = counts.get('disabled_in_source', 0)
        print(f"[relevance_filter]     {section:<20} "
              f"total={total:>4}  customer={cust:>4}  "
              f"builtin={bi:>4}  dead={dead:>4}  disabled={dis:>4}")
    
    by_bucket_total: dict[str, int] = {b: 0 for b in VALID_BUCKETS}
    for section, counts in stats.by_section.items():
        for bucket, count in counts.items():
            by_bucket_total[bucket] = by_bucket_total.get(bucket, 0) + count
    non_actionable = (by_bucket_total['vendor_builtin']
                       + by_bucket_total['dead_unreferenced']
                       + by_bucket_total['disabled_in_source'])
    pct = (non_actionable / stats.total_entries * 100
           if stats.total_entries else 0)
    print(f"[relevance_filter]   Translator workload reduction: "
          f"{pct:.1f}% ({non_actionable} of {stats.total_entries} "
          f"entries auto-handled)")
    
    # Write outputs
    write_filtered_jsons(results, args.output)
    print(f"[relevance_filter] Wrote filtered JSONs to: {args.output}")
    
    source_label = (args.source_label
                    or str(args.parser_output.parent.name))
    report_path = write_migration_scope_report(
        stats, registry, args.output, source_label=source_label)
    print(f"[relevance_filter] Wrote migration scope report: "
          f"{report_path}")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
