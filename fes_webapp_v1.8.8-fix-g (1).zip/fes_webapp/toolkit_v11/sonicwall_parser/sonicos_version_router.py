"""sonicos_version_router.py

Routes SonicOS-version-specific rule lookups through the version_detection.ini
+ version_exceptions.ini pair.

Public API (read by parser and downstream stages):

    router = get_router(input_path)        # module-level cached singleton
    router.branch                          # 'sonicos_6_5', 'sonicos_6_2',
                                           #  or 'default'
    router.firmware_version_observed       # raw string from e-CLI header
                                           #  or None if not present
    router.get_rule(rule_id)               # dict OR None — exception value
                                           #  if active branch has one,
                                           #  None means use baseline rule
    router.manifest_record()               # dict for build manifest

This module is import-safe: importing it has no side effects. The first
call to get_router(path) does the detection and caches the result by
input file path.

Provenance: Architecture chosen 2026-06-13 per Captain's call — single
catalog + version exception matrix (Path A2) over parallel per-version
catalogs (Path A1). Rationale documented inline in
version_detection.ini and version_exceptions.ini.
"""
from __future__ import annotations

import configparser
import re
import sys
from pathlib import Path
from typing import Optional


_PARSER_DIR = Path(__file__).parent


class SonicOSVersionRouter:
    """Single-input-file router. One instance per pipeline run."""

    def __init__(
        self,
        input_path: Path,
        detection_ini_path: Optional[Path] = None,
        exceptions_ini_path: Optional[Path] = None,
    ):
        self.input_path = Path(input_path)
        self.detection_ini_path = (
            detection_ini_path
            or _PARSER_DIR / 'version_detection.ini'
        )
        self.exceptions_ini_path = (
            exceptions_ini_path
            or _PARSER_DIR / 'version_exceptions.ini'
        )

        self.firmware_version_observed: Optional[str] = None
        self.model_observed: Optional[str] = None
        self.branch: str = 'default'
        self._exceptions: dict[str, dict] = {}
        self._scan_lines: int = 50

        self._load_and_detect()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_rule(self, rule_id: str) -> Optional[dict]:
        """Return the exception override dict for rule_id under the active
        branch, or None if no exception is declared (caller uses baseline)."""
        return self._exceptions.get(rule_id)

    def override_section_regex(self, section_name: str) -> Optional[str]:
        """Return a replacement match_regex for the given parser section
        under the active branch, or None if no exception is declared
        (caller uses the baseline regex from parser_config.ini).

        Used by SonicWallParser._load_section_defs to substitute version-
        specific section regexes — for example SonicOS 6.2's bare
        'access-rule from ...' form (no ipv4|ipv6 keyword) vs the 6.5
        family-tagged 'access-rule ipv4 from ...' form.

        Returns the new_regex string. The parser strips leading/trailing
        whitespace itself before compiling.
        """
        if not self._exceptions:
            return None
        for rule_id, rule in self._exceptions.items():
            if rule.get('rule_kind', '').strip() != 'section_regex_override':
                continue
            if rule.get('parser_section', '').strip() != section_name:
                continue
            new_rx = rule.get('new_regex', '').strip()
            if new_rx:
                return new_rx
        return None

    def override_section_form(self, section_name: str) -> Optional[str]:
        """Return a replacement form ('block'|'single_line'|'block_or_single')
        for the given parser section under the active branch, or None if
        no exception is declared.

        Companion to override_section_regex(). Used when a SonicOS branch's
        new form differs structurally from the 6.5 baseline — e.g. 6.2's
        inline single-line address-object declaration (no sub-block) where
        6.5 uses a multi-line block.

        Returns the new_form string. Caller defaults to baseline if None.
        """
        if not self._exceptions:
            return None
        for rule_id, rule in self._exceptions.items():
            if rule.get('rule_kind', '').strip() != 'section_regex_override':
                continue
            if rule.get('parser_section', '').strip() != section_name:
                continue
            new_form = rule.get('new_form', '').strip()
            if new_form:
                return new_form
        return None

    def split_field_value(self, head: str, rest: str) -> Optional[dict]:
        """Generic parser-time field splitter, INI-driven.

        For body lines of the form 'head rest_string', check every exception
        rule with rule_kind == 'parser_field_pattern' under the active
        SonicOS branch. If any rule's field_name matches `head` AND its
        value_pattern matches `rest`, return the named-group capture dict.
        The parser stores each named group as its own field in the block
        body — so 'ip 192.168.168.168 netmask 255.255.255.0' becomes
        body['ip'] AND body['netmask'] correctly.

        Returns None when:
          - No exceptions are loaded (default branch, or baseline)
          - No rule matches the field name
          - The matching rule's regex doesn't match `rest`
            (defensive: e.g. unknown SonicOS sub-version variations)

        Callers MUST fall through to baseline behavior on None.
        """
        if not self._exceptions:
            return None
        if not rest:
            return None
        for rule_id, rule in self._exceptions.items():
            if rule.get('rule_kind', '').strip() != 'parser_field_pattern':
                continue
            if rule.get('field_name', '').strip() != head:
                continue
            pat_src = rule.get('value_pattern', '').strip()
            if not pat_src:
                continue
            try:
                m = re.match(pat_src, rest)
            except re.error:
                continue
            if m is None:
                continue
            captures = {k: v for k, v in m.groupdict().items() if v}
            if captures:
                return captures
        return None

    def manifest_record(self) -> dict:
        """Provenance block for the build manifest."""
        return {
            'sonicos_version_detected':
                self.firmware_version_observed or '(not_present)',
            'sonicos_model_detected':
                self.model_observed or '(not_present)',
            'sonicos_version_branch_used': self.branch,
            'exception_rules_loaded': sorted(self._exceptions.keys()),
            'detection_ini': str(self.detection_ini_path),
            'exceptions_ini': str(self.exceptions_ini_path),
        }

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _load_and_detect(self):
        if not self.detection_ini_path.is_file():
            print(
                f'  [version-router] WARNING: '
                f'{self.detection_ini_path.name} not found; '
                f'falling back to default branch.',
                file=sys.stderr,
            )
            return
        det = configparser.ConfigParser()
        det.optionxform = str
        det.read(self.detection_ini_path, encoding='utf-8')

        # Honor meta.scan_lines if declared
        if det.has_section('meta') and det.has_option('meta', 'scan_lines'):
            try:
                self._scan_lines = int(det.get('meta', 'scan_lines').strip())
            except (TypeError, ValueError):
                pass

        # Read the first N lines of input to scan for signatures
        scan_buffer = self._read_scan_lines()
        self._capture_firmware_and_model_strings(scan_buffer)

        # Iterate branches in INI file order; first match wins.
        # Skip the meta section and the default branch (default is
        # the no-match fallback, never first-match wins).
        chosen_branch = None
        for sect in det.sections():
            if not sect.startswith('branch.'):
                continue
            branch_name = sect[len('branch.'):]
            if branch_name == 'default':
                continue
            sigs_raw = det.get(sect, 'signatures', fallback='').strip()
            if not sigs_raw:
                continue
            patterns = [s.strip() for s in sigs_raw.splitlines() if s.strip()]
            # Also support comma-separated on a single line
            expanded = []
            for p in patterns:
                if ',' in p and not p.startswith('^'):
                    expanded.extend(x.strip() for x in p.split(',') if x.strip())
                else:
                    expanded.append(p)
            for pat in expanded:
                try:
                    rx = re.compile(pat, re.MULTILINE)
                except re.error as e:
                    print(
                        f'  [version-router] WARNING: bad regex in '
                        f'{sect}: {pat!r} ({e})',
                        file=sys.stderr,
                    )
                    continue
                if rx.search(scan_buffer):
                    chosen_branch = branch_name
                    break
            if chosen_branch:
                break

        if chosen_branch is None:
            # No branch matched — use default with stderr warning
            self.branch = 'default'
            obs = self.firmware_version_observed or '(no firmware-version line found)'
            print(
                f'  [version-router] no SonicOS branch signature matched '
                f'(observed: {obs!r}); using default (6.5 baseline rules).',
                file=sys.stderr,
            )
        else:
            self.branch = chosen_branch
            print(
                f'  [version-router] SonicOS branch detected: {chosen_branch!r} '
                f'(firmware: {self.firmware_version_observed!r}, '
                f'model: {self.model_observed!r})',
                file=sys.stderr,
            )

        # Now load exceptions for the active branch
        self._load_exceptions_for_branch()

    def _read_scan_lines(self) -> str:
        if not self.input_path.is_file():
            return ''
        try:
            with open(self.input_path, 'r', encoding='utf-8',
                      errors='replace') as f:
                lines = []
                for i, line in enumerate(f):
                    if i >= self._scan_lines:
                        break
                    lines.append(line)
                return ''.join(lines)
        except OSError:
            return ''

    def _capture_firmware_and_model_strings(self, buffer: str):
        """Pull the firmware-version and model strings from the buffer for
        manifest provenance, regardless of which branch matches."""
        fw_match = re.search(
            r'^firmware-version\s+"([^"]+)"',
            buffer,
            re.MULTILINE,
        )
        if fw_match:
            self.firmware_version_observed = fw_match.group(1)
        model_match = re.search(
            r'^model\s+"([^"]+)"',
            buffer,
            re.MULTILINE,
        )
        if model_match:
            self.model_observed = model_match.group(1)

    def _load_exceptions_for_branch(self):
        if self.branch == 'default':
            # Default branch uses baseline rules with no exceptions
            return
        if not self.exceptions_ini_path.is_file():
            print(
                f'  [version-router] WARNING: '
                f'{self.exceptions_ini_path.name} not found; '
                f'branch {self.branch!r} has no exception overrides loaded.',
                file=sys.stderr,
            )
            return
        exc = configparser.ConfigParser()
        exc.optionxform = str
        exc.read(self.exceptions_ini_path, encoding='utf-8')

        prefix = f'exception.{self.branch}.'
        for sect in exc.sections():
            if not sect.startswith(prefix):
                continue
            rule_id = sect[len(prefix):]
            rule_dict = dict(exc.items(sect))
            self._exceptions[rule_id] = rule_dict


# ------------------------------------------------------------------
# Module-level cached singleton (one per input file path)
# ------------------------------------------------------------------

_ROUTER_CACHE: dict[str, SonicOSVersionRouter] = {}


def get_router(input_path) -> SonicOSVersionRouter:
    """Return a cached SonicOSVersionRouter for the given input file path.
    Cached by absolute path string."""
    key = str(Path(input_path).resolve())
    if key not in _ROUTER_CACHE:
        _ROUTER_CACHE[key] = SonicOSVersionRouter(Path(input_path))
    return _ROUTER_CACHE[key]


def reset_cache():
    """Test-only: clear the cached routers. Pipeline doesn't call this."""
    _ROUTER_CACHE.clear()


# ------------------------------------------------------------------
# Self-test if executed directly
# ------------------------------------------------------------------

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('usage: sonicos_version_router.py <input_file>', file=sys.stderr)
        sys.exit(2)
    r = get_router(sys.argv[1])
    import json
    print(json.dumps(r.manifest_record(), indent=2))
