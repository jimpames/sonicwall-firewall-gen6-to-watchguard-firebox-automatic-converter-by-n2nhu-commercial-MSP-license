#!/usr/bin/env python3
"""
sanity_check.py
================

Cross-check the parser output against simple grep counts on the source.
For each section, count how many times its keyword appears at column 0 in
the raw config and compare to the entry count emitted by the parser.

This is purposely independent of the parser code — it reads the same
parser_config.ini to know what to count, but uses dumb regex on raw lines.

Usage:
    python3 sanity_check.py --config parser_config.ini \
                            --input  input/slimmed-sonicwallconfig.txt \
                            --output output/
"""
from __future__ import annotations

import argparse
import configparser
import json
import re
import sys
from pathlib import Path


def load_section_defs(cp: configparser.ConfigParser) -> list[tuple[str, re.Pattern, str]]:
    out = []
    for sect_name in cp.sections():
        if not sect_name.startswith("section."):
            continue
        short = sect_name.split(".", 1)[1]
        rx = cp[sect_name].get("match_regex", "").replace("\n", "")
        of = cp[sect_name].get("output_file", f"{short}.json").strip()
        if rx:
            try:
                out.append((short, re.compile(rx), of))
            except re.error:
                pass
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="parser_config.ini")
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(";",),
                                   comment_prefixes=("#",))
    cp.read(args.config, encoding="utf-8")
    sections = load_section_defs(cp)

    with open(args.input, encoding="utf-8", errors="replace") as f:
        col0_lines = [ln.rstrip() for ln in f if ln and not ln.startswith((" ", "\t"))
                      and ln.strip() != ""]

    total_col0 = len(col0_lines)
    matched_lines: set[int] = set()
    rows = []
    for name, pat, outfile in sections:
        # Grep count
        grep_n = sum(1 for ln in col0_lines if pat.match(ln.strip()))
        # Mark which raw lines this section's regex claims
        for i, ln in enumerate(col0_lines):
            if pat.match(ln.strip()):
                matched_lines.add(i)

        # Parser count
        out_path = Path(args.output) / outfile
        if out_path.is_file():
            with open(out_path) as f:
                d = json.load(f)
            parsed_n = len(d.get("entries", d) if isinstance(d, dict) else d)
        else:
            parsed_n = 0

        if grep_n == 0 and parsed_n == 0:
            continue
        rows.append((name, grep_n, parsed_n, "OK" if grep_n == parsed_n else "MISMATCH"))

    rows.sort(key=lambda r: -r[1])

    print(f"\n{'SECTION':<32} {'GREP':>6} {'PARSED':>7}  STATUS")
    print("-" * 60)
    mismatches = 0
    for name, g, p, s in rows:
        flag = "" if s == "OK" else "  <-- check"
        if s != "OK":
            mismatches += 1
        print(f"{name:<32} {g:>6} {p:>7}  {s}{flag}")

    coverage = len(matched_lines) / total_col0 if total_col0 else 0
    print(f"\nColumn-0 line coverage: {len(matched_lines)}/{total_col0} ({coverage*100:.1f}%)")
    unparsed_path = Path(args.output) / "_unparsed.json"
    if unparsed_path.is_file():
        with open(unparsed_path) as f:
            u = json.load(f)
        n_unparsed = len(u.get("entries", u) if isinstance(u, dict) else u)
        print(f"_unparsed entries:      {n_unparsed}")
    print(f"Mismatches:             {mismatches}")
    return 1 if mismatches > 0 else 0


if __name__ == "__main__":
    sys.exit(main())
