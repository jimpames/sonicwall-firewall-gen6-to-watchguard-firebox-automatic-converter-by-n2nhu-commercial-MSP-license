#!/usr/bin/env python3
"""
merge_engine.py
================

Step 4 of the schema_learner subsystem. Applies operator-approved
proposals to the INI bundles, with backups, provenance comments,
rollback support, and mechanical enforcement of the founding principle.

Founding principle (binds every operation in this module):

    No claim without provenance.
    
    Every line this engine writes to a permanent INI file MUST include
    a provenance marker: who declared it, when, what citation source
    they provided. The engine refuses to merge any proposal where:
    
      * Operator declarations are missing (Q1-Q4 unanswered)
      * Citations are missing (Source field blank)
      * The post-merge schema fails validation
      * Backups cannot be created
    
    This is mechanical enforcement, not judgment-based. The engine
    cannot be told "skip the citation check just this once."

Three modes:

    validate      — parse intervention doc, check declarations and
                    citations. Returns 0 if all gates pass, non-zero
                    with explicit reasons if any gate fails.
    
    dry-run       — show what would change without writing. Useful for
                    operator review before committing.
    
    apply         — create backups of all files that would be modified,
                    then apply changes with provenance comments.
                    Requires --confirm flag.
    
    rollback      — restore from a previous merge's backups. Identified
                    by merge_id (timestamp).

Reads from:
    proposals/<date>_<source>/OPERATOR_INTERVENTION_REQUIRED.md
    proposals/<date>_<source>/findings.json
    
Writes to:
    wg_validator/wg_xml_schema.ini             (schema entries)
    concept_map/concept_map.ini                (concept entries with warnings)
    sonicwall_parser/parser_config.ini         (warning blurbs only)
    xml_emitter/xml_emit_config.ini            (warning blurbs only)
    
Backs up to:
    schema_learner/backups/<merge_id>/
        <original_file>.bak.<timestamp>
        merge_manifest.json

Usage:
    python3 merge_engine.py validate --proposal <dir>
    python3 merge_engine.py dry-run --proposal <dir>
    python3 merge_engine.py apply --proposal <dir> --confirm
    python3 merge_engine.py rollback --merge-id <id>
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import re
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))


# Markers used by the schema-learner's intervention doc generator
# (see schema_learner.py). The merge engine parses these to extract
# operator-authored content.
OP_OPEN = "<!-- OPERATOR-AUTHORED-BEGIN -->"
OP_CLOSE = "<!-- OPERATOR-AUTHORED-END -->"
OBS_OPEN = "<!-- ENGINE-OBSERVATION-BEGIN -->"
OBS_CLOSE = "<!-- ENGINE-OBSERVATION-END -->"

# Surface category taxonomy (must match schema_learner DESIGN.md)
VALID_CATEGORIES = {
    "network-plumbing",
    "policy-access-control",
    "object-library",
    "tunnel-vpn",
    "html-web-app",
    "threat-detection",
    "authentication-infrastructure",
    "device-management",
    "administrative",
}


# ---------------------------------------------------------------------------
# Operator-declaration parsing
# ---------------------------------------------------------------------------

@dataclass
class OperatorDeclaration:
    """Operator-authored answers for one Category-1 finding.
    
    Filled in by the operator inside <!-- OPERATOR-AUTHORED-BEGIN -->
    blocks in the intervention doc. The merge engine parses these and
    REFUSES to merge if any required field is empty or unciteded.
    """
    surface_tag: str
    
    # Q1: What does this element do?
    purpose: str = ""
    purpose_source: str = ""
    
    # Q2: Surface category
    category: str = ""
    category_source: str = ""
    
    # Q3: SonicWall equivalent
    sonicwall_equivalent: str = ""
    sonicwall_equivalent_source: str = ""
    
    # Q4: Security/operational considerations
    operational_notes: str = ""
    operational_notes_source: str = ""
    
    # Operator identification (filled in by engine, not from doc)
    declared_by: str = ""
    declared_at: str = ""
    
    def is_complete(self) -> tuple[bool, list[str]]:
        """Return (all_filled, list_of_missing_fields)."""
        missing: list[str] = []
        # Q1 required (purpose + source)
        if not self.purpose or self.purpose.startswith("___"):
            missing.append(f"Q1 purpose for <{self.surface_tag}>")
        if not self.purpose_source or self.purpose_source.startswith("___"):
            missing.append(f"Q1 purpose_source for <{self.surface_tag}>")
        # Q2 required
        if not self.category or self.category.startswith("___"):
            missing.append(f"Q2 category for <{self.surface_tag}>")
        elif self.category not in VALID_CATEGORIES:
            missing.append(
                f"Q2 category for <{self.surface_tag}>: "
                f"{self.category!r} is not a valid category. "
                f"Allowed: {sorted(VALID_CATEGORIES)}"
            )
        if not self.category_source or self.category_source.startswith("___"):
            missing.append(f"Q2 category_source for <{self.surface_tag}>")
        # Q3 required (even if answer is "none — net-new on WatchGuard")
        if (not self.sonicwall_equivalent
                or self.sonicwall_equivalent.startswith("___")):
            missing.append(
                f"Q3 sonicwall_equivalent for <{self.surface_tag}>")
        if (not self.sonicwall_equivalent_source
                or self.sonicwall_equivalent_source.startswith("___")):
            missing.append(
                f"Q3 sonicwall_equivalent_source for <{self.surface_tag}>")
        # Q4 required (even if answer is "none")
        if (not self.operational_notes
                or self.operational_notes.startswith("___")):
            missing.append(
                f"Q4 operational_notes for <{self.surface_tag}>")
        if (not self.operational_notes_source
                or self.operational_notes_source.startswith("___")):
            missing.append(
                f"Q4 operational_notes_source for <{self.surface_tag}>")
        return (len(missing) == 0, missing)


def parse_intervention_doc(
    intervention_path: Path,
) -> dict[str, OperatorDeclaration]:
    """Parse OPERATOR_INTERVENTION_REQUIRED.md and extract one
    OperatorDeclaration per surface.
    
    Returns dict: surface_tag -> OperatorDeclaration
    """
    if not intervention_path.is_file():
        raise FileNotFoundError(
            f"Intervention doc not found: {intervention_path}")
    text = intervention_path.read_text(encoding='utf-8')
    
    declarations: dict[str, OperatorDeclaration] = {}
    
    # Find each "## Surface N: `<tag>`" section
    surface_pattern = re.compile(
        r'^## Surface \d+:\s*`<([^>]+)>`\s*$',
        flags=re.MULTILINE,
    )
    matches = list(surface_pattern.finditer(text))
    if not matches:
        return {}
    
    for i, m in enumerate(matches):
        tag = m.group(1)
        section_start = m.end()
        section_end = (matches[i + 1].start()
                       if i + 1 < len(matches) else len(text))
        section_text = text[section_start:section_end]
        
        # Extract operator-authored block
        op_open_idx = section_text.find(OP_OPEN)
        op_close_idx = section_text.find(OP_CLOSE)
        if op_open_idx < 0 or op_close_idx < 0:
            continue  # Section without operator block — skip
        op_block = section_text[op_open_idx + len(OP_OPEN):op_close_idx]
        
        decl = OperatorDeclaration(surface_tag=tag)
        _parse_questionnaire_block(op_block, decl)
        declarations[tag] = decl
    
    return declarations


def _parse_questionnaire_block(
    block: str, decl: OperatorDeclaration,
) -> None:
    """Extract Q1-Q4 answers from the operator-authored block.
    
    Robust to variations in operator filling style:
      Answer: <text>
      Answer:<text>
      Answer:
          <text>
    """
    lines = block.splitlines()
    
    # State machine: track which question we're inside, and whether
    # we're looking for an Answer or a Source line.
    current_q: int | None = None
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        
        # Detect question headers
        if "**Q1:" in stripped or "Q1:" in stripped and "**" in stripped:
            current_q = 1
            continue
        if "**Q2:" in stripped or "Q2:" in stripped and "**" in stripped:
            current_q = 2
            continue
        if "**Q3:" in stripped or "Q3:" in stripped and "**" in stripped:
            current_q = 3
            continue
        if "**Q4:" in stripped or "Q4:" in stripped and "**" in stripped:
            current_q = 4
            continue
        
        # Extract Answer: and Source: lines
        if current_q is None:
            continue
        
        # Normalize: strip leading whitespace and bullet markers
        normalized = line.lstrip(" \t-*").rstrip()
        
        answer_match = re.match(
            r'^Answer\s*[:|\-]\s*(.+)$', normalized, re.IGNORECASE)
        if answer_match:
            value = answer_match.group(1).strip()
            # If it's still the placeholder underscores, skip
            if value and not value.startswith("___"):
                _set_q_answer(decl, current_q, value)
            continue
        
        source_match = re.match(
            r'^Source[^:]*[:|\-]\s*(.+)$', normalized, re.IGNORECASE)
        if source_match:
            value = source_match.group(1).strip()
            if value and not value.startswith("___"):
                _set_q_source(decl, current_q, value)
            continue


def _set_q_answer(decl: OperatorDeclaration, q: int, value: str) -> None:
    if q == 1:
        decl.purpose = value
    elif q == 2:
        decl.category = value
    elif q == 3:
        decl.sonicwall_equivalent = value
    elif q == 4:
        decl.operational_notes = value


def _set_q_source(decl: OperatorDeclaration, q: int, value: str) -> None:
    if q == 1:
        decl.purpose_source = value
    elif q == 2:
        decl.category_source = value
    elif q == 3:
        decl.sonicwall_equivalent_source = value
    elif q == 4:
        decl.operational_notes_source = value


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    """Result of validating a proposal against the principle gates."""
    proposal_path: Path
    all_declarations: dict[str, OperatorDeclaration]
    missing_per_surface: dict[str, list[str]]
    
    @property
    def is_valid(self) -> bool:
        """Returns True only if EVERY surface has complete declarations."""
        return all(not missing for missing in self.missing_per_surface.values())
    
    @property
    def total_surfaces(self) -> int:
        return len(self.all_declarations)
    
    @property
    def complete_surfaces(self) -> int:
        return sum(1 for missing in self.missing_per_surface.values()
                   if not missing)
    
    @property
    def incomplete_surfaces(self) -> int:
        return self.total_surfaces - self.complete_surfaces


def validate_proposal(proposal_dir: Path) -> ValidationResult:
    """Parse the proposal's intervention doc and check each surface
    has all required declarations and citations."""
    intervention_path = proposal_dir / "OPERATOR_INTERVENTION_REQUIRED.md"
    declarations = parse_intervention_doc(intervention_path)
    
    missing_per_surface: dict[str, list[str]] = {}
    for tag, decl in declarations.items():
        ok, missing = decl.is_complete()
        missing_per_surface[tag] = missing if not ok else []
    
    return ValidationResult(
        proposal_path=proposal_dir,
        all_declarations=declarations,
        missing_per_surface=missing_per_surface,
    )


def report_validation(result: ValidationResult, stream=sys.stdout) -> None:
    """Print a human-readable validation report."""
    print(f"Proposal: {result.proposal_path}", file=stream)
    print(f"Total Category-1 surfaces in proposal: "
          f"{result.total_surfaces}", file=stream)
    print(f"Complete (all Q1-Q4 + sources): "
          f"{result.complete_surfaces}", file=stream)
    print(f"Incomplete: {result.incomplete_surfaces}", file=stream)
    print("", file=stream)
    
    if result.is_valid:
        print("✓ All declarations complete and cited. "
              "Proposal is mergeable.", file=stream)
        return
    
    print("✗ Proposal is NOT mergeable. Missing declarations:", file=stream)
    print("", file=stream)
    for tag, missing in result.missing_per_surface.items():
        if not missing:
            continue
        print(f"  <{tag}>:", file=stream)
        for m in missing:
            print(f"    - {m}", file=stream)
        print("", file=stream)


# ---------------------------------------------------------------------------
# Merge planning (dry-run)
# ---------------------------------------------------------------------------

@dataclass
class MergePlan:
    """What the apply step would do, computed without writing anything."""
    proposal_path: Path
    merge_id: str
    schema_additions: list[dict[str, Any]] = field(default_factory=list)
    concept_map_additions: list[dict[str, Any]] = field(default_factory=list)
    parser_config_warnings: list[dict[str, Any]] = field(default_factory=list)
    emit_config_warnings: list[dict[str, Any]] = field(default_factory=list)
    files_to_backup: list[Path] = field(default_factory=list)
    

def plan_merge(
    proposal_dir: Path,
    declarations: dict[str, OperatorDeclaration],
    findings_json_path: Path,
    target_paths: dict[str, Path],
) -> MergePlan:
    """Compute the merge plan from the proposal and declarations.
    
    target_paths must contain:
        'wg_xml_schema'    -> Path
        'concept_map'      -> Path
        'parser_config'    -> Path
        'emit_config'      -> Path
    
    The plan is COMPUTED but not applied. Use apply_merge() to actually
    write changes.
    """
    findings = json.loads(findings_json_path.read_text(encoding='utf-8'))
    findings_by_tag = {
        f['element_tag']: f for f in findings.get('findings', [])
    }
    
    timestamp = _dt.datetime.now().strftime('%Y-%m-%d_%H%M%S')
    merge_id = f"{timestamp}_{proposal_dir.name}"
    
    plan = MergePlan(
        proposal_path=proposal_dir,
        merge_id=merge_id,
    )
    
    for tag, decl in declarations.items():
        finding = findings_by_tag.get(tag)
        if finding is None:
            continue
        
        # Schema addition: new wg_xml_element entry
        plan.schema_additions.append({
            'tag': tag,
            'declaration': decl,
            'finding': finding,
        })
        
        # Concept-map addition: new concept entry with warning blurb
        plan.concept_map_additions.append({
            'tag': tag,
            'declaration': decl,
        })
        
        # Parser-config warning: incomplete (operator authoring needed)
        plan.parser_config_warnings.append({
            'tag': tag,
            'declaration': decl,
        })
        
        # Emit-config warning: incomplete (operator authoring needed)
        plan.emit_config_warnings.append({
            'tag': tag,
            'declaration': decl,
        })
    
    # All four target files would be modified
    if plan.schema_additions:
        plan.files_to_backup.append(target_paths['wg_xml_schema'])
    if plan.concept_map_additions:
        plan.files_to_backup.append(target_paths['concept_map'])
    if plan.parser_config_warnings:
        plan.files_to_backup.append(target_paths['parser_config'])
    if plan.emit_config_warnings:
        plan.files_to_backup.append(target_paths['emit_config'])
    
    return plan


def report_plan(plan: MergePlan, stream=sys.stdout) -> None:
    """Print a human-readable plan summary."""
    print(f"Merge plan for proposal: {plan.proposal_path}", file=stream)
    print(f"Merge ID: {plan.merge_id}", file=stream)
    print("", file=stream)
    print(f"Schema entries to add (wg_xml_schema.ini):    "
          f"{len(plan.schema_additions)}", file=stream)
    print(f"Concept-map entries to add:                   "
          f"{len(plan.concept_map_additions)}", file=stream)
    print(f"Parser-config warnings to insert:             "
          f"{len(plan.parser_config_warnings)}", file=stream)
    print(f"Emit-config warnings to insert:               "
          f"{len(plan.emit_config_warnings)}", file=stream)
    print(f"Files to backup before applying: "
          f"{len(plan.files_to_backup)}", file=stream)
    for f in plan.files_to_backup:
        print(f"  - {f}", file=stream)
    print("", file=stream)
    
    if plan.schema_additions:
        print("--- Schema additions (sample) ---", file=stream)
        for entry in plan.schema_additions[:3]:
            decl = entry['declaration']
            print(f"  <{entry['tag']}>:", file=stream)
            print(f"    purpose:  {decl.purpose[:80]}", file=stream)
            print(f"    category: {decl.category}", file=stream)
            print(f"    source:   {decl.purpose_source[:80]}", file=stream)
        if len(plan.schema_additions) > 3:
            print(f"  ... and {len(plan.schema_additions) - 3} more",
                  file=stream)
        print("", file=stream)


# ---------------------------------------------------------------------------
# INI snippet generators (write provenance comments per founding principle)
# ---------------------------------------------------------------------------

def _wrap_in_observation_markers(text: str) -> str:
    """Wrap text in observation-block markers so the provenance audit
    treats it as engine-observation, not a semantic claim."""
    return f"{OBS_OPEN}\n{text}\n{OBS_CLOSE}"


def render_schema_entry(
    tag: str,
    decl: OperatorDeclaration,
    finding: dict[str, Any],
) -> str:
    """Render a wg_xml_schema.ini entry for a learned element.
    
    All semantic claims include their citations inline. The element's
    structural facts come from the schema-learner's findings.json.
    
    Phase 1 (DESIGN_team_scale_addendum.md): two new fields are
    reserved for downstream phases but written empty by Phase 1-2:
      - deprecated: timestamp + vendor citation if surface deprecated
      - lab_verified: marker for deep-research lab verification
                      (Phase 4 deep-research workflow populates this)
    """
    structural = finding.get('structural_facts', {})
    children_tags = [t for t, _ in structural.get('top_children_tags', [])]
    allowed_fields = ', '.join(children_tags) if children_tags else ''
    
    instance_count = structural.get('instance_count', 1)
    distinct_shapes = structural.get('distinct_field_shapes', 1)
    
    lines: list[str] = []
    lines.append(f"")
    lines.append(f"; ============================================================")
    lines.append(f"; element.{tag}")
    lines.append(f"; ============================================================")
    lines.append(f"; SCHEMA LEARNED — see provenance below.")
    lines.append(f"; declared_by:        {decl.declared_by}")
    lines.append(f"; declared_at:        {decl.declared_at}")
    lines.append(f"; purpose:            {decl.purpose}")
    lines.append(f"; purpose_source:     {decl.purpose_source}")
    lines.append(f"; category:           {decl.category}")
    lines.append(f"; category_source:    {decl.category_source}")
    lines.append(f"; sonicwall_equiv:    {decl.sonicwall_equivalent}")
    lines.append(f"; sw_equiv_source:    {decl.sonicwall_equivalent_source}")
    if decl.operational_notes:
        lines.append(f"; operational_notes:  {decl.operational_notes}")
    if decl.operational_notes_source:
        lines.append(f"; ops_notes_source:   {decl.operational_notes_source}")
    lines.append(f"; observed_instances: {instance_count}")
    lines.append(f"; distinct_shapes:    {distinct_shapes}")
    lines.append(f"[element.{tag}]")
    if allowed_fields:
        lines.append(f"allowed_fields = {allowed_fields}")
    # Phase 1 forward-compatibility fields — empty by default,
    # populated by deprecation sweep (Phase 4) and deep-research
    # lab verification (Phase 4) respectively.
    lines.append(f"deprecated = ")
    lines.append(f"lab_verified = ")
    lines.append(f"; END element.{tag}")
    return "\n".join(lines) + "\n"


def render_concept_map_entry(
    tag: str,
    decl: OperatorDeclaration,
    proposal_dir_name: str,
) -> str:
    """Render a concept_map.ini entry for a learned element. Includes
    a TRANSLATION-BLOCKED warning blurb because the SonicWall side
    requires further operator work (parser pattern + emit rule)."""
    canonical = re.sub(r'[^a-z0-9_]', '_', tag.lower())
    
    lines: list[str] = []
    lines.append(f"")
    lines.append(f"; ============================================================")
    lines.append(f"; concept.{canonical}")
    lines.append(f"; ============================================================")
    lines.append(f"; SCHEMA LEARNED on {decl.declared_at}.")
    lines.append(f"; ⛔ TRANSLATION BLOCKED until SonicWall mapping authored.")
    lines.append(f";    See proposal: {proposal_dir_name}")
    lines.append(f";    Operator must:")
    lines.append(f";      1. Add parser pattern in sonicwall_parser/parser_config.ini")
    lines.append(f";      2. Author the `sonicwall = ...` field below")
    lines.append(f";      3. Add emit rule in xml_emitter/xml_emit_config.ini")
    lines.append(f";      4. Run test suite and confirm clean validation")
    lines.append(f"; declared_by:     {decl.declared_by}")
    lines.append(f"; declared_at:     {decl.declared_at}")
    lines.append(f"; purpose:         {decl.purpose}")
    lines.append(f"; purpose_source:  {decl.purpose_source}")
    lines.append(f"; category:        {decl.category}")
    lines.append(f"; sonicwall_equiv: {decl.sonicwall_equivalent}")
    lines.append(f"; sw_equiv_source: {decl.sonicwall_equivalent_source}")
    lines.append(f"[concept.{canonical}]")
    # Use the operator's purpose declaration as the description
    desc = decl.purpose.replace('\n', ' ').strip()
    lines.append(f"description = {desc}")
    lines.append(f"canonical_term = {canonical}")
    lines.append(f"category = {decl.category}")
    sw_value = decl.sonicwall_equivalent.strip()
    if sw_value.lower() in ('none', 'none — net-new on watchguard',
                             'none - net-new on watchguard'):
        lines.append(f"sonicwall = NONE — net-new on WatchGuard, "
                     f"no SonicWall side")
    else:
        lines.append(f"; ⚠ SonicWall directive identified by operator. Parser "
                     f"pattern still needed.")
        lines.append(f"sonicwall_directive_hint = {sw_value}")
        lines.append(f"sonicwall = ⚠ NOT MAPPED — operator must author "
                     f"parser pattern ⚠")
    lines.append(f"watchguard = {tag}")
    lines.append(f"; END concept.{canonical}")
    return "\n".join(lines) + "\n"


def render_parser_warning(
    tag: str,
    decl: OperatorDeclaration,
    proposal_dir_name: str,
) -> str:
    """Render a TRANSLATION GAP warning in parser_config.ini.
    Searchable via grep -r 'TRANSLATION BLOCKED'."""
    sw_hint = decl.sonicwall_equivalent.strip()
    if sw_hint.lower() in ('none', 'none — net-new on watchguard',
                            'none - net-new on watchguard'):
        return ""  # No SonicWall side to author — skip parser warning
    
    lines: list[str] = []
    lines.append(f"")
    lines.append(f"; ============================================================")
    lines.append(f"; ⚠ TRANSLATION GAP — SonicWall parser pattern needed ⚠")
    lines.append(f"; ============================================================")
    lines.append(f"; WG element <{tag}> learned on {decl.declared_at}.")
    lines.append(f"; Surface category: {decl.category}")
    lines.append(f"; Operator-identified SonicWall directive: {sw_hint}")
    lines.append(f"; Source: {decl.sonicwall_equivalent_source}")
    lines.append(f";")
    lines.append(f"; Operator action required: add a [parse.<section>] block")
    lines.append(f"; here that captures the SonicWall directive(s) for this")
    lines.append(f"; feature.")
    lines.append(f";")
    lines.append(f"; See proposal: {proposal_dir_name}")
    lines.append(f"; ⛔ Until added, configs containing this feature emit")
    lines.append(f";    hard-error advisories in migration_notes.md.")
    return "\n".join(lines) + "\n"


def render_emit_warning(
    tag: str,
    decl: OperatorDeclaration,
    proposal_dir_name: str,
) -> str:
    """Render a TRANSLATION GAP warning in xml_emit_config.ini."""
    canonical = re.sub(r'[^a-z0-9_]', '_', tag.lower())
    
    lines: list[str] = []
    lines.append(f"")
    lines.append(f"; ============================================================")
    lines.append(f"; ⚠ EMIT RULE NEEDED — WG <{tag}> learned but unmapped ⚠")
    lines.append(f"; ============================================================")
    lines.append(f"; Schema entry exists in wg_xml_schema.ini.")
    lines.append(f"; Concept-map entry exists in concept_map.ini.")
    lines.append(f"; Surface category: {decl.category}")
    lines.append(f"; declared_by:      {decl.declared_by}")
    lines.append(f"; declared_at:      {decl.declared_at}")
    lines.append(f";")
    lines.append(f"; Operator action required: author an [emit.{canonical}]")
    lines.append(f"; section that maps enriched JSON fields to the")
    lines.append(f"; WatchGuard <{tag}> XML structure.")
    lines.append(f";")
    lines.append(f"; See proposal: {proposal_dir_name}")
    lines.append(f"; ⛔ Until authored, configs needing this surface produce")
    lines.append(f";    hard-error advisories in migration_notes.md.")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Apply (write changes with backups)
# ---------------------------------------------------------------------------

def _backup_file(
    src: Path,
    backup_root: Path,
    timestamp: str,
) -> Path:
    """Copy src to backup_root with a timestamped name. Returns backup path."""
    backup_root.mkdir(parents=True, exist_ok=True)
    backup_name = f"{src.name}.bak.{timestamp}"
    backup_path = backup_root / backup_name
    shutil.copy2(src, backup_path)
    return backup_path


def apply_merge(
    plan: MergePlan,
    target_paths: dict[str, Path],
    backups_root: Path,
    operator_name: str,
) -> dict[str, Any]:
    """Apply the merge plan: backup all target files, then append
    new content with provenance comments.
    
    Returns the merge manifest as a dict (also written to disk).
    """
    backup_dir = backups_root / plan.merge_id
    backup_dir.mkdir(parents=True, exist_ok=True)
    timestamp = _dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # Stage 1: backup all target files
    backup_paths: dict[str, str] = {}
    for f in plan.files_to_backup:
        bp = _backup_file(f, backup_dir, timestamp)
        backup_paths[str(f)] = str(bp)
    
    # Stage 2: append schema entries
    proposal_dir_name = plan.proposal_path.name
    schema_path = target_paths['wg_xml_schema']
    if plan.schema_additions:
        with schema_path.open('a', encoding='utf-8') as f:
            f.write("\n")
            f.write(f"; +++ MERGE {plan.merge_id} +++\n")
            f.write(f"; Source proposal: {proposal_dir_name}\n")
            f.write(f"; Operator: {operator_name}\n")
            for entry in plan.schema_additions:
                snippet = render_schema_entry(
                    entry['tag'],
                    entry['declaration'],
                    entry['finding'],
                )
                f.write(snippet)
            f.write(f"; +++ END MERGE {plan.merge_id} +++\n")
    
    # Stage 3: append concept-map entries (with warning blurbs)
    cm_path = target_paths['concept_map']
    if plan.concept_map_additions:
        with cm_path.open('a', encoding='utf-8') as f:
            f.write("\n")
            f.write(f"; +++ MERGE {plan.merge_id} +++\n")
            f.write(f"; Source proposal: {proposal_dir_name}\n")
            f.write(f"; Operator: {operator_name}\n")
            for entry in plan.concept_map_additions:
                snippet = render_concept_map_entry(
                    entry['tag'],
                    entry['declaration'],
                    proposal_dir_name,
                )
                f.write(snippet)
            f.write(f"; +++ END MERGE {plan.merge_id} +++\n")
    
    # Stage 4: append parser warnings (only for surfaces with
    # operator-identified SonicWall side that needs authoring)
    pc_path = target_paths['parser_config']
    parser_warnings_written = 0
    if plan.parser_config_warnings:
        with pc_path.open('a', encoding='utf-8') as f:
            f.write("\n")
            f.write(f"; +++ MERGE {plan.merge_id} +++\n")
            f.write(f"; Source proposal: {proposal_dir_name}\n")
            f.write(f"; Operator: {operator_name}\n")
            for entry in plan.parser_config_warnings:
                snippet = render_parser_warning(
                    entry['tag'],
                    entry['declaration'],
                    proposal_dir_name,
                )
                if snippet:
                    f.write(snippet)
                    parser_warnings_written += 1
            f.write(f"; +++ END MERGE {plan.merge_id} +++\n")
    
    # Stage 5: append emit warnings
    ec_path = target_paths['emit_config']
    if plan.emit_config_warnings:
        with ec_path.open('a', encoding='utf-8') as f:
            f.write("\n")
            f.write(f"; +++ MERGE {plan.merge_id} +++\n")
            f.write(f"; Source proposal: {proposal_dir_name}\n")
            f.write(f"; Operator: {operator_name}\n")
            for entry in plan.emit_config_warnings:
                snippet = render_emit_warning(
                    entry['tag'],
                    entry['declaration'],
                    proposal_dir_name,
                )
                f.write(snippet)
            f.write(f"; +++ END MERGE {plan.merge_id} +++\n")
    
    # Stage 6: write merge manifest
    manifest = {
        'merge_id': plan.merge_id,
        'applied_at': _dt.datetime.now().isoformat(),
        'operator': operator_name,
        'proposal': str(plan.proposal_path),
        'backup_paths': backup_paths,
        'changes': {
            'schema_entries_added': len(plan.schema_additions),
            'concept_map_entries_added': len(plan.concept_map_additions),
            'parser_warnings_inserted': parser_warnings_written,
            'emit_warnings_inserted': len(plan.emit_config_warnings),
        },
        'declarations': {
            tag: {
                'purpose': e['declaration'].purpose,
                'purpose_source': e['declaration'].purpose_source,
                'category': e['declaration'].category,
                'category_source': e['declaration'].category_source,
                'sonicwall_equivalent': e['declaration'].sonicwall_equivalent,
                'sonicwall_equivalent_source':
                    e['declaration'].sonicwall_equivalent_source,
                'operational_notes': e['declaration'].operational_notes,
                'operational_notes_source':
                    e['declaration'].operational_notes_source,
            }
            for tag, e in (
                (entry['tag'], entry) for entry in plan.schema_additions
            )
        },
    }
    manifest_path = backup_dir / 'merge_manifest.json'
    manifest_path.write_text(
        json.dumps(manifest, indent=2), encoding='utf-8')
    
    return manifest


# ---------------------------------------------------------------------------
# Rollback
# ---------------------------------------------------------------------------

def rollback_merge(
    merge_id: str,
    backups_root: Path,
) -> dict[str, str]:
    """Restore files from a previous merge's backups.
    
    Returns dict of restored_file -> backup_path.
    """
    backup_dir = backups_root / merge_id
    if not backup_dir.is_dir():
        raise FileNotFoundError(
            f"No backup directory for merge {merge_id}: {backup_dir}")
    
    manifest_path = backup_dir / 'merge_manifest.json'
    if not manifest_path.is_file():
        raise FileNotFoundError(
            f"No merge manifest in {backup_dir}")
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    
    restored: dict[str, str] = {}
    for original_path_str, backup_path_str in manifest['backup_paths'].items():
        original = Path(original_path_str)
        backup = Path(backup_path_str)
        if not backup.is_file():
            print(f"  [warn] backup missing: {backup}", file=sys.stderr)
            continue
        shutil.copy2(backup, original)
        restored[str(original)] = str(backup)
    
    return restored


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _resolve_target_paths() -> dict[str, Path]:
    """Resolve the four standard target file paths from the toolkit root."""
    return {
        'wg_xml_schema': _TOOLKIT_ROOT / 'wg_validator' / 'wg_xml_schema.ini',
        'concept_map':   _TOOLKIT_ROOT / 'concept_map' / 'concept_map.ini',
        'parser_config': _TOOLKIT_ROOT / 'sonicwall_parser' / 'parser_config.ini',
        'emit_config':   _TOOLKIT_ROOT / 'xml_emitter' / 'xml_emit_config.ini',
    }


def cmd_validate(args) -> int:
    proposal_dir = Path(args.proposal).resolve()
    result = validate_proposal(proposal_dir)
    report_validation(result)
    return 0 if result.is_valid else 1


def cmd_dry_run(args) -> int:
    proposal_dir = Path(args.proposal).resolve()
    result = validate_proposal(proposal_dir)
    if not result.is_valid:
        print("✗ Cannot plan merge: proposal validation failed.\n")
        report_validation(result)
        return 1
    
    findings_json = proposal_dir / "findings.json"
    target_paths = _resolve_target_paths()
    plan = plan_merge(
        proposal_dir, result.all_declarations,
        findings_json, target_paths,
    )
    report_plan(plan)
    print("Run with `apply --confirm` to actually write changes.")
    return 0


def cmd_apply(args) -> int:
    proposal_dir = Path(args.proposal).resolve()
    
    # Phase 5: validate operator against team roster
    try:
        sys.path.insert(0, str(_TOOLKIT_ROOT / 'schema_learner'))
        from team_coordination import (
            log_action, require_authenticated_operator,
        )
        operator_for_audit = args.operator or "unspecified"
        auth_ok, auth_msg = require_authenticated_operator(
            operator_for_audit)
        if not auth_ok:
            print(f"✗ Refusing to apply merge: {auth_msg}")
            return 1
    except ImportError:
        # team_coordination unavailable — Phase 4 fallback behavior
        log_action = None

    # Gate 1: validation must pass
    result = validate_proposal(proposal_dir)
    if not result.is_valid:
        print("✗ Refusing to apply merge: proposal validation failed.\n")
        report_validation(result)
        return 1
    
    # Gate 2: --confirm flag required (mechanical safeguard)
    if not args.confirm:
        print("✗ Refusing to apply merge without --confirm flag.")
        print("  Run dry-run first to see what would change, then re-run")
        print("  with --confirm to actually apply.")
        return 1
    
    # Plan
    findings_json = proposal_dir / "findings.json"
    target_paths = _resolve_target_paths()
    plan = plan_merge(
        proposal_dir, result.all_declarations,
        findings_json, target_paths,
    )
    
    # Stamp declarations with operator identity and timestamp
    operator = args.operator or "unspecified"
    timestamp = _dt.datetime.now().isoformat()
    for decl in result.all_declarations.values():
        decl.declared_by = operator
        decl.declared_at = timestamp
    
    # Apply
    backups_root = _TOOLKIT_ROOT / 'schema_learner' / 'backups'
    print(f"Applying merge {plan.merge_id}...")
    print(f"  Backups: {backups_root / plan.merge_id}")
    manifest = apply_merge(plan, target_paths, backups_root, operator)
    
    # Phase 5: audit log the merge
    if log_action is not None:
        log_action(
            operator=operator,
            action_type='merge_apply',
            target=plan.merge_id,
            source_proposal=proposal_dir.name,
            detail=(
                f"schema={manifest['changes']['schema_entries_added']}, "
                f"concept={manifest['changes']['concept_map_entries_added']}"
            ),
        )

    print()
    print(f"✓ Merge applied: {plan.merge_id}")
    print(f"  Schema entries:     {manifest['changes']['schema_entries_added']}")
    print(f"  Concept entries:    {manifest['changes']['concept_map_entries_added']}")
    print(f"  Parser warnings:    {manifest['changes']['parser_warnings_inserted']}")
    print(f"  Emit warnings:      {manifest['changes']['emit_warnings_inserted']}")
    print(f"  Manifest:           "
          f"{backups_root / plan.merge_id / 'merge_manifest.json'}")
    print()
    print("Next steps:")
    print(f"  1. Run test suite: python3 harness/run_all.py")
    print(f"  2. Author parser patterns and emit rules per warning blurbs")
    print(f"  3. If anything goes wrong: rollback --merge-id {plan.merge_id}")
    return 0


def cmd_rollback(args) -> int:
    # Phase 5: log rollback to audit
    try:
        sys.path.insert(0, str(_TOOLKIT_ROOT / 'schema_learner'))
        from team_coordination import log_action
    except ImportError:
        log_action = None

    backups_root = _TOOLKIT_ROOT / 'schema_learner' / 'backups'
    print(f"Rolling back merge: {args.merge_id}")
    try:
        restored = rollback_merge(args.merge_id, backups_root)
    except FileNotFoundError as e:
        print(f"✗ {e}")
        return 1
    if log_action is not None:
        log_action(
            operator=getattr(args, 'operator', None) or 'unspecified',
            action_type='merge_rollback',
            target=args.merge_id,
            detail=f'restored {len(restored)} file(s)',
        )
    print(f"✓ Restored {len(restored)} file(s):")
    for original, backup in restored.items():
        print(f"  {original}")
        print(f"    from: {backup}")
    return 0


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest='command', required=True)
    
    p_validate = sub.add_parser(
        'validate',
        help="Check proposal has all declarations and citations")
    p_validate.add_argument('--proposal', required=True,
                            help="Path to proposal directory")
    p_validate.set_defaults(func=cmd_validate)
    
    p_dry = sub.add_parser(
        'dry-run',
        help="Show what would change without writing")
    p_dry.add_argument('--proposal', required=True,
                       help="Path to proposal directory")
    p_dry.set_defaults(func=cmd_dry_run)
    
    p_apply = sub.add_parser(
        'apply',
        help="Apply the merge with backups")
    p_apply.add_argument('--proposal', required=True,
                         help="Path to proposal directory")
    p_apply.add_argument('--confirm', action='store_true',
                         help="Required safety flag — refuses without it")
    p_apply.add_argument('--operator', default=None,
                         help="Operator name for provenance (e.g. 'jimames')")
    p_apply.set_defaults(func=cmd_apply)
    
    p_rollback = sub.add_parser(
        'rollback',
        help="Restore from a previous merge's backups")
    p_rollback.add_argument('--merge-id', required=True,
                            help="Merge ID (timestamp from merge manifest)")
    p_rollback.set_defaults(func=cmd_rollback)
    
    args = ap.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
