#!/usr/bin/env python3
"""
triage.py
==========

Phase 2 of the schema_learner subsystem (DESIGN_team_scale_addendum.md).
Operator-facing CLI for the four-state triage taxonomy:

    (c)orrect    — approved as-is, enters approved corpus
    (e)dit       — operator rewrites then approves, enters approved corpus
    (h)armful    — discarded, enters banned corpus, future similar
                   drafts suppressed
    (s)ideline   — flag for deep research, enters sideline queue,
                   surface blocked from translation

Workflow:

    1. Schema-learner produces a proposal with N Category-1 findings
       (novel surfaces requiring operator intervention).
    
    2. Operator runs `triage.py --proposal <dir>`.
    
    3. For each Category-1 finding (in order), the CLI presents:
         - the structural observations from the engine
         - the top-K structural neighbors as research context
         - any LLM draft (if available — Phase 3)
         - a prompt for (c)/(e)/(h)/(s)
    
    4. The operator's choice routes to the appropriate corpus tier
       and the next finding is presented.
    
    5. Resume support: triage state persists in the proposal directory.
       Operator can quit mid-session and resume later.

Per the founding principle:
    
    Every action carries operator identity (--operator flag) and a
    timestamp. Every (h)armful decision requires a free-text reason
    (mandatory). Every (c)orrect and (e)dit decision requires Q1-Q4
    answers and citations (existing merge_engine validation).
    Every (s)ideline records the surface for deep-research follow-up.

Usage:

    # Walk through all pending findings, prompt for action on each
    python3 triage.py walk --proposal <dir> --operator <name>
    
    # List the sideline queue
    python3 triage.py sideline list
    
    # List the banned corpus
    python3 triage.py banned list
    
    # Appeal a banned entry (mark held during review)
    python3 triage.py banned appeal --entry-id <id> --operator <name>
    
    # Resolve appeal (restore ban or unban)
    python3 triage.py banned resolve --entry-id <id> \\
        --action restore|unban --operator <name> --reason "..."
"""
from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import subprocess
import sys
from pathlib import Path

_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))
sys.path.insert(0, str(_TOOLKIT_ROOT / "schema_learner"))

from corpus_tiers import (  # noqa: E402
    BannedEntry, SidelineEntry,
    fingerprint_from_feature_vector,
    load_banned_entries, load_sideline_queue,
    make_entry_id,
    write_banned_entry, write_sideline_entry,
)
from llm_provider import (  # noqa: E402
    LLMDrafter, LLMDraft,
    build_provider_from_config,
)
from team_coordination import (  # noqa: E402
    acquire_lock, release_lock,
    log_action, require_authenticated_operator,
)


# ---------------------------------------------------------------------------
# MCP configuration loader
# ---------------------------------------------------------------------------

def _load_mcp_provider(config_path: Path):
    """Load [mcp] section from learn_config.ini. Returns LLMProvider or None."""
    import configparser
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(config_path, encoding='utf-8')
    if not cp.has_section('mcp'):
        return None
    section = dict(cp.items('mcp'))
    return build_provider_from_config(section)


def _load_mcp_drafter_config(config_path: Path) -> dict:
    """Read MCP-relevant config knobs we need beyond the provider build."""
    import configparser
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(config_path, encoding='utf-8')
    cfg = {'verify_citations': True, 'timeout': 15}
    if cp.has_section('mcp'):
        v = cp.get('mcp', 'verify_citations',
                   fallback='true').strip().lower()
        cfg['verify_citations'] = (v == 'true')
        try:
            cfg['timeout'] = int(cp.get('mcp', 'timeout_seconds',
                                         fallback='30'))
        except ValueError:
            cfg['timeout'] = 30
    return cfg


# ---------------------------------------------------------------------------
# Draft persistence (sibling to findings.json)
# ---------------------------------------------------------------------------

def _drafts_dir(proposal_dir: Path) -> Path:
    p = proposal_dir / "drafts"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _draft_path(proposal_dir: Path, surface_tag: str) -> Path:
    import re as _re
    safe = _re.sub(r'[^a-zA-Z0-9_-]', '_', surface_tag)
    return _drafts_dir(proposal_dir) / f"{safe}.json"


def _serialize_draft(draft: LLMDraft) -> dict:
    """Convert LLMDraft to a JSON-serializable dict."""
    def _claim_dict(c):
        return {
            'claim_text': c.claim_text,
            'citation_url': c.citation_url,
            'citation_excerpt': c.citation_excerpt,
            'verification_status': c.verification_status,
            'confidence': c.confidence,
            'confidence_reason': c.confidence_reason,
        }
    return {
        'surface_tag': draft.surface_tag,
        'model': draft.model,
        'drafted_at': draft.drafted_at,
        'purpose': _claim_dict(draft.purpose),
        'category': _claim_dict(draft.category),
        'sonicwall_equivalent': _claim_dict(draft.sonicwall_equivalent),
        'operational_notes': _claim_dict(draft.operational_notes),
        'self_validation_passed': draft.self_validation_passed,
        'self_validation_response': draft.self_validation_response,
        'structural_cross_check_consistent':
            draft.structural_cross_check_consistent,
        'structural_cross_check_note': draft.structural_cross_check_note,
        'overall_confidence': draft.overall_confidence,
        'drafting_notes': draft.drafting_notes,
    }


def _write_draft(proposal_dir: Path, draft: LLMDraft) -> Path:
    path = _draft_path(proposal_dir, draft.surface_tag)
    path.write_text(
        json.dumps(_serialize_draft(draft), indent=2),
        encoding='utf-8',
    )
    return path


def _deserialize_draft(data: dict) -> LLMDraft:
    """Reconstruct an LLMDraft from a previously-serialized dict."""
    from llm_provider import CitedClaim
    def _claim_from(d):
        return CitedClaim(
            claim_text=d.get('claim_text', ''),
            citation_url=d.get('citation_url', ''),
            citation_excerpt=d.get('citation_excerpt', ''),
            verification_status=d.get('verification_status', 'skipped'),
            confidence=d.get('confidence', 'low'),
            confidence_reason=d.get('confidence_reason', ''),
        )
    return LLMDraft(
        surface_tag=data.get('surface_tag', ''),
        model=data.get('model', ''),
        drafted_at=data.get('drafted_at', ''),
        purpose=_claim_from(data.get('purpose', {})),
        category=_claim_from(data.get('category', {})),
        sonicwall_equivalent=_claim_from(
            data.get('sonicwall_equivalent', {})),
        operational_notes=_claim_from(data.get('operational_notes', {})),
        self_validation_passed=data.get('self_validation_passed', False),
        self_validation_response=data.get('self_validation_response', ''),
        structural_cross_check_consistent=data.get(
            'structural_cross_check_consistent', True),
        structural_cross_check_note=data.get(
            'structural_cross_check_note', ''),
        overall_confidence=data.get('overall_confidence', 'low'),
        drafting_notes=data.get('drafting_notes', ''),
    )


def _format_draft_for_operator(draft: LLMDraft) -> str:
    """Render an LLM draft for display in the triage CLI."""
    lines: list[str] = []
    lines.append("")
    lines.append("LLM DRAFT (research assistant — operator must verify):")
    lines.append(f"  Model: {draft.model}")
    lines.append(f"  Overall confidence: {draft.overall_confidence}")
    if not draft.self_validation_passed:
        lines.append(f"  ⚠ LLM self-validation FAILED on its own draft")
    lines.append("")

    def _show_claim(label: str, claim) -> list[str]:
        out = []
        confidence_marker = {
            'high': '✓ HIGH (citation verified)',
            'medium': '~ MEDIUM',
            'low': '✗ LOW (citation not verified — operator must research)',
        }.get(claim.confidence, claim.confidence)
        out.append(f"  {label}: {claim.claim_text[:300]}")
        if claim.citation_url:
            out.append(f"    Citation: {claim.citation_url[:120]}")
            out.append(f"    Status:   {confidence_marker}")
            if claim.citation_excerpt:
                out.append(f"    Excerpt:  {claim.citation_excerpt[:150]}...")
            if claim.confidence_reason:
                out.append(f"    Reason:   {claim.confidence_reason[:150]}")
        else:
            out.append(f"    Citation: (none provided by LLM)")
            out.append(f"    Status:   {confidence_marker}")
        out.append("")
        return out

    lines.extend(_show_claim("Q1 Purpose", draft.purpose))
    lines.extend(_show_claim("Q2 Category", draft.category))
    lines.extend(_show_claim("Q3 SonicWall equivalent",
                              draft.sonicwall_equivalent))
    lines.extend(_show_claim("Q4 Operational notes",
                              draft.operational_notes))

    if not draft.structural_cross_check_consistent:
        lines.append("  ⚠ Structural cross-check flagged a discrepancy:")
        lines.append(f"    {draft.structural_cross_check_note}")
        lines.append("")

    return "\n".join(lines)


# Markers from intervention docs
OBS_OPEN = "<!-- ENGINE-OBSERVATION-BEGIN -->"
OBS_CLOSE = "<!-- ENGINE-OBSERVATION-END -->"
OP_OPEN = "<!-- OPERATOR-AUTHORED-BEGIN -->"
OP_CLOSE = "<!-- OPERATOR-AUTHORED-END -->"


# ---------------------------------------------------------------------------
# Triage state — tracks which findings have been processed
# ---------------------------------------------------------------------------

def _triage_state_path(proposal_dir: Path) -> Path:
    return proposal_dir / ".triage_state.json"


def _load_triage_state(proposal_dir: Path) -> dict:
    p = _triage_state_path(proposal_dir)
    if not p.is_file():
        return {'processed': {}, 'started_at': None,
                'last_action_at': None}
    return json.loads(p.read_text(encoding='utf-8'))


def _save_triage_state(proposal_dir: Path, state: dict) -> None:
    state['last_action_at'] = _dt.datetime.now().isoformat()
    _triage_state_path(proposal_dir).write_text(
        json.dumps(state, indent=2), encoding='utf-8')


# ---------------------------------------------------------------------------
# Finding presentation
# ---------------------------------------------------------------------------

def _format_finding_for_operator(finding: dict) -> str:
    """Format a single finding for operator display."""
    lines: list[str] = []
    lines.append("=" * 70)
    lines.append(f"  Surface: <{finding['element_tag']}>")
    lines.append(f"  Source:  {finding['source_file']}")
    lines.append(f"  Category: {finding['category']}")
    
    # Phase 6: tier-suggestion display
    status = finding.get('enabled_status', 'unknown')
    tier = finding.get('tier_suggestion', 1)
    evidence = finding.get('enabled_status_evidence', '')
    tier_label = {1: "🔴 Tier 1 (full triage)",
                  2: "🟡 Tier 2 (defer w/config)",
                  3: "🟢 Tier 3 (auto-skip OK)"}.get(tier, f"Tier {tier}")
    lines.append(f"  Status:  {status} — {tier_label}")
    if evidence:
        lines.append(f"  Evidence: {evidence}")
    lines.append("=" * 70)

    structural = finding.get('structural_facts', {})
    if structural:
        lines.append("")
        lines.append("STRUCTURAL OBSERVATIONS (engine):")
        lines.append(f"  Instance count:        {structural.get('instance_count', 0)}")
        lines.append(f"  Distinct child tags:   {structural.get('distinct_children_tags', 0)}")
        lines.append(f"  Distinct field shapes: {structural.get('distinct_field_shapes', 0)}")
        lines.append(f"  Naming tokens:         {structural.get('naming_tokens', [])}")
        top = structural.get('top_children_tags', [])[:10]
        if top:
            tag_list = ', '.join(t[0] for t in top)
            lines.append(f"  Top child tags:        {tag_list}")
        vp = structural.get('value_pattern_summary', {})
        if vp:
            lines.append("  Value patterns observed:")
            for fname, ptn in list(vp.items())[:8]:
                lines.append(f"    - {fname}: {ptn}")

    neighbors = finding.get('neighbors', [])
    if neighbors:
        lines.append("")
        lines.append("STRUCTURAL NEIGHBORS (research context, NOT kinship claim):")
        for n in neighbors[:5]:
            tag = n['tag']
            sim = n['aggregate_similarity']
            lines.append(f"  {tag:<40} similarity = {sim:.3f}")
    
    # Phase 6.5: surface the auto-promotion story when applicable.
    # Operator sees the original deferral reason alongside the new
    # finding so they understand WHY this surface is back in triage.
    if finding.get('category') == 'auto_promoted_from_deferred':
        detail = finding.get('detail', {})
        lines.append("")
        lines.append("AUTO-PROMOTED FROM DEFERRED (Phase 6.5):")
        lines.append(f"  Previously deferred in: "
                     f"{detail.get('original_source_proposal', '?')}")
        lines.append(f"  Deferred at: "
                     f"{detail.get('original_deferred_at', '?')}")
        lines.append(f"  Original deferral reason:")
        for line in (detail.get('original_deferral_reason', '')
                     .split('|')):
            line = line.strip()
            if line:
                lines.append(f"    {line[:100]}")
        lines.append(f"  Sideline entry: "
                     f"{detail.get('sideline_entry_id', '?')}")
        lines.append(f"  Why promoted now: "
                     f"{detail.get('new_status_evidence', '?')}")

    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Operator prompts
# ---------------------------------------------------------------------------

def _prompt(text: str) -> str:
    """Prompt for input. Returns trimmed string."""
    try:
        return input(text).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return ''


def _prompt_action() -> str:
    """Prompt for triage action — (c)orrect, (e)dit, (h)armful, (s)ideline,
    (q)uit, (?)help. Returns 'c', 'e', 'h', 's', 'q', or '' (skip)."""
    while True:
        choice = _prompt(
            "Action — (c)orrect, (e)dit, (h)armful, (s)ideline, "
            "(q)uit, (?)help: ").lower()
        if choice in ('c', 'e', 'h', 's', 'q'):
            return choice
        if choice == '?':
            print("""
  c — Correct: approved as-is. Enters approved corpus.
       Requires Q1-Q4 declarations with citations. The CLI will
       offer to launch your editor to fill in the existing
       OPERATOR_INTERVENTION_REQUIRED.md, then run merge_engine.
  
  e — Edit: rewrite the draft, then approve. Same as (c) but you
       are editing the LLM-drafted answer before approval.
  
  h — Harmful: this draft is wrong. Discard and ban the pattern.
       Requires a free-text REASON (mandatory). Future drafts
       structurally similar to this will be suppressed before
       reaching any operator. The surface is also routed to
       sideline so deep research can produce a non-banned answer.
  
  s — Sideline: not obviously wrong, not confidently right. Flag
       for deep research. Surface enters sideline queue. Translation
       blocks for this surface until deep research resolves.
  
  q — Quit: save state and exit. Resume later with the same command.
""")
            continue
        if choice == '':
            return ''  # skip / no action this round


def _prompt_reason(prompt_label: str, mandatory: bool) -> str:
    """Prompt for a free-text reason. Empty allowed only if not mandatory."""
    while True:
        reason = _prompt(f"  {prompt_label}: ")
        if reason or not mandatory:
            return reason
        print("  Reason is mandatory. Enter a non-empty reason.")


# ---------------------------------------------------------------------------
# Action handlers
# ---------------------------------------------------------------------------

def _handle_correct(
    finding: dict,
    proposal_dir: Path,
    operator: str,
) -> bool:
    """Action: (c)orrect — proceed to merge_engine apply for this surface.
    
    Strategy: write a one-surface intervention doc tailored to this
    finding, then invoke merge_engine. If declarations are missing,
    merge_engine will refuse and the operator will need to fill them in.
    
    For Phase 2, we use a simpler model: tell the operator to fill in
    the proposal's existing OPERATOR_INTERVENTION_REQUIRED.md for this
    surface, then run merge_engine apply on the proposal.
    """
    print(f"\n  CORRECT path for <{finding['element_tag']}>:")
    print(f"  ")
    print(f"  Step 1: Edit OPERATOR_INTERVENTION_REQUIRED.md in the")
    print(f"          proposal directory and fill in Q1-Q4 for this")
    print(f"          surface with citations.")
    print(f"  ")
    print(f"  Proposal: {proposal_dir / 'OPERATOR_INTERVENTION_REQUIRED.md'}")
    print(f"  ")
    print(f"  Step 2: Run the merge engine:")
    print(f"          python3 schema_learner/merge_engine.py apply \\")
    print(f"              --proposal {proposal_dir} \\")
    print(f"              --operator {operator} \\")
    print(f"              --confirm")
    print(f"  ")
    confirmed = _prompt(
        "  Type 'done' when you've completed both steps "
        "(or 'cancel' to skip): ").lower()
    return confirmed == 'done'


def _handle_edit(
    finding: dict,
    proposal_dir: Path,
    operator: str,
) -> bool:
    """Action: (e)dit — same as (c)orrect for Phase 2. The distinction
    matters more in Phase 3 when LLM drafts arrive — (c) accepts the
    draft as-is, (e) means rewrite it. For Phase 2 with no LLM drafts,
    both paths are identical from the operator's perspective."""
    return _handle_correct(finding, proposal_dir, operator)


def _handle_harmful(
    finding: dict,
    proposal_dir: Path,
    operator: str,
    draft: LLMDraft | None = None,
) -> bool:
    """Action: (h)armful — write to banned corpus.
    
    If an LLM draft is present, its text is captured in the banned
    corpus entry. This is the negative-training-signal loop:
    future LLM drafts that look like THIS specific draft will be
    suppressed before reaching any operator (Phase 2 mechanism).
    """
    print(f"\n  HARMFUL path for <{finding['element_tag']}>:")
    print(f"  Per addendum risk management, the reason field is mandatory.")
    print(f"  ")
    reason = _prompt_reason(
        "Reason this draft is harmful (mandatory)", mandatory=True)
    if not reason:
        return False

    # We need a feature-vector-equivalent fingerprint, but we only have
    # the JSON-serialized structural_facts. Build the fingerprint from
    # those facts directly.
    structural = finding.get('structural_facts', {})
    children = sorted(t for t, _ in structural.get('top_children_tags', []))
    values = sorted(
        f"{k}:{v}"
        for k, v in structural.get('value_pattern_summary', {}).items())
    tokens = list(structural.get('naming_tokens', []))

    # Phase 3: if an LLM draft was shown to the operator and is what
    # the operator is calling harmful, store its text. This makes the
    # banned-corpus entry richer than just the engine observation —
    # it records what the LLM said that was wrong.
    if draft is not None and draft.is_complete():
        banned_text = (
            f"LLM draft (model: {draft.model}) for "
            f"<{finding['element_tag']}>:\n"
            f"  Q1 purpose: {draft.purpose.claim_text}\n"
            f"  Q1 cited:   {draft.purpose.citation_url}\n"
            f"  Q2 category: {draft.category.claim_text}\n"
            f"  Q3 SonicWall equiv: {draft.sonicwall_equivalent.claim_text}\n"
            f"  Q4 operational: {draft.operational_notes.claim_text}"
        )
    else:
        banned_text = (
            f"Engine observation for surface <{finding['element_tag']}>: "
            f"children={children}, value_patterns={values[:10]}, "
            f"tokens={tokens}"
        )

    entry_id = make_entry_id(finding['element_tag'], 'ban')
    entry = BannedEntry(
        entry_id=entry_id,
        surface_tag=finding['element_tag'],
        operator=operator,
        timestamp=_dt.datetime.now().isoformat(),
        reason=reason,
        banned_draft_text=banned_text,
        children_tags_fingerprint=', '.join(children[:20]),
        value_patterns_fingerprint=', '.join(values[:20]),
        naming_tokens_fingerprint=', '.join(tokens),
        source_proposal=str(proposal_dir.name),
        status='active',
    )
    md_path = write_banned_entry(entry)
    print(f"  ✓ Banned-corpus entry written: {md_path}")
    print(f"    Entry ID: {entry_id}")
    if draft is not None and draft.is_complete():
        print(f"    Draft text captured for future suppression matching.")
    print(f"    Future drafts structurally similar to this surface will")
    print(f"    be suppressed before reaching any operator.")

    # Per addendum: harmful surfaces also enter sideline so deep
    # research can produce a non-banned classification eventually
    sideline_id = make_entry_id(finding['element_tag'], 'sl')
    sl_entry = SidelineEntry(
        entry_id=sideline_id,
        surface_tag=finding['element_tag'],
        operator=operator,
        timestamp=_dt.datetime.now().isoformat(),
        reason=(
            f'Routed to sideline because operator marked the engine '
            f'finding as (h)armful. Banned entry: {entry_id}. '
            f'Deep research needed to produce a non-banned classification.'
        ),
        first_seen_in=str(proposal_dir.name),
        last_seen_in=str(proposal_dir.name),
        last_seen_at=_dt.datetime.now().isoformat(),
        source_proposal=str(proposal_dir.name),
        children_tags_fingerprint=', '.join(children[:20]),
        value_patterns_fingerprint=', '.join(values[:20]),
        naming_tokens_fingerprint=', '.join(tokens),
        status='open',
    )
    write_sideline_entry(sl_entry)
    print(f"  ✓ Surface also routed to sideline queue: {sideline_id}")
    return True


def _handle_sideline(
    finding: dict,
    proposal_dir: Path,
    operator: str,
) -> bool:
    """Action: (s)ideline — write to sideline queue (no ban)."""
    print(f"\n  SIDELINE path for <{finding['element_tag']}>:")
    print(f"  Reason is encouraged but not required.")
    print(f"  ")
    reason = _prompt_reason(
        "Reason for sideline (optional)", mandatory=False)

    structural = finding.get('structural_facts', {})
    children = sorted(t for t, _ in structural.get('top_children_tags', []))
    values = sorted(
        f"{k}:{v}"
        for k, v in structural.get('value_pattern_summary', {}).items())
    tokens = list(structural.get('naming_tokens', []))

    sideline_id = make_entry_id(finding['element_tag'], 'sl')
    entry = SidelineEntry(
        entry_id=sideline_id,
        surface_tag=finding['element_tag'],
        operator=operator,
        timestamp=_dt.datetime.now().isoformat(),
        reason=reason or '(operator did not provide reason)',
        first_seen_in=str(proposal_dir.name),
        last_seen_in=str(proposal_dir.name),
        last_seen_at=_dt.datetime.now().isoformat(),
        source_proposal=str(proposal_dir.name),
        children_tags_fingerprint=', '.join(children[:20]),
        value_patterns_fingerprint=', '.join(values[:20]),
        naming_tokens_fingerprint=', '.join(tokens),
        status='open',
    )
    md_path = write_sideline_entry(entry)
    print(f"  ✓ Sideline entry written: {md_path}")
    print(f"    Entry ID: {sideline_id}")
    print(f"    Surface translation BLOCKED until deep research resolves.")
    return True


# ---------------------------------------------------------------------------
# Walk command — main triage workflow
# ---------------------------------------------------------------------------

def cmd_walk(args) -> int:
    proposal_dir = Path(args.proposal).resolve()
    if not proposal_dir.is_dir():
        print(f"✗ Proposal directory not found: {proposal_dir}")
        return 1

    findings_path = proposal_dir / 'findings.json'
    if not findings_path.is_file():
        print(f"✗ findings.json not found in: {proposal_dir}")
        return 1

    if not args.operator:
        print(f"✗ --operator <name> is required for triage")
        return 1

    # Phase 5: validate operator against team roster
    ok, msg = require_authenticated_operator(args.operator)
    if not ok:
        print(f"✗ {msg}")
        return 1

    findings_data = json.loads(findings_path.read_text(encoding='utf-8'))
    findings = findings_data.get('findings', [])
    cat1 = [f for f in findings
            if f['category'] in (
                'novel_element_type',
                'auto_promoted_from_deferred',  # Phase 6.5
            )]
    if not cat1:
        print(f"  No Category-1 findings in this proposal "
              f"({len(findings)} total).")
        print(f"  Nothing to triage.")
        return 0

    # ── Phase 6: tier filter ────────────────────────────────────────
    # Parse --tier into a set of acceptable tier values. "all" or
    # "1,2,3" both mean "no filter." Anything else restricts the
    # pending findings to those matching tier_suggestion.
    tier_filter_set: set[int] | None = None
    if args.tier and args.tier.lower() != 'all':
        try:
            tier_filter_set = {int(t.strip()) for t in args.tier.split(',')
                               if t.strip()}
        except ValueError:
            print(f"  ✗ --tier must be 'all' or comma-separated "
                  f"integers (e.g. '1', '1,2', '2,3')")
            return 1
        if not tier_filter_set.issubset({1, 2, 3}):
            print(f"  ✗ --tier values must be 1, 2, or 3")
            return 1

    cat1_filtered = cat1
    cat1_deferred: list[dict] = []
    if tier_filter_set is not None:
        cat1_filtered = [f for f in cat1
                          if f.get('tier_suggestion', 1) in tier_filter_set]
        cat1_deferred = [f for f in cat1
                          if f.get('tier_suggestion', 1) not in tier_filter_set]
        print(f"  Phase 6 tier filter: tier(s) {sorted(tier_filter_set)} "
              f"= {len(cat1_filtered)} findings; "
              f"{len(cat1_deferred)} deferred")

    if not cat1_filtered:
        print(f"  Tier filter excluded all {len(cat1)} cat-1 findings.")
        print(f"  Nothing to triage in current tier selection.")
        return 0

    state = _load_triage_state(proposal_dir)
    if state.get('started_at') is None:
        state['started_at'] = _dt.datetime.now().isoformat()
        state['operator'] = args.operator

    processed_tags = set(state.get('processed', {}).keys())
    pending = [f for f in cat1_filtered
               if f['element_tag'] not in processed_tags]
    
    # Phase 6: auto-sideline deferred findings (one-time per surface).
    # Each deferred finding becomes a sideline entry with reason
    # "deferred_disabled_in_source" so the work is visible in the
    # sideline queue. Skip surfaces already processed.
    if args.auto_sideline_deferred and cat1_deferred:
        deferred_pending = [f for f in cat1_deferred
                             if f['element_tag'] not in processed_tags]
        if deferred_pending:
            print(f"  Phase 6: auto-sidelining "
                  f"{len(deferred_pending)} deferred finding(s)...")
            sidelined_count = 0
            for f in deferred_pending:
                surface_tag = f['element_tag']
                # Build a minimal SidelineEntry. fingerprint pulled from
                # structural_facts emitted in findings.json.
                structural = f.get('structural_facts', {})
                children = sorted(t for t, _ in
                                   structural.get('top_children_tags', []))
                values = sorted(
                    f"{k}:{v}" for k, v in
                    structural.get('value_pattern_summary', {}).items())
                tokens = list(structural.get('naming_tokens', []))
                
                entry_id = make_entry_id(surface_tag, 'sl')
                evidence = f.get('enabled_status_evidence',
                                  'no evidence captured')
                sl_entry = SidelineEntry(
                    entry_id=entry_id,
                    surface_tag=surface_tag,
                    operator=args.operator,
                    timestamp=_dt.datetime.now().isoformat(),
                    reason=(
                        f'Phase 6 auto-defer: '
                        f'enabled_status={f.get("enabled_status", "?")}, '
                        f'tier={f.get("tier_suggestion", "?")}. '
                        f'Evidence: {evidence}'
                    ),
                    first_seen_in=str(proposal_dir.name),
                    last_seen_in=str(proposal_dir.name),
                    last_seen_at=_dt.datetime.now().isoformat(),
                    source_proposal=str(proposal_dir.name),
                    children_tags_fingerprint=', '.join(children[:20]),
                    value_patterns_fingerprint=', '.join(values[:20]),
                    naming_tokens_fingerprint=', '.join(tokens),
                    status='deferred_disabled_in_source',
                )
                try:
                    write_sideline_entry(sl_entry)
                    sidelined_count += 1
                    # Mark as processed in triage state so future runs
                    # don't re-defer
                    state.setdefault('processed', {})[surface_tag] = {
                        'action': 'auto_deferred',
                        'at': _dt.datetime.now().isoformat(),
                        'operator': args.operator,
                        'reason': 'tier-filter Phase 6',
                    }
                except Exception as e:
                    print(f"    ✗ failed to sideline <{surface_tag}>: {e}")
            _save_triage_state(proposal_dir, state)
            print(f"  ✓ {sidelined_count} deferred surfaces sidelined "
                  f"with reason 'deferred_disabled_in_source'")

    # ── Phase 3: LLM drafter setup ──────────────────────────────────
    # Load MCP provider if (1) MCP is enabled in config, (2) API key
    # is available in environment, and (3) operator did not pass
    # --no-llm. If any condition fails, drafter is None and Phase 2
    # behavior continues unchanged.
    mcp_drafter = None
    if not args.no_llm:
        config_path = (Path(args.config).resolve() if args.config
                       else _TOOLKIT_ROOT / 'schema_learner'
                            / 'learn_config.ini')
        provider = _load_mcp_provider(config_path)
        if provider is not None and provider.is_available:
            drafter_cfg = _load_mcp_drafter_config(config_path)
            mcp_drafter = LLMDrafter(
                provider=provider,
                verify_citations=drafter_cfg['verify_citations'],
                verification_timeout=drafter_cfg['timeout'],
            )

    print()
    print(f"  Triage walk for proposal: {proposal_dir.name}")
    print(f"  Operator:                 {args.operator}")
    print(f"  Category-1 findings:      {len(cat1)}")
    print(f"  Already processed:        {len(processed_tags)}")
    print(f"  Pending this session:     {len(pending)}")
    if mcp_drafter is not None:
        print(f"  LLM drafter:              ENABLED "
              f"({mcp_drafter.provider.model_label})")
    elif args.no_llm:
        print(f"  LLM drafter:              disabled (--no-llm)")
    else:
        print(f"  LLM drafter:              not configured "
              f"(set [mcp] enabled=true and API key)")
    print()

    for i, finding in enumerate(pending, 1):
        print()
        print(f"--- Finding {i} of {len(pending)} (this session) ---")
        print(_format_finding_for_operator(finding))

        # ── Phase 3: load or generate LLM draft ───────────────────
        draft: LLMDraft | None = None
        draft_file = _draft_path(proposal_dir, finding['element_tag'])
        if draft_file.is_file():
            # Cache hit — reuse prior draft (avoids re-spending API budget)
            try:
                cached = json.loads(draft_file.read_text(encoding='utf-8'))
                draft = _deserialize_draft(cached)
                print(f"  [LLM draft loaded from cache: {draft_file.name}]")
            except Exception:
                draft = None
        if draft is None and mcp_drafter is not None:
            print(f"  [Calling LLM drafter for <{finding['element_tag']}>...]")
            structural = finding.get('structural_facts', {})
            neighbors = finding.get('neighbors', [])
            try:
                draft = mcp_drafter.draft(
                    surface_tag=finding['element_tag'],
                    structural_facts=structural,
                    neighbors=neighbors,
                )
                if draft.is_complete():
                    _write_draft(proposal_dir, draft)
                    print(f"  [Draft cached: {draft_file.name}]")
                else:
                    print(f"  [LLM draft incomplete: "
                          f"{draft.drafting_notes or 'unknown reason'}]")
            except Exception as e:
                print(f"  [LLM drafter failed: {type(e).__name__}: {e}]")
                draft = None
        if draft is not None and draft.is_complete():
            print(_format_draft_for_operator(draft))

        # Phase 5: acquire lock for this (surface, proposal) pair
        # before showing the action prompt. Refuses if another
        # engineer is already classifying the same surface here.
        lock_ok, lock_msg, _ = acquire_lock(
            surface_tag=finding['element_tag'],
            proposal_dir=proposal_dir.name,
            operator=args.operator,
        )
        if not lock_ok:
            print(f"  ⚠ Lock contention: {lock_msg}")
            print(f"  Skipping this finding to avoid concurrent edit.")
            continue

        action = _prompt_action()

        if action == 'q':
            print(f"\n  Quitting. State saved. Resume with the same command.")
            release_lock(finding['element_tag'], proposal_dir.name,
                         args.operator)
            _save_triage_state(proposal_dir, state)
            return 0
        if action == '':
            print(f"  Skipping this finding without action.")
            release_lock(finding['element_tag'], proposal_dir.name,
                         args.operator)
            continue

        success = False
        if action == 'c':
            success = _handle_correct(finding, proposal_dir, args.operator)
        elif action == 'e':
            success = _handle_edit(finding, proposal_dir, args.operator)
        elif action == 'h':
            success = _handle_harmful(
                finding, proposal_dir, args.operator, draft=draft)
        elif action == 's':
            success = _handle_sideline(finding, proposal_dir, args.operator)

        if success:
            state['processed'][finding['element_tag']] = {
                'action': action,
                'at': _dt.datetime.now().isoformat(),
                'operator': args.operator,
            }
            _save_triage_state(proposal_dir, state)
            print(f"  ✓ {finding['element_tag']}: {action}")
            # Phase 5: audit log the action
            log_action(
                operator=args.operator,
                action_type=f'triage_{action}',
                target=finding['element_tag'],
                source_proposal=proposal_dir.name,
                detail=f'action={action}',
            )
        else:
            print(f"  ✗ {finding['element_tag']}: action cancelled, not recorded")

        # Release lock — action complete (success or cancelled)
        release_lock(finding['element_tag'], proposal_dir.name,
                     args.operator)

    print()
    print(f"  Triage walk complete. {len(state.get('processed', {}))} of "
          f"{len(cat1)} surfaces processed.")
    return 0


# ---------------------------------------------------------------------------
# Sideline list command
# ---------------------------------------------------------------------------

def cmd_sideline_list(args) -> int:
    queue = load_sideline_queue()
    if not queue:
        print(f"  Sideline queue is empty.")
        return 0
    # Phase 4: load deep_research helpers for SLA aging
    from deep_research import days_since_iso, is_sla_overdue
    print()
    print(f"  Sideline queue — {len(queue)} entries")
    print(f"  Sorted by occurrence (highest impact first)")
    print(f"  Phase 4: SLA aging shown per Decision #4 tiers")
    print()
    print(f"  {'STATUS':<12} {'TIER':<5} {'OCCUR':<6} "
          f"{'SURFACE':<28} {'OPERATOR':<18} {'SLA':<28}")
    print(f"  {'-'*12} {'-'*5} {'-'*6} {'-'*28} {'-'*18} {'-'*28}")
    overdue_count = 0
    for entry in queue:
        age = days_since_iso(entry.timestamp)
        overdue, sla_label = is_sla_overdue(entry.sla_tier, age)
        if overdue:
            overdue_count += 1
        print(f"  {entry.status:<12} {entry.sla_tier:<5} "
              f"{entry.occurrence_count:<6} "
              f"{entry.surface_tag[:26]:<28} {entry.operator[:16]:<18} "
              f"{sla_label:<28}")
    print()
    if overdue_count:
        print(f"  ⚠ {overdue_count} entries are SLA-overdue. "
              f"Senior engineer queue burndown needed.")
    print()
    return 0


# ---------------------------------------------------------------------------
# Phase 4: sideline claim (senior-engineer takes ownership for deep research)
# ---------------------------------------------------------------------------

def cmd_sideline_claim(args) -> int:
    """Senior engineer claims a sideline entry for deep research.
    Marks status='in_research' with the engineer's identity."""
    # Phase 5: validate operator
    auth_ok, auth_msg = require_authenticated_operator(args.operator)
    if not auth_ok:
        print(f"  ✗ {auth_msg}")
        return 1

    from deep_research import claim_sideline_entry
    success, message = claim_sideline_entry(args.entry_id, args.operator)
    if success:
        # Phase 5: audit log
        log_action(
            operator=args.operator,
            action_type='sideline_claim',
            target=args.entry_id,
            detail=message[:200],
        )
        print(f"  ✓ {message}")
        print(f"  ")
        print(f"  Next steps for deep research per Decision #7:")
        print(f"    1. Two citations per Q1-Q4 claim (vendor docs, "
              f"vendor KB, peer-reviewed sources)")
        print(f"    2. Lab verification on real Firebox "
              f"(MANDATORY — no exceptions)")
        print(f"    3. Peer review by another senior engineer")
        print(f"    4. Run: triage.py sideline promote --entry-id "
              f"{args.entry_id} ...")
        return 0
    print(f"  ✗ {message}")
    return 1


# ---------------------------------------------------------------------------
# Phase 4: sideline promote (the strict-validation merge for deep research)
# ---------------------------------------------------------------------------

def cmd_sideline_promote(args) -> int:
    """Promote a sideline entry to the approved corpus via deep-research
    workflow. Requires a JSON file containing the DeepResearchPromotion
    fields (Q1-Q4 with two sources, lab verification, peer review).
    
    The JSON file is the operator's deliverable — typically authored
    by the senior engineer via their preferred editor, then handed to
    this command."""
    from deep_research import (
        DeepResearchPromotion, LabVerification,
        write_lab_verification_artifact,
        mark_sideline_status,
    )
    promo_file = Path(args.promotion_file).resolve()
    if not promo_file.is_file():
        print(f"  ✗ Promotion file not found: {promo_file}")
        return 1
    try:
        data = json.loads(promo_file.read_text(encoding='utf-8'))
    except json.JSONDecodeError as e:
        print(f"  ✗ Promotion file is not valid JSON: {e}")
        return 1

    # Reconstruct the LabVerification from the JSON
    lv_data = data.get('lab_verification', {})
    lv = LabVerification(
        firebox_model=lv_data.get('firebox_model', ''),
        firmware_version=lv_data.get('firmware_version', ''),
        verified_by=lv_data.get('verified_by', ''),
        verified_at=lv_data.get('verified_at', ''),
        test_result=lv_data.get('test_result', ''),
        test_notes=lv_data.get('test_notes', ''),
        artifact_path=lv_data.get('artifact_path', ''),
    )

    promo = DeepResearchPromotion(
        surface_tag=data.get('surface_tag', ''),
        sideline_entry_id=data.get('sideline_entry_id', ''),
        purpose=data.get('purpose', ''),
        purpose_source_1=data.get('purpose_source_1', ''),
        purpose_source_2=data.get('purpose_source_2', ''),
        category=data.get('category', ''),
        category_source_1=data.get('category_source_1', ''),
        category_source_2=data.get('category_source_2', ''),
        sonicwall_equivalent=data.get('sonicwall_equivalent', ''),
        sonicwall_source_1=data.get('sonicwall_source_1', ''),
        sonicwall_source_2=data.get('sonicwall_source_2', ''),
        operational_notes=data.get('operational_notes', ''),
        operational_source_1=data.get('operational_source_1', ''),
        operational_source_2=data.get('operational_source_2', ''),
        lab_verification=lv,
        peer_reviewer=data.get('peer_reviewer', ''),
        peer_reviewed_at=data.get('peer_reviewed_at', ''),
        peer_review_notes=data.get('peer_review_notes', ''),
        deep_researcher=data.get('deep_researcher', args.operator),
        deep_research_at=data.get('deep_research_at',
                                   _dt.datetime.now().isoformat()),
    )

    # Validate stricter than operator-time
    ok, errors = promo.validate()
    if not ok:
        print(f"  ✗ Deep-research promotion validation failed.")
        print(f"    {len(errors)} error(s):")
        for e in errors:
            print(f"      - {e}")
        print(f"  ")
        print(f"  Per Decision #7 and the addendum, deep-research")
        print(f"  promotions are stricter than operator-time. Fill in")
        print(f"  the missing fields and retry.")
        return 1

    # Write the lab-verification artifact if test_notes are substantive
    # and no artifact_path was provided
    if not promo.lab_verification.artifact_path:
        artifact_path = write_lab_verification_artifact(
            promo.surface_tag, promo.lab_verification)
        print(f"  ✓ Lab-verification artifact written: {artifact_path}")

    print(f"  ✓ Promotion validates. Promoting via merge_engine...")
    print(f"  ")
    print(f"  Per addendum: the merge_engine apply step still runs")
    print(f"  with --confirm. The deep-research promotion provides")
    print(f"  the additional provenance (lab + peer review) on top")
    print(f"  of the existing operator-declaration validation.")
    print(f"  ")
    print(f"  Recommended next step: invoke merge_engine.py apply on")
    print(f"  a proposal that contains this surface, OR have the")
    print(f"  approved-corpus entry written via the existing flow.")
    print(f"  ")
    print(f"  Lab verification field for the schema entry:")
    print(f"  ")
    print(f"    lab_verified = {promo.lab_verification.to_field_string()}")
    print(f"  ")

    # Mark the sideline entry as resolved
    if promo.sideline_entry_id:
        success, msg = mark_sideline_status(
            promo.sideline_entry_id, 'resolved')
        if success:
            print(f"  ✓ Sideline entry marked resolved: {msg}")
    return 0


# ---------------------------------------------------------------------------
# Banned list / appeal commands
# ---------------------------------------------------------------------------

def cmd_banned_list(args) -> int:
    entries = load_banned_entries()
    if not entries:
        print(f"  Banned corpus is empty.")
        return 0
    print()
    print(f"  Banned corpus — {len(entries)} entries")
    print()
    print(f"  {'STATUS':<10} {'SURFACE':<30} {'OPERATOR':<20} "
          f"{'TIMESTAMP':<25}")
    print(f"  {'-'*10} {'-'*30} {'-'*20} {'-'*25}")
    for e in entries:
        print(f"  {e.status:<10} {e.surface_tag[:28]:<30} "
              f"{e.operator[:18]:<20} {e.timestamp[:23]:<25}")
    print()
    return 0


def cmd_banned_appeal(args) -> int:
    """Mark a banned entry as 'held' so its suppression is paused
    while a senior engineer reviews the appeal."""
    # Phase 5: validate operator
    auth_ok, auth_msg = require_authenticated_operator(args.operator)
    if not auth_ok:
        print(f"✗ {auth_msg}")
        return 1

    entries = load_banned_entries()
    target = None
    for e in entries:
        if e.entry_id == args.entry_id:
            target = e
            break
    if target is None:
        print(f"✗ Banned entry not found: {args.entry_id}")
        return 1
    if target.status != 'active':
        print(f"✗ Entry is not in 'active' status (currently: "
              f"{target.status}). Only active bans can be appealed.")
        return 1
    target.status = 'held'
    write_banned_entry(target)
    log_action(
        operator=args.operator,
        action_type='banned_appeal',
        target=args.entry_id,
        detail='ban marked held for senior review',
    )
    print(f"  ✓ Banned entry {args.entry_id} marked HELD.")
    print(f"    Suppression is now paused for this entry.")
    print(f"    Senior engineer review required to resolve appeal.")
    return 0


def cmd_banned_resolve(args) -> int:
    """Resolve an appeal: either restore the ban or unban."""
    # Phase 5: validate operator
    auth_ok, auth_msg = require_authenticated_operator(args.operator)
    if not auth_ok:
        print(f"✗ {auth_msg}")
        return 1

    if not args.reason:
        print(f"✗ --reason is required for resolve")
        return 1
    if args.action not in ('restore', 'unban'):
        print(f"✗ --action must be 'restore' or 'unban'")
        return 1

    entries = load_banned_entries()
    target = None
    for e in entries:
        if e.entry_id == args.entry_id:
            target = e
            break
    if target is None:
        print(f"✗ Banned entry not found: {args.entry_id}")
        return 1
    if target.status != 'held':
        print(f"✗ Entry is not in 'held' status (currently: "
              f"{target.status}). Only held entries can be resolved.")
        return 1

    if args.action == 'restore':
        target.status = 'restored'
    else:
        target.status = 'unbanned'
        target.unbanned_by = args.operator or 'unknown'
        target.unbanned_at = _dt.datetime.now().isoformat()
        target.unban_reason = args.reason
    write_banned_entry(target)
    log_action(
        operator=args.operator,
        action_type=f'banned_{args.action}',
        target=args.entry_id,
        detail=f'reason: {args.reason[:150]}',
    )
    print(f"  ✓ Appeal resolved: status = {target.status}")
    return 0


# ---------------------------------------------------------------------------
# Phase 4: deprecation registry commands (Decision #5: quarterly sweep)
# ---------------------------------------------------------------------------

def cmd_deprecation_mark(args) -> int:
    """Mark an approved-corpus entry as deprecated. Records timestamp,
    operator, vendor citation URL, and reason. The merge_engine will
    refuse to translate using deprecated features without explicit
    operator override."""
    # Phase 5: validate operator
    auth_ok, auth_msg = require_authenticated_operator(args.operator)
    if not auth_ok:
        print(f"  ✗ {auth_msg}")
        return 1

    from deep_research import DeprecationEntry, write_deprecation_entry
    if not args.vendor_citation.startswith(('http://', 'https://')):
        print(f"  ✗ vendor_citation must be a URL "
              f"(got: {args.vendor_citation[:60]!r})")
        return 1
    if len(args.reason.strip()) < 20:
        print(f"  ✗ deprecation reason must be substantive (20+ chars)")
        return 1
    entry = DeprecationEntry(
        surface_tag=args.surface_tag,
        deprecated_at=_dt.datetime.now().isoformat(),
        deprecated_by=args.operator,
        vendor_citation=args.vendor_citation,
        deprecation_reason=args.reason,
        replacement_feature=args.replacement or '',
    )
    path = write_deprecation_entry(entry)
    log_action(
        operator=args.operator,
        action_type='deprecation_mark',
        target=args.surface_tag,
        detail=f'cite={args.vendor_citation}; reason={args.reason[:120]}',
    )
    print(f"  ✓ Deprecation marked: {entry.surface_tag}")
    print(f"    Log: {path}")
    print(f"    Vendor citation: {args.vendor_citation}")
    if args.replacement:
        print(f"    Replacement: {args.replacement}")
    print(f"  ")
    print(f"  Run 'deprecation propagate --surface-tag {args.surface_tag}'")
    print(f"  to identify customer configs that may need review.")
    return 0


def cmd_deprecation_list(args) -> int:
    """List all deprecation entries from the registry."""
    from deep_research import load_deprecation_log
    deprecations = load_deprecation_log()
    if not deprecations:
        print(f"  Deprecation registry is empty.")
        return 0
    print()
    print(f"  Deprecation registry — {len(deprecations)} entries")
    print(f"  Per Decision #5: quarterly sweep against vendor release notes")
    print()
    print(f"  {'SURFACE':<28} {'DEPRECATED_AT':<22} {'BY':<16} "
          f"{'REPLACEMENT':<24}")
    print(f"  {'-'*28} {'-'*22} {'-'*16} {'-'*24}")
    for tag, entry in sorted(deprecations.items()):
        print(f"  {tag[:26]:<28} {entry.deprecated_at[:20]:<22} "
              f"{entry.deprecated_by[:14]:<16} "
              f"{(entry.replacement_feature or 'none')[:22]:<24}")
    print()
    print(f"  Use 'deprecation show --surface-tag <tag>' for full details.")
    return 0


def cmd_deprecation_show(args) -> int:
    """Show full details of one deprecation entry."""
    from deep_research import load_deprecation_log
    deprecations = load_deprecation_log()
    entry = deprecations.get(args.surface_tag)
    if entry is None:
        print(f"  ✗ No deprecation entry for surface "
              f"{args.surface_tag!r}")
        return 1
    print()
    print(f"  Deprecation: <{entry.surface_tag}>")
    print(f"  Deprecated at: {entry.deprecated_at}")
    print(f"  Deprecated by: {entry.deprecated_by}")
    print(f"  Vendor citation: {entry.vendor_citation}")
    if entry.replacement_feature:
        print(f"  Replacement: {entry.replacement_feature}")
    print(f"  Reason: {entry.deprecation_reason}")
    print()
    return 0


def cmd_deprecation_propagate(args) -> int:
    """Identify proposals/customer configs that previously translated
    using a now-deprecated feature. Per addendum: this is the
    'deprecation responsive' mechanism — knowing a feature is
    deprecated isn't enough; the team must know which past
    translations are affected."""
    from deep_research import find_proposals_referencing_surface
    matching = find_proposals_referencing_surface(args.surface_tag)
    if not matching:
        print(f"  No proposals reference surface "
              f"{args.surface_tag!r} in their findings.")
        print(f"  No customer notification needed for this deprecation.")
        return 0
    print()
    print(f"  Surface {args.surface_tag!r} appears in {len(matching)} "
          f"prior proposal(s):")
    for p in matching:
        print(f"    - {p.name}")
    print(f"  ")
    print(f"  Recommended action: review each proposal's translation")
    print(f"  output to determine whether the deprecated feature was")
    print(f"  actually used in the customer config. If yes, contact")
    print(f"  the customer to discuss replacement strategy.")
    return 0


# ---------------------------------------------------------------------------
# Phase 5: team / audit / disagreement / lock CLI handlers
# ---------------------------------------------------------------------------

def cmd_team_list(args) -> int:
    """List all authenticated team members."""
    from team_coordination import load_team_roster
    roster = load_team_roster()
    if not roster:
        print(f"  Team roster is empty (bootstrap mode).")
        print(f"  Add the first member with: team add --name <name> "
              f"--added-by <name> --email <email>")
        return 0
    print()
    print(f"  Team roster — {len(roster)} authenticated member(s)")
    print(f"  Per Decision #3: senior operators only, full triage rights.")
    print()
    print(f"  {'NAME':<22} {'EMAIL':<32} {'ADDED_AT':<22} {'ADDED_BY':<14}")
    print(f"  {'-'*22} {'-'*32} {'-'*22} {'-'*14}")
    for name, m in sorted(roster.items()):
        print(f"  {name[:20]:<22} {m.email[:30]:<32} "
              f"{m.added_at[:20]:<22} {m.added_by[:12]:<14}")
    print()
    return 0


def cmd_team_add(args) -> int:
    """Add an authenticated member to the roster."""
    from team_coordination import (TeamMember, load_team_roster,
                                    require_authenticated_operator,
                                    write_team_member)
    # The adder must be authenticated (or bootstrap empty roster)
    auth_ok, auth_msg = require_authenticated_operator(args.added_by)
    if not auth_ok:
        print(f"  ✗ {auth_msg}")
        return 1
    member = TeamMember(
        name=args.name,
        email=args.email,
        added_at=_dt.datetime.now().isoformat(),
        added_by=args.added_by,
        notes=args.notes,
    )
    write_team_member(member)
    log_action(
        operator=args.added_by,
        action_type='team_add',
        target=args.name,
        detail=f'email={args.email}, notes={args.notes[:80]}',
    )
    print(f"  ✓ Added {args.name} to team roster.")
    return 0


def cmd_team_remove(args) -> int:
    """Remove a member from the roster. Audit-logged."""
    from team_coordination import (remove_team_member,
                                    require_authenticated_operator)
    auth_ok, auth_msg = require_authenticated_operator(args.operator)
    if not auth_ok:
        print(f"  ✗ {auth_msg}")
        return 1
    removed = remove_team_member(args.name)
    if not removed:
        print(f"  ✗ {args.name!r} not in roster.")
        return 1
    log_action(
        operator=args.operator,
        action_type='team_remove',
        target=args.name,
    )
    print(f"  ✓ Removed {args.name} from team roster.")
    return 0


def cmd_audit_list(args) -> int:
    """List audit entries with optional filtering."""
    from team_coordination import load_audit_log
    entries = load_audit_log(args.month)
    if not entries:
        period = args.month or 'current month'
        print(f"  No audit entries for {period}.")
        return 0
    if args.operator:
        entries = [e for e in entries if e.operator == args.operator]
    if args.action:
        entries = [e for e in entries if args.action in e.action_type]
    if not entries:
        print(f"  No matching audit entries (after filters).")
        return 0
    print()
    print(f"  Audit log — {len(entries)} entries")
    print()
    print(f"  {'TIMESTAMP':<22} {'OPERATOR':<16} "
          f"{'ACTION':<22} {'TARGET':<28}")
    print(f"  {'-'*22} {'-'*16} {'-'*22} {'-'*28}")
    for e in entries:
        print(f"  {e.timestamp[:20]:<22} {e.operator[:14]:<16} "
              f"{e.action_type[:20]:<22} {e.target[:26]:<28}")
    print()
    return 0


def cmd_disagreement_file(args) -> int:
    """File a cross-engineer disagreement against a prior classification."""
    from team_coordination import (file_disagreement_flag,
                                    require_authenticated_operator)
    auth_ok, auth_msg = require_authenticated_operator(args.operator)
    if not auth_ok:
        print(f"  ✗ {auth_msg}")
        return 1
    if len(args.reason.strip()) < 20:
        print(f"  ✗ disagreement reason must be substantive (20+ chars)")
        return 1
    flag = file_disagreement_flag(args.surface_tag, args.operator,
                                   args.reason)
    log_action(
        operator=args.operator,
        action_type='disagreement_file',
        target=args.surface_tag,
        detail=f'flag_id={flag.flag_id}; reason={args.reason[:120]}',
    )
    print(f"  ✓ Disagreement filed: {flag.flag_id}")
    print(f"    Status: open — awaiting senior reviewer claim")
    return 0


def cmd_disagreement_list(args) -> int:
    """List all disagreement flags."""
    from team_coordination import load_disagreement_flags
    flags = load_disagreement_flags()
    if not flags:
        print(f"  No disagreement flags.")
        return 0
    print()
    print(f"  Disagreement flags — {len(flags)} total")
    print()
    print(f"  {'STATUS':<18} {'SURFACE':<26} {'FILED_BY':<14} "
          f"{'REVIEWER':<14}")
    print(f"  {'-'*18} {'-'*26} {'-'*14} {'-'*14}")
    for f in flags:
        print(f"  {f.status:<18} {f.surface_tag[:24]:<26} "
              f"{f.flagged_by[:12]:<14} {f.reviewer[:12]:<14}")
    print()
    return 0


def cmd_disagreement_claim(args) -> int:
    """Reviewer claims a disagreement flag."""
    from team_coordination import (claim_disagreement,
                                    require_authenticated_operator)
    auth_ok, auth_msg = require_authenticated_operator(args.operator)
    if not auth_ok:
        print(f"  ✗ {auth_msg}")
        return 1
    ok, msg = claim_disagreement(args.flag_id, args.operator)
    if not ok:
        print(f"  ✗ {msg}")
        return 1
    log_action(
        operator=args.operator,
        action_type='disagreement_claim',
        target=args.flag_id,
    )
    print(f"  ✓ {msg}")
    return 0


def cmd_disagreement_resolve(args) -> int:
    """Resolve a disagreement: keep / amend / revoke."""
    from team_coordination import (require_authenticated_operator,
                                    resolve_disagreement)
    auth_ok, auth_msg = require_authenticated_operator(args.operator)
    if not auth_ok:
        print(f"  ✗ {auth_msg}")
        return 1
    ok, msg = resolve_disagreement(args.flag_id, args.operator,
                                    args.resolution, args.notes)
    if not ok:
        print(f"  ✗ {msg}")
        return 1
    log_action(
        operator=args.operator,
        action_type=f'disagreement_resolve_{args.resolution}',
        target=args.flag_id,
        detail=args.notes[:200],
    )
    print(f"  ✓ {msg}")
    return 0


def cmd_lock_list(args) -> int:
    """List currently-active triage locks."""
    from team_coordination import list_active_locks
    locks = list_active_locks()
    if not locks:
        print(f"  No active triage locks.")
        return 0
    print()
    print(f"  Active triage locks — {len(locks)}")
    print()
    print(f"  {'SURFACE':<24} {'PROPOSAL':<32} "
          f"{'HELD_BY':<14} {'ACQUIRED_AT':<22}")
    print(f"  {'-'*24} {'-'*32} {'-'*14} {'-'*22}")
    for l in locks:
        print(f"  {l.surface_tag[:22]:<24} {l.proposal_dir[:30]:<32} "
              f"{l.held_by[:12]:<14} {l.acquired_at[:20]:<22}")
    print()
    return 0


def cmd_lock_break(args) -> int:
    """Forcibly release a lock. Use with caution. Audit-logged."""
    from team_coordination import (force_release_lock,
                                    require_authenticated_operator)
    auth_ok, auth_msg = require_authenticated_operator(args.operator)
    if not auth_ok:
        print(f"  ✗ {auth_msg}")
        return 1
    ok, msg, prior = force_release_lock(args.surface_tag,
                                          args.proposal_dir, args.operator)
    log_action(
        operator=args.operator,
        action_type='lock_break',
        target=f"{args.surface_tag}@{args.proposal_dir}",
        detail=f'prior_holder={prior}',
    )
    print(f"  ✓ {msg}")
    return 0


# ---------------------------------------------------------------------------
# Main CLI
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                  formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='command', required=True)

    p_walk = sub.add_parser('walk',
        help='Walk through pending Category-1 findings and triage each')
    p_walk.add_argument('--proposal', required=True,
                        help='Path to proposal directory')
    p_walk.add_argument('--operator', required=True,
                        help='Operator name for provenance')
    p_walk.add_argument('--no-llm', action='store_true',
                        help='Disable LLM drafting for this run '
                             '(Phase 2 behavior even if MCP configured)')
    p_walk.add_argument('--config',
                        help='Path to learn_config.ini (default: '
                             'schema_learner/learn_config.ini)')
    p_walk.add_argument('--tier', default='all',
                        help='Phase 6: filter findings by tier '
                             'suggestion. "1" = only enabled/unknown '
                             '(critical path). "1,2" = include disabled-'
                             'with-config (defer). "all" = no filter '
                             '(default).')
    p_walk.add_argument('--auto-sideline-deferred', action='store_true',
                        help='Phase 6: when --tier filters out findings, '
                             'auto-sideline them with reason '
                             '"deferred_disabled_in_source" so they '
                             'appear in sideline queue rather than '
                             'silently vanishing.')
    p_walk.set_defaults(func=cmd_walk)

    p_sl = sub.add_parser('sideline',
        help='Sideline-queue management')
    p_sl_sub = p_sl.add_subparsers(dest='subcommand', required=True)
    p_sl_list = p_sl_sub.add_parser('list',
        help='List sideline queue (sorted by occurrence)')
    p_sl_list.set_defaults(func=cmd_sideline_list)
    # Phase 4: claim and promote
    p_sl_claim = p_sl_sub.add_parser('claim',
        help='Senior engineer claims a sideline entry for deep research')
    p_sl_claim.add_argument('--entry-id', required=True,
                             help='Sideline entry ID to claim')
    p_sl_claim.add_argument('--operator', required=True,
                             help='Senior engineer name')
    p_sl_claim.set_defaults(func=cmd_sideline_claim)
    p_sl_prom = p_sl_sub.add_parser('promote',
        help='Promote a sideline entry to approved corpus via deep '
             'research (requires lab verification + peer review)')
    p_sl_prom.add_argument('--promotion-file', required=True,
                            help='JSON file with deep-research deliverables')
    p_sl_prom.add_argument('--operator', required=True,
                            help='Senior engineer doing the promotion')
    p_sl_prom.set_defaults(func=cmd_sideline_promote)

    p_ban = sub.add_parser('banned',
        help='Banned-corpus management')
    p_ban_sub = p_ban.add_subparsers(dest='subcommand', required=True)
    p_ban_list = p_ban_sub.add_parser('list', help='List banned entries')
    p_ban_list.set_defaults(func=cmd_banned_list)
    p_ban_appeal = p_ban_sub.add_parser('appeal',
        help='Mark a banned entry held for senior review')
    p_ban_appeal.add_argument('--entry-id', required=True)
    p_ban_appeal.add_argument('--operator', required=True)
    p_ban_appeal.set_defaults(func=cmd_banned_appeal)
    p_ban_resolve = p_ban_sub.add_parser('resolve',
        help='Resolve a held appeal — restore or unban')
    p_ban_resolve.add_argument('--entry-id', required=True)
    p_ban_resolve.add_argument('--action', required=True,
                                choices=['restore', 'unban'])
    p_ban_resolve.add_argument('--operator', required=True)
    p_ban_resolve.add_argument('--reason', required=True)
    p_ban_resolve.set_defaults(func=cmd_banned_resolve)

    # Phase 4: deprecation registry (Decision #5: quarterly sweep)
    p_dep = sub.add_parser('deprecation',
        help='Deprecation registry — mark/list/propagate deprecations')
    p_dep_sub = p_dep.add_subparsers(dest='subcommand', required=True)
    p_dep_mark = p_dep_sub.add_parser('mark',
        help='Mark an approved-corpus entry as deprecated')
    p_dep_mark.add_argument('--surface-tag', required=True,
                             help='Surface tag to mark deprecated')
    p_dep_mark.add_argument('--operator', required=True,
                             help='Senior engineer authoring deprecation')
    p_dep_mark.add_argument('--vendor-citation', required=True,
                             help='URL to vendor release notes')
    p_dep_mark.add_argument('--reason', required=True,
                             help='Why deprecated (substantive, 20+ chars)')
    p_dep_mark.add_argument('--replacement', default='',
                             help='Replacement feature if vendor specifies')
    p_dep_mark.set_defaults(func=cmd_deprecation_mark)
    p_dep_list = p_dep_sub.add_parser('list',
        help='List all deprecation entries')
    p_dep_list.set_defaults(func=cmd_deprecation_list)
    p_dep_show = p_dep_sub.add_parser('show',
        help='Show full details of one deprecation')
    p_dep_show.add_argument('--surface-tag', required=True)
    p_dep_show.set_defaults(func=cmd_deprecation_show)
    p_dep_prop = p_dep_sub.add_parser('propagate',
        help='Find prior proposals referencing a deprecated surface')
    p_dep_prop.add_argument('--surface-tag', required=True)
    p_dep_prop.set_defaults(func=cmd_deprecation_propagate)

    # Phase 5: team coordination
    p_team = sub.add_parser('team',
        help='Team roster management (Phase 5)')
    p_team_sub = p_team.add_subparsers(dest='subcommand', required=True)
    p_team_list = p_team_sub.add_parser('list',
        help='List authenticated team members')
    p_team_list.set_defaults(func=cmd_team_list)
    p_team_add = p_team_sub.add_parser('add',
        help='Add an authenticated team member')
    p_team_add.add_argument('--name', required=True)
    p_team_add.add_argument('--email', default='')
    p_team_add.add_argument('--added-by', required=True,
                             help='Existing member adding this one')
    p_team_add.add_argument('--notes', default='')
    p_team_add.set_defaults(func=cmd_team_add)
    p_team_rm = p_team_sub.add_parser('remove',
        help='Remove a team member from roster')
    p_team_rm.add_argument('--name', required=True)
    p_team_rm.add_argument('--operator', required=True,
                            help='Existing member performing removal')
    p_team_rm.set_defaults(func=cmd_team_remove)

    # Phase 5: audit log
    p_audit = sub.add_parser('audit',
        help='Audit log inspection (Phase 5)')
    p_audit_sub = p_audit.add_subparsers(dest='subcommand', required=True)
    p_audit_list = p_audit_sub.add_parser('list',
        help='List audit entries (current month, or specify --month)')
    p_audit_list.add_argument('--month', default=None,
        help='YYYY-MM format (default: current month)')
    p_audit_list.add_argument('--operator', default=None,
        help='Filter by operator')
    p_audit_list.add_argument('--action', default=None,
        help='Filter by action_type substring')
    p_audit_list.set_defaults(func=cmd_audit_list)

    # Phase 5: disagreement flags
    p_dis = sub.add_parser('disagreement',
        help='Cross-engineer disagreement flags (Phase 5)')
    p_dis_sub = p_dis.add_subparsers(dest='subcommand', required=True)
    p_dis_file = p_dis_sub.add_parser('file',
        help='File a disagreement against a prior classification')
    p_dis_file.add_argument('--surface-tag', required=True)
    p_dis_file.add_argument('--operator', required=True,
        help='Engineer filing the disagreement')
    p_dis_file.add_argument('--reason', required=True,
        help='Why you disagree (substantive)')
    p_dis_file.set_defaults(func=cmd_disagreement_file)
    p_dis_list = p_dis_sub.add_parser('list',
        help='List all disagreement flags')
    p_dis_list.set_defaults(func=cmd_disagreement_list)
    p_dis_claim = p_dis_sub.add_parser('claim',
        help='Reviewer claims a disagreement flag')
    p_dis_claim.add_argument('--flag-id', required=True)
    p_dis_claim.add_argument('--operator', required=True,
        help='Reviewer name')
    p_dis_claim.set_defaults(func=cmd_disagreement_claim)
    p_dis_resolve = p_dis_sub.add_parser('resolve',
        help='Resolve a disagreement: keep/amend/revoke')
    p_dis_resolve.add_argument('--flag-id', required=True)
    p_dis_resolve.add_argument('--operator', required=True)
    p_dis_resolve.add_argument('--resolution', required=True,
        choices=['keep', 'amend', 'revoke'])
    p_dis_resolve.add_argument('--notes', required=True,
        help='Substantive review notes (20+ chars)')
    p_dis_resolve.set_defaults(func=cmd_disagreement_resolve)

    # Phase 5: lock management
    p_lock = sub.add_parser('lock',
        help='Triage lock management (Phase 5)')
    p_lock_sub = p_lock.add_subparsers(dest='subcommand', required=True)
    p_lock_list = p_lock_sub.add_parser('list',
        help='List active triage locks')
    p_lock_list.set_defaults(func=cmd_lock_list)
    p_lock_break = p_lock_sub.add_parser('break',
        help='Forcibly release a lock (use with caution)')
    p_lock_break.add_argument('--surface-tag', required=True)
    p_lock_break.add_argument('--proposal-dir', required=True)
    p_lock_break.add_argument('--operator', required=True,
        help='Engineer forcing the break (audit trail)')
    p_lock_break.set_defaults(func=cmd_lock_break)

    args = ap.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
