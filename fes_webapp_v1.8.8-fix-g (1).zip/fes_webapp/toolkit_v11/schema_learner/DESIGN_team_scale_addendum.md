# DESIGN Addendum: Team-Scale Learning System

**Status:** Design draft, ready for review before implementation
**Author:** Jim Ames + Claude (collaborative design, May 2026)
**Supersedes:** Nothing — extends DESIGN.md with a higher-level architectural frame
**Predecessor:** schema_learner/DESIGN.md (Mission A and Mission B remain valid; this
addendum reframes the surrounding system that consumes their output)

---

## Why this addendum exists

The original DESIGN.md captured Mission A (schema-learner detecting novel surfaces) and
Mission B (corpus scorer producing rich confidence signals). Those designs are sound and
the implementation is complete through Step 4.

This addendum captures a reframe that surfaced during a design conversation in May 2026.
The reframe is significant enough to warrant explicit documentation so that future
implementers — and future Claude sessions — understand what the toolkit is *for* at the
business and operational level, not just the technical level.

The reframe in one sentence:

> **The toolkit is not a translator with a learning component. It is a learning system
> with a translation frontend, designed to scale expert work from one engineer to a team
> of engineers while compounding the team's knowledge into permanent infrastructure.**

Every architectural decision below follows from that reframe.

---

## The bottleneck the reframe addresses

A single senior field engineer working alone can convert roughly one customer firewall
configuration per day, including the operator-research cycle for novel surfaces. This is
the "Jim baseline" — one expert, one config per day, deep research with citations on
every novel surface, full provenance maintained throughout.

The Jim baseline is a hard ceiling for a one-engineer operation. It is also the wrong
ceiling for a managed services provider that wants to convert dozens or hundreds of
configurations per month across a customer base.

Adding more engineers does not directly multiply throughput. Each new engineer faces the
same per-surface research work the first engineer faced. Without coordination, the team
re-does the same research. Without shared corpus, novel surfaces classified by Engineer A
on Monday remain novel to Engineer B on Tuesday. Without quality gates, junior engineers
under deadline pressure produce lower-quality classifications than senior engineers, and
the toolkit's permanent knowledge base degrades silently.

The reframe addresses this by making the toolkit itself the coordination layer:

- Each engineer's classification work is **persisted to a shared corpus**
- The corpus serves **all engineers on subsequent configs**
- The toolkit **detects duplicate work** and serves prior classifications automatically
- **Quality gates** prevent low-quality classifications from contaminating the corpus
- **Negative training signal** (banned drafts) accumulates and is enforced mechanically

The result: the team's first month of work compounds. By month three, the typical
customer config produces few enough novel surfaces that conversion throughput
approximates "one engineer-hour per config" rather than "one engineer-day per config."

---

## The four-state triage taxonomy

This is the operational core of the system. When the schema-learner detects a novel
surface in a customer config, the toolkit produces an LLM-drafted candidate
classification with verified citations. The operator (any engineer on the team) sees the
draft and selects one of four actions:

### (c)orrect — approved and stored

The draft is accurate and complete. Operator approves. The classification enters the
**approved corpus** with full provenance: operator name, timestamp, citation sources,
LLM model used for drafting (if any), structural-similarity score relative to existing
corpus.

Future engineers encountering this surface receive the approved classification
automatically — no re-research required.

### (e)dit — operator rewrites then approves

The draft is partially right, or in the right direction but worded poorly. Operator
rewrites Q1-Q4 to their preferred form, supplies their own citations, then approves. The
operator-edited version enters the approved corpus with the operator listed as the
author, not the LLM.

This is the most common path for senior engineers: the LLM draft is a starting point;
the operator's expertise produces the final form.

### (h)armful — discard and ban

The draft is wrong in a way that future drafts on the same surface would also be wrong.
Operator marks it banned. The pattern enters the **banned corpus** with the reason
operator gave for banning (free-text field, encouraged but not required).

Subsequent LLM drafts that match the banned pattern (by structural similarity above
threshold) are intercepted before being shown to any operator. The surface is routed
directly to sideline.

This is the negative training signal most systems throw away. Capturing it is what
prevents the LLM's failure modes from re-presenting themselves to operators.

### (s)ideline — flag for deep research

The draft is not obviously wrong, not confidently right. Operator does not have time or
authority to research it now. The surface enters the **sideline queue**.

Surfaces in sideline are blocked from translation (per existing hard-block enforcement)
and are visible to the team prioritized by occurrence frequency across configs. A
designated senior engineer (the "deep research" role) works the queue, producing
high-quality classifications that go through a stricter approval path before entering
the corpus.

---

## Three-tier corpus architecture

The classification work feeds three persistent stores. Each has its own role,
provenance discipline, and access pattern.

### Tier 1: Approved corpus

**What it stores:** every (c)orrect or (e)dit-then-approved classification.

**Existing implementation:** today this is the toolkit's INI bundle —
`wg_xml_schema.ini`, `concept_map.ini`, etc., as modified by the merge engine. The
addendum doesn't replace this; it extends it.

**Provenance carried:** operator name, timestamp, citation sources, structural facts
the schema-learner observed, LLM-draft-was-accepted vs operator-edited flag.

**Access pattern:** read on every translation, written on every approved classification.

**Growth profile:** monotonically increasing as the team works more configs. Cleanup
only happens through the explicit deprecation workflow (see "Vendor Deprecation
Awareness" below).

### Tier 2: Banned corpus

**What it stores:** every (h)armful classification with the operator's reason.

**Implementation:** new — `schema_learner/corpus/_banned.ini` or equivalent. Structured
the same way as the approved corpus but with a different role taxonomy entry in
`_corpus_index.ini`.

**Provenance carried:** which surface tag and structural fingerprint was banned,
operator name, timestamp, banning reason, the LLM draft text that triggered the ban
(stored verbatim so future drafts can be compared to it).

**Access pattern:** every LLM draft is checked against this before being shown to any
operator. If structural similarity exceeds threshold, the draft is intercepted.

**Critical safety property:** the banned corpus is **append-mostly** but supports a
formal appeal workflow (see "Banned-Corpus Risk Management" below). False positives in
the banned corpus are operationally dangerous and the system must support corrections.

### Tier 3: Sideline queue

**What it stores:** surfaces where the operator deferred classification.

**Implementation:** new — `schema_learner/sideline/<surface_id>.md` per entry, plus a
queue index sorted by frequency-of-occurrence.

**Provenance carried:** the surface's structural facts, the LLM draft (if any),
operator name and timestamp of sideline action, occurrence count across configs (the
primary prioritization signal), assigned-to field if a senior engineer has claimed it.

**Access pattern:** read-mostly during operator workflow (to skip surfaces already
sidelined). Written when an operator sideline-routes. Closed when a senior engineer
completes deep research and promotes the entry to the approved corpus (or, less
commonly, to the banned corpus).

**Critical operational property:** the sideline queue is the system's most likely
failure mode. Surfaces accumulate, deep research is deprioritized, customers wait. The
SLA discipline below is non-negotiable.

---

## The LLM's role, precisely scoped

The reframe changes the LLM's role significantly. Documenting it precisely so future
sessions don't re-expand the scope:

### What the LLM does

**Draft generation for genuinely-novel surfaces.** When the schema-learner detects a
surface that does not match any approved-corpus entry by tag or structural similarity,
the LLM is invoked to draft Q1-Q4 candidate answers. The draft uses the multi-turn
interview pattern from the N2NHU world generator (describe → extract → self-validate →
correct) plus mandatory citation finding via web tools.

**Citation finding for known-but-uncited surfaces.** When the operator authors a
classification and asks the toolkit to find a vendor-documentation URL to cite, the LLM
performs a constrained search: given a known surface tag, find the canonical vendor doc
page, return the URL plus 2-3 relevant excerpts.

**Structural-similarity-aware suggestion.** When drafting, the LLM is given the
schema-learner's top-K structural neighbors as context. Drafts that contradict the
structural context (e.g., LLM says "VPN tunnel" when neighbors are HTML-web-app
elements) are flagged for operator attention rather than presented as confident.

### What the LLM does NOT do

**The LLM never produces a final classification that enters the corpus directly.** All
LLM output passes through operator triage. The corpus contains operator-authored or
operator-approved entries only.

**The LLM never marks anything "high confidence" without a verified citation URL.** A
citation is verified by `web_fetch`-ing the URL and confirming the page contains terms
relevant to the draft's claims. URLs that 404 or contain unrelated content downgrade
confidence to "low — operator must research."

**The LLM never overrides the (h)armful classification of a similar prior draft.** The
banned corpus is checked first. If a draft is structurally similar to a banned entry,
it is suppressed, not shown to the operator with a "but this might be different"
caveat.

**The LLM never sees the previous operator's name or judgment as input.** The toolkit
looks up prior classifications by structural fingerprint, but the LLM drafts are
independent of who drafted before. This prevents the LLM from "agreeing with the senior
engineer" as a default behavior.

---

## The workflow per surface

This is the operational sequence the toolkit follows when a customer config arrives and
the schema-learner detects a novel surface. Documented precisely so the implementation
sequence is clear:

```
[ INPUT: customer XML config submitted to pipeline ]

  1. Schema-learner runs.
     For each element type in the config, classify against existing schema:
       - in approved corpus by tag → use it, done
       - novel surface → continue to step 2

  2. Approved-corpus structural-similarity lookup.
     For the novel surface, compute feature vector.
     Compare to all approved-corpus entries by structural similarity.
     If aggregate similarity > AUTO_REUSE_THRESHOLD (default 0.85) AND
        the matched entry shares same surface category:
         → auto-apply the matched entry's classification with provenance
           comment noting "auto-reused from <prior_surface_tag>, similarity X.XX"
         → done for this surface
     Otherwise → continue to step 3

  3. Banned-corpus structural-similarity lookup.
     Compare to all banned-corpus entries by structural similarity.
     If aggregate similarity > BANNED_SUPPRESS_THRESHOLD (default 0.80):
         → route surface directly to sideline queue with note
           "structurally similar to banned pattern; needs deep research"
         → no LLM draft is generated, no draft is shown to operator
         → done for this surface (operator sees it later via sideline queue)
     Otherwise → continue to step 4

  4. LLM drafting (if MCP enabled and configured).
     Run multi-turn interview to draft Q1-Q4.
     For each claim that requires citation, run web_fetch verification.
     Produce a draft document with confidence per claim.

  5. Operator triage interface.
     Operator sees:
       - Schema-learner structural observations (engine-authored)
       - LLM draft (if any) with verified citations
       - Approved-corpus near-neighbors as research context
       - Four action buttons: (c)orrect / (e)dit / (h)armful / (s)ideline

  6. Operator decision routes to appropriate corpus:
     - (c)orrect    → approved corpus, future configs auto-reuse
     - (e)dit       → operator rewrites, approved corpus, future configs auto-reuse
     - (h)armful    → banned corpus, future similar drafts suppressed
     - (s)ideline   → sideline queue, surface blocked, awaits deep research

[ OUTPUT: corpus updated, surface translated (or blocked with reason) ]
```

This sequence explicitly handles the three-tier corpus, the LLM-suppression check, and
the operator triage in a defined order with defined thresholds. Implementations
should not reorder these steps.

---

## Banned-corpus risk management

The banned corpus is the most operationally dangerous part of this design. False
positives — drafts marked (h)armful when they were actually correct — silently degrade
the system's ability to classify similar surfaces correctly in the future. Captain Ames
flagged this risk during the design conversation and it deserves explicit treatment.

### Mechanisms to prevent harmful banned-corpus growth

**Mandatory reason field.** When an operator clicks (h)armful, they must provide a
free-text reason explaining why the draft was wrong. This serves three purposes:
deters click-through bans under deadline pressure; provides context for future
appeal review; gives senior engineers signal about which LLM failure modes recur.

**Periodic banned-corpus review.** A senior engineer is responsible for reviewing the
banned corpus quarterly (or per N additions, whichever comes first). The review
confirms that bans remain appropriate as vendor documentation, vendor versions, or
team understanding evolves.

**Appeal mechanism.** Any team member can flag a banned-corpus entry for appeal. The
appeal moves the entry to a held state: future LLM drafts that match are NOT
auto-suppressed during the held period. The senior reviewer either restores the ban
(with updated reason) or promotes the surface to sideline for deep research.

**Disambiguation between banned-pattern and banned-context.** The banned corpus stores
both the surface tag and the structural fingerprint. A draft is suppressed only if BOTH
the tag matches AND the structural fingerprint exceeds threshold. This prevents
"draft was wrong for surface A" from suppressing a similar draft that might be right
for surface B.

### Anti-pattern to avoid

A banned corpus that grows by N entries per Jim per day, without periodic review,
becomes a permanent set of cataracts on the LLM's vision. By month three, the LLM
cannot draft anything because everything looks like something previously banned. The
operator workflow degrades because every novel surface routes to sideline instead of
producing useful drafts.

The mitigation is the appeal mechanism plus the senior-review cadence. Both are
required. Skipping either is a path to system failure.

---

## Sideline queue management

The sideline queue is the second most operationally dangerous failure mode. Surfaces
flagged for deep research can sit indefinitely if no engineer has time to do deep
research. The queue grows; translations stay blocked; customer configs accumulate
unfinished work.

### SLA discipline

Surfaces in the sideline queue have explicit aging rules:

**Tier 1 (low impact):** surface appears in 1-2 customer configs. Sideline tolerated
indefinitely. Translation is blocked but the customer impact is bounded.

**Tier 2 (medium impact):** surface appears in 3-9 customer configs. SLA: deep research
must complete within 30 days of first sideline. After 30 days, the surface escalates to
"customer-impact review."

**Tier 3 (high impact):** surface appears in 10+ customer configs OR appears in
configurations of customers above a revenue threshold. SLA: deep research must complete
within 7 days. After 7 days, escalates to "all-hands review."

### Senior engineer ownership

A designated senior engineer owns the sideline queue burndown. This is not collateral
duty — it is a defined role with allocated time. The senior engineer:

- Reviews the queue weekly
- Prioritizes by tier and revenue impact
- Performs deep research with citations
- Authors final classifications that enter the approved corpus
- Surfaces patterns to the team (e.g., "this vendor sub-feature is appearing
  everywhere; let's get authoritative documentation before more bans accumulate")

### What "deep research" means

Deep research is distinct from operator-time research in three ways:

- **Multiple citations required.** Where operator-time classifications need one
  citation per claim, deep research requires two independent sources per claim where
  available.
- **Lab verification when feasible.** For deep research surfaces that affect
  translation behavior, the senior engineer attempts to import the surface on a lab
  Firebox and confirm round-trip behavior matches the proposed mapping.
- **Multi-engineer review.** Before promotion to approved corpus, deep research
  classifications are reviewed by at least one other senior engineer.

The output of deep research is the strongest possible classification: multi-cited,
lab-verified where applicable, peer-reviewed. It enters the approved corpus marked
with a "deep_research" flag so its provenance is distinguishable from operator-time
classifications.

---

## Vendor deprecation awareness

A risk surfaced during the May 2026 design conversation: vendors deprecate features.
WatchGuard deprecated DLP in February 2025 (confirmed via web_fetch during that
session). A toolkit that confidently maps a deprecated source feature to a deprecated
target feature, without flagging the deprecation, produces broken production
configurations.

### Mechanisms

**Deprecation registry.** A new INI section in the corpus index marks any
approved-corpus entry as deprecated, with the deprecation date and source citation
(typically a vendor release notes URL). The merge engine refuses to apply translations
that involve deprecated source-or-target features without explicit operator
acknowledgment.

**Periodic deprecation sweep.** Quarterly, a senior engineer reviews the approved
corpus against vendor release notes from the prior quarter. Any newly-deprecated
features are marked.

**Deprecation propagation.** When a feature is marked deprecated, every customer
config that has used that feature in a prior translation receives a notification —
"customer X's prior translation included `feature Y` which has been deprecated by
vendor Z; consider review before the next configuration push."

This last mechanism is the difference between "deprecation aware" and "deprecation
responsive." A toolkit that knows DLP is deprecated but doesn't tell anyone about
prior translations using DLP is providing minimal value.

---

## Multi-engineer coordination

The reframe assumes multiple engineers working in parallel. The toolkit's existing
single-engineer assumptions need extension.

### Authentication and operator identity

Every classification action records the operator's identity. This is already partially
implemented (the merge engine takes `--operator <name>`). The team-scale extension:

- Operator identity is verified against a team roster (new INI:
  `team_config/engineers.ini`)
- All authenticated operators have full triage rights — no role-based access control
  per the resolved decision (see "Decisions resolved" #3)
- Lab access for deep-research lab verification is a separate operational concern,
  not a toolkit-enforced role gate

### Audit log

A new file: `schema_learner/audit/<year>-<month>.log` records every action with
operator identity, timestamp, action type, surface tag, and merge ID. This is
append-only, never modified. Provides forensic history for any classification dispute.

### Concurrent edit handling

Two engineers might encounter the same novel surface in different customer configs at
the same time. The toolkit handles this with a lock-on-classification:

- When operator A opens a triage view for surface X, a lock entry is written
  (`schema_learner/locks/<surface_fingerprint>.lock`) with operator and timestamp
- Operator B opening the same surface sees "in classification by Operator A since
  HH:MM" and is shown a read-only view with the option to wait or work on a different
  surface
- Locks expire after a configurable timeout (default 4 hours) so abandoned sessions
  don't permanently block surfaces

### Cross-engineer disagreement

If Operator A classifies surface X as (c)orrect and Operator B later believes the
classification is wrong, B can flag the entry for re-review. The flag does not modify
the corpus entry but does mark it "under review." Senior engineers see flagged
entries in their queue and resolve them with the appeal mechanism (similar to
banned-corpus appeals).

---

## Implementation phasing

The full design is substantial. Implementing everything at once is a bad idea. The
following phasing prioritizes value delivery and risk management:

### Phase 1: Approved-corpus auto-reuse (highest priority, lowest risk)

**Scope:** add the structural-similarity lookup against the approved corpus to the
schema-learner's workflow. When a novel surface matches an approved-corpus entry above
threshold, auto-apply with provenance comment.

**Schema requirement:** approved-corpus entries gain two new fields from day one,
introduced in Phase 1 even though they are most actively used in Phases 4-5:
  - `deprecated`: timestamp + vendor citation if the surface is deprecated by vendor
  - `lab_verified`: timestamp + Firebox model + firmware version if the entry was
    deep-research lab-verified (vs operator-time classification)

These fields default to empty for Phase 1-2 entries and are populated by Phase 4
deep-research workflow. Defining them now prevents schema migration later.

**Why first:** delivers compounding value immediately. Every previously-classified
surface stops re-appearing in intervention docs. This is the foundational mechanism
that makes the team-scale value proposition work.

**Estimated build:** 200-400 lines of code in `schema_learner.py`, new test cases in
`test_merge_engine.py`, new threshold config in `learn_config.ini`.

**Validation:** rerun schema-learner on TEMPLATE_FW after one synthetic
"approved-corpus" entry for `<vpn-portal>`. Verify that subsequent runs do not surface
`<vpn-portal>` as novel.

### Phase 2: The four-state triage frontend

**Scope:** build the operator triage interface that presents schema-learner
observations + LLM draft + approved-corpus near-neighbors with the four action
buttons. Implement the routing of each action to its appropriate corpus.

**Why second:** this is the operational core. Phase 1 alone delivers value, but Phase
2 turns the toolkit into a learning system rather than a translation tool with a
corpus lookup.

**Estimated build:** 600-1000 lines split across a new `triage_engine.py`, GUI
extensions, and corpus persistence layer. New test suite. New `_banned.ini` and
`sideline/` directory structures with corpus index updates.

**Validation:** end-to-end test on TEMPLATE_FW with synthetic operator decisions
covering all four actions. Verify each routes to the correct corpus, verify
auto-reuse works after (c)orrect, verify suppression works after (h)armful.

### Phase 3: LLM drafting integration (the MCP)

**Scope:** integrate the multi-turn LLM interview pattern with mandatory citation
verification. Drafts feed into the Phase 2 triage interface as input.

**Why third:** Phases 1 and 2 deliver value with operator-only research. Phase 3 adds
the productivity multiplier on top, but only after the surrounding architecture is
proven. Building the MCP first risks over-investing in a component whose surrounding
context isn't yet load-tested.

**Estimated build:** 500-800 lines split across `mcp_drafter.py`, web_fetch
verification logic, citation extraction, and structural-similarity-aware draft
suggestion.

**Validation:** operator A/B test on a real customer config: half of novel surfaces
go through MCP-drafted triage, half through manual triage. Compare time-per-surface,
classification quality (measured by post-hoc senior review), and operator satisfaction.

### Phase 4: Sideline queue and deep-research workflow

**Scope:** sideline queue indexing and prioritization. Senior-engineer queue
ownership. Deep-research approval path with multi-engineer review.

**Why fourth:** sideline only matters once the team has accumulated sideline entries
worth working through. Premature implementation creates a queue with no entries and
no engineers assigned to it.

**Estimated build:** 300-500 lines plus the senior-review workflow UI.

**Validation:** the queue accumulates entries naturally during Phases 2 and 3
operation. Validation is operational: does the senior engineer's queue burndown rate
keep pace with sideline accumulation rate?

### Phase 5: Multi-engineer coordination

**Scope:** authenticated operator identity, audit log, lock-on-classification,
cross-engineer disagreement handling, sideline queue assignment.

**Why last:** the team coordination features matter when the team exists. A
two-engineer team can operate Phases 1-4 without explicit coordination by working
different customer configs. Coordination becomes necessary at 3+ engineers working
in parallel.

**Estimated build:** 300-500 lines (reduced from original draft estimate per
Decision #3 — no role-based access control, only authenticated identity).
Authentication, audit logging, lock management, and the appeal/disagreement
workflow.

**Validation:** synthetic multi-engineer test scenarios. Does Operator B see
Operator A's lock? Do bans propagate correctly? Does the audit log capture all
actions?

### Vendor deprecation awareness — woven throughout

The deprecation registry, periodic sweep, and propagation mechanisms are not a
separate phase. They are concerns that must be designed into Phases 1, 2, and 3 as
they are built, not retrofitted later. Specific build items:

- Phase 1: approved-corpus entries gain a `deprecated` field
- Phase 2: triage interface displays deprecation warnings prominently
- Phase 3: LLM drafting includes a deprecation-check step (LLM is asked to check
  recent vendor release notes for deprecation status of the surface being drafted)

---

## Founding-principle audit

Before this design becomes implementation, every component must be audited against the
founding principle. Captain Ames' core architectural rule survives the reframe; this
section documents how:

### "No claim without provenance"

**Approved corpus:** every entry carries operator name, timestamp, citation sources,
draft-author flag (LLM vs operator). Same as today, just at scale.

**Banned corpus:** every entry carries the operator who banned it, the reason, the
draft text that was banned. The negative claim ("this draft is wrong") is itself
provenance-tracked.

**Sideline queue:** entries carry the operator who deferred, the LLM draft (if any),
and the deep-research classification when promoted. Even the deferral has provenance.

**LLM drafts:** every draft carries the LLM model used, the citation URLs verified,
the timestamp of drafting. If a draft enters the corpus via (c)orrect or (e)dit, the
LLM's contribution is traceable.

### "Engine produces structural observations, operator produces semantic claims"

**Schema-learner:** unchanged. Continues to produce only structural observations.

**Triage interface:** displays both engine observations (in observation markers per
the existing convention) and LLM drafts (clearly marked as drafts requiring
ratification). The operator's action is what produces semantic content.

**Auto-reuse:** when a prior classification is auto-applied, the provenance comment
makes clear that the current operator did not classify; the prior operator's
classification is being reused. The current customer config inherits that prior
operator's authority by reference.

### "Operator approval required"

**Auto-reuse:** is the only mechanism that bypasses real-time operator approval, and
only when a prior operator approved the same classification. The principle holds
through transitive provenance.

**LLM drafts:** never enter the corpus directly. Always pass through (c)/(e)/(h)/(s)
triage. Even high-confidence drafts require an operator click.

**Banned-corpus suppression:** is itself an operator-authored decision (the prior
operator who banned the pattern). Future drafts being suppressed are being suppressed
by a prior operator's authority, not by the LLM's judgment.

### Mechanical enforcement, not honor system

Every gate in this design is enforced in code. The triage interface refuses to mark a
draft (c)orrect without verified citations. The banned-corpus suppression runs
automatically. The deprecation flag prevents merge when set. The lock mechanism
prevents concurrent classification.

The operator cannot "skip the citation check just this once" any more than they could
in the existing merge engine. The principle binds the team-scale system the same way
it binds the single-engineer system.

---

## What we agreed NOT to build

Documenting what was considered and rejected, so future sessions don't re-litigate:

**Confidence-based auto-merge (no operator click).** Even at high LLM confidence with
verified citations, every classification requires explicit operator action. The
productivity gain of skipping the click is not worth the principle erosion.

**LLM judgment of banned-corpus appeals.** When an entry is appealed, only senior
engineers resolve the appeal. The LLM does not vote, does not recommend, does not
"weigh evidence." Bans are operator-authored and unbanning is operator-authored.

**Cross-vendor automatic learning.** When the toolkit eventually expands to support
ANY-to-ANY conversions (not just SonicWall→WatchGuard), each vendor pair has its own
corpus. Lessons from SonicWall→WatchGuard do not automatically apply to Cisco→Juniper
without explicit operator authorization. Vendor-specific knowledge does not generalize
without verification.

**Public banned-corpus.** The banned corpus contains operator opinions about LLM
output quality. Publishing it externally (e.g., contributing back to the LLM vendor
as training data) is not in scope. The corpus is the team's institutional memory and
remains private to the team.

---

## Decisions resolved (May 2026)

The eight open questions raised in the original draft were resolved by Captain Ames
on review. The resolved decisions are recorded here and bind the implementation:

### 1. Auto-reuse threshold: **0.85 baseline**

Aggregate structural similarity ≥ 0.85 against an approved-corpus entry triggers
auto-reuse with provenance comment. The threshold is a single global default in
`learn_config.ini`; per-surface-category overrides are deferred unless operational
experience surfaces a need.

### 2. Banned-corpus suppression threshold: **0.80**

Aggregate structural similarity ≥ 0.80 against a banned-corpus entry suppresses the
LLM draft and routes the surface to sideline. The threshold is conservative on the
explicit basis that operator time is more valuable than missed-suppression false
negatives.

### 3. Operator role: **senior operators only**

The toolkit is not designed for junior operators. All triage actions ((c)/(e)/(h)/(s))
are available to every authenticated operator. The junior/senior role distinction
in the original draft is removed; the team_config simply records authenticated
operator identities, all with full triage rights.

This simplifies Phase 5 (multi-engineer coordination) significantly: no role-based
access control is required, only authenticated identity for audit-log purposes. The
implication is also operational: hiring strategy targets senior engineers, not a
mixed senior/junior team.

### 4. Sideline queue SLA tiers: **7 / 30 / indefinite as proposed**

- Tier 1 (1-2 occurrences across configs): indefinite
- Tier 2 (3-9 occurrences): 30-day SLA
- Tier 3 (10+ occurrences OR high-revenue customer): 7-day SLA

Tiers are uniform across the team; per-customer-revenue SLA variation is deferred.
The tier durations bind the senior-engineer queue ownership role's accountability.

### 5. Deprecation sweep cadence: **quarterly**

Quarterly review of the approved corpus against vendor release notes from the prior
quarter. Captain Ames' read: vendor release pace does not warrant the operational
cost of monthly sweeps for a senior-engineer-only team. Quarterly is the right
frequency given the SLA tiers above and the typical lifecycle of vendor feature
deprecation announcements.

### 6. Phase order: **proposal order — auto-reuse first**

Phase 1 (auto-reuse) → Phase 2 (triage) → Phase 3 (LLM drafting) → Phase 4 (sideline)
→ Phase 5 (coordination). The compounding value of auto-reuse is delivered first;
LLM drafting is layered on after the surrounding architecture is proven. This trades
delayed LLM-drafting value visibility for reduced risk of over-investing in a
component whose surrounding context isn't yet load-tested.

### 7. Lab verification for deep research: **always required**

Every deep-research classification entering the approved corpus must be lab-verified
on a real Firebox round-trip. No exceptions, no impact-tier carve-outs. Lab access
is a real constraint but the cost of an unverified deep-research classification
silently entering the corpus is operationally higher than the cost of slower queue
burndown.

This decision binds the senior engineer who owns the sideline queue: their work
includes scheduling lab time, not just performing literature research. The toolkit
must support a lab-verification status field on each approved-corpus entry so deep-
research classifications carry that mark distinctly from operator-time
classifications.

### 8. Cross-team corpus sharing: **future feature, not Phase 1-5**

A shared corpus facility (multiple MSPs sharing approved-corpus entries) is in
scope as a future feature. Acknowledged as "an easy add-on" given the corpus
already has provenance tracking, structural-similarity matching, and operator
authentication. Deferred until the team-internal corpus is operational and the
sharing model (entries only? full corpus? per-vendor-pair?) can be informed by
real operational experience.

The Phase 1-5 architecture must not preclude sharing — specifically:
- Approved-corpus entries already carry full provenance, suitable for export
- The corpus index format can be extended with a `source_team` field without breaking
  existing consumers
- The merge engine's lookup logic should treat external-source entries as
  read-only with explicit team-provenance display

These are forward-compatibility constraints on the Phase 1-2 implementation, not new
features.

---

## Summary

The reframe changes the toolkit from a translator with learning into a learning system
with translation. The architecture extends the existing engine with three corpus tiers
(approved, banned, sideline), a four-state triage taxonomy ((c)/(e)/(h)/(s)), a
mandatory operator-in-the-loop gate, and explicit team coordination mechanisms.

The implementation phases prioritize compounding value: auto-reuse first, triage second,
LLM drafting third, queue management fourth, full team coordination fifth. Each phase
delivers value standalone and composes with successors.

The founding principle ("no claim without provenance") survives the reframe and is
mechanically enforced at every new gate. Operator authority remains the toolkit's
center of gravity. The LLM is a productivity tool, not a judgment producer.

The open questions above need Captain Ames' input before any code is written. Once
those are resolved, Phase 1 (approved-corpus auto-reuse) is the first concrete build
target.

This document is a draft for review. It will be updated as decisions are made and
implementation choices reveal additional considerations.
