#!/usr/bin/env python3
"""
llm_provider.py
================

Phase 3 of the schema_learner subsystem (DESIGN_team_scale_addendum.md).
Abstraction layer for calling an LLM as a research assistant during
the operator triage workflow.

Per the addendum:
  - The LLM drafts Q1-Q4 candidates for novel surfaces
  - Every claim must have a citation URL
  - Citations are verified programmatically (web_fetch + content match)
  - URLs that 404 or contain unrelated content downgrade confidence
  - Operator approval still required — drafts never enter the corpus
    directly without operator action

This module is pluggable: the production deployment uses
AnthropicProvider; tests use StubProvider with deterministic outputs.

Founding-principle binding:
  - Mark "high confidence" ONLY when web_fetch verifies the citation
    URL exists AND page contents contain claim-relevant terms.
  - Otherwise, confidence is "low — operator must research."
  - The toolkit refuses to merge any draft until operator ratifies
    via existing (c)orrect/(e)dit triage path.
"""
from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol


# ---------------------------------------------------------------------------
# Draft & verification dataclasses
# ---------------------------------------------------------------------------

@dataclass
class CitedClaim:
    """One Q1-Q4 answer with its citation and verification status."""
    claim_text: str = ""           # the answer itself
    citation_url: str = ""         # the URL the LLM provided
    citation_excerpt: str = ""     # relevant excerpt from the URL (post-fetch)
    
    # Verification status set by verify_citations():
    #   "verified"   — fetched OK, contains relevant terms, high confidence
    #   "unverified" — URL didn't fetch, didn't contain relevant terms
    #   "skipped"    — verification was disabled or no URL provided
    verification_status: str = "skipped"
    
    # Confidence per addendum:
    #   "high"   — citation verified, draft can be confidently presented
    #   "medium" — citation present but not verified
    #   "low"    — no citation OR citation failed verification
    # Mark high ONLY when verification_status == "verified".
    confidence: str = "low"
    
    # Free-text explanation of why this confidence level (for operator)
    confidence_reason: str = ""


@dataclass
class LLMDraft:
    """A complete LLM draft of operator declarations for one surface.
    
    Contains four CitedClaim instances (one per Q1-Q4) plus metadata
    about the drafting process. Stored as a sibling artifact to
    findings.json: drafts/<surface_tag>.json so it can be loaded
    independently and is auditable.
    """
    surface_tag: str
    model: str = ""                # which model was used
    drafted_at: str = ""           # ISO timestamp
    
    # The four cited claims
    purpose: CitedClaim = field(default_factory=CitedClaim)
    category: CitedClaim = field(default_factory=CitedClaim)
    sonicwall_equivalent: CitedClaim = field(default_factory=CitedClaim)
    operational_notes: CitedClaim = field(default_factory=CitedClaim)
    
    # Self-validation (Turn 3 — LLM yes/no on its own draft)
    self_validation_passed: bool = False
    self_validation_response: str = ""
    
    # Structural-cross-check (does Q2 category match top-neighbors' categories?)
    structural_cross_check_consistent: bool = True
    structural_cross_check_note: str = ""
    
    # Overall draft confidence (worst of the four claims)
    overall_confidence: str = "low"
    
    # Free-text engine notes (drafting failures, partial outputs, etc.)
    drafting_notes: str = ""
    
    def is_complete(self) -> bool:
        """A draft is complete if all four Q1-Q4 claims have non-empty
        text. Citations may be present or absent; verification is a
        separate concern."""
        return bool(self.purpose.claim_text
                    and self.category.claim_text
                    and self.sonicwall_equivalent.claim_text
                    and self.operational_notes.claim_text)


# ---------------------------------------------------------------------------
# Provider protocol
# ---------------------------------------------------------------------------

class LLMProvider(Protocol):
    """A minimal protocol an LLM provider must satisfy.
    
    The provider takes a prompt and returns a string response. That's
    it. Multi-turn flows are orchestrated by the LLMDrafter, not the
    provider — providers are stateless.
    """
    def generate(self, prompt: str) -> str: ...
    
    @property
    def is_available(self) -> bool: ...
    
    @property
    def model_label(self) -> str: ...


# ---------------------------------------------------------------------------
# AnthropicProvider — production
# ---------------------------------------------------------------------------

class AnthropicProvider:
    """Calls the Anthropic API directly via urllib (no external deps)."""

    # Used by LLMDrafter to pick prompt style. Anthropic models follow
    # strict structured-output reliably, so use strict format.
    prompt_style = "strict"

    def __init__(self,
                 api_key: str,
                 model: str = "claude-haiku-4-5-20251001",
                 timeout: int = 30,
                 max_tokens: int = 1500):
        self.api_key = api_key
        self.model = model
        self.timeout = timeout
        self.max_tokens = max_tokens
        self._endpoint = "https://api.anthropic.com/v1/messages"

    @property
    def is_available(self) -> bool:
        return bool(self.api_key)

    @property
    def model_label(self) -> str:
        return f"anthropic:{self.model}"

    def generate(self, prompt: str) -> str:
        if not self.is_available:
            return ""
        body = json.dumps({
            "model": self.model,
            "max_tokens": self.max_tokens,
            "messages": [{"role": "user", "content": prompt}],
        }).encode("utf-8")
        req = urllib.request.Request(
            self._endpoint,
            data=body,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
            },
        )
        try:
            with urllib.request.urlopen(
                    req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except (urllib.error.URLError, urllib.error.HTTPError,
                TimeoutError, OSError) as e:
            return ""
        # Extract first text block from content array
        for block in data.get("content", []):
            if block.get("type") == "text":
                return block.get("text", "").strip()
        return ""


# ---------------------------------------------------------------------------
# StubProvider — for tests
# ---------------------------------------------------------------------------

class StubProvider:
    """Returns deterministic responses keyed by prompt content.
    
    Used in regression tests and during development when API access
    isn't available. Never goes over the network. The stub is
    configured with a list of (prompt_substring, response) pairs;
    when a prompt arrives it returns the response of the first
    matching pair.
    """

    # Stub uses strict prompts so test fixtures match the strict format.
    prompt_style = "strict"

    def __init__(self,
                 responses: list[tuple[str, str]] | None = None,
                 default: str = ""):
        self.responses = responses or []
        self.default = default
        self.call_log: list[str] = []

    @property
    def is_available(self) -> bool:
        return True

    @property
    def model_label(self) -> str:
        return "stub:fixed-responses"

    def generate(self, prompt: str) -> str:
        self.call_log.append(prompt[:200])
        for substring, response in self.responses:
            if substring in prompt:
                return response
        return self.default


# ---------------------------------------------------------------------------
# GPT4AllProvider — local OpenAI-compatible LLM server
# ---------------------------------------------------------------------------

class GPT4AllProvider:
    """Calls a local GPT4All server via its OpenAI-compatible chat
    completions endpoint. Useful for token-budget-conscious use:
    no API costs, runs offline, but smaller models may produce less
    structured output than Anthropic.

    The principle binding is provider-agnostic: this provider returns
    raw text, the same as AnthropicProvider, and the LLMDrafter applies
    the same four-turn interview, citation parsing, and
    web_fetch-based verification regardless of which provider produced
    the text. Local models that hallucinate citation URLs will simply
    fail verification → claims stay at low confidence.

    Default endpoint: http://localhost:4891/v1 (GPT4All's default).
    """

    # Used by LLMDrafter. Local 7-8B models produce more reliable output
    # with a simpler, plain-prose prompt rather than strict ALL_CAPS
    # field labels. The toolkit's lenient parser handles markdown
    # variations + missing strict separators.
    prompt_style = "lenient"

    def __init__(self,
                 host: str = "localhost",
                 port: int = 4891,
                 model: str = "Llama 3 8B Instruct",
                 timeout: int = 60,
                 max_tokens: int = 1500,
                 temperature: float = 0.3):
        self.host = host
        self.port = port
        self.model = model
        self.timeout = timeout
        self.max_tokens = max_tokens
        # Lower temperature than free-form chat — we want structured output.
        self.temperature = temperature
        self._base_url = f"http://{host}:{port}/v1"

    @property
    def is_available(self) -> bool:
        """Probe the /models endpoint. Returns True if the server
        responds within timeout."""
        try:
            req = urllib.request.Request(
                f"{self._base_url}/models",
                method="GET",
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.getcode() == 200
        except (urllib.error.URLError, urllib.error.HTTPError,
                TimeoutError, OSError):
            return False

    @property
    def model_label(self) -> str:
        return f"gpt4all:{self.model}"

    def generate(self, prompt: str) -> str:
        """OpenAI-compatible chat completions call. Returns the
        assistant message text, or empty string on failure.
        
        On failure, prints a diagnostic line to stderr explaining why.
        Silent failures (empty string with no log) make troubleshooting
        much harder than they need to be.
        """
        body = json.dumps({
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{self._base_url}/chat/completions",
            data=body,
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(
                    req, timeout=self.timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as e:
            sys.stderr.write(
                f"  [gpt4all] HTTP {e.code} from server: "
                f"{e.reason}\n")
            try:
                detail = e.read().decode("utf-8", errors="replace")[:300]
                sys.stderr.write(f"  [gpt4all] body: {detail}\n")
            except Exception:
                pass
            return ""
        except urllib.error.URLError as e:
            sys.stderr.write(
                f"  [gpt4all] connection failed: {e.reason}\n")
            return ""
        except (TimeoutError, OSError) as e:
            sys.stderr.write(
                f"  [gpt4all] timeout/IO error "
                f"(timeout={self.timeout}s): {e}\n")
            sys.stderr.write(
                f"  [gpt4all] If this keeps happening, increase "
                f"timeout_seconds in learn_config.ini [mcp]\n")
            return ""
        # Parse JSON
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as e:
            sys.stderr.write(
                f"  [gpt4all] response was not valid JSON: {e}\n")
            sys.stderr.write(
                f"  [gpt4all] raw response (first 200 chars): "
                f"{raw[:200]!r}\n")
            return ""
        # OpenAI format: choices[0].message.content
        # Some servers return error objects: {"error": "..."}
        if "error" in data:
            sys.stderr.write(
                f"  [gpt4all] server returned error: {data['error']}\n")
            return ""
        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            sys.stderr.write(
                f"  [gpt4all] response has no choices[0].message.content; "
                f"keys present: {list(data.keys()) if isinstance(data, dict) else 'not-dict'}\n")
            sys.stderr.write(
                f"  [gpt4all] HINT: in GPT4All UI, verify '{self.model}' "
                f"is the LOADED model (not just in the model list)\n")
            return ""
        if not content or not content.strip():
            sys.stderr.write(
                f"  [gpt4all] model returned empty content "
                f"(prompt was {len(prompt)} chars, max_tokens={self.max_tokens})\n")
            return ""
        return content.strip()


# ---------------------------------------------------------------------------
# Prompts (multi-turn interview pattern)
# ---------------------------------------------------------------------------

DISCOVERY_PROMPT = """\
You are helping classify a novel WatchGuard Firebox XML element for a
SonicWall→WatchGuard migration toolkit. The schema-learner detected a
new element and the operator needs a draft classification with
citations.

The novel element:
  Tag:               <{surface_tag}>
  Naming tokens:     {naming_tokens}
  Top child tags:    {top_children}
  Value patterns:    {value_patterns}
  Top structural neighbors (existing schema elements with similar
  structure, NOT semantic kinship — context only):
{neighbors_text}

In 2-3 sentences, describe what this element is and what it
configures. If you don't recognize it from training, say so explicitly
and mark your draft as low confidence.

Be specific. Don't guess. If you're not sure, say so."""


EXTRACT_PROMPT = """\
For the WatchGuard XML element <{surface_tag}>, fill in the four
operator declarations needed for the migration toolkit. EVERY claim
must have a citation source URL. If you cannot find a citation source,
say so explicitly — do not invent URLs.

Description from previous turn:
{description}

Return ONLY this exact format with NO additional text:

Q1_PURPOSE: (one sentence describing what this element does)
Q1_SOURCE: (full URL to vendor documentation supporting Q1, or "no citation found")

Q2_CATEGORY: (one of: network-plumbing, policy-access-control, object-library, tunnel-vpn, html-web-app, threat-detection, authentication-infrastructure, device-management, administrative)
Q2_SOURCE: (URL or "no citation found")

Q3_SW_EQUIVALENT: (the SonicWall equivalent feature, or "none — net-new on WatchGuard")
Q3_SOURCE: (URL or operator-experience marker, or "no citation found")

Q4_OPERATIONAL: (security or operational considerations to flag, or "none")
Q4_SOURCE: (URL or "no citation found")"""


# Lenient extract prompt for local LLMs (Llama 3 8B, Mistral 7B, etc).
# Smaller models reliably follow shorter, simpler structured-output
# instructions. The lenient parser accepts variations including
# markdown bold and missing colons.
EXTRACT_PROMPT_LENIENT = """\
For the WatchGuard Firebox XML element <{surface_tag}>, answer these
four questions. Provide a citation URL for each answer. If you don't
know a citation URL, write "no citation found" — never invent URLs.

Context: {description}

Q1_PURPOSE: What does this element configure? (one sentence)
Q1_SOURCE: URL to WatchGuard docs, or "no citation found"

Q2_CATEGORY: Pick exactly one: network-plumbing, policy-access-control, object-library, tunnel-vpn, html-web-app, threat-detection, authentication-infrastructure, device-management, administrative
Q2_SOURCE: URL or "no citation found"

Q3_SW_EQUIVALENT: SonicWall equivalent feature, or "none — net-new on WatchGuard"
Q3_SOURCE: URL or "no citation found"

Q4_OPERATIONAL: Migration or security notes, or "none"
Q4_SOURCE: URL or "no citation found"

Answer all eight lines in that order. Keep each answer short."""


def _extract_prompt_for_provider(provider) -> str:
    """Pick the right EXTRACT prompt for this provider's style."""
    style = getattr(provider, 'prompt_style', 'strict')
    if style == 'lenient':
        return EXTRACT_PROMPT_LENIENT
    return EXTRACT_PROMPT


SELF_VALIDATE_PROMPT = """\
Review your own draft for the WatchGuard element <{surface_tag}>:

  Q1 (purpose): {purpose}
  Q2 (category): {category}
  Q3 (SonicWall equivalent): {sw_equivalent}
  Q4 (operational notes): {operational}

Are these answers internally consistent and consistent with the
structural facts that the engine observed about this element
(child tags, value patterns)?

Answer with ONLY one word: yes or no."""


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------

def _extract_field(text: str, field_name: str) -> str:
    """Extract a 'FIELD: value' line from LLM structured output.
    
    Lenient: handles common variations that smaller local models
    produce (markdown bold, alternate separators, different cases):
    
      Q1_PURPOSE: foo
      Q1_PURPOSE - foo
      **Q1_PURPOSE**: foo
      Q1 PURPOSE: foo
      q1_purpose: foo
    
    Returns first non-empty match. Strips leading markdown bold/italic.
    """
    # Build a forgiving pattern: allow markdown bold around the field,
    # space-or-underscore between Q-number and field word, and
    # colon-or-dash separator.
    label = field_name.replace('_', '[ _]')
    pattern = (
        rf'(?:\*\*|__)?\s*{label}\s*(?:\*\*|__)?'   # field with optional bold
        rf'\s*[:\-]\s*'                              # separator
        rf'(.+?)'                                    # value
        rf'(?=\n\s*(?:\*\*|__)?\s*Q[0-9]_'           # stop at next Q-field
        rf'|\Z)'
    )
    m = re.search(pattern, text, re.MULTILINE | re.DOTALL | re.IGNORECASE)
    if not m:
        return ""
    value = m.group(1).strip()
    # Strip surrounding markdown formatting
    value = re.sub(r'^[*_]+|[*_]+$', '', value).strip()
    # Single-line responses: trim trailing newlines from multi-line capture
    value = value.split('\n\n')[0].strip()
    return value


def _parse_extract_response(text: str) -> dict[str, str]:
    """Parse the extract-turn response into a dict of Q1-Q4 + sources."""
    return {
        'purpose':           _extract_field(text, 'Q1_PURPOSE'),
        'purpose_source':    _extract_field(text, 'Q1_SOURCE'),
        'category':          _extract_field(text, 'Q2_CATEGORY'),
        'category_source':   _extract_field(text, 'Q2_SOURCE'),
        'sw_equivalent':     _extract_field(text, 'Q3_SW_EQUIVALENT'),
        'sw_source':         _extract_field(text, 'Q3_SOURCE'),
        'operational':       _extract_field(text, 'Q4_OPERATIONAL'),
        'operational_source': _extract_field(text, 'Q4_SOURCE'),
    }


def _is_yes(text: str) -> bool:
    """Extract yes/no from a verbose LLM response. First real word wins."""
    cleaned = re.sub(r'^[^a-zA-Z]*', '', text.strip())
    if not cleaned:
        return False
    first_word = cleaned.split()[0].lower().rstrip('.,!?:;')
    return first_word in ('yes', 'y', 'yep', 'yup', 'correct',
                          'right', 'true', 'affirmative', 'confirmed')


# ---------------------------------------------------------------------------
# Citation verification (programmatic, post-LLM)
# ---------------------------------------------------------------------------

def _is_no_citation(source: str) -> bool:
    """Check if the LLM admitted it has no citation."""
    if not source:
        return True
    s = source.strip().lower()
    markers = ["no citation", "not found", "unknown", "cannot find",
               "don't know", "not sure", "no url", "n/a", "none"]
    return any(m in s for m in markers)


def _is_url(text: str) -> bool:
    """Quick check for whether a string is a URL."""
    return text.strip().lower().startswith(('http://', 'https://'))


@dataclass
class VerificationResult:
    url: str
    fetched: bool
    status_code: int = 0
    relevant_terms_found: list[str] = field(default_factory=list)
    excerpt: str = ""
    error: str = ""


def verify_citation_url(
    url: str,
    relevant_terms: list[str],
    timeout: int = 15,
    max_excerpt_chars: int = 400,
) -> VerificationResult:
    """Fetch a URL and check whether the page contains relevant terms.
    
    Returns a VerificationResult. The caller uses .fetched and
    len(.relevant_terms_found) to decide confidence.
    
    Network errors, timeouts, and 4xx/5xx responses all result in
    fetched=False with a populated error field. The toolkit must NOT
    crash if a citation URL is unreachable — it must downgrade
    confidence and let the operator handle the gap.
    """
    result = VerificationResult(url=url, fetched=False)
    if not _is_url(url):
        result.error = "not a valid URL"
        return result
    
    req = urllib.request.Request(
        url,
        headers={
            'User-Agent': 'n2nhu-migration-toolkit-citation-verifier/1.0',
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result.status_code = resp.status
            content = resp.read(200_000).decode(
                'utf-8', errors='replace').lower()
    except urllib.error.HTTPError as e:
        result.error = f"HTTP {e.code}"
        result.status_code = e.code
        return result
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        result.error = f"{type(e).__name__}: {e}"
        return result
    except Exception as e:
        result.error = f"unexpected: {type(e).__name__}: {e}"
        return result
    
    result.fetched = True
    
    # Find which relevant terms appear on the page
    for term in relevant_terms:
        t = term.strip().lower()
        if t and t in content:
            result.relevant_terms_found.append(term)
    
    # Pull a short excerpt around the first matching term
    if result.relevant_terms_found:
        first = result.relevant_terms_found[0].lower()
        idx = content.find(first)
        if idx >= 0:
            start = max(0, idx - 100)
            end = min(len(content), idx + max_excerpt_chars - 100)
            excerpt = content[start:end]
            # Compress whitespace
            excerpt = re.sub(r'\s+', ' ', excerpt).strip()
            result.excerpt = excerpt[:max_excerpt_chars]
    
    return result


def relevant_terms_from_surface(
    surface_tag: str,
    naming_tokens: list[str],
) -> list[str]:
    """Compute the list of terms the citation page should mention.
    
    Used by verify_citation_url to decide whether a fetched page is
    actually relevant to the surface being researched."""
    terms = list(naming_tokens)
    # Always include the full tag itself
    terms.insert(0, surface_tag)
    # And the tag with hyphens removed (some docs concatenate)
    if '-' in surface_tag:
        terms.append(surface_tag.replace('-', ''))
    return terms


# ---------------------------------------------------------------------------
# The LLMDrafter — orchestrates the multi-turn interview
# ---------------------------------------------------------------------------

class LLMDrafter:
    """Orchestrates a multi-turn LLM interview to produce a verified draft
    of operator declarations for a novel surface.
    
    Per the addendum: this is a research assistant pattern. The LLM
    proposes; the operator ratifies. The drafter NEVER produces a
    classification that goes directly into the corpus — drafts always
    pass through the (c)/(e)/(h)/(s) triage gate.
    """

    def __init__(
        self,
        provider: LLMProvider,
        verify_citations: bool = True,
        verification_timeout: int = 15,
    ):
        self.provider = provider
        self.verify_citations = verify_citations
        self.verification_timeout = verification_timeout

    def draft(
        self,
        surface_tag: str,
        structural_facts: dict[str, Any],
        neighbors: list[dict[str, Any]] | None = None,
    ) -> LLMDraft:
        """Produce a complete LLMDraft for one surface.
        
        Args:
            surface_tag: e.g. 'vpn-portal'
            structural_facts: from finding['structural_facts']
            neighbors: top-K structural neighbors with 'tag', 'aggregate_similarity'
        
        Returns:
            LLMDraft with all fields populated. May have empty claims
            if the LLM was unavailable; in that case overall_confidence
            will be 'low' and drafting_notes will explain.
        """
        import datetime as _dt
        draft = LLMDraft(
            surface_tag=surface_tag,
            model=self.provider.model_label,
            drafted_at=_dt.datetime.now().isoformat(),
        )
        
        if not self.provider.is_available:
            draft.drafting_notes = "LLM provider not available"
            return draft
        
        # Turn 1: Discovery
        naming_tokens = structural_facts.get('naming_tokens', [])
        top_children = [t for t, _ in
                        structural_facts.get('top_children_tags', [])][:10]
        value_patterns = structural_facts.get('value_pattern_summary', {})
        neighbors = neighbors or []
        neighbors_text = "\n".join(
            f"    - {n.get('tag', '?')}: similarity "
            f"{n.get('aggregate_similarity', 0):.3f}"
            for n in neighbors[:5]) or "    (no close structural neighbors)"
        
        discovery = self.provider.generate(DISCOVERY_PROMPT.format(
            surface_tag=surface_tag,
            naming_tokens=naming_tokens,
            top_children=', '.join(top_children) or "(none — leaf element)",
            value_patterns=dict(list(value_patterns.items())[:8]),
            neighbors_text=neighbors_text,
        ))
        if not discovery:
            draft.drafting_notes = "Turn 1 (discovery) returned empty"
            return draft
        
        # Turn 2: Structured extraction (provider-aware prompt)
        extract_prompt_template = _extract_prompt_for_provider(self.provider)
        extract_response = self.provider.generate(extract_prompt_template.format(
            surface_tag=surface_tag,
            description=discovery,
        ))
        if not extract_response:
            draft.drafting_notes = "Turn 2 (extract) returned empty"
            return draft
        
        parsed = _parse_extract_response(extract_response)
        
        # Populate the four CitedClaims (no verification yet)
        draft.purpose = CitedClaim(
            claim_text=parsed['purpose'],
            citation_url=parsed['purpose_source'],
            confidence='low',
            confidence_reason='not yet verified',
        )
        draft.category = CitedClaim(
            claim_text=parsed['category'],
            citation_url=parsed['category_source'],
            confidence='low',
            confidence_reason='not yet verified',
        )
        draft.sonicwall_equivalent = CitedClaim(
            claim_text=parsed['sw_equivalent'],
            citation_url=parsed['sw_source'],
            confidence='low',
            confidence_reason='not yet verified',
        )
        draft.operational_notes = CitedClaim(
            claim_text=parsed['operational'],
            citation_url=parsed['operational_source'],
            confidence='low',
            confidence_reason='not yet verified',
        )
        
        # Turn 3: Self-validation
        self_validate = self.provider.generate(SELF_VALIDATE_PROMPT.format(
            surface_tag=surface_tag,
            purpose=draft.purpose.claim_text[:200],
            category=draft.category.claim_text[:80],
            sw_equivalent=draft.sonicwall_equivalent.claim_text[:200],
            operational=draft.operational_notes.claim_text[:200],
        ))
        draft.self_validation_response = self_validate
        draft.self_validation_passed = _is_yes(self_validate)
        
        # Programmatic verification of citations
        if self.verify_citations:
            relevant_terms = relevant_terms_from_surface(
                surface_tag, naming_tokens)
            self._verify_claim(draft.purpose, relevant_terms)
            self._verify_claim(draft.category, relevant_terms)
            self._verify_claim(draft.sonicwall_equivalent, relevant_terms)
            self._verify_claim(draft.operational_notes, relevant_terms)
        
        # Structural cross-check (Q2 vs neighbors' categories)
        # For Phase 3 we do a basic version: if the operator-declared
        # category of any of the top-3 neighbors is known and contradicts
        # the LLM's category, flag. (Phase 1 corpus entries don't yet
        # carry category metadata — this is a forward-compatible hook.)
        draft.structural_cross_check_consistent = True
        draft.structural_cross_check_note = (
            "no neighbor categories available for cross-check"
            if not neighbors else
            "structural neighbors did not contradict LLM category claim"
        )
        
        # Compute overall confidence (worst of the four)
        draft.overall_confidence = self._aggregate_confidence(draft)
        
        return draft

    def _verify_claim(
        self,
        claim: CitedClaim,
        relevant_terms: list[str],
    ) -> None:
        """Verify a single claim's citation. Updates claim in-place."""
        # No URL or LLM admitted no citation → confidence stays low
        if _is_no_citation(claim.citation_url):
            claim.verification_status = "skipped"
            claim.confidence = "low"
            claim.confidence_reason = (
                "LLM did not provide a citation URL — operator must research"
            )
            return
        
        if not _is_url(claim.citation_url):
            claim.verification_status = "unverified"
            claim.confidence = "low"
            claim.confidence_reason = (
                f"citation field is not a URL ({claim.citation_url[:60]!r})"
            )
            return
        
        result = verify_citation_url(
            claim.citation_url,
            relevant_terms,
            timeout=self.verification_timeout,
        )
        
        if not result.fetched:
            claim.verification_status = "unverified"
            claim.confidence = "low"
            claim.confidence_reason = (
                f"URL did not fetch: {result.error or 'unknown error'}"
            )
            return
        
        if not result.relevant_terms_found:
            claim.verification_status = "unverified"
            claim.confidence = "low"
            claim.confidence_reason = (
                f"URL fetched (HTTP {result.status_code}) but page "
                f"contained none of the relevant terms "
                f"({', '.join(relevant_terms[:5])})"
            )
            return
        
        # Verified! High confidence is granted.
        claim.verification_status = "verified"
        claim.citation_excerpt = result.excerpt
        claim.confidence = "high"
        claim.confidence_reason = (
            f"URL fetched (HTTP {result.status_code}); "
            f"{len(result.relevant_terms_found)} relevant term(s) found: "
            f"{', '.join(result.relevant_terms_found[:5])}"
        )

    @staticmethod
    def _aggregate_confidence(draft: LLMDraft) -> str:
        """Overall draft confidence is the worst of any individual
        claim's confidence, plus penalty if self-validation failed."""
        confidences = [
            draft.purpose.confidence,
            draft.category.confidence,
            draft.sonicwall_equivalent.confidence,
            draft.operational_notes.confidence,
        ]
        if "low" in confidences or not draft.self_validation_passed:
            return "low"
        if "medium" in confidences:
            return "medium"
        return "high"


# ---------------------------------------------------------------------------
# Provider factory
# ---------------------------------------------------------------------------

def build_provider_from_config(
    config_section: dict[str, str],
) -> LLMProvider | None:
    """Build a provider from the [mcp] config section. Returns None
    if MCP is disabled, or if the chosen provider is not available
    (e.g. no API key for anthropic, or GPT4All server unreachable).

    Provider selection (per-section key `provider`):
      - "anthropic" (default): use AnthropicProvider, requires API key
                                in env var named by api_key_env_var
      - "gpt4all":              use GPT4AllProvider, requires GPT4All
                                server running on host/port
      - "stub":                 use StubProvider (test-only; not for
                                production triage)

    Expected config keys:
      enabled         = true|false
      provider        = anthropic|gpt4all|stub  (default: anthropic)
      timeout_seconds = 30

    Anthropic-specific keys:
      api_key_env_var = ANTHROPIC_API_KEY
      model           = claude-haiku-4-5-20251001

    GPT4All-specific keys:
      gpt4all_host    = localhost
      gpt4all_port    = 4891
      gpt4all_model   = Llama 3 8B Instruct
    """
    if config_section.get('enabled', 'false').strip().lower() != 'true':
        return None

    provider_kind = config_section.get('provider', 'anthropic').strip().lower()
    try:
        timeout = int(config_section.get('timeout_seconds', '30'))
    except ValueError:
        timeout = 30

    if provider_kind == 'anthropic':
        api_key_env = config_section.get('api_key_env_var',
                                         'ANTHROPIC_API_KEY').strip()
        api_key = os.environ.get(api_key_env, '')
        if not api_key:
            return None
        model = config_section.get('model',
                                    'claude-haiku-4-5-20251001').strip()
        return AnthropicProvider(api_key=api_key, model=model,
                                 timeout=timeout)

    if provider_kind == 'gpt4all':
        host = config_section.get('gpt4all_host', 'localhost').strip()
        try:
            port = int(config_section.get('gpt4all_port', '4891'))
        except ValueError:
            port = 4891
        model = config_section.get('gpt4all_model',
                                    'Llama 3 8B Instruct').strip()
        provider = GPT4AllProvider(host=host, port=port, model=model,
                                    timeout=timeout)
        # Probe availability — return None if server not running so
        # triage falls back to Phase 2 behavior cleanly.
        if not provider.is_available:
            return None
        return provider

    if provider_kind == 'stub':
        # Stub provider for test/dev only; default response is empty.
        return StubProvider(responses=[], default='')

    # Unknown provider name — fail closed.
    return None
