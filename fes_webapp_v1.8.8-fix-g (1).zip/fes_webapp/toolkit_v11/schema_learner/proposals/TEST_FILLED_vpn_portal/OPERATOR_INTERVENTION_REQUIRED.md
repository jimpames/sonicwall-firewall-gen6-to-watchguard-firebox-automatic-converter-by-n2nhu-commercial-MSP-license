# OPERATOR INTERVENTION REQUIRED

Generated: 2026-05-05
Source: TEST_FILLED_vpn_portal
Test fixture: ONE surface (vpn-portal) with operator declarations FILLED IN
and citations provided. Used to test merge_engine validate/dry-run/apply.

---

## Surface 1: `<vpn-portal>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

- Element tag: `vpn-portal`
- Naming tokens: ['vpn', 'portal']
- Distinct child element tags observed: 9
- Top structural neighbors:
    - logon-banner: 0.354
    - threat-correlation: 0.321
    - clientless-vpn: 0.296

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

<!-- OPERATOR-AUTHORED-BEGIN -->

[X] **Q1: What does this element do?** (one sentence)

    Answer: Configures the WatchGuard Access Portal HTML5 web app — a
    browser-based clientless VPN where remote users authenticate to a
    web page and access internal resources without installing a client.

    Source: https://www.watchguard.com/help/docs/help-center/en-US/Content/en-US/Fireware/access_portal/access_portal_about.html

[X] **Q2: Surface category from the toolkit's taxonomy?**

    Answer: html-web-app

    Source: WatchGuard help center documentation (URL above) describes
    this as a web portal feature with branding, customization, and
    HTTP-based authentication, distinct from tunnel-based VPN.

[X] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    Answer: SonicWall Virtual Office (the SSL-VPN web portal) is the
    closest equivalent. Both are clientless web portals for remote
    access.

    Source: 25 years field experience as primary engineer on both
    vendors (Jim Ames, NYC).

[X] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: SonicWall Virtual Office bookmarks (RDP/SSH/VNC) use
    vendor-specific URL substitution variables that do NOT translate
    cleanly. Branding/CSS customization usually needs to be rebuilt
    on the WG side.

    Source: Field experience.

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<vpn-portal>`.
