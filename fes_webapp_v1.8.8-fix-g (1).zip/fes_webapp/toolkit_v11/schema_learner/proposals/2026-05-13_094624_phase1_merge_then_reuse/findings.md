# Schema-Learner Findings

Generated: 2026-05-13T09:46:24.837864
Total findings: 201

This document contains STRUCTURAL OBSERVATIONS produced by the schema-learner engine. The engine reports what it observed in the XML — counts, similarities, presence/absence. The engine makes NO claim about semantic meaning, vendor mapping, or surface category. Those determinations are operator-authored with citations. See OPERATOR_INTERVENTION_REQUIRED.md for the required operator declarations.

---

## Category 1 — Novel Element Types

Count: 166

### `<Botnet>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['botnet']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `IPS` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `GAV` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `IAV` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `Engine` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `DLP` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `Geolocation` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.276 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<DLP>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['dlp']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `dlp-enabled` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `IPS` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `GAV` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `IAV` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `Engine` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `Botnet` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `Geolocation` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `log-dlp-stats` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `log-dlp-stats-interval` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dlp-sensor-list` | 0.222 | 0.000 | 0.577 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<Geolocation>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['geolocation']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `IPS` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `GAV` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `IAV` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `Engine` | 0.276 | 0.000 | 0.000 | 0.000 | 0.843 |
| `DLP` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `Botnet` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.276 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<account-id>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['account', 'id']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `client-id` | 0.308 | 0.000 | 0.500 | 0.000 | 0.384 |
| `rp-candidate` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `ccl-name` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `header-value` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `restrict-user-access` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `session-idle-timeout` | 0.284 | 0.000 | 0.000 | 0.000 | 0.894 |
| `login-id-attr` | 0.270 | 0.000 | 0.408 | 0.000 | 0.258 |
| `agent-ip-list` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |
| `protection-type` | 0.252 | 0.000 | 0.000 | 0.000 | 0.679 |
| `account-list` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.308 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<accounting-client-ip>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['accounting', 'client', 'ip']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `ip` | 0.279 | 0.000 | 0.577 | 0.000 | 0.088 |
| `secret` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `group-attr-type` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `exception-list` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `agent-ip-list` | 0.260 | 0.000 | 0.333 | 0.000 | 0.289 |
| `client-id` | 0.255 | 0.000 | 0.408 | 0.000 | 0.157 |
| `client-to-client` | 0.253 | 0.000 | 0.516 | 0.000 | 0.000 |
| `exclude-ip-list` | 0.252 | 0.000 | 0.333 | 0.000 | 0.236 |
| `sso-agent-ip` | 0.251 | 0.000 | 0.333 | 0.000 | 0.226 |
| `server-ip` | 0.245 | 0.000 | 0.408 | 0.000 | 0.087 |

**Placement confidence (top-1 structural):** 0.279 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<address-pool>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['address', 'pool']
- Top child tags (by occurrence): ['end-ip', 'start-ip']
- Value-pattern observations per child field:
    - `end-ip`: ipv4
    - `start-ip`: ipv4
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `pool` | 0.391 | 0.000 | 0.707 | 1.000 | 0.000 |
| `route` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `dns-server-list` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `ip-list` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `resource-addr` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `ip-domain-list` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `route-entry` | 0.200 | 0.000 | 0.000 | 0.802 | 0.000 |
| `primary-server` | 0.177 | 0.000 | 0.000 | 0.707 | 0.000 |
| `local-addr` | 0.177 | 0.000 | 0.000 | 0.707 | 0.000 |
| `remote-addr` | 0.177 | 0.000 | 0.000 | 0.707 | 0.000 |

**Placement confidence (top-1 structural):** 0.391 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<address-pool-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['address', 'pool', 'list']
- Top child tags (by occurrence): ['address-pool']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `reserved-address-list` | 0.258 | 0.000 | 0.667 | 0.000 | 0.833 |
| `address-pool` | 0.163 | 0.000 | 0.816 | 0.000 | 0.000 |
| `pool-list` | 0.163 | 0.000 | 0.816 | 0.000 | 0.000 |
| `address-group-list` | 0.133 | 0.000 | 0.667 | 0.000 | 0.000 |
| `server-type` | 0.125 | 0.000 | 0.000 | 0.000 | 0.833 |
| `backup-server-list` | 0.120 | 0.000 | 0.333 | 0.000 | 0.354 |
| `lease-time` | 0.116 | 0.000 | 0.000 | 0.000 | 0.772 |
| `address` | 0.115 | 0.000 | 0.577 | 0.000 | 0.000 |
| `pool` | 0.115 | 0.000 | 0.577 | 0.000 | 0.000 |
| `dns-server-list` | 0.112 | 0.000 | 0.333 | 0.000 | 0.302 |

**Placement confidence (top-1 structural):** 0.258 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<aging-time>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['aging', 'time']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `hello-time` | 0.370 | 0.000 | 0.500 | 0.000 | 0.800 |
| `time` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `stp-enabled` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `bridge-priority` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `max-age` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `forward-delay` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `time-exceeded` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `time-zone` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `time-unit` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `lease-time` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.370 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<aging-timeout>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['aging', 'timeout']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `retention-timeout` | 0.362 | 0.000 | 0.500 | 0.000 | 0.750 |
| `session-idle-timeout` | 0.299 | 0.000 | 0.408 | 0.000 | 0.447 |
| `keepalive-timeout` | 0.281 | 0.000 | 0.500 | 0.000 | 0.204 |
| `session-timeout` | 0.269 | 0.000 | 0.500 | 0.000 | 0.125 |
| `if-list` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `user-ip-cache-timeout` | 0.262 | 0.000 | 0.354 | 0.000 | 0.277 |
| `idle-timeout` | 0.259 | 0.000 | 0.500 | 0.000 | 0.059 |
| `icmp-timeout` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `udp-timeout` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `server-timeout` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.362 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<app-group-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['app', 'group', 'list']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `user-access-list` | 0.292 | 0.000 | 0.333 | 0.000 | 0.500 |
| `ras-server-group-list` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `muvpn-users-list` | 0.246 | 0.000 | 0.333 | 0.000 | 0.196 |
| `account-list` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `dh-group` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `server-list` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `allow-list` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `app_id` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `cert-list` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `geo-list` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.292 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<attr-name-dns-ip>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['attr', 'name', 'dns', 'ip']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `attr-name-ip` | 0.463 | 0.000 | 0.866 | 0.000 | 0.933 |
| `attr-name-ip-mask` | 0.440 | 0.000 | 0.750 | 0.000 | 0.933 |
| `attr-name-wins-ip` | 0.440 | 0.000 | 0.750 | 0.000 | 0.933 |
| `group-attr-name` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-sess-timeout` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `attr-name-idle-timeout` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `login-id-attr` | 0.348 | 0.000 | 0.289 | 0.000 | 0.933 |
| `server-ip` | 0.345 | 0.000 | 0.354 | 0.000 | 0.826 |
| `dns-ip` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `search-base` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.463 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<attr-name-idle-timeout>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['attr', 'name', 'idle', 'timeout']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `attr-name-sess-timeout` | 0.440 | 0.000 | 0.750 | 0.000 | 0.933 |
| `group-attr-name` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-ip` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-ip-mask` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `attr-name-dns-ip` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `attr-name-wins-ip` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `login-id-attr` | 0.348 | 0.000 | 0.289 | 0.000 | 0.933 |
| `session-idle-timeout` | 0.300 | 0.000 | 0.577 | 0.000 | 0.231 |
| `idle-timeout` | 0.292 | 0.000 | 0.707 | 0.000 | 0.002 |
| `search-base` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.440 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<attr-name-ip>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['attr', 'name', 'ip']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `attr-name-ip-mask` | 0.463 | 0.000 | 0.866 | 0.000 | 0.933 |
| `attr-name-dns-ip` | 0.463 | 0.000 | 0.866 | 0.000 | 0.933 |
| `attr-name-wins-ip` | 0.463 | 0.000 | 0.866 | 0.000 | 0.933 |
| `group-attr-name` | 0.423 | 0.000 | 0.667 | 0.000 | 0.933 |
| `attr-name-sess-timeout` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-idle-timeout` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `login-id-attr` | 0.357 | 0.000 | 0.333 | 0.000 | 0.933 |
| `server-ip` | 0.356 | 0.000 | 0.408 | 0.000 | 0.826 |
| `search-base` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `deadtime` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.463 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<attr-name-ip-mask>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['attr', 'name', 'ip', 'mask']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `attr-name-ip` | 0.463 | 0.000 | 0.866 | 0.000 | 0.933 |
| `attr-name-dns-ip` | 0.440 | 0.000 | 0.750 | 0.000 | 0.933 |
| `attr-name-wins-ip` | 0.440 | 0.000 | 0.750 | 0.000 | 0.933 |
| `group-attr-name` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-sess-timeout` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `attr-name-idle-timeout` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `login-id-attr` | 0.348 | 0.000 | 0.289 | 0.000 | 0.933 |
| `server-ip` | 0.345 | 0.000 | 0.354 | 0.000 | 0.826 |
| `ip-mask` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `search-base` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.463 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<attr-name-sess-timeout>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['attr', 'name', 'sess', 'timeout']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `attr-name-idle-timeout` | 0.440 | 0.000 | 0.750 | 0.000 | 0.933 |
| `group-attr-name` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-ip` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-ip-mask` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `attr-name-dns-ip` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `attr-name-wins-ip` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `login-id-attr` | 0.348 | 0.000 | 0.289 | 0.000 | 0.933 |
| `search-base` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `deadtime` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `search-user-dn` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.440 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<attr-name-wins-ip>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['attr', 'name', 'wins', 'ip']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `attr-name-ip` | 0.463 | 0.000 | 0.866 | 0.000 | 0.933 |
| `attr-name-ip-mask` | 0.440 | 0.000 | 0.750 | 0.000 | 0.933 |
| `attr-name-dns-ip` | 0.440 | 0.000 | 0.750 | 0.000 | 0.933 |
| `group-attr-name` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-sess-timeout` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `attr-name-idle-timeout` | 0.390 | 0.000 | 0.500 | 0.000 | 0.933 |
| `login-id-attr` | 0.348 | 0.000 | 0.289 | 0.000 | 0.933 |
| `server-ip` | 0.345 | 0.000 | 0.354 | 0.000 | 0.826 |
| `wins-ip` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `search-base` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.463 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<auth-domain-name-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['auth', 'domain', 'name', 'list']
- Top child tags (by occurrence): ['name']
- Value-pattern observations per child field:
    - `name`: enum-small
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `auth-group` | 0.326 | 0.555 | 0.354 | 0.577 | 0.000 |
| `tls-profile` | 0.318 | 0.378 | 0.000 | 0.970 | 0.000 |
| `ntp-server-list` | 0.308 | 0.000 | 0.289 | 1.000 | 0.000 |
| `dlp-sensor` | 0.271 | 0.333 | 0.000 | 0.816 | 0.000 |
| `user-group` | 0.269 | 0.816 | 0.000 | 0.000 | 0.000 |
| `device-group` | 0.260 | 0.577 | 0.000 | 0.577 | 0.000 |
| `address-group` | 0.252 | 0.541 | 0.000 | 0.577 | 0.000 |
| `log` | 0.250 | 0.000 | 0.000 | 1.000 | 0.002 |
| `sslfilter` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `ocsp` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.326 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<auto-reboot>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 4
- Distinct field shapes: 1
- Naming tokens: ['auto', 'reboot']
- Top child tags (by occurrence): ['hour', 'enabled', 'minute', 'day']
- Value-pattern observations per child field:
    - `day`: port
    - `enabled`: boolean-numeric
    - `hour`: boolean-numeric
    - `minute`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `botnet-detection` | 0.337 | 0.500 | 0.000 | 0.949 | 0.000 |
| `multicast` | 0.337 | 0.500 | 0.000 | 0.949 | 0.000 |
| `daas-client` | 0.337 | 0.500 | 0.000 | 0.949 | 0.000 |
| `multicast-if` | 0.308 | 0.354 | 0.000 | 0.949 | 0.000 |
| `dns-forwarding` | 0.308 | 0.354 | 0.000 | 0.949 | 0.000 |
| `remote-logging` | 0.308 | 0.354 | 0.000 | 0.949 | 0.000 |
| `ike-policy-group` | 0.270 | 0.224 | 0.000 | 0.900 | 0.000 |
| `common-logging` | 0.262 | 0.250 | 0.000 | 0.849 | 0.000 |
| `ipsec-action` | 0.254 | 0.144 | 0.000 | 0.900 | 0.000 |
| `geolocation-blocking` | 0.249 | 0.408 | 0.000 | 0.671 | 0.000 |

**Placement confidence (top-1 structural):** 0.337 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<auto-reconnect>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['auto', 'reconnect']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `remember-connection` | 0.286 | 0.000 | 0.000 | 0.000 | 0.909 |
| `networking-mode` | 0.286 | 0.000 | 0.000 | 0.000 | 0.909 |
| `server-mode` | 0.286 | 0.000 | 0.000 | 0.000 | 0.909 |
| `auto-start` | 0.282 | 0.000 | 0.500 | 0.000 | 0.211 |
| `auto-negotiation` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `auto-interval` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `auto-redirect` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `proxy-auto-gen` | 0.249 | 0.000 | 0.408 | 0.000 | 0.114 |
| `feature-key-auto-sync` | 0.238 | 0.000 | 0.354 | 0.000 | 0.114 |
| `mode` | 0.232 | 0.000 | 0.000 | 0.000 | 0.547 |

**Placement confidence (top-1 structural):** 0.286 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<auto-redirect>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['auto', 'redirect']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `redirect-url` | 0.383 | 0.000 | 0.500 | 0.000 | 0.889 |
| `mgmt-multi-rw-session` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |
| `hotspot-user-idle-timeout` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |
| `hotspot-user-session-timeout` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |
| `hotspot-max-guest-num` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |
| `auth-user-timeout` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `auth-user-session-timeout` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `mgmt-user-idle-timeout` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `mgmt-user-session-timeout` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `firebox-user-case-sensitivity` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |

**Placement confidence (top-1 structural):** 0.383 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<beh_id>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 33
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['beh', 'id']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `cat_id` | 0.353 | 0.000 | 0.500 | 0.000 | 0.685 |
| `app_id` | 0.352 | 0.000 | 0.500 | 0.000 | 0.679 |
| `override-id-list` | 0.318 | 0.000 | 0.408 | 0.000 | 0.577 |
| `card-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `client-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `rsa-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `message-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `membership-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `counter-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `module-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.353 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<br-protos>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 6
- Distinct field shapes: 1
- Naming tokens: ['br', 'protos']
- Top child tags (by occurrence): ['max-age', 'aging-time', 'hello-time', 'stp-enabled', 'forward-delay', 'bridge-priority']
- Value-pattern observations per child field:
    - `aging-time`: port
    - `bridge-priority`: port
    - `forward-delay`: port
    - `hello-time`: port
    - `max-age`: port
    - `stp-enabled`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `stp-port` | 0.263 | 0.000 | 0.000 | 0.832 | 0.365 |
| `external-if` | 0.253 | 0.000 | 0.000 | 0.832 | 0.298 |
| `mgmt-acct-lockout` | 0.248 | 0.000 | 0.000 | 0.992 | 0.000 |
| `lockout` | 0.248 | 0.000 | 0.000 | 0.992 | 0.000 |
| `blocked-port-list` | 0.245 | 0.000 | 0.000 | 0.981 | 0.000 |
| `username` | 0.245 | 0.000 | 0.000 | 0.981 | 0.000 |
| `timeout` | 0.245 | 0.000 | 0.000 | 0.981 | 0.000 |
| `uri` | 0.245 | 0.000 | 0.000 | 0.981 | 0.000 |
| `max-length` | 0.245 | 0.000 | 0.000 | 0.981 | 0.000 |
| `backlog` | 0.245 | 0.000 | 0.000 | 0.981 | 0.000 |

**Placement confidence (top-1 structural):** 0.263 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<bridge-priority>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['bridge', 'priority']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `stp-enabled` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `aging-time` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `hello-time` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `max-age` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `forward-delay` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `priority-method` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `port-priority` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.270 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<cipher>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['cipher']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `dh` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `hash` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `force-auth-reconnect` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `require-client-cert` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `base-model` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.262 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<client-to-client>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['client', 'to', 'client']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `remote-routes` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `wins` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `redirect-gateway` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `use-firebox-routes` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `client-id` | 0.276 | 0.000 | 0.632 | 0.000 | 0.000 |
| `client-fallthrough-option` | 0.253 | 0.000 | 0.516 | 0.000 | 0.000 |
| `accounting-client-ip` | 0.253 | 0.000 | 0.516 | 0.000 | 0.000 |
| `require-client-cert` | 0.253 | 0.000 | 0.516 | 0.000 | 0.000 |
| `to-hour` | 0.213 | 0.000 | 0.316 | 0.000 | 0.000 |
| `to-min` | 0.213 | 0.000 | 0.316 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.283 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<clientless-vpn>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 3
- Distinct field shapes: 1
- Naming tokens: ['clientless', 'vpn']
- Top child tags (by occurrence): ['app-group-list', 'user-access-list', 'settings']
- Value-pattern observations per child field:
    - `app-group-list`: empty
    - `user-access-list`: empty
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `system-parameters` | 0.394 | 0.000 | 0.000 | 1.000 | 0.963 |
| `gateway-wireless-controller` | 0.386 | 0.000 | 0.000 | 1.000 | 0.909 |
| `signature-update` | 0.344 | 0.000 | 0.000 | 0.800 | 0.963 |
| `logon-banner` | 0.324 | 0.000 | 0.000 | 0.707 | 0.982 |
| `threat-correlation` | 0.324 | 0.000 | 0.000 | 0.707 | 0.982 |
| `geolocation-blocking` | 0.321 | 0.000 | 0.000 | 0.707 | 0.963 |
| `vpn-portal` | 0.296 | 0.000 | 0.500 | 0.196 | 0.982 |
| `snmp-conf` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `encryption` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `terminal-service` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.394 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<compat-version>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['compat', 'version']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `rs-version` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `for-version` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `snmp-version` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `view` | 0.245 | 0.000 | 0.000 | 0.000 | 0.632 |
| `snmp-trap-version` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `version` | 0.205 | 0.000 | 0.707 | 0.000 | 0.000 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `base-model` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.250 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<compression>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['compression']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `listen-to` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `reneg-datachannel` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `server-port` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `host` | 0.191 | 0.000 | 0.000 | 0.000 | 0.272 |
| `type` | 0.190 | 0.000 | 0.000 | 0.000 | 0.270 |
| `tls-port` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |
| `icmp-type` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |
| `icmp-code` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |
| `start-server-port` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |
| `end-server-port` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |

**Placement confidence (top-1 structural):** 0.275 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<config-change-log-enable>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['config', 'change', 'log', 'enable']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `traffic-log-enable` | 0.398 | 0.000 | 0.577 | 0.000 | 0.886 |
| `event-log-level` | 0.341 | 0.000 | 0.289 | 0.000 | 0.886 |
| `ike-decryp-pkt-trace` | 0.283 | 0.000 | 0.000 | 0.000 | 0.886 |
| `debug-level` | 0.283 | 0.000 | 0.000 | 0.000 | 0.886 |
| `local-enabled` | 0.283 | 0.000 | 0.000 | 0.000 | 0.886 |
| `support-cache-enabled` | 0.283 | 0.000 | 0.000 | 0.000 | 0.886 |
| `enable` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `log` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dos-enable` | 0.221 | 0.000 | 0.354 | 0.000 | 0.000 |
| `qos-enable` | 0.221 | 0.000 | 0.354 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.398 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<control-hostout-traffic>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['control', 'hostout', 'traffic']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `syn-checking-enable` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `vlan-forward` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `log-in-out-broadcast` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `auto-blocked-duration` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `block-spoof-enabled` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `auto-order-enabled` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `qos-enable` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `tcp-mtu-probing` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `traffic-mgmt` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `restrict-traffic` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.285 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<custom-background-image>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['custom', 'background', 'image']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `custom-css` | 0.363 | 0.000 | 0.408 | 0.000 | 0.875 |
| `custom-header-logo` | 0.348 | 0.000 | 0.333 | 0.000 | 0.875 |
| `custom-logo` | 0.344 | 0.000 | 0.408 | 0.000 | 0.746 |
| `page-title` | 0.281 | 0.000 | 0.000 | 0.000 | 0.875 |
| `session-timeout` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |
| `accounting-client-ip` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `secret` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `group-attr-type` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `exception-list` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `host` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |

**Placement confidence (top-1 structural):** 0.363 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<custom-css>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['custom', 'css']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `custom-header-logo` | 0.363 | 0.000 | 0.408 | 0.000 | 0.875 |
| `custom-background-image` | 0.363 | 0.000 | 0.408 | 0.000 | 0.875 |
| `custom-logo` | 0.362 | 0.000 | 0.500 | 0.000 | 0.746 |
| `page-title` | 0.281 | 0.000 | 0.000 | 0.000 | 0.875 |
| `session-timeout` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |
| `accounting-client-ip` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `secret` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `group-attr-type` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `exception-list` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `host` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |

**Placement confidence (top-1 structural):** 0.363 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<custom-header-logo>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['custom', 'header', 'logo']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `custom-logo` | 0.425 | 0.000 | 0.816 | 0.000 | 0.746 |
| `custom-css` | 0.363 | 0.000 | 0.408 | 0.000 | 0.875 |
| `custom-background-image` | 0.348 | 0.000 | 0.333 | 0.000 | 0.875 |
| `page-title` | 0.281 | 0.000 | 0.000 | 0.000 | 0.875 |
| `session-timeout` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |
| `header-value` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `accounting-client-ip` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `secret` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `group-attr-type` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `exception-list` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |

**Placement confidence (top-1 structural):** 0.425 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<custom-logo>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['custom', 'logo']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `custom-header-logo` | 0.425 | 0.000 | 0.816 | 0.000 | 0.746 |
| `custom-css` | 0.362 | 0.000 | 0.500 | 0.000 | 0.746 |
| `custom-background-image` | 0.344 | 0.000 | 0.408 | 0.000 | 0.746 |
| `page-title` | 0.262 | 0.000 | 0.000 | 0.000 | 0.746 |
| `session-timeout` | 0.240 | 0.000 | 0.000 | 0.000 | 0.603 |
| `title` | 0.202 | 0.000 | 0.000 | 0.000 | 0.348 |
| `fault_upload` | 0.195 | 0.000 | 0.000 | 0.000 | 0.302 |
| `accounting-client-ip` | 0.187 | 0.000 | 0.000 | 0.000 | 0.246 |
| `secret` | 0.187 | 0.000 | 0.000 | 0.000 | 0.246 |
| `group-attr-type` | 0.187 | 0.000 | 0.000 | 0.000 | 0.246 |

**Placement confidence (top-1 structural):** 0.425 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<daas-client>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['daas', 'client']
- Top child tags (by occurrence): ['enabled']
- Value-pattern observations per child field:
    - `enabled`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `multicast` | 0.746 | 1.000 | 0.000 | 1.000 | 0.976 |
| `botnet-detection` | 0.741 | 1.000 | 0.000 | 1.000 | 0.942 |
| `common-logging` | 0.465 | 0.500 | 0.000 | 0.894 | 0.942 |
| `network-discovery` | 0.440 | 0.447 | 0.000 | 0.816 | 0.976 |
| `dvcp-client` | 0.430 | 0.277 | 0.500 | 0.535 | 0.942 |
| `dns-forwarding` | 0.415 | 0.707 | 0.000 | 1.000 | 0.157 |
| `multicast-if` | 0.399 | 0.707 | 0.000 | 1.000 | 0.049 |
| `traffic-flow-conf` | 0.396 | 0.000 | 0.000 | 1.000 | 0.976 |
| `dxcp-client` | 0.395 | 0.408 | 0.500 | 0.267 | 0.976 |
| `remote-logging` | 0.391 | 0.707 | 0.000 | 1.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.746 (medium)

<!-- ENGINE-OBSERVATION-END -->

### `<daily>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['daily']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `op` | 0.188 | 0.000 | 0.000 | 0.000 | 0.250 |
| `severity` | 0.152 | 0.000 | 0.000 | 0.000 | 0.011 |
| `email-enable` | 0.152 | 0.000 | 0.000 | 0.000 | 0.011 |
| `email-addr` | 0.152 | 0.000 | 0.000 | 0.000 | 0.011 |
| `email-subject` | 0.152 | 0.000 | 0.000 | 0.000 | 0.011 |
| `email-from` | 0.152 | 0.000 | 0.000 | 0.000 | 0.011 |
| `block-ip-enable` | 0.152 | 0.000 | 0.000 | 0.000 | 0.011 |
| `trap-enable` | 0.152 | 0.000 | 0.000 | 0.000 | 0.010 |
| `remote-enable` | 0.152 | 0.000 | 0.000 | 0.000 | 0.010 |
| `launch-interval` | 0.152 | 0.000 | 0.000 | 0.000 | 0.010 |

**Placement confidence (top-1 structural):** 0.188 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<day>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['day']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `day-of-week` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `hour` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `minute` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `rp-candidate` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `ccl-name` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `header-value` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `account-id` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `restrict-user-access` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `session-idle-timeout` | 0.227 | 0.000 | 0.000 | 0.000 | 0.516 |
| `agent-ip-list` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |

**Placement confidence (top-1 structural):** 0.265 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<deactivate-count>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['deactivate', 'count']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `reactivate-count` | 0.350 | 0.000 | 0.500 | 0.000 | 0.667 |
| `probe-interval` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `repeat-count` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `if-name` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `ip` | 0.153 | 0.000 | 0.000 | 0.000 | 0.018 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.350 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<deadtime>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['deadtime']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `search-base` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `group-attr-name` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-ip-mask` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-dns-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-wins-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-sess-timeout` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-idle-timeout` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `login-id-attr` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `search-user-dn` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.290 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<device-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['device', 'list']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `account-list` | 0.394 | 0.000 | 0.500 | 0.000 | 0.963 |
| `l2tp-list` | 0.386 | 0.000 | 0.500 | 0.000 | 0.909 |
| `hotspot-list` | 0.386 | 0.000 | 0.500 | 0.000 | 0.909 |
| `probe-list` | 0.379 | 0.000 | 0.500 | 0.000 | 0.963 |
| `traffic-mgmt-list` | 0.376 | 0.000 | 0.408 | 0.000 | 0.963 |
| `ras-user-list` | 0.376 | 0.000 | 0.408 | 0.000 | 0.963 |
| `policy-tag-list` | 0.368 | 0.000 | 0.408 | 0.000 | 0.909 |
| `policy-filter-list` | 0.368 | 0.000 | 0.408 | 0.000 | 0.909 |
| `ras-domain-item-list` | 0.365 | 0.000 | 0.354 | 0.000 | 0.963 |
| `ras-server-group-list` | 0.365 | 0.000 | 0.354 | 0.000 | 0.963 |

**Placement confidence (top-1 structural):** 0.394 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<dh>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['dh']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `dh-group` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `hash` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `cipher` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `force-auth-reconnect` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `require-client-cert` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<dlp-custom-rule>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 4
- Distinct field shapes: 1
- Naming tokens: ['dlp', 'custom', 'rule']
- Top child tags (by occurrence): ['terms', 'description', 'property', 'name']
- Value-pattern observations per child field:
    - `description`: free-text
    - `name`: free-text
    - `property`: boolean-numeric
    - `terms`: empty
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `user-group` | 0.399 | 0.816 | 0.000 | 0.943 | 0.000 |
| `https-exception-override` | 0.360 | 0.756 | 0.000 | 0.833 | 0.000 |
| `geo-action` | 0.358 | 0.750 | 0.000 | 0.833 | 0.000 |
| `auth-domain` | 0.354 | 0.730 | 0.000 | 0.833 | 0.000 |
| `rule` | 0.353 | 0.260 | 0.577 | 0.744 | 0.000 |
| `abs-ipsec-action` | 0.340 | 0.530 | 0.000 | 0.937 | 0.000 |
| `load-balance` | 0.338 | 0.671 | 0.000 | 0.816 | 0.000 |
| `dlp-action` | 0.332 | 0.000 | 0.408 | 1.000 | 0.000 |
| `app-action` | 0.322 | 0.589 | 0.000 | 0.816 | 0.000 |
| `service` | 0.316 | 0.615 | 0.000 | 0.772 | 0.000 |

**Placement confidence (top-1 structural):** 0.399 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<dlp-custom-rule-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['dlp', 'custom', 'rule', 'list']
- Top child tags (by occurrence): ['dlp-custom-rule']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `dlp-sensor-list` | 0.252 | 0.000 | 0.577 | 0.000 | 0.912 |
| `device-list` | 0.218 | 0.000 | 0.354 | 0.000 | 0.982 |
| `account-list` | 0.215 | 0.000 | 0.354 | 0.000 | 0.963 |
| `service-list` | 0.215 | 0.000 | 0.354 | 0.000 | 0.963 |
| `nat-list` | 0.215 | 0.000 | 0.354 | 0.000 | 0.963 |
| `schedule-list` | 0.215 | 0.000 | 0.354 | 0.000 | 0.963 |
| `alias-list` | 0.215 | 0.000 | 0.354 | 0.000 | 0.963 |
| `interface-list` | 0.215 | 0.000 | 0.354 | 0.000 | 0.963 |
| `probe-list` | 0.215 | 0.000 | 0.354 | 0.000 | 0.963 |
| `dnat-list` | 0.215 | 0.000 | 0.354 | 0.000 | 0.963 |

**Placement confidence (top-1 structural):** 0.252 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<dns-domain>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['dns', 'domain']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `domain-name-list` | 0.382 | 0.000 | 0.408 | 0.000 | 1.000 |
| `domain` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `dns-entry` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dns-mgmt` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dns-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `ip-domain` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dns-forwarding` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `auth-domain` | 0.242 | 0.000 | 0.500 | 0.000 | 0.000 |
| `proxy-user-domain` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `policy-domain-list` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.382 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<dns-ip>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['dns', 'ip']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `wins-ip` | 0.389 | 0.000 | 0.500 | 0.000 | 0.929 |
| `dns-mgmt` | 0.375 | 0.000 | 0.500 | 0.000 | 0.837 |
| `dns-forwarding` | 0.311 | 0.000 | 0.500 | 0.000 | 0.411 |
| `ip` | 0.294 | 0.000 | 0.707 | 0.000 | 0.016 |
| `attr-name-dns-ip` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `max-concurrent-logins` | 0.289 | 0.000 | 0.000 | 0.000 | 0.929 |
| `eap-method` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `addr-mgmt` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `addr-grp-name` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `expiry` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |

**Placement confidence (top-1 structural):** 0.389 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<duration>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['duration']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `auto-blocked-duration` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `failures` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `lockouts` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `rp-candidate` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `ccl-name` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `header-value` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `account-id` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `restrict-user-access` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `session-idle-timeout` | 0.227 | 0.000 | 0.000 | 0.000 | 0.516 |
| `agent-ip-list` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |

**Placement confidence (top-1 structural):** 0.265 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<dxcp-client>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 6
- Distinct field shapes: 1
- Naming tokens: ['dxcp', 'client']
- Top child tags (by occurrence): ['health-report-interval', 'enabled', 'password', 'client-id', 'server-port', 'server-list']
- Value-pattern observations per child field:
    - `client-id`: empty
    - `enabled`: boolean-numeric
    - `health-report-interval`: port
    - `password`: empty
    - `server-list`: empty
    - `server-port`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `dvcp-client` | 0.541 | 0.340 | 0.500 | 0.929 | 0.942 |
| `single-sign-on` | 0.423 | 0.198 | 0.000 | 0.969 | 0.942 |
| `radius-sso` | 0.420 | 0.154 | 0.000 | 0.972 | 0.976 |
| `ldap` | 0.398 | 0.129 | 0.000 | 0.933 | 0.929 |
| `terminal-service` | 0.396 | 0.272 | 0.000 | 0.802 | 0.942 |
| `daas-client` | 0.395 | 0.408 | 0.500 | 0.267 | 0.976 |
| `snmp-conf` | 0.342 | 0.000 | 0.000 | 0.802 | 0.942 |
| `common-logging` | 0.331 | 0.204 | 0.000 | 0.598 | 0.942 |
| `dynamic-routing` | 0.330 | 0.000 | 0.000 | 0.756 | 0.942 |
| `traffic-flow-timers` | 0.326 | 0.000 | 0.000 | 0.802 | 0.840 |

**Placement confidence (top-1 structural):** 0.541 (medium)

<!-- ENGINE-OBSERVATION-END -->

### `<end-ip>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['end', 'ip']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `ip` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `gateway-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `use-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `ip-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `ip-mask` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `ip-addr` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `firebox-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `server-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dns-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `wins-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<exception-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['exception', 'list']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `sso-exception-list` | 0.338 | 0.000 | 0.816 | 0.000 | 0.167 |
| `ips-signature-exception-list` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `if-list` | 0.281 | 0.000 | 0.500 | 0.000 | 0.204 |
| `accounting-client-ip` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `secret` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `group-attr-type` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `agent-ip-list` | 0.275 | 0.000 | 0.408 | 0.000 | 0.289 |
| `exclude-ip-list` | 0.267 | 0.000 | 0.408 | 0.000 | 0.236 |
| `backup-log-server-list` | 0.256 | 0.000 | 0.354 | 0.000 | 0.236 |
| `server-list` | 0.255 | 0.000 | 0.500 | 0.000 | 0.032 |

**Placement confidence (top-1 structural):** 0.338 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<facility-map>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 5
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['facility', 'map']
- Top child tags (by occurrence): ['log-type', 'log-facility']
- Value-pattern observations per child field:
    - `log-facility`: port
    - `log-type`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `blocked-port-list` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `username` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `timeout` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `uri` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `max-length` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `backlog` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `method` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `max-line-length` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `content-actions` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `filename` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.250 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<facility-map-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['facility', 'map', 'list']
- Top child tags (by occurrence): ['facility-map']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `facility-map` | 0.163 | 0.000 | 0.816 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.163 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<failures>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['failures']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `lockouts` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `duration` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `rp-candidate` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `ccl-name` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `header-value` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `account-id` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `restrict-user-access` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `session-idle-timeout` | 0.227 | 0.000 | 0.000 | 0.000 | 0.516 |
| `agent-ip-list` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |
| `protection-type` | 0.209 | 0.000 | 0.000 | 0.000 | 0.392 |

**Placement confidence (top-1 structural):** 0.250 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<fault_upload>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['fault', 'upload']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `title` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `feature-key-url` | 0.207 | 0.000 | 0.000 | 0.000 | 0.378 |
| `rss-url` | 0.207 | 0.000 | 0.000 | 0.000 | 0.378 |
| `staging-url` | 0.207 | 0.000 | 0.000 | 0.000 | 0.378 |
| `rss-check` | 0.207 | 0.000 | 0.000 | 0.000 | 0.378 |
| `feature-key-auto-sync` | 0.207 | 0.000 | 0.000 | 0.000 | 0.378 |
| `serial` | 0.205 | 0.000 | 0.000 | 0.000 | 0.365 |
| `custom-logo` | 0.195 | 0.000 | 0.000 | 0.000 | 0.302 |
| `remember-connection` | 0.195 | 0.000 | 0.000 | 0.000 | 0.302 |
| `auto-reconnect` | 0.195 | 0.000 | 0.000 | 0.000 | 0.302 |

**Placement confidence (top-1 structural):** 0.237 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<feedback>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='false'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['feedback']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `base-model` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `account-list` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `dest-address` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `mask` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `gateway-ip` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.150 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<firebox>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['firebox']
- Top child tags (by occurrence): ['min-password-length', 'lockout']
- Value-pattern observations per child field:
    - `min-password-length`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `nat-t-config` | 0.292 | 0.000 | 0.000 | 0.832 | 0.557 |
| `gateway` | 0.271 | 0.000 | 0.000 | 0.853 | 0.387 |
| `protocol` | 0.262 | 0.000 | 0.000 | 0.832 | 0.362 |
| `ctspam` | 0.262 | 0.000 | 0.000 | 0.913 | 0.224 |
| `blocked-port-list` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `username` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `timeout` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `uri` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `max-length` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `backlog` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.292 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<flush-connections>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['flush', 'connections']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `base-model` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `account-list` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `dest-address` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `mask` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `gateway-ip` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.150 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<force-auth-reconnect>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['force', 'auth', 'reconnect']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `dh` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `hash` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `cipher` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `require-client-cert` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `auth-algm` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `auth-method` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `auth-enabled` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `proxy-auth` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `force-renew` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `auto-reconnect` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.262 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<forward-delay>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['forward', 'delay']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `stp-enabled` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `bridge-priority` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `aging-time` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `hello-time` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `max-age` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `vlan-forward` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `forward-traffic-mgmt` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.270 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<gateway>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 3
- Distinct child element tags: 9
- Distinct field shapes: 2
- Naming tokens: ['gateway']
- Top child tags (by occurrence): ['ip', 'if-name', 'ip-domain-list', 'compression', 'port', 'reneg-datachannel', 'listen-to', 'mtu', 'protocol']
- Value-pattern observations per child field:
    - `compression`: boolean-numeric
    - `if-name`: enum-small
    - `ip`: empty
    - `listen-to`: empty
    - `mtu`: port
    - `port`: port
    - `protocol`: port
    - `reneg-datachannel`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `peer` | 0.297 | 0.000 | 0.000 | 0.627 | 0.934 |
| `quarantine` | 0.280 | 0.183 | 0.000 | 0.905 | 0.115 |
| `firebox` | 0.271 | 0.000 | 0.000 | 0.853 | 0.387 |
| `nat-t-config` | 0.264 | 0.000 | 0.000 | 0.828 | 0.384 |
| `radius-conf` | 0.264 | 0.387 | 0.000 | 0.746 | 0.000 |
| `ctspam` | 0.251 | 0.000 | 0.000 | 0.934 | 0.115 |
| `probe` | 0.247 | 0.258 | 0.000 | 0.783 | 0.000 |
| `member` | 0.238 | 0.146 | 0.000 | 0.835 | 0.000 |
| `uri` | 0.228 | 0.000 | 0.000 | 0.853 | 0.097 |
| `physical-if` | 0.228 | 0.164 | 0.000 | 0.779 | 0.000 |

**Placement confidence (top-1 structural):** 0.297 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<gateway-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['gateway', 'list']
- Top child tags (by occurrence): ['gateway']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `geo-list` | 0.230 | 0.000 | 0.500 | 0.000 | 0.866 |
| `alias-member-list` | 0.211 | 0.000 | 0.408 | 0.000 | 0.859 |
| `gateway` | 0.200 | 0.000 | 0.707 | 0.000 | 0.387 |
| `block-list` | 0.197 | 0.000 | 0.500 | 0.000 | 0.645 |
| `if-item-list` | 0.190 | 0.000 | 0.408 | 0.000 | 0.722 |
| `filter-list` | 0.180 | 0.000 | 0.500 | 0.000 | 0.530 |
| `allow-list` | 0.175 | 0.000 | 0.500 | 0.000 | 0.500 |
| `policy-list` | 0.163 | 0.000 | 0.500 | 0.000 | 0.423 |
| `content-rule-list` | 0.161 | 0.000 | 0.408 | 0.000 | 0.530 |
| `override-id-list` | 0.157 | 0.000 | 0.408 | 0.000 | 0.500 |

**Placement confidence (top-1 structural):** 0.230 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<group-attr-name>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['group', 'attr', 'name']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `attr-name-ip` | 0.423 | 0.000 | 0.667 | 0.000 | 0.933 |
| `attr-name-ip-mask` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-dns-ip` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-wins-ip` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-sess-timeout` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `attr-name-idle-timeout` | 0.405 | 0.000 | 0.577 | 0.000 | 0.933 |
| `login-id-attr` | 0.357 | 0.000 | 0.333 | 0.000 | 0.933 |
| `group-attr-type` | 0.299 | 0.000 | 0.667 | 0.000 | 0.105 |
| `search-base` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `deadtime` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.423 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<group-attr-type>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['group', 'attr', 'type']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `group-attr-name` | 0.299 | 0.000 | 0.667 | 0.000 | 0.105 |
| `proxy-type-attr` | 0.283 | 0.000 | 0.667 | 0.000 | 0.000 |
| `accounting-client-ip` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `secret` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `exception-list` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `protection-type` | 0.273 | 0.000 | 0.408 | 0.000 | 0.277 |
| `type` | 0.270 | 0.000 | 0.577 | 0.000 | 0.028 |
| `proxy-type` | 0.256 | 0.000 | 0.408 | 0.000 | 0.162 |
| `traffic-type` | 0.249 | 0.000 | 0.408 | 0.000 | 0.116 |
| `vpn-type` | 0.248 | 0.000 | 0.408 | 0.000 | 0.107 |

**Placement confidence (top-1 structural):** 0.299 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<hash>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['hash']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `dh` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `cipher` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `force-auth-reconnect` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `require-client-cert` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `base-model` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.262 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<header-value>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['header', 'value']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `rp-candidate` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `ccl-name` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `account-id` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `restrict-user-access` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `value` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `session-idle-timeout` | 0.284 | 0.000 | 0.000 | 0.000 | 0.894 |
| `agent-ip-list` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |
| `protection-type` | 0.252 | 0.000 | 0.000 | 0.000 | 0.679 |
| `backup-log-server-list` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `exclude-ip-list` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |

**Placement confidence (top-1 structural):** 0.300 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<health-report-interval>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['health', 'report', 'interval']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `lease-interval` | 0.290 | 0.000 | 0.408 | 0.000 | 0.387 |
| `interval` | 0.263 | 0.000 | 0.577 | 0.000 | 0.000 |
| `keepalive-interval` | 0.259 | 0.000 | 0.408 | 0.000 | 0.183 |
| `keep-alive-interval` | 0.234 | 0.000 | 0.333 | 0.000 | 0.117 |
| `launch-interval` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `auto-interval` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `probe-interval` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `client-id` | 0.219 | 0.000 | 0.000 | 0.000 | 0.458 |
| `rp-candidate` | 0.217 | 0.000 | 0.000 | 0.000 | 0.447 |
| `ccl-name` | 0.217 | 0.000 | 0.000 | 0.000 | 0.447 |

**Placement confidence (top-1 structural):** 0.290 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<hello-time>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['hello', 'time']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `aging-time` | 0.370 | 0.000 | 0.500 | 0.000 | 0.800 |
| `time` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `stp-enabled` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `bridge-priority` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `max-age` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `forward-delay` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `time-exceeded` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `time-zone` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `time-unit` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `lease-time` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.370 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<hotspot-max-guest-num>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['hotspot', 'max', 'guest', 'num']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `hotspot-user-idle-timeout` | 0.338 | 0.000 | 0.250 | 0.000 | 0.917 |
| `hotspot-user-session-timeout` | 0.338 | 0.000 | 0.250 | 0.000 | 0.917 |
| `mgmt-multi-rw-session` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |
| `auto-redirect` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |
| `auth-user-timeout` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `auth-user-session-timeout` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `mgmt-user-idle-timeout` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `mgmt-user-session-timeout` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `redirect-url` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `firebox-user-case-sensitivity` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |

**Placement confidence (top-1 structural):** 0.338 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<hotspot-user-idle-timeout>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['hotspot', 'user', 'idle', 'timeout']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `hotspot-user-session-timeout` | 0.438 | 0.000 | 0.750 | 0.000 | 0.917 |
| `mgmt-user-idle-timeout` | 0.433 | 0.000 | 0.750 | 0.000 | 0.889 |
| `auth-user-timeout` | 0.399 | 0.000 | 0.577 | 0.000 | 0.889 |
| `auth-user-session-timeout` | 0.383 | 0.000 | 0.500 | 0.000 | 0.889 |
| `mgmt-user-session-timeout` | 0.383 | 0.000 | 0.500 | 0.000 | 0.889 |
| `hotspot-max-guest-num` | 0.338 | 0.000 | 0.250 | 0.000 | 0.917 |
| `firebox-user-case-sensitivity` | 0.333 | 0.000 | 0.250 | 0.000 | 0.889 |
| `idle-timeout` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `mgmt-multi-rw-session` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |
| `auto-redirect` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |

**Placement confidence (top-1 structural):** 0.438 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<hotspot-user-session-timeout>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['hotspot', 'user', 'session', 'timeout']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `hotspot-user-idle-timeout` | 0.438 | 0.000 | 0.750 | 0.000 | 0.917 |
| `auth-user-session-timeout` | 0.433 | 0.000 | 0.750 | 0.000 | 0.889 |
| `mgmt-user-session-timeout` | 0.433 | 0.000 | 0.750 | 0.000 | 0.889 |
| `auth-user-timeout` | 0.399 | 0.000 | 0.577 | 0.000 | 0.889 |
| `mgmt-user-idle-timeout` | 0.383 | 0.000 | 0.500 | 0.000 | 0.889 |
| `mgmt-multi-rw-session` | 0.338 | 0.000 | 0.250 | 0.000 | 0.917 |
| `hotspot-max-guest-num` | 0.338 | 0.000 | 0.250 | 0.000 | 0.917 |
| `firebox-user-case-sensitivity` | 0.333 | 0.000 | 0.250 | 0.000 | 0.889 |
| `session-timeout` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `auto-redirect` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |

**Placement confidence (top-1 structural):** 0.438 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<hour>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['hour']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `from-hour` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `to-hour` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `day` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `minute` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `rp-candidate` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `ccl-name` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `header-value` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `account-id` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `restrict-user-access` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `session-idle-timeout` | 0.227 | 0.000 | 0.000 | 0.000 | 0.516 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<if-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['if', 'list']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `agent-ip-list` | 0.285 | 0.000 | 0.408 | 0.000 | 0.354 |
| `exception-list` | 0.281 | 0.000 | 0.500 | 0.000 | 0.204 |
| `exclude-ip-list` | 0.275 | 0.000 | 0.408 | 0.000 | 0.289 |
| `if-property` | 0.267 | 0.000 | 0.500 | 0.000 | 0.114 |
| `if-num` | 0.267 | 0.000 | 0.500 | 0.000 | 0.111 |
| `backup-log-server-list` | 0.264 | 0.000 | 0.354 | 0.000 | 0.289 |
| `aging-timeout` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `retention-timeout` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `sso-exception-list` | 0.262 | 0.000 | 0.408 | 0.000 | 0.204 |
| `server-list` | 0.256 | 0.000 | 0.500 | 0.000 | 0.039 |

**Placement confidence (top-1 structural):** 0.285 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<if-name>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 4
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['if', 'name']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `if-dev-name` | 0.331 | 0.000 | 0.816 | 0.000 | 0.119 |
| `name` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `if-num` | 0.268 | 0.000 | 0.500 | 0.000 | 0.119 |
| `if-property` | 0.267 | 0.000 | 0.500 | 0.000 | 0.114 |
| `system-name` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `addr-name` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `local-if` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `proxy-name` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `helper-name` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `helo-name` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.331 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<intra-vlan-inspection>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['intra', 'vlan', 'inspection']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `vlan-id` | 0.367 | 0.000 | 0.408 | 0.000 | 0.900 |
| `intra-inspection` | 0.365 | 0.000 | 0.816 | 0.000 | 0.347 |
| `vif-property` | 0.285 | 0.000 | 0.000 | 0.000 | 0.900 |
| `vlan-forward` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `ip-node-type` | 0.210 | 0.000 | 0.000 | 0.000 | 0.403 |
| `pvid-enabled` | 0.205 | 0.000 | 0.000 | 0.000 | 0.365 |
| `if-property` | 0.205 | 0.000 | 0.000 | 0.000 | 0.365 |
| `secondary-ip-list` | 0.205 | 0.000 | 0.000 | 0.000 | 0.365 |
| `vpn-df-bit` | 0.204 | 0.000 | 0.000 | 0.000 | 0.357 |
| `netmask` | 0.203 | 0.000 | 0.000 | 0.000 | 0.354 |

**Placement confidence (top-1 structural):** 0.367 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<ip-domain>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['ip', 'domain']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `domain` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `ip` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `gateway-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `use-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `ip-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `ip-mask` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `ip-addr` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `firebox-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `server-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dns-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<ip-domain-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['ip', 'domain', 'list']
- Top child tags (by occurrence): ['ip-domain']
- Value-pattern observations per child field:
    - `ip-domain`: ipv4
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `ip-list` | 0.413 | 0.000 | 0.816 | 1.000 | 0.000 |
| `dns-server-list` | 0.317 | 0.000 | 0.333 | 1.000 | 0.000 |
| `route` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `resource-addr` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `address-pool` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `pool` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `route-entry` | 0.200 | 0.000 | 0.000 | 0.802 | 0.000 |
| `primary-server` | 0.177 | 0.000 | 0.000 | 0.707 | 0.000 |
| `local-addr` | 0.177 | 0.000 | 0.000 | 0.707 | 0.000 |
| `remote-addr` | 0.177 | 0.000 | 0.000 | 0.707 | 0.000 |

**Placement confidence (top-1 structural):** 0.413 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<ip-node-type>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 9
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['ip', 'node', 'type']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `ip` | 0.407 | 0.000 | 0.577 | 0.000 | 0.941 |
| `secondary-ip-list` | 0.360 | 0.000 | 0.333 | 0.000 | 0.956 |
| `ip-type` | 0.313 | 0.000 | 0.816 | 0.000 | 0.000 |
| `default-gateway` | 0.297 | 0.000 | 0.000 | 0.000 | 0.978 |
| `auto-negotiation` | 0.294 | 0.000 | 0.000 | 0.000 | 0.961 |
| `link-speed` | 0.294 | 0.000 | 0.000 | 0.000 | 0.961 |
| `mac-address-enable` | 0.294 | 0.000 | 0.000 | 0.000 | 0.961 |
| `mac-address` | 0.294 | 0.000 | 0.000 | 0.000 | 0.961 |
| `full-duplex` | 0.294 | 0.000 | 0.000 | 0.000 | 0.961 |
| `anti-spoof` | 0.294 | 0.000 | 0.000 | 0.000 | 0.961 |

**Placement confidence (top-1 structural):** 0.407 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<keepalive>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['keepalive']
- Top child tags (by occurrence): ['timeout', 'interval']
- Value-pattern observations per child field:
    - `interval`: port
    - `timeout`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `protocol` | 0.258 | 0.248 | 0.000 | 0.832 | 0.000 |
| `blocked-port-list` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `username` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `timeout` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `uri` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `max-length` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `backlog` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `method` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `max-line-length` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `content-actions` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.258 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<keepalive-interval>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['keepalive', 'interval']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `keepalive-timeout` | 0.375 | 0.000 | 0.500 | 0.000 | 0.833 |
| `interval` | 0.289 | 0.000 | 0.707 | 0.000 | 0.000 |
| `sso-through-bovpn` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `sso-exception-list` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `sso-agent-ip` | 0.269 | 0.000 | 0.000 | 0.000 | 0.793 |
| `user-ip-cache-timeout` | 0.269 | 0.000 | 0.000 | 0.000 | 0.793 |
| `lease-interval` | 0.268 | 0.000 | 0.500 | 0.000 | 0.118 |
| `health-report-interval` | 0.259 | 0.000 | 0.408 | 0.000 | 0.183 |
| `exclude-ip-list` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |
| `launch-interval` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.375 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<keepalive-timeout>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['keepalive', 'timeout']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `keepalive-interval` | 0.375 | 0.000 | 0.500 | 0.000 | 0.833 |
| `user-ip-cache-timeout` | 0.340 | 0.000 | 0.354 | 0.000 | 0.793 |
| `session-idle-timeout` | 0.286 | 0.000 | 0.408 | 0.000 | 0.365 |
| `aging-timeout` | 0.281 | 0.000 | 0.500 | 0.000 | 0.204 |
| `retention-timeout` | 0.281 | 0.000 | 0.500 | 0.000 | 0.204 |
| `sso-through-bovpn` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `sso-exception-list` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `sso-agent-ip` | 0.269 | 0.000 | 0.000 | 0.000 | 0.793 |
| `session-timeout` | 0.265 | 0.000 | 0.500 | 0.000 | 0.102 |
| `exclude-ip-list` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |

**Placement confidence (top-1 structural):** 0.375 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<listen-to>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['listen', 'to']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `compression` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `reneg-datachannel` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `to-hour` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `to-min` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `redirect-to` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `maximum-to` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `to-alias` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `nat-t-to-port` | 0.221 | 0.000 | 0.354 | 0.000 | 0.000 |
| `client-to-client` | 0.213 | 0.000 | 0.316 | 0.000 | 0.000 |
| `one-to-one-nat-list` | 0.203 | 0.000 | 0.267 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.275 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<load-balance>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 5
- Distinct field shapes: 1
- Naming tokens: ['load', 'balance']
- Top child tags (by occurrence): ['property', 'gateway-list', 'description', 'algorithm', 'name']
- Value-pattern observations per child field:
    - `algorithm`: port
    - `description`: empty
    - `name`: free-text
    - `property`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `user-group` | 0.363 | 0.730 | 0.000 | 0.866 | 0.000 |
| `https-exception-override` | 0.339 | 0.676 | 0.000 | 0.816 | 0.000 |
| `geo-action` | 0.338 | 0.671 | 0.000 | 0.816 | 0.000 |
| `dlp-custom-rule` | 0.338 | 0.671 | 0.000 | 0.816 | 0.000 |
| `auth-domain` | 0.335 | 0.653 | 0.000 | 0.816 | 0.000 |
| `app-action` | 0.314 | 0.527 | 0.000 | 0.833 | 0.000 |
| `ras-user-group` | 0.313 | 0.383 | 0.000 | 0.945 | 0.000 |
| `ike-action` | 0.301 | 0.467 | 0.000 | 0.832 | 0.000 |
| `device-group` | 0.299 | 0.775 | 0.000 | 0.577 | 0.000 |
| `service` | 0.299 | 0.550 | 0.000 | 0.756 | 0.000 |

**Placement confidence (top-1 structural):** 0.363 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<local-routes>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['local', 'routes']
- Top child tags (by occurrence): ['route']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `remote-routes` | 0.233 | 0.000 | 0.500 | 0.000 | 0.889 |
| `use-firebox-routes` | 0.215 | 0.000 | 0.408 | 0.000 | 0.889 |
| `pool-list` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |
| `wins` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |
| `redirect-gateway` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |
| `client-to-client` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |
| `keepalive` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |

**Placement confidence (top-1 structural):** 0.233 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<lockout>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 4
- Distinct field shapes: 1
- Naming tokens: ['lockout']
- Top child tags (by occurrence): ['duration', 'enabled', 'failures', 'lockouts']
- Value-pattern observations per child field:
    - `duration`: port
    - `enabled`: boolean-numeric
    - `failures`: port
    - `lockouts`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `mgmt-acct-lockout` | 0.715 | 1.000 | 0.577 | 1.000 | 0.000 |
| `br-protos` | 0.248 | 0.000 | 0.000 | 0.992 | 0.000 |
| `dos-item` | 0.247 | 0.000 | 0.000 | 0.990 | 0.000 |
| `ctspam` | 0.245 | 0.000 | 0.000 | 0.981 | 0.000 |
| `nat-t-config` | 0.241 | 0.000 | 0.000 | 0.965 | 0.000 |
| `blocked-port-list` | 0.237 | 0.000 | 0.000 | 0.949 | 0.000 |
| `username` | 0.237 | 0.000 | 0.000 | 0.949 | 0.000 |
| `timeout` | 0.237 | 0.000 | 0.000 | 0.949 | 0.000 |
| `uri` | 0.237 | 0.000 | 0.000 | 0.949 | 0.000 |
| `max-length` | 0.237 | 0.000 | 0.000 | 0.949 | 0.000 |

**Placement confidence (top-1 structural):** 0.715 (medium)

<!-- ENGINE-OBSERVATION-END -->

### `<lockouts>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['lockouts']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `failures` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `duration` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `rp-candidate` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `ccl-name` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `header-value` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `account-id` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `restrict-user-access` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `session-idle-timeout` | 0.227 | 0.000 | 0.000 | 0.000 | 0.516 |
| `agent-ip-list` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |
| `protection-type` | 0.209 | 0.000 | 0.000 | 0.000 | 0.392 |

**Placement confidence (top-1 structural):** 0.250 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<log-deny>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='false'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 4
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['log', 'deny']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `deny` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `log` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `log-clean` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `deny-message` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `log-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `log-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `log-facility` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `traffic-log-enable` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `event-log-level` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `log-dlp-stats` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<log-facility>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 5
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['log', 'facility']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `log` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `log-clean` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `log-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `log-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `log-deny` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `traffic-log-enable` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `event-log-level` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `log-dlp-stats` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `log-for-report` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `diag-log-level` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<log-type>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 5
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['log', 'type']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `type` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `log` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `port-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dos-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `trace-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `ip-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `log-clean` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `proxy-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `icmp-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `addr-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<logging-entry>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 6
- Distinct field shapes: 1
- Naming tokens: ['logging', 'entry']
- Top child tags (by occurrence): ['format', 'syslog', 'server-port', 'description', 'server-ip', 'property']
- Value-pattern observations per child field:
    - `description`: empty
    - `format`: boolean-numeric
    - `property`: boolean-numeric
    - `server-ip`: ipv4
    - `server-port`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `common-logging` | 0.311 | 0.000 | 0.500 | 0.845 | 0.000 |
| `remote-logging` | 0.289 | 0.000 | 0.500 | 0.756 | 0.000 |
| `route-entry` | 0.277 | 0.000 | 0.500 | 0.707 | 0.000 |
| `ike-action` | 0.267 | 0.284 | 0.000 | 0.839 | 0.000 |
| `ipsec-proposal` | 0.266 | 0.326 | 0.000 | 0.802 | 0.000 |
| `load-balance` | 0.262 | 0.365 | 0.000 | 0.756 | 0.000 |
| `ras-user-group` | 0.261 | 0.233 | 0.000 | 0.857 | 0.000 |
| `schedule` | 0.259 | 0.294 | 0.000 | 0.802 | 0.000 |
| `sslvpn` | 0.259 | 0.236 | 0.000 | 0.847 | 0.000 |
| `interface` | 0.258 | 0.396 | 0.000 | 0.717 | 0.000 |

**Placement confidence (top-1 structural):** 0.311 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<login-id-attr>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['login', 'id', 'attr']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `group-attr-name` | 0.357 | 0.000 | 0.333 | 0.000 | 0.933 |
| `attr-name-ip` | 0.357 | 0.000 | 0.333 | 0.000 | 0.933 |
| `attr-name-ip-mask` | 0.348 | 0.000 | 0.289 | 0.000 | 0.933 |
| `attr-name-dns-ip` | 0.348 | 0.000 | 0.289 | 0.000 | 0.933 |
| `attr-name-wins-ip` | 0.348 | 0.000 | 0.289 | 0.000 | 0.933 |
| `attr-name-sess-timeout` | 0.348 | 0.000 | 0.289 | 0.000 | 0.933 |
| `attr-name-idle-timeout` | 0.348 | 0.000 | 0.289 | 0.000 | 0.933 |
| `search-base` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `deadtime` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `search-user-dn` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.357 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<login-limit>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['login', 'limit']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `scan-limit` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `login-option` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `mss-maximum-limit` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `login-id-attr` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `base-model` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.250 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<login-option>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['login', 'option']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `login-limit` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `client-fallthrough-option` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `server-fallthrough-option` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `login-id-attr` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `pptp-mppe-encryption-option` | 0.221 | 0.000 | 0.354 | 0.000 | 0.000 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.250 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<login-setting>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['login', 'setting']
- Top child tags (by occurrence): ['login-limit', 'login-option']
- Value-pattern observations per child field:
    - `login-limit`: boolean-numeric
    - `login-option`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `misc-global-setting` | 0.330 | 0.000 | 0.408 | 0.992 | 0.000 |
| `vpn-global-setting` | 0.317 | 0.000 | 0.408 | 0.943 | 0.000 |
| `auth-global-setting` | 0.257 | 0.000 | 0.408 | 0.700 | 0.000 |
| `snmp-trap` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `ntp-conf` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `icmp-error-handling` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `spyware` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `multi-wan` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `performance-log` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `tunnel-switch-para` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.330 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<logon-banner>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 4
- Distinct field shapes: 1
- Naming tokens: ['logon', 'banner']
- Top child tags (by occurrence): ['enable', 'message', 'title', 'custom-logo']
- Value-pattern observations per child field:
    - `custom-logo`: boolean-numeric
    - `enable`: boolean-numeric
    - `message`: empty
    - `title`: empty
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `threat-correlation` | 0.397 | 0.000 | 0.000 | 1.000 | 0.982 |
| `geolocation-blocking` | 0.394 | 0.000 | 0.000 | 1.000 | 0.963 |
| `vpn-portal` | 0.354 | 0.167 | 0.000 | 0.693 | 0.982 |
| `clientless-vpn` | 0.324 | 0.000 | 0.000 | 0.707 | 0.982 |
| `system-parameters` | 0.321 | 0.000 | 0.000 | 0.707 | 0.963 |
| `signature-update` | 0.321 | 0.000 | 0.000 | 0.707 | 0.963 |
| `gateway-wireless-controller` | 0.313 | 0.000 | 0.000 | 0.707 | 0.909 |
| `static-mac-acl` | 0.277 | 0.500 | 0.000 | 0.707 | 0.000 |
| `wgsync` | 0.266 | 0.447 | 0.000 | 0.707 | 0.000 |
| `dynamic-routing` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.397 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<loopback-if>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 8
- Distinct field shapes: 1
- Naming tokens: ['loopback', 'if']
- Top child tags (by occurrence): ['ip-node-type', 'enabled', 'netmask', 'if-property', 'if-num', 'ip', 'secondary-ip-list', 'if-dev-name']
- Value-pattern observations per child field:
    - `enabled`: boolean-numeric
    - `if-dev-name`: free-text
    - `if-num`: boolean-numeric
    - `if-property`: boolean-numeric
    - `ip`: ipv4
    - `ip-node-type`: free-text
    - `netmask`: ipv4
    - `secondary-ip-list`: empty
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `vlan-if` | 0.597 | 0.533 | 0.500 | 0.962 | 1.000 |
| `physical-if` | 0.539 | 0.564 | 0.500 | 0.705 | 1.000 |
| `sslvpn` | 0.348 | 0.000 | 0.000 | 0.793 | 1.000 |
| `multicast-if` | 0.327 | 0.250 | 0.500 | 0.707 | 0.000 |
| `ipsec-action` | 0.266 | 0.102 | 0.000 | 0.745 | 0.392 |
| `botnet-detection` | 0.247 | 0.354 | 0.000 | 0.707 | 0.000 |
| `multicast` | 0.247 | 0.354 | 0.000 | 0.707 | 0.000 |
| `daas-client` | 0.247 | 0.354 | 0.000 | 0.707 | 0.000 |
| `abs-ipsec-action` | 0.241 | 0.125 | 0.000 | 0.865 | 0.000 |
| `ike-policy-group` | 0.237 | 0.158 | 0.000 | 0.820 | 0.000 |

**Placement confidence (top-1 structural):** 0.597 (medium)

<!-- ENGINE-OBSERVATION-END -->

### `<max-age>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['max', 'age']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `stp-enabled` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `bridge-priority` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `aging-time` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `hello-time` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `forward-delay` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `max-sessions` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `max-threads` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `keep-alive-max` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `dpd-max-failure` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `max-link-bandwidth` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.270 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<max-concurrent-logins>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['max', 'concurrent', 'logins']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `dns-ip` | 0.289 | 0.000 | 0.000 | 0.000 | 0.929 |
| `wins-ip` | 0.289 | 0.000 | 0.000 | 0.000 | 0.929 |
| `eap-method` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `addr-mgmt` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `addr-grp-name` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `expiry` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `global-idle-timeout` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `dns-mgmt` | 0.275 | 0.000 | 0.000 | 0.000 | 0.837 |
| `auth-domain` | 0.274 | 0.000 | 0.000 | 0.000 | 0.885 |
| `keep-alive-max` | 0.255 | 0.000 | 0.333 | 0.000 | 0.257 |

**Placement confidence (top-1 structural):** 0.289 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<mgmt-acct-lockout>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 4
- Distinct field shapes: 1
- Naming tokens: ['mgmt', 'acct', 'lockout']
- Top child tags (by occurrence): ['duration', 'enabled', 'failures', 'lockouts']
- Value-pattern observations per child field:
    - `duration`: port
    - `enabled`: boolean-numeric
    - `failures`: port
    - `lockouts`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `lockout` | 0.715 | 1.000 | 0.577 | 1.000 | 0.000 |
| `br-protos` | 0.248 | 0.000 | 0.000 | 0.992 | 0.000 |
| `dos-item` | 0.247 | 0.000 | 0.000 | 0.990 | 0.000 |
| `ctspam` | 0.245 | 0.000 | 0.000 | 0.981 | 0.000 |
| `nat-t-config` | 0.241 | 0.000 | 0.000 | 0.965 | 0.000 |
| `blocked-port-list` | 0.237 | 0.000 | 0.000 | 0.949 | 0.000 |
| `username` | 0.237 | 0.000 | 0.000 | 0.949 | 0.000 |
| `timeout` | 0.237 | 0.000 | 0.000 | 0.949 | 0.000 |
| `uri` | 0.237 | 0.000 | 0.000 | 0.949 | 0.000 |
| `max-length` | 0.237 | 0.000 | 0.000 | 0.949 | 0.000 |

**Placement confidence (top-1 structural):** 0.715 (medium)

<!-- ENGINE-OBSERVATION-END -->

### `<mgmt-multi-rw-session>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['mgmt', 'multi', 'rw', 'session']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `mgmt-user-session-timeout` | 0.383 | 0.000 | 0.500 | 0.000 | 0.889 |
| `hotspot-user-session-timeout` | 0.338 | 0.000 | 0.250 | 0.000 | 0.917 |
| `auth-user-session-timeout` | 0.333 | 0.000 | 0.250 | 0.000 | 0.889 |
| `mgmt-user-idle-timeout` | 0.333 | 0.000 | 0.250 | 0.000 | 0.889 |
| `hotspot-user-idle-timeout` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |
| `hotspot-max-guest-num` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |
| `auto-redirect` | 0.287 | 0.000 | 0.000 | 0.000 | 0.917 |
| `auth-user-timeout` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `redirect-url` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `firebox-user-case-sensitivity` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |

**Placement confidence (top-1 structural):** 0.383 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<min-password-length>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['min', 'password', 'length']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `password` | 0.232 | 0.000 | 0.577 | 0.000 | 0.000 |
| `life-length` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `from-min` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `to-min` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `match-length` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `maximum-length` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `proxy-password` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `ldap-server-password` | 0.217 | 0.000 | 0.333 | 0.000 | 0.000 |
| `auth-key-length` | 0.217 | 0.000 | 0.333 | 0.000 | 0.000 |
| `encryp-key-length` | 0.217 | 0.000 | 0.333 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.232 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<minute>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['minute']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `day` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `hour` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `rp-candidate` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `ccl-name` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `header-value` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `account-id` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `restrict-user-access` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `session-idle-timeout` | 0.227 | 0.000 | 0.000 | 0.000 | 0.516 |
| `agent-ip-list` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |
| `protection-type` | 0.209 | 0.000 | 0.000 | 0.000 | 0.392 |

**Placement confidence (top-1 structural):** 0.250 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<multicast>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['multicast']
- Top child tags (by occurrence): ['enabled']
- Value-pattern observations per child field:
    - `enabled`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `daas-client` | 0.746 | 1.000 | 0.000 | 1.000 | 0.976 |
| `botnet-detection` | 0.741 | 1.000 | 0.000 | 1.000 | 0.942 |
| `multicast-if` | 0.540 | 0.707 | 0.707 | 1.000 | 0.049 |
| `common-logging` | 0.465 | 0.500 | 0.000 | 0.894 | 0.942 |
| `network-discovery` | 0.440 | 0.447 | 0.000 | 0.816 | 0.976 |
| `dns-forwarding` | 0.415 | 0.707 | 0.000 | 1.000 | 0.157 |
| `traffic-flow-conf` | 0.396 | 0.000 | 0.000 | 1.000 | 0.976 |
| `remote-logging` | 0.391 | 0.707 | 0.000 | 1.000 | 0.000 |
| `ntp-conf` | 0.391 | 0.000 | 0.000 | 1.000 | 0.942 |
| `icmp-error-handling` | 0.391 | 0.000 | 0.000 | 1.000 | 0.942 |

**Placement confidence (top-1 structural):** 0.746 (medium)

<!-- ENGINE-OBSERVATION-END -->

### `<network>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['network']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `network-unreachable` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `ip-network-addr` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `ip` | 0.199 | 0.000 | 0.000 | 0.000 | 0.324 |
| `vlan-id` | 0.197 | 0.000 | 0.000 | 0.000 | 0.316 |
| `vif-property` | 0.197 | 0.000 | 0.000 | 0.000 | 0.316 |
| `intra-vlan-inspection` | 0.197 | 0.000 | 0.000 | 0.000 | 0.316 |
| `ip-node-type` | 0.187 | 0.000 | 0.000 | 0.000 | 0.249 |
| `if-num` | 0.186 | 0.000 | 0.000 | 0.000 | 0.239 |
| `if-dev-name` | 0.186 | 0.000 | 0.000 | 0.000 | 0.239 |
| `if-property` | 0.184 | 0.000 | 0.000 | 0.000 | 0.227 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<network-discovery>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 5
- Distinct field shapes: 1
- Naming tokens: ['network', 'discovery']
- Top child tags (by occurrence): ['enabled', 'retention-timeout', 'if-list', 'schedule', 'aging-timeout']
- Value-pattern observations per child field:
    - `aging-timeout`: numeric-int
    - `enabled`: boolean-numeric
    - `if-list`: empty
    - `retention-timeout`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `multicast` | 0.440 | 0.447 | 0.000 | 0.816 | 0.976 |
| `daas-client` | 0.440 | 0.447 | 0.000 | 0.816 | 0.976 |
| `botnet-detection` | 0.435 | 0.447 | 0.000 | 0.816 | 0.942 |
| `common-logging` | 0.414 | 0.224 | 0.000 | 0.913 | 0.942 |
| `vpn-global-setting` | 0.358 | 0.000 | 0.000 | 0.866 | 0.942 |
| `dynamic-routing` | 0.358 | 0.000 | 0.000 | 0.866 | 0.942 |
| `dvcp-client` | 0.357 | 0.124 | 0.000 | 0.764 | 0.942 |
| `radius-sso` | 0.354 | 0.169 | 0.000 | 0.693 | 0.976 |
| `traffic-flow-conf` | 0.351 | 0.000 | 0.000 | 0.816 | 0.976 |
| `ntp-conf` | 0.345 | 0.000 | 0.000 | 0.816 | 0.942 |

**Placement confidence (top-1 structural):** 0.440 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<networking-mode>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['networking', 'mode']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `server-mode` | 0.386 | 0.000 | 0.500 | 0.000 | 0.909 |
| `mode` | 0.373 | 0.000 | 0.707 | 0.000 | 0.547 |
| `key-mode` | 0.298 | 0.000 | 0.500 | 0.000 | 0.318 |
| `remember-connection` | 0.286 | 0.000 | 0.000 | 0.000 | 0.909 |
| `auto-reconnect` | 0.286 | 0.000 | 0.000 | 0.000 | 0.909 |
| `scan-mode` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `line-conn-mode` | 0.247 | 0.000 | 0.408 | 0.000 | 0.101 |
| `full-scan-mode` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `geo-list` | 0.228 | 0.000 | 0.000 | 0.000 | 0.522 |
| `terms` | 0.228 | 0.000 | 0.000 | 0.000 | 0.522 |

**Placement confidence (top-1 structural):** 0.386 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<non-continuous>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['non', 'continuous']
- Top child tags (by occurrence): ['daily', 'interval']
- Value-pattern observations per child field:
    - `daily`: empty
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `non-inet-class` | 0.258 | 0.000 | 0.408 | 0.707 | 0.000 |
| `system-parameters` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `snmp-conf` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `encryption` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `terminal-service` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `traffic-flow-timers` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `gen-cert-id` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `gateway-wireless-controller` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `clientless-vpn` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `profile` | 0.248 | 0.000 | 0.000 | 0.993 | 0.000 |

**Placement confidence (top-1 structural):** 0.258 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<page-title>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['page', 'title']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `title` | 0.322 | 0.000 | 0.707 | 0.000 | 0.204 |
| `custom-header-logo` | 0.281 | 0.000 | 0.000 | 0.000 | 0.875 |
| `custom-background-image` | 0.281 | 0.000 | 0.000 | 0.000 | 0.875 |
| `custom-css` | 0.281 | 0.000 | 0.000 | 0.000 | 0.875 |
| `custom-logo` | 0.262 | 0.000 | 0.000 | 0.000 | 0.746 |
| `session-timeout` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |
| `accounting-client-ip` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `secret` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `group-attr-type` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `exception-list` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |

**Placement confidence (top-1 structural):** 0.322 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<path-cost>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['path', 'cost']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `base-model` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `account-list` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `dest-address` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `mask` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `gateway-ip` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.150 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<peer>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 10
- Distinct field shapes: 1
- Naming tokens: ['peer']
- Top child tags (by occurrence): ['client-to-client', 'keepalive', 'local-routes', 'remote-routes', 'wins', 'redirect-gateway', 'use-firebox-routes', 'dns-mgmt', 'dns', 'pool-list']
- Value-pattern observations per child field:
    - `client-to-client`: boolean-numeric
    - `dns-mgmt`: port
    - `redirect-gateway`: boolean-numeric
    - `remote-routes`: empty
    - `use-firebox-routes`: boolean-numeric
    - `wins`: empty
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `peer-auth` | 0.315 | 0.000 | 0.707 | 0.567 | 0.211 |
| `gateway` | 0.297 | 0.000 | 0.000 | 0.627 | 0.934 |
| `dns-forwarding` | 0.270 | 0.000 | 0.000 | 0.802 | 0.463 |
| `local-cert` | 0.264 | 0.000 | 0.000 | 0.929 | 0.211 |
| `multicast-if` | 0.255 | 0.000 | 0.000 | 0.802 | 0.361 |
| `ras-user-group` | 0.254 | 0.090 | 0.000 | 0.943 | 0.000 |
| `ike-action` | 0.254 | 0.000 | 0.000 | 0.889 | 0.208 |
| `vpn-tunnel-sharing` | 0.248 | 0.000 | 0.000 | 0.802 | 0.318 |
| `ipsec-action` | 0.247 | 0.000 | 0.000 | 0.845 | 0.237 |
| `ike-policy-group` | 0.242 | 0.000 | 0.000 | 0.761 | 0.348 |

**Placement confidence (top-1 structural):** 0.315 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<pm-use-only>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='true'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['pm', 'use', 'only']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `feature-details-list` | 0.265 | 0.000 | 0.000 | 0.000 | 0.770 |
| `cert-list` | 0.265 | 0.000 | 0.000 | 0.000 | 0.770 |
| `global-settings` | 0.234 | 0.000 | 0.000 | 0.000 | 0.667 |
| `use-ldap` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `use-ip` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `use-template` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `use-alias` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `use-cloud-service` | 0.217 | 0.000 | 0.333 | 0.000 | 0.000 |
| `use-firebox-routes` | 0.217 | 0.000 | 0.333 | 0.000 | 0.000 |
| `use-any-for-service` | 0.208 | 0.000 | 0.289 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.265 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<pool>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['pool']
- Top child tags (by occurrence): ['network', 'netmask']
- Value-pattern observations per child field:
    - `netmask`: ipv4
    - `network`: ipv4
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `address-pool` | 0.391 | 0.000 | 0.707 | 1.000 | 0.000 |
| `route` | 0.349 | 0.497 | 0.000 | 1.000 | 0.000 |
| `dns-server-list` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `ip-list` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `resource-addr` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `ip-domain-list` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `route-entry` | 0.200 | 0.000 | 0.000 | 0.802 | 0.000 |
| `primary-server` | 0.177 | 0.000 | 0.000 | 0.707 | 0.000 |
| `local-addr` | 0.177 | 0.000 | 0.000 | 0.707 | 0.000 |
| `remote-addr` | 0.177 | 0.000 | 0.000 | 0.707 | 0.000 |

**Placement confidence (top-1 structural):** 0.391 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<pool-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['pool', 'list']
- Top child tags (by occurrence): ['pool']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `address-pool-list` | 0.163 | 0.000 | 0.816 | 0.000 | 0.000 |
| `pool` | 0.141 | 0.000 | 0.707 | 0.000 | 0.000 |
| `local-routes` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |
| `remote-routes` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |
| `wins` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |
| `redirect-gateway` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |
| `use-firebox-routes` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |
| `client-to-client` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |
| `keepalive` | 0.133 | 0.000 | 0.000 | 0.000 | 0.889 |

**Placement confidence (top-1 structural):** 0.163 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<port-priority>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['port', 'priority']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `port` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `port-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `port-unreachable` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `server-port` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `blocked-port` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `tls-port` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `priority-method` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dest-port` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `proxy-port` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `bridge-priority` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<pptp>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 5
- Distinct field shapes: 1
- Naming tokens: ['pptp']
- Top child tags (by occurrence): ['pptp-mru', 'pptp-mtu', 'pptp-enabled', 'pptp-mppe-encryption-option', 'pptp-ras-user-group']
- Value-pattern observations per child field:
    - `pptp-enabled`: boolean-numeric
    - `pptp-mppe-encryption-option`: boolean-numeric
    - `pptp-mru`: port
    - `pptp-mtu`: port
    - `pptp-ras-user-group`: free-text
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `mss-adjustment` | 0.377 | 0.000 | 0.000 | 0.943 | 0.942 |
| `auth-global-setting` | 0.375 | 0.000 | 0.000 | 0.934 | 0.942 |
| `log-conf` | 0.333 | 0.000 | 0.000 | 0.767 | 0.942 |
| `blocked-ports` | 0.328 | 0.000 | 0.000 | 0.745 | 0.942 |
| `misc-global-setting` | 0.327 | 0.000 | 0.000 | 0.744 | 0.942 |
| `lsd` | 0.327 | 0.000 | 0.000 | 0.743 | 0.942 |
| `single-sign-on` | 0.319 | 0.000 | 0.000 | 0.711 | 0.942 |
| `vpn-global-setting` | 0.318 | 0.000 | 0.000 | 0.707 | 0.942 |
| `multicast` | 0.313 | 0.000 | 0.000 | 0.667 | 0.976 |
| `daas-client` | 0.313 | 0.000 | 0.000 | 0.667 | 0.976 |

**Placement confidence (top-1 structural):** 0.377 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<pptp-enabled>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['pptp', 'enabled']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `pptp-mtu` | 0.362 | 0.000 | 0.500 | 0.000 | 0.750 |
| `pptp-mru` | 0.362 | 0.000 | 0.500 | 0.000 | 0.750 |
| `pptp-mppe-encryption-option` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `pptp-ras-user-group` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `enabled` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `ntp-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `local-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dlp-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dpd-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `quota-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.362 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<pptp-mppe-encryption-option>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['pptp', 'mppe', 'encryption', 'option']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `pptp-enabled` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `pptp-mtu` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `pptp-mru` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `pptp-ras-user-group` | 0.312 | 0.000 | 0.250 | 0.000 | 0.750 |
| `login-option` | 0.221 | 0.000 | 0.354 | 0.000 | 0.000 |
| `client-fallthrough-option` | 0.208 | 0.000 | 0.289 | 0.000 | 0.000 |
| `server-fallthrough-option` | 0.208 | 0.000 | 0.289 | 0.000 | 0.000 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.333 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<pptp-mru>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['pptp', 'mru']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `pptp-enabled` | 0.362 | 0.000 | 0.500 | 0.000 | 0.750 |
| `pptp-mtu` | 0.362 | 0.000 | 0.500 | 0.000 | 0.750 |
| `pptp-mppe-encryption-option` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `pptp-ras-user-group` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `base-model` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.362 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<pptp-mtu>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['pptp', 'mtu']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `pptp-enabled` | 0.362 | 0.000 | 0.500 | 0.000 | 0.750 |
| `pptp-mru` | 0.362 | 0.000 | 0.500 | 0.000 | 0.750 |
| `pptp-mppe-encryption-option` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `pptp-ras-user-group` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `mtu` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `tcp-mtu-probing` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.362 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<pptp-ras-user-group>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['pptp', 'ras', 'user', 'group']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `pptp-enabled` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `pptp-mtu` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `pptp-mru` | 0.333 | 0.000 | 0.354 | 0.000 | 0.750 |
| `pptp-mppe-encryption-option` | 0.312 | 0.000 | 0.250 | 0.000 | 0.750 |
| `ras-user-group-name` | 0.300 | 0.000 | 0.750 | 0.000 | 0.000 |
| `ras-user-list` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `ras-server-group-list` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `user` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dh-group` | 0.221 | 0.000 | 0.354 | 0.000 | 0.000 |
| `user-firewall` | 0.221 | 0.000 | 0.354 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.333 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<probe>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 4
- Distinct field shapes: 1
- Naming tokens: ['probe']
- Top child tags (by occurrence): ['deactivate-count', 'reactivate-count', 'probe-interval', 'if-name']
- Value-pattern observations per child field:
    - `deactivate-count`: port
    - `if-name`: enum-small
    - `probe-interval`: numeric-int
    - `reactivate-count`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `gateway` | 0.247 | 0.258 | 0.000 | 0.783 | 0.000 |
| `app` | 0.226 | 0.000 | 0.000 | 0.904 | 0.000 |
| `message` | 0.217 | 0.000 | 0.000 | 0.866 | 0.000 |
| `dlp-sensor` | 0.208 | 0.000 | 0.000 | 0.833 | 0.000 |
| `blocked-port-list` | 0.204 | 0.000 | 0.000 | 0.816 | 0.000 |
| `username` | 0.204 | 0.000 | 0.000 | 0.816 | 0.000 |
| `timeout` | 0.204 | 0.000 | 0.000 | 0.816 | 0.000 |
| `uri` | 0.204 | 0.000 | 0.000 | 0.816 | 0.000 |
| `max-length` | 0.204 | 0.000 | 0.000 | 0.816 | 0.000 |
| `backlog` | 0.204 | 0.000 | 0.000 | 0.816 | 0.000 |

**Placement confidence (top-1 structural):** 0.247 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<probe-interval>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['probe', 'interval']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `interval` | 0.289 | 0.000 | 0.707 | 0.000 | 0.000 |
| `deactivate-count` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `reactivate-count` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `lease-interval` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `launch-interval` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `auto-interval` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `keepalive-interval` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `if-name` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `probe-list` | 0.234 | 0.000 | 0.500 | 0.000 | 0.000 |
| `keep-alive-interval` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.289 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<proxy-auto-gen>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='true'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['proxy', 'auto', 'gen']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `proxy-referenced` | 0.362 | 0.000 | 0.408 | 0.000 | 0.869 |
| `proxy-name` | 0.343 | 0.000 | 0.408 | 0.000 | 0.745 |
| `proxy-description` | 0.343 | 0.000 | 0.408 | 0.000 | 0.745 |
| `proxy-type-attr` | 0.328 | 0.000 | 0.333 | 0.000 | 0.743 |
| `proxy-type` | 0.289 | 0.000 | 0.408 | 0.000 | 0.383 |
| `diag-log-level` | 0.281 | 0.000 | 0.000 | 0.000 | 0.876 |
| `proxy` | 0.273 | 0.000 | 0.577 | 0.000 | 0.049 |
| `proxy-arp` | 0.257 | 0.000 | 0.408 | 0.000 | 0.169 |
| `auto-reconnect` | 0.249 | 0.000 | 0.408 | 0.000 | 0.114 |
| `auto-start` | 0.247 | 0.000 | 0.408 | 0.000 | 0.099 |

**Placement confidence (top-1 structural):** 0.362 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<pvid-enabled>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['pvid', 'enabled']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `enabled` | 0.294 | 0.000 | 0.707 | 0.000 | 0.017 |
| `ntp-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `local-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dlp-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dpd-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `quota-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `auth-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `apt-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `vod-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `log-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.294 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<radius-sso>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 7
- Distinct field shapes: 1
- Naming tokens: ['radius', 'sso']
- Top child tags (by occurrence): ['accounting-client-ip', 'group-attr-type', 'enabled', 'idle-timeout', 'secret', 'exception-list', 'session-timeout']
- Value-pattern observations per child field:
    - `accounting-client-ip`: empty
    - `enabled`: boolean-numeric
    - `exception-list`: empty
    - `group-attr-type`: port
    - `idle-timeout`: port
    - `secret`: empty
    - `session-timeout`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `single-sign-on` | 0.424 | 0.183 | 0.000 | 0.982 | 0.942 |
| `dxcp-client` | 0.420 | 0.154 | 0.000 | 0.972 | 0.976 |
| `dvcp-client` | 0.405 | 0.105 | 0.000 | 0.972 | 0.942 |
| `ldap` | 0.378 | 0.060 | 0.000 | 0.908 | 0.929 |
| `terminal-service` | 0.374 | 0.252 | 0.000 | 0.728 | 0.942 |
| `common-logging` | 0.369 | 0.189 | 0.000 | 0.759 | 0.942 |
| `dynamic-routing` | 0.356 | 0.000 | 0.000 | 0.857 | 0.942 |
| `network-discovery` | 0.354 | 0.169 | 0.000 | 0.693 | 0.976 |
| `multicast` | 0.343 | 0.378 | 0.000 | 0.485 | 0.976 |
| `daas-client` | 0.343 | 0.378 | 0.000 | 0.485 | 0.976 |

**Placement confidence (top-1 structural):** 0.424 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<reactivate-count>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['reactivate', 'count']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `deactivate-count` | 0.350 | 0.000 | 0.500 | 0.000 | 0.667 |
| `probe-interval` | 0.250 | 0.000 | 0.000 | 0.000 | 0.667 |
| `repeat-count` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `if-name` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `ip` | 0.153 | 0.000 | 0.000 | 0.000 | 0.018 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.350 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<redirect-gateway>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['redirect', 'gateway']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `remote-routes` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `wins` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `use-firebox-routes` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `client-to-client` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `gateway-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `redirect-url` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `redirect-to` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `redirect-imaps` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `redirect-pop3s` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `redirect-smtps` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.283 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<regTimeout>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['regtimeout']
- Top child tags (by occurrence): ['value', 'action']
- Value-pattern observations per child field:
    - `value`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `timeout` | 0.610 | 1.000 | 0.000 | 1.000 | 0.219 |
| `backlog` | 0.600 | 1.000 | 0.000 | 1.000 | 0.000 |
| `max-line-length` | 0.600 | 1.000 | 0.000 | 1.000 | 0.000 |
| `filename` | 0.600 | 1.000 | 0.000 | 1.000 | 0.000 |
| `line` | 0.600 | 1.000 | 0.000 | 1.000 | 0.000 |
| `username` | 0.596 | 1.000 | 0.000 | 1.000 | 0.000 |
| `max-length` | 0.556 | 1.000 | 0.000 | 1.000 | 0.000 |
| `logins` | 0.525 | 0.997 | 0.000 | 0.707 | 0.000 |
| `password` | 0.376 | 0.747 | 0.000 | 0.577 | 0.080 |
| `max-total-length` | 0.350 | 1.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.610 (medium)

<!-- ENGINE-OBSERVATION-END -->

### `<remember-connection>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['remember', 'connection']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `auto-reconnect` | 0.286 | 0.000 | 0.000 | 0.000 | 0.909 |
| `networking-mode` | 0.286 | 0.000 | 0.000 | 0.000 | 0.909 |
| `server-mode` | 0.286 | 0.000 | 0.000 | 0.000 | 0.909 |
| `connection-rate` | 0.273 | 0.000 | 0.500 | 0.000 | 0.156 |
| `connection-rate-alarm` | 0.255 | 0.000 | 0.408 | 0.000 | 0.153 |
| `mode` | 0.232 | 0.000 | 0.000 | 0.000 | 0.547 |
| `connection-string-override` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `geo-list` | 0.228 | 0.000 | 0.000 | 0.000 | 0.522 |
| `terms` | 0.228 | 0.000 | 0.000 | 0.000 | 0.522 |
| `dns-forwarding` | 0.219 | 0.000 | 0.000 | 0.000 | 0.463 |

**Placement confidence (top-1 structural):** 0.286 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<remote-logging>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['remote', 'logging']
- Top child tags (by occurrence): ['remote-logging-list', 'enabled']
- Value-pattern observations per child field:
    - `enabled`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `common-logging` | 0.394 | 0.354 | 0.500 | 0.894 | 0.000 |
| `botnet-detection` | 0.391 | 0.707 | 0.000 | 1.000 | 0.000 |
| `multicast` | 0.391 | 0.707 | 0.000 | 1.000 | 0.000 |
| `daas-client` | 0.391 | 0.707 | 0.000 | 1.000 | 0.000 |
| `multicast-if` | 0.350 | 0.500 | 0.000 | 1.000 | 0.000 |
| `dns-forwarding` | 0.350 | 0.500 | 0.000 | 1.000 | 0.000 |
| `remote-action` | 0.350 | 0.000 | 0.500 | 1.000 | 0.000 |
| `auto-reboot` | 0.308 | 0.354 | 0.000 | 0.949 | 0.000 |
| `ike-policy-group` | 0.300 | 0.316 | 0.000 | 0.949 | 0.000 |
| `geolocation-blocking` | 0.292 | 0.577 | 0.000 | 0.707 | 0.000 |

**Placement confidence (top-1 structural):** 0.394 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<remote-logging-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['remote', 'logging', 'list']
- Top child tags (by occurrence): ['logging-entry']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `geo-action-list` | 0.217 | 0.000 | 0.333 | 0.000 | 1.000 |
| `agent-ip-list` | 0.173 | 0.000 | 0.333 | 0.000 | 0.707 |
| `local-remote-pair-list` | 0.170 | 0.000 | 0.577 | 0.000 | 0.367 |
| `remote-logging` | 0.163 | 0.000 | 0.816 | 0.000 | 0.000 |
| `if-list` | 0.157 | 0.000 | 0.408 | 0.000 | 0.500 |
| `exclude-ip-list` | 0.153 | 0.000 | 0.333 | 0.000 | 0.577 |
| `rp-candidate` | 0.150 | 0.000 | 0.000 | 0.000 | 1.000 |
| `ccl-name` | 0.150 | 0.000 | 0.000 | 0.000 | 1.000 |
| `header-value` | 0.150 | 0.000 | 0.000 | 0.000 | 1.000 |
| `account-id` | 0.150 | 0.000 | 0.000 | 0.000 | 1.000 |

**Placement confidence (top-1 structural):** 0.217 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<remote-routes>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['remote', 'routes']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `use-firebox-routes` | 0.365 | 0.000 | 0.408 | 0.000 | 0.889 |
| `wins` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `redirect-gateway` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `client-to-client` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `remote-enable` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `remote-addr` | 0.234 | 0.000 | 0.500 | 0.000 | 0.000 |
| `local-routes` | 0.233 | 0.000 | 0.500 | 0.000 | 0.889 |
| `use-local-remote-pair` | 0.221 | 0.000 | 0.354 | 0.000 | 0.000 |
| `use-any-for-remote-address` | 0.213 | 0.000 | 0.316 | 0.000 | 0.000 |
| `dns-mgmt` | 0.204 | 0.000 | 0.000 | 0.000 | 0.363 |

**Placement confidence (top-1 structural):** 0.365 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<reneg-datachannel>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['reneg', 'datachannel']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `listen-to` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `compression` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `server-port` | 0.193 | 0.000 | 0.000 | 0.000 | 0.289 |
| `host` | 0.191 | 0.000 | 0.000 | 0.000 | 0.272 |
| `type` | 0.190 | 0.000 | 0.000 | 0.000 | 0.270 |
| `tls-port` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |
| `icmp-type` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |
| `icmp-code` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |
| `start-server-port` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |
| `end-server-port` | 0.185 | 0.000 | 0.000 | 0.000 | 0.236 |

**Placement confidence (top-1 structural):** 0.275 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<require-client-cert>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['require', 'client', 'cert']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `dh` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `hash` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `cipher` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `force-auth-reconnect` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `client-to-client` | 0.253 | 0.000 | 0.516 | 0.000 | 0.000 |
| `client-id` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `ca-cert` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `rsa-cert` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `dsa-cert` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `ec-cert` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.262 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<reserved-address-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['reserved', 'address', 'list']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `server-type` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `backup-server-list` | 0.270 | 0.000 | 0.333 | 0.000 | 0.354 |
| `lease-time` | 0.266 | 0.000 | 0.000 | 0.000 | 0.772 |
| `address` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `wins-server-list` | 0.262 | 0.000 | 0.333 | 0.000 | 0.302 |
| `address-pool-list` | 0.258 | 0.000 | 0.667 | 0.000 | 0.833 |
| `blocked-ip-list` | 0.237 | 0.000 | 0.333 | 0.000 | 0.135 |
| `ddns-service-list` | 0.237 | 0.000 | 0.333 | 0.000 | 0.135 |
| `dns-server-list` | 0.237 | 0.000 | 0.333 | 0.000 | 0.302 |
| `static-arp-list` | 0.236 | 0.000 | 0.333 | 0.000 | 0.131 |

**Placement confidence (top-1 structural):** 0.275 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<restrict-user-access>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['restrict', 'user', 'access']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `rp-candidate` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `ccl-name` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `header-value` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `account-id` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `user-ip-cache-timeout` | 0.291 | 0.000 | 0.289 | 0.000 | 0.555 |
| `session-idle-timeout` | 0.284 | 0.000 | 0.000 | 0.000 | 0.894 |
| `user-access-list` | 0.283 | 0.000 | 0.667 | 0.000 | 0.000 |
| `user` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `agent-ip-list` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |
| `search-user-dn` | 0.255 | 0.000 | 0.333 | 0.000 | 0.258 |

**Placement confidence (top-1 structural):** 0.300 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<retention-timeout>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['retention', 'timeout']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `aging-timeout` | 0.362 | 0.000 | 0.500 | 0.000 | 0.750 |
| `session-idle-timeout` | 0.299 | 0.000 | 0.408 | 0.000 | 0.447 |
| `keepalive-timeout` | 0.281 | 0.000 | 0.500 | 0.000 | 0.204 |
| `session-timeout` | 0.269 | 0.000 | 0.500 | 0.000 | 0.125 |
| `if-list` | 0.262 | 0.000 | 0.000 | 0.000 | 0.750 |
| `user-ip-cache-timeout` | 0.262 | 0.000 | 0.354 | 0.000 | 0.277 |
| `idle-timeout` | 0.259 | 0.000 | 0.500 | 0.000 | 0.059 |
| `icmp-timeout` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `udp-timeout` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `server-timeout` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.362 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<scan>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 34
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['scan']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `strip` | 0.299 | 0.000 | 0.000 | 0.000 | 0.995 |
| `allow` | 0.297 | 0.000 | 0.000 | 0.000 | 0.983 |
| `scan-limit` | 0.295 | 0.000 | 0.707 | 0.000 | 0.024 |
| `replace` | 0.294 | 0.000 | 0.000 | 0.000 | 0.957 |
| `scan-mode` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `anti-scan` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `enabled` | 0.278 | 0.000 | 0.000 | 0.000 | 0.854 |
| `alarm` | 0.272 | 0.000 | 0.000 | 0.000 | 0.815 |
| `deny` | 0.271 | 0.000 | 0.000 | 0.000 | 0.808 |
| `full-scan-mode` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.299 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<search-base>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['search', 'base']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `search-user-dn` | 0.372 | 0.000 | 0.408 | 0.000 | 0.933 |
| `search-user-pwd` | 0.372 | 0.000 | 0.408 | 0.000 | 0.933 |
| `group-attr-name` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-ip-mask` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-dns-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-wins-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-sess-timeout` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-idle-timeout` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `deadtime` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.372 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<search-user-dn>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['search', 'user', 'dn']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `search-user-pwd` | 0.423 | 0.000 | 0.667 | 0.000 | 0.933 |
| `search-base` | 0.372 | 0.000 | 0.408 | 0.000 | 0.933 |
| `group-attr-name` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-ip-mask` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-dns-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-wins-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-sess-timeout` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-idle-timeout` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `deadtime` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.423 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<search-user-pwd>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['search', 'user', 'pwd']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `search-user-dn` | 0.423 | 0.000 | 0.667 | 0.000 | 0.933 |
| `search-base` | 0.372 | 0.000 | 0.408 | 0.000 | 0.933 |
| `group-attr-name` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-ip-mask` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-dns-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-wins-ip` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-sess-timeout` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `attr-name-idle-timeout` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |
| `deadtime` | 0.290 | 0.000 | 0.000 | 0.000 | 0.933 |

**Placement confidence (top-1 structural):** 0.423 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<secret>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['secret']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `accounting-client-ip` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `group-attr-type` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `exception-list` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `session-timeout` | 0.242 | 0.000 | 0.000 | 0.000 | 0.612 |
| `rp-candidate` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |
| `ccl-name` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |
| `header-value` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |
| `account-id` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |
| `restrict-user-access` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |
| `session-idle-timeout` | 0.205 | 0.000 | 0.000 | 0.000 | 0.365 |

**Placement confidence (top-1 structural):** 0.275 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<server-ip>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['server', 'ip']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `attr-name-ip` | 0.356 | 0.000 | 0.408 | 0.000 | 0.826 |
| `attr-name-ip-mask` | 0.345 | 0.000 | 0.354 | 0.000 | 0.826 |
| `attr-name-dns-ip` | 0.345 | 0.000 | 0.354 | 0.000 | 0.826 |
| `attr-name-wins-ip` | 0.345 | 0.000 | 0.354 | 0.000 | 0.826 |
| `ldap-server-ip` | 0.313 | 0.000 | 0.816 | 0.000 | 0.000 |
| `ntp-server-ip` | 0.313 | 0.000 | 0.816 | 0.000 | 0.000 |
| `management-server-ip` | 0.313 | 0.000 | 0.816 | 0.000 | 0.000 |
| `ip` | 0.298 | 0.000 | 0.707 | 0.000 | 0.046 |
| `search-base` | 0.274 | 0.000 | 0.000 | 0.000 | 0.826 |
| `group-attr-name` | 0.274 | 0.000 | 0.000 | 0.000 | 0.826 |

**Placement confidence (top-1 structural):** 0.356 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<server-mode>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['server', 'mode']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `networking-mode` | 0.386 | 0.000 | 0.500 | 0.000 | 0.909 |
| `mode` | 0.373 | 0.000 | 0.707 | 0.000 | 0.547 |
| `key-mode` | 0.298 | 0.000 | 0.500 | 0.000 | 0.318 |
| `remember-connection` | 0.286 | 0.000 | 0.000 | 0.000 | 0.909 |
| `auto-reconnect` | 0.286 | 0.000 | 0.000 | 0.000 | 0.909 |
| `server-ip` | 0.269 | 0.000 | 0.500 | 0.000 | 0.129 |
| `server-port` | 0.250 | 0.000 | 0.500 | 0.000 | 0.001 |
| `scan-mode` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `server-replies` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `server-list` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.386 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<session-timeout>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['session', 'timeout']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `session-idle-timeout` | 0.347 | 0.000 | 0.816 | 0.000 | 0.224 |
| `auth-user-session-timeout` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `mgmt-user-session-timeout` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `hotspot-user-session-timeout` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `aging-timeout` | 0.269 | 0.000 | 0.500 | 0.000 | 0.125 |
| `retention-timeout` | 0.269 | 0.000 | 0.500 | 0.000 | 0.125 |
| `keepalive-timeout` | 0.265 | 0.000 | 0.500 | 0.000 | 0.102 |
| `page-title` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |
| `custom-header-logo` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |
| `custom-background-image` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |

**Placement confidence (top-1 structural):** 0.347 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<sslvpn>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 12
- Distinct field shapes: 2
- Naming tokens: ['sslvpn']
- Top child tags (by occurrence): ['server-mode', 'auth', 'enable', 'property', 'auto-reconnect', 'networking-mode', 'description', 'mode', 'gateway', 'peer']
- Value-pattern observations per child field:
    - `auto-reconnect`: boolean-numeric
    - `description`: empty
    - `enable`: boolean-numeric
    - `mode`: port
    - `name`: free-text
    - `networking-mode`: boolean-numeric
    - `property`: boolean-numeric
    - `remember-connection`: boolean-numeric
    - `server-mode`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `ipsec-action` | 0.445 | 0.292 | 0.000 | 0.911 | 0.392 |
| `ike-action` | 0.410 | 0.402 | 0.000 | 0.933 | 0.000 |
| `policy` | 0.380 | 0.228 | 0.000 | 0.950 | 0.000 |
| `ike-policy-group` | 0.367 | 0.258 | 0.000 | 0.962 | 0.000 |
| `schedule` | 0.366 | 0.312 | 0.000 | 0.793 | 0.000 |
| `physical-if` | 0.366 | 0.000 | 0.000 | 0.864 | 1.000 |
| `interface` | 0.366 | 0.436 | 0.000 | 0.709 | 0.000 |
| `vlan-if` | 0.362 | 0.000 | 0.000 | 0.850 | 1.000 |
| `loopback-if` | 0.348 | 0.000 | 0.000 | 0.793 | 1.000 |
| `dns-forwarding` | 0.346 | 0.000 | 0.000 | 0.961 | 0.000 |

**Placement confidence (top-1 structural):** 0.445 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<sso-exception-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['sso', 'exception', 'list']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `sso-through-bovpn` | 0.342 | 0.000 | 0.333 | 0.000 | 0.833 |
| `exception-list` | 0.338 | 0.000 | 0.816 | 0.000 | 0.167 |
| `sso-agent-ip` | 0.336 | 0.000 | 0.333 | 0.000 | 0.793 |
| `exclude-ip-list` | 0.323 | 0.000 | 0.333 | 0.000 | 0.707 |
| `keepalive-interval` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `keepalive-timeout` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `user-ip-cache-timeout` | 0.269 | 0.000 | 0.000 | 0.000 | 0.793 |
| `ips-signature-exception-list` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `if-list` | 0.262 | 0.000 | 0.408 | 0.000 | 0.204 |
| `agent-ip-list` | 0.260 | 0.000 | 0.333 | 0.000 | 0.289 |

**Placement confidence (top-1 structural):** 0.342 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<sso-through-bovpn>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['sso', 'through', 'bovpn']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `sso-exception-list` | 0.342 | 0.000 | 0.333 | 0.000 | 0.833 |
| `sso-agent-ip` | 0.336 | 0.000 | 0.333 | 0.000 | 0.793 |
| `keepalive-interval` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `keepalive-timeout` | 0.275 | 0.000 | 0.000 | 0.000 | 0.833 |
| `user-ip-cache-timeout` | 0.269 | 0.000 | 0.000 | 0.000 | 0.793 |
| `exclude-ip-list` | 0.256 | 0.000 | 0.000 | 0.000 | 0.707 |
| `ipsec-pass-through` | 0.217 | 0.000 | 0.333 | 0.000 | 0.000 |
| `rp-candidate` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |
| `ccl-name` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |
| `header-value` | 0.211 | 0.000 | 0.000 | 0.000 | 0.408 |

**Placement confidence (top-1 structural):** 0.342 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<start>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['start']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `auto-start` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `start-ip` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `auto-start-tunnel` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `start-server-port` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `using-cpm-profile` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `for-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `xml-purpose` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `base-model` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<start-ip>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['start', 'ip']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `ip` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `start` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `gateway-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `use-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `ip-type` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `ip-mask` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `ip-addr` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `auto-start` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `firebox-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `server-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<stp-enabled>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['stp', 'enabled']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `enabled` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `bridge-priority` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `aging-time` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `hello-time` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `max-age` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `forward-delay` | 0.270 | 0.000 | 0.000 | 0.000 | 0.800 |
| `ntp-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `local-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dlp-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dpd-enabled` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.291 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<stp-port>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['stp', 'port']
- Top child tags (by occurrence): ['port-priority', 'path-cost']
- Value-pattern observations per child field:
    - `path-cost`: boolean-numeric
    - `port-priority`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `external-if` | 0.285 | 0.000 | 0.000 | 1.000 | 0.233 |
| `br-protos` | 0.263 | 0.000 | 0.000 | 0.832 | 0.365 |
| `blocked-port-list` | 0.258 | 0.000 | 0.408 | 0.707 | 0.000 |
| `mss-adjustment` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `trace-item` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `addresses` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `logins` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `dhcp-client` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `auth-global-setting` | 0.248 | 0.000 | 0.000 | 0.990 | 0.000 |
| `nat-t-config` | 0.245 | 0.000 | 0.000 | 0.981 | 0.000 |

**Placement confidence (top-1 structural):** 0.285 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<syslog>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 3
- Distinct field shapes: 1
- Naming tokens: ['syslog']
- Top child tags (by occurrence): ['timestamp', 'serial', 'facility-map-list']
- Value-pattern observations per child field:
    - `serial`: boolean-numeric
    - `timestamp`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `dns-forwarding` | 0.315 | 0.000 | 0.000 | 1.000 | 0.432 |
| `multicast-if` | 0.304 | 0.000 | 0.000 | 1.000 | 0.357 |
| `vpn-tunnel-sharing` | 0.280 | 0.000 | 0.000 | 1.000 | 0.202 |
| `ike-policy-group` | 0.276 | 0.000 | 0.000 | 0.949 | 0.258 |
| `remote-action` | 0.268 | 0.000 | 0.000 | 1.000 | 0.117 |
| `qos-marking` | 0.267 | 0.000 | 0.000 | 1.000 | 0.115 |
| `lsd` | 0.255 | 0.204 | 0.000 | 0.857 | 0.000 |
| `snmp-trap` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `ntp-conf` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |
| `icmp-error-handling` | 0.250 | 0.000 | 0.000 | 1.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.315 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<tcp-mtu-probing>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['tcp', 'mtu', 'probing']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `syn-checking-enable` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `vlan-forward` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `log-in-out-broadcast` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `auto-blocked-duration` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `block-spoof-enabled` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `auto-order-enabled` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `qos-enable` | 0.285 | 0.000 | 0.000 | 0.000 | 0.898 |
| `control-hostout-traffic` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `mtu` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `pptp-mtu` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.285 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<terms>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['terms']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `geo-list` | 0.300 | 0.000 | 0.000 | 0.000 | 1.000 |
| `dns-forwarding` | 0.283 | 0.000 | 0.000 | 0.000 | 0.887 |
| `proxy-arp` | 0.266 | 0.000 | 0.000 | 0.000 | 0.775 |
| `anti-replay-window` | 0.266 | 0.000 | 0.000 | 0.000 | 0.775 |
| `on-off` | 0.266 | 0.000 | 0.000 | 0.000 | 0.775 |
| `proxy-type` | 0.266 | 0.000 | 0.000 | 0.000 | 0.772 |
| `idle-timeout` | 0.261 | 0.000 | 0.000 | 0.000 | 0.740 |
| `algorithm` | 0.258 | 0.000 | 0.000 | 0.000 | 0.721 |
| `mode` | 0.255 | 0.000 | 0.000 | 0.000 | 0.698 |
| `netflow` | 0.254 | 0.000 | 0.000 | 0.000 | 0.691 |

**Placement confidence (top-1 structural):** 0.300 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<threat-correlation>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['threat', 'correlation']
- Top child tags (by occurrence): ['enabled', 'account-id']
- Value-pattern observations per child field:
    - `account-id`: empty
    - `enabled`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `geolocation-blocking` | 0.510 | 0.577 | 0.000 | 1.000 | 0.963 |
| `logon-banner` | 0.397 | 0.000 | 0.000 | 1.000 | 0.982 |
| `clientless-vpn` | 0.324 | 0.000 | 0.000 | 0.707 | 0.982 |
| `system-parameters` | 0.321 | 0.000 | 0.000 | 0.707 | 0.963 |
| `signature-update` | 0.321 | 0.000 | 0.000 | 0.707 | 0.963 |
| `vpn-portal` | 0.321 | 0.000 | 0.000 | 0.693 | 0.982 |
| `botnet-detection` | 0.318 | 0.707 | 0.000 | 0.707 | 0.000 |
| `multicast` | 0.318 | 0.707 | 0.000 | 0.707 | 0.000 |
| `daas-client` | 0.318 | 0.707 | 0.000 | 0.707 | 0.000 |
| `gateway-wireless-controller` | 0.313 | 0.000 | 0.000 | 0.707 | 0.909 |

**Placement confidence (top-1 structural):** 0.510 (medium)

<!-- ENGINE-OBSERVATION-END -->

### `<timestamp>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: leaf value='0'; no nested config

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['timestamp']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `feature-key-url` | 0.190 | 0.000 | 0.000 | 0.000 | 0.267 |
| `rss-url` | 0.190 | 0.000 | 0.000 | 0.000 | 0.267 |
| `staging-url` | 0.190 | 0.000 | 0.000 | 0.000 | 0.267 |
| `rss-check` | 0.190 | 0.000 | 0.000 | 0.000 | 0.267 |
| `feature-key-auto-sync` | 0.190 | 0.000 | 0.000 | 0.000 | 0.267 |
| `serial` | 0.169 | 0.000 | 0.000 | 0.000 | 0.129 |
| `debug` | 0.157 | 0.000 | 0.000 | 0.000 | 0.049 |
| `enable` | 0.150 | 0.000 | 0.000 | 0.000 | 0.003 |
| `product-grade` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |
| `rs-version` | 0.150 | 0.000 | 0.000 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.190 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<title>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['title']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `page-title` | 0.322 | 0.000 | 0.707 | 0.000 | 0.204 |
| `fault_upload` | 0.237 | 0.000 | 0.000 | 0.000 | 0.577 |
| `custom-logo` | 0.202 | 0.000 | 0.000 | 0.000 | 0.348 |
| `feature-key-url` | 0.183 | 0.000 | 0.000 | 0.000 | 0.218 |
| `rss-url` | 0.183 | 0.000 | 0.000 | 0.000 | 0.218 |
| `staging-url` | 0.183 | 0.000 | 0.000 | 0.000 | 0.218 |
| `rss-check` | 0.183 | 0.000 | 0.000 | 0.000 | 0.218 |
| `feature-key-auto-sync` | 0.183 | 0.000 | 0.000 | 0.000 | 0.218 |
| `serial` | 0.182 | 0.000 | 0.000 | 0.000 | 0.211 |
| `custom-header-logo` | 0.181 | 0.000 | 0.000 | 0.000 | 0.204 |

**Placement confidence (top-1 structural):** 0.322 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<traffic-flow-conf>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['traffic', 'flow', 'conf']
- Top child tags (by occurrence): ['flush-connections']
- Value-pattern observations per child field:
    - `flush-connections`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `ntp-conf` | 0.473 | 0.000 | 0.408 | 1.000 | 0.942 |
| `log-conf` | 0.470 | 0.000 | 0.408 | 0.986 | 0.942 |
| `multicast` | 0.396 | 0.000 | 0.000 | 1.000 | 0.976 |
| `daas-client` | 0.396 | 0.000 | 0.000 | 1.000 | 0.976 |
| `icmp-error-handling` | 0.391 | 0.000 | 0.000 | 1.000 | 0.942 |
| `multi-wan` | 0.391 | 0.000 | 0.000 | 1.000 | 0.942 |
| `performance-log` | 0.391 | 0.000 | 0.000 | 1.000 | 0.942 |
| `antivirus` | 0.391 | 0.000 | 0.000 | 1.000 | 0.942 |
| `botnet-detection` | 0.391 | 0.000 | 0.000 | 1.000 | 0.942 |
| `wgsync` | 0.391 | 0.000 | 0.000 | 1.000 | 0.942 |

**Placement confidence (top-1 structural):** 0.473 (low)

<!-- ENGINE-OBSERVATION-END -->

### `<use-firebox-routes>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['use', 'firebox', 'routes']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `remote-routes` | 0.365 | 0.000 | 0.408 | 0.000 | 0.889 |
| `wins` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `redirect-gateway` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `client-to-client` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `use-ldap` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `use-ip` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `use-template` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `use-alias` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `firebox-ip` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `use-cloud-service` | 0.217 | 0.000 | 0.333 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.365 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<user-access-list>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['user', 'access', 'list']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `app-group-list` | 0.292 | 0.000 | 0.333 | 0.000 | 0.500 |
| `ras-user-list` | 0.283 | 0.000 | 0.667 | 0.000 | 0.000 |
| `restrict-user-access` | 0.283 | 0.000 | 0.667 | 0.000 | 0.000 |
| `user` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `muvpn-users-list` | 0.246 | 0.000 | 0.333 | 0.000 | 0.196 |
| `account-list` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `user-firewall` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `user-agent` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `server-list` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |
| `proxy-access` | 0.232 | 0.000 | 0.408 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.292 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<vif-property>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['vif', 'property']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `if-property` | 0.305 | 0.000 | 0.500 | 0.000 | 0.365 |
| `property` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `vlan-id` | 0.285 | 0.000 | 0.000 | 0.000 | 0.900 |
| `intra-vlan-inspection` | 0.285 | 0.000 | 0.000 | 0.000 | 0.900 |
| `ip-node-type` | 0.210 | 0.000 | 0.000 | 0.000 | 0.403 |
| `pvid-enabled` | 0.205 | 0.000 | 0.000 | 0.000 | 0.365 |
| `secondary-ip-list` | 0.205 | 0.000 | 0.000 | 0.000 | 0.365 |
| `vpn-df-bit` | 0.204 | 0.000 | 0.000 | 0.000 | 0.357 |
| `netmask` | 0.203 | 0.000 | 0.000 | 0.000 | 0.354 |
| `ip` | 0.203 | 0.000 | 0.000 | 0.000 | 0.351 |

**Placement confidence (top-1 structural):** 0.305 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<vlan-id>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **enabled** — 🔴 Tier 1 (full triage)
Evidence: leaf value='1'

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['vlan', 'id']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `intra-vlan-inspection` | 0.367 | 0.000 | 0.408 | 0.000 | 0.900 |
| `vif-property` | 0.285 | 0.000 | 0.000 | 0.000 | 0.900 |
| `card-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `client-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `vlan-forward` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `rsa-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `message-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `cat_id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `app_id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `membership-id` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |

**Placement confidence (top-1 structural):** 0.367 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<vlan-if>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 11
- Distinct field shapes: 1
- Naming tokens: ['vlan', 'if']
- Top child tags (by occurrence): ['vif-property', 'member-list', 'ip-node-type', 'vlan-id', 'netmask', 'intra-vlan-inspection', 'if-num', 'dhcp-server', 'ip', 'br-protos']
- Value-pattern observations per child field:
    - `if-dev-name`: free-text
    - `if-num`: boolean-numeric
    - `intra-vlan-inspection`: boolean-numeric
    - `ip`: ipv4
    - `ip-node-type`: free-text
    - `netmask`: ipv4
    - `vif-property`: boolean-numeric
    - `vlan-id`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `loopback-if` | 0.597 | 0.533 | 0.500 | 0.962 | 1.000 |
| `physical-if` | 0.493 | 0.324 | 0.500 | 0.712 | 1.000 |
| `sslvpn` | 0.362 | 0.000 | 0.000 | 0.850 | 1.000 |
| `multicast-if` | 0.304 | 0.000 | 0.500 | 0.816 | 0.000 |
| `ike-policy-group` | 0.253 | 0.135 | 0.000 | 0.904 | 0.000 |
| `ipsec-action` | 0.252 | 0.000 | 0.000 | 0.775 | 0.392 |
| `external-if` | 0.244 | 0.000 | 0.500 | 0.577 | 0.000 |
| `blocked-ports` | 0.228 | 0.000 | 0.000 | 0.913 | 0.000 |
| `medium` | 0.228 | 0.000 | 0.000 | 0.913 | 0.000 |
| `info` | 0.228 | 0.000 | 0.000 | 0.913 | 0.000 |

**Placement confidence (top-1 structural):** 0.597 (medium)

<!-- ENGINE-OBSERVATION-END -->

### `<vpn-portal>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 9
- Distinct field shapes: 1
- Naming tokens: ['vpn', 'portal']
- Top child tags (by occurrence): ['custom-logo', 'custom-header-logo', 'page-title', 'idle-timeout', 'port', 'auth-domain-name-list', 'custom-css', 'custom-background-image', 'session-timeout']
- Value-pattern observations per child field:
    - `custom-background-image`: boolean-numeric
    - `custom-css`: boolean-numeric
    - `custom-header-logo`: boolean-numeric
    - `custom-logo`: boolean-numeric
    - `idle-timeout`: port
    - `page-title`: empty
    - `port`: port
    - `session-timeout`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `logon-banner` | 0.354 | 0.167 | 0.000 | 0.693 | 0.982 |
| `threat-correlation` | 0.321 | 0.000 | 0.000 | 0.693 | 0.982 |
| `geolocation-blocking` | 0.318 | 0.000 | 0.000 | 0.693 | 0.963 |
| `clientless-vpn` | 0.296 | 0.000 | 0.500 | 0.196 | 0.982 |
| `signature-update` | 0.282 | 0.000 | 0.000 | 0.549 | 0.963 |
| `vpn-global-setting` | 0.278 | 0.000 | 0.408 | 0.786 | 0.000 |
| `vpn-tunnel-sharing` | 0.278 | 0.000 | 0.408 | 0.784 | 0.000 |
| `radius-sso` | 0.253 | 0.252 | 0.000 | 0.809 | 0.000 |
| `alarm-action` | 0.248 | 0.000 | 0.000 | 0.990 | 0.000 |
| `auth-global-setting` | 0.247 | 0.000 | 0.000 | 0.989 | 0.000 |

**Placement confidence (top-1 structural):** 0.354 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<wins>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['wins']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `wins-ip` | 0.305 | 0.000 | 0.707 | 0.000 | 0.089 |
| `remote-routes` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `redirect-gateway` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `use-firebox-routes` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `client-to-client` | 0.283 | 0.000 | 0.000 | 0.000 | 0.889 |
| `wins-server-list` | 0.265 | 0.000 | 0.577 | 0.000 | 0.000 |
| `attr-name-wins-ip` | 0.250 | 0.000 | 0.500 | 0.000 | 0.000 |
| `dns-mgmt` | 0.204 | 0.000 | 0.000 | 0.000 | 0.363 |
| `eap-method` | 0.165 | 0.000 | 0.000 | 0.000 | 0.099 |
| `addr-mgmt` | 0.165 | 0.000 | 0.000 | 0.000 | 0.099 |

**Placement confidence (top-1 structural):** 0.305 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<wins-ip>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **disabled** — 🟢 Tier 3 (auto-skip OK)
Evidence: empty container (no children, no text values)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 0
- Distinct field shapes: 1
- Naming tokens: ['wins', 'ip']
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `dns-ip` | 0.389 | 0.000 | 0.500 | 0.000 | 0.929 |
| `wins` | 0.305 | 0.000 | 0.707 | 0.000 | 0.089 |
| `ip` | 0.294 | 0.000 | 0.707 | 0.000 | 0.016 |
| `attr-name-wins-ip` | 0.291 | 0.000 | 0.707 | 0.000 | 0.000 |
| `max-concurrent-logins` | 0.289 | 0.000 | 0.000 | 0.000 | 0.929 |
| `eap-method` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `addr-mgmt` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `addr-grp-name` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `expiry` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |
| `global-idle-timeout` | 0.287 | 0.000 | 0.000 | 0.000 | 0.916 |

**Placement confidence (top-1 structural):** 0.389 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

### `<youtube-for-school>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)
Evidence: no enabled/disabled signal detected

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['youtube', 'for', 'school']
- Top child tags (by occurrence): ['header-value', 'enabled']
- Value-pattern observations per child field:
    - `enabled`: boolean-text
    - `header-value`: empty
- Observed in corpus files: ['phase1_merge_then_reuse']

**Top structurally-similar existing elements (engine observations):**

Note: these are STRUCTURAL similarity scores. They indicate which existing elements share child tags, value patterns, naming tokens, etc. They do NOT indicate semantic kinship. Operator must declare semantic relationships separately, with citations.

| Existing element | Aggregate | Children | Naming | Values | Siblings |
|---|---|---|---|---|---|
| `authentication` | 0.318 | 0.707 | 0.000 | 0.707 | 0.000 |
| `acl` | 0.302 | 0.535 | 0.000 | 0.707 | 0.121 |
| `starttls` | 0.275 | 0.500 | 0.000 | 0.500 | 0.333 |
| `terminal-service` | 0.271 | 0.471 | 0.000 | 0.707 | 0.000 |
| `errors` | 0.270 | 0.000 | 0.000 | 1.000 | 0.136 |
| `non-inet-class` | 0.270 | 0.000 | 0.000 | 1.000 | 0.136 |
| `recursion` | 0.270 | 0.000 | 0.000 | 1.000 | 0.136 |
| `filter` | 0.267 | 0.078 | 0.000 | 0.949 | 0.097 |
| `apop` | 0.267 | 0.000 | 0.000 | 1.000 | 0.111 |
| `capa` | 0.267 | 0.000 | 0.000 | 1.000 | 0.111 |

**Placement confidence (top-1 structural):** 0.318 (below threshold — operator must classify manually)

<!-- ENGINE-OBSERVATION-END -->

## Category 4 — New Value Patterns

Count: 35

### `<abs-policy>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 16
- Distinct child element tags: 15
- Distinct field shapes: 2
- Naming tokens: ['abs', 'policy']
- Top child tags (by occurrence): ['reject-action', 'type', 'policy-list', 'to-alias-list', 'policy-nat', 'enabled', 'from-alias-list', 'service', 'description', 'traffic-type']
- Value-pattern observations per child field:
    - `app-action`: free-text
    - `description`: enum-large
    - `enabled`: boolean-text
    - `firewall`: enum-small
    - `name`: enum-large
    - `policy-nat`: empty
    - `property`: boolean-numeric
    - `reject-action`: free-text
    - `service`: enum-large
    - `traffic-type`: boolean-numeric
    - `type`: free-text
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: description
- `observed_pattern`: enum-large
- `previously_known_pattern`: empty

<!-- ENGINE-OBSERVATION-END -->

### `<abs-policy>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 16
- Distinct child element tags: 15
- Distinct field shapes: 2
- Naming tokens: ['abs', 'policy']
- Top child tags (by occurrence): ['reject-action', 'type', 'policy-list', 'to-alias-list', 'policy-nat', 'enabled', 'from-alias-list', 'service', 'description', 'traffic-type']
- Value-pattern observations per child field:
    - `app-action`: free-text
    - `description`: enum-large
    - `enabled`: boolean-text
    - `firewall`: enum-small
    - `name`: enum-large
    - `policy-nat`: empty
    - `property`: boolean-numeric
    - `reject-action`: free-text
    - `service`: enum-large
    - `traffic-type`: boolean-numeric
    - `type`: free-text
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: reject-action
- `observed_pattern`: free-text
- `previously_known_pattern`: enum-small

<!-- ENGINE-OBSERVATION-END -->

### `<address-group>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 10
- Distinct child element tags: 4
- Distinct field shapes: 2
- Naming tokens: ['address', 'group']
- Top child tags (by occurrence): ['description', 'property', 'name', 'addr-group-member']
- Value-pattern observations per child field:
    - `description`: enum-small
    - `name`: enum-large
    - `property`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: name
- `observed_pattern`: enum-large
- `previously_known_pattern`: free-text

<!-- ENGINE-OBSERVATION-END -->

### `<alias>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 119
- Distinct child element tags: 4
- Distinct field shapes: 2
- Naming tokens: ['alias']
- Top child tags (by occurrence): ['alias-member-list', 'description', 'property', 'name']
- Value-pattern observations per child field:
    - `description`: enum-large
    - `name`: free-text
    - `property`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: name
- `observed_pattern`: free-text
- `previously_known_pattern`: enum-large

<!-- ENGINE-OBSERVATION-END -->

### `<alias-member>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 68
- Distinct child element tags: 5
- Distinct field shapes: 2
- Naming tokens: ['alias', 'member']
- Top child tags (by occurrence): ['type', 'alias-name', 'interface', 'address', 'user']
- Value-pattern observations per child field:
    - `address`: enum-large
    - `alias-name`: enum-small
    - `interface`: enum-large
    - `type`: port
    - `user`: enum-small
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: address
- `observed_pattern`: enum-large
- `previously_known_pattern`: enum-small

<!-- ENGINE-OBSERVATION-END -->

### `<anti-virus>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 22
- Distinct child element tags: 7
- Distinct field shapes: 2
- Naming tokens: ['anti', 'virus']
- Top child tags (by occurrence): ['buffer-size', 'scan-limit', 'enabled', 'error', 'virus-found', 'too-large', 'encrypted']
- Value-pattern observations per child field:
    - `buffer-size`: numeric-int
    - `enabled`: enum-small
    - `scan-limit`: numeric-int
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: enabled
- `observed_pattern`: enum-small
- `previously_known_pattern`: boolean-text

<!-- ENGINE-OBSERVATION-END -->

### `<anti-virus>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 22
- Distinct child element tags: 7
- Distinct field shapes: 2
- Naming tokens: ['anti', 'virus']
- Top child tags (by occurrence): ['buffer-size', 'scan-limit', 'enabled', 'error', 'virus-found', 'too-large', 'encrypted']
- Value-pattern observations per child field:
    - `buffer-size`: numeric-int
    - `enabled`: enum-small
    - `scan-limit`: numeric-int
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: scan-limit
- `observed_pattern`: numeric-int
- `previously_known_pattern`: enum-small

<!-- ENGINE-OBSERVATION-END -->

### `<app>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 35
- Distinct child element tags: 4
- Distinct field shapes: 3
- Naming tokens: ['app']
- Top child tags (by occurrence): ['cat_id', 'name', 'app_id', 'beh_id']
- Value-pattern observations per child field:
    - `app_id`: port
    - `beh_id`: port
    - `cat_id`: port
    - `name`: enum-large
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: name
- `observed_pattern`: enum-large
- `previously_known_pattern`: enum-small

<!-- ENGINE-OBSERVATION-END -->

### `<auth-domain>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 4
- Distinct child element tags: 6
- Distinct field shapes: 3
- Naming tokens: ['auth', 'domain']
- Top child tags (by occurrence): ['type', 'description', 'property', 'name', 'firebox', 'ldap']
- Value-pattern observations per child field:
    - `description`: enum-small
    - `name`: enum-small
    - `property`: port
    - `type`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: name
- `observed_pattern`: enum-small
- `previously_known_pattern`: free-text

<!-- ENGINE-OBSERVATION-END -->

### `<auth-domain>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 4
- Distinct child element tags: 6
- Distinct field shapes: 3
- Naming tokens: ['auth', 'domain']
- Top child tags (by occurrence): ['type', 'description', 'property', 'name', 'firebox', 'ldap']
- Value-pattern observations per child field:
    - `description`: enum-small
    - `name`: enum-small
    - `property`: port
    - `type`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: description
- `observed_pattern`: enum-small
- `previously_known_pattern`: free-text

<!-- ENGINE-OBSERVATION-END -->

### `<block>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 6
- Distinct child element tags: 4
- Distinct field shapes: 2
- Naming tokens: ['block']
- Top child tags (by occurrence): ['enable', 'threshold', 'log', 'alarm']
- Value-pattern observations per child field:
    - `alarm`: boolean-numeric
    - `enable`: enum-small
    - `log`: boolean-text
    - `threshold`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: enable
- `observed_pattern`: enum-small
- `previously_known_pattern`: boolean-text

<!-- ENGINE-OBSERVATION-END -->

### `<block>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 6
- Distinct child element tags: 4
- Distinct field shapes: 2
- Naming tokens: ['block']
- Top child tags (by occurrence): ['enable', 'threshold', 'log', 'alarm']
- Value-pattern observations per child field:
    - `alarm`: boolean-numeric
    - `enable`: enum-small
    - `log`: boolean-text
    - `threshold`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: alarm
- `observed_pattern`: boolean-numeric
- `previously_known_pattern`: free-text

<!-- ENGINE-OBSERVATION-END -->

### `<bypass>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 15
- Distinct child element tags: 4
- Distinct field shapes: 2
- Naming tokens: ['bypass']
- Top child tags (by occurrence): ['enable', 'threshold', 'log', 'alarm']
- Value-pattern observations per child field:
    - `alarm`: boolean-numeric
    - `enable`: enum-small
    - `log`: boolean-text
    - `threshold`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: enable
- `observed_pattern`: enum-small
- `previously_known_pattern`: boolean-text

<!-- ENGINE-OBSERVATION-END -->

### `<content-checking>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 10
- Distinct child element tags: 7
- Distinct field shapes: 3
- Naming tokens: ['content', 'checking']
- Top child tags (by occurrence): ['file-patterns', 'content-types', 'autodetect', 'binhex', 'uuencode', 'deny-message', 'messages']
- Value-pattern observations per child field:
    - `autodetect`: boolean-text
    - `binhex`: enum-small
    - `deny-message`: enum-small
    - `uuencode`: enum-small
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: deny-message
- `observed_pattern`: enum-small
- `previously_known_pattern`: free-text

<!-- ENGINE-OBSERVATION-END -->

### `<ctspam>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 9
- Distinct field shapes: 1
- Naming tokens: ['ctspam']
- Top child tags (by occurrence): ['connection-string', 'cache-size', 'connection-string-override', 'vod-max-scan-file-size', 'spam-threshold', 'max-scan-file-size', 'max-threads', 'vod-threshold', 'vod-activated']
- Value-pattern observations per child field:
    - `cache-size`: port
    - `connection-string-override`: empty
    - `max-scan-file-size`: numeric-int
    - `max-threads`: port
    - `spam-threshold`: port
    - `vod-activated`: boolean-numeric
    - `vod-max-scan-file-size`: numeric-int
    - `vod-threshold`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: max-scan-file-size
- `observed_pattern`: numeric-int
- `previously_known_pattern`: port

<!-- ENGINE-OBSERVATION-END -->

### `<ctspam>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 9
- Distinct field shapes: 1
- Naming tokens: ['ctspam']
- Top child tags (by occurrence): ['connection-string', 'cache-size', 'connection-string-override', 'vod-max-scan-file-size', 'spam-threshold', 'max-scan-file-size', 'max-threads', 'vod-threshold', 'vod-activated']
- Value-pattern observations per child field:
    - `cache-size`: port
    - `connection-string-override`: empty
    - `max-scan-file-size`: numeric-int
    - `max-threads`: port
    - `spam-threshold`: port
    - `vod-activated`: boolean-numeric
    - `vod-max-scan-file-size`: numeric-int
    - `vod-threshold`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: vod-max-scan-file-size
- `observed_pattern`: numeric-int
- `previously_known_pattern`: port

<!-- ENGINE-OBSERVATION-END -->

### `<exception-ip>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 4
- Distinct field shapes: 1
- Naming tokens: ['exception', 'ip']
- Top child tags (by occurrence): ['ip-type', 'reason', 'description', 'domain']
- Value-pattern observations per child field:
    - `description`: free-text
    - `domain`: free-text
    - `ip-type`: port
    - `reason`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: domain
- `observed_pattern`: free-text
- `previously_known_pattern`: enum-large

<!-- ENGINE-OBSERVATION-END -->

### `<exception-ip>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 4
- Distinct field shapes: 1
- Naming tokens: ['exception', 'ip']
- Top child tags (by occurrence): ['ip-type', 'reason', 'description', 'domain']
- Value-pattern observations per child field:
    - `description`: free-text
    - `domain`: free-text
    - `ip-type`: port
    - `reason`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: description
- `observed_pattern`: free-text
- `previously_known_pattern`: enum-large

<!-- ENGINE-OBSERVATION-END -->

### `<high>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 3
- Distinct field shapes: 1
- Naming tokens: ['high']
- Top child tags (by occurrence): ['log', 'action', 'alarm']
- Value-pattern observations per child field:
    - `action`: free-text
    - `alarm`: free-text
    - `log`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: alarm
- `observed_pattern`: free-text
- `previously_known_pattern`: enum-small

<!-- ENGINE-OBSERVATION-END -->

### `<interface>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 44
- Distinct child element tags: 5
- Distinct field shapes: 4
- Naming tokens: ['interface']
- Top child tags (by occurrence): ['dns-forwarding', 'property', 'name', 'description', 'if-item-list']
- Value-pattern observations per child field:
    - `description`: enum-large
    - `dns-forwarding`: boolean-numeric
    - `name`: enum-large
    - `property`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: description
- `observed_pattern`: enum-large
- `previously_known_pattern`: enum-small

<!-- ENGINE-OBSERVATION-END -->

### `<interface>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 44
- Distinct child element tags: 5
- Distinct field shapes: 4
- Naming tokens: ['interface']
- Top child tags (by occurrence): ['dns-forwarding', 'property', 'name', 'description', 'if-item-list']
- Value-pattern observations per child field:
    - `description`: enum-large
    - `dns-forwarding`: boolean-numeric
    - `name`: enum-large
    - `property`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: property
- `observed_pattern`: boolean-numeric
- `previously_known_pattern`: port

<!-- ENGINE-OBSERVATION-END -->

### `<low>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 3
- Distinct field shapes: 1
- Naming tokens: ['low']
- Top child tags (by occurrence): ['log', 'action', 'alarm']
- Value-pattern observations per child field:
    - `action`: free-text
    - `alarm`: boolean-numeric
    - `log`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: action
- `observed_pattern`: free-text
- `previously_known_pattern`: enum-small

<!-- ENGINE-OBSERVATION-END -->

### `<member>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 190
- Distinct child element tags: 29
- Distinct field shapes: 10
- Naming tokens: ['member']
- Top child tags (by occurrence): ['type', 'protocol', 'server-port', 'auth-algm', 'encryp-key-length', 'encryp-algm', 'time-unit', 'auth-key-length', 'life-length', 'lifetime']
- Value-pattern observations per child field:
    - `auth-algm`: boolean-numeric
    - `auth-key-length`: boolean-numeric
    - `day-of-week`: port
    - `encryp-algm`: port
    - `encryp-key-length`: port
    - `end-server-port`: port
    - `from-hour`: port
    - `from-min`: boolean-numeric
    - `host-ip-addr`: ipv4
    - `icmp-code`: port
    - `icmp-type`: port
    - `if-dev-name`: free-text
    - `if-num`: port
    - `ip-mask`: ipv4
    - `ip-network-addr`: ipv4
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: auth-algm
- `observed_pattern`: boolean-numeric
- `previously_known_pattern`: port

<!-- ENGINE-OBSERVATION-END -->

### `<messages>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 4
- Distinct child element tags: 1
- Distinct field shapes: 1
- Naming tokens: ['messages']
- Top child tags (by occurrence): ['deny']
- Value-pattern observations per child field:
    - `deny`: enum-small
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: deny
- `observed_pattern`: enum-small
- `previously_known_pattern`: free-text

<!-- ENGINE-OBSERVATION-END -->

### `<mss-adjustment>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['mss', 'adjustment']
- Top child tags (by occurrence): ['mss-adjustment-type', 'mss-maximum-limit']
- Value-pattern observations per child field:
    - `mss-adjustment-type`: port
    - `mss-maximum-limit`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: mss-adjustment-type
- `observed_pattern`: port
- `previously_known_pattern`: boolean-numeric

<!-- ENGINE-OBSERVATION-END -->

### `<multi-wan>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 5
- Distinct field shapes: 1
- Naming tokens: ['multi', 'wan']
- Top child tags (by occurrence): ['failback-grace-period', 'udp-sticky-timer', 'others-sticky-timer', 'tcp-sticky-timer', 'algorithm']
- Value-pattern observations per child field:
    - `algorithm`: port
    - `failback-grace-period`: boolean-numeric
    - `others-sticky-timer`: boolean-numeric
    - `tcp-sticky-timer`: boolean-numeric
    - `udp-sticky-timer`: boolean-numeric
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: algorithm
- `observed_pattern`: port
- `previously_known_pattern`: boolean-numeric

<!-- ENGINE-OBSERVATION-END -->

### `<nat>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 18
- Distinct child element tags: 6
- Distinct field shapes: 2
- Naming tokens: ['nat']
- Top child tags (by occurrence): ['proxy-arp', 'type', 'property', 'description', 'algorithm', 'name']
- Value-pattern observations per child field:
    - `algorithm`: boolean-numeric
    - `description`: free-text
    - `name`: free-text
    - `property`: port
    - `proxy-arp`: boolean-numeric
    - `type`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: name
- `observed_pattern`: free-text
- `previously_known_pattern`: enum-small

<!-- ENGINE-OBSERVATION-END -->

### `<nat>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 18
- Distinct child element tags: 6
- Distinct field shapes: 2
- Naming tokens: ['nat']
- Top child tags (by occurrence): ['proxy-arp', 'type', 'property', 'description', 'algorithm', 'name']
- Value-pattern observations per child field:
    - `algorithm`: boolean-numeric
    - `description`: free-text
    - `name`: free-text
    - `property`: port
    - `proxy-arp`: boolean-numeric
    - `type`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: description
- `observed_pattern`: free-text
- `previously_known_pattern`: enum-small

<!-- ENGINE-OBSERVATION-END -->

### `<policy>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 33
- Distinct child element tags: 31
- Distinct field shapes: 5
- Naming tokens: ['policy']
- Top child tags (by occurrence): ['enable', 'global-1to1-nat', 'ips-monitor-enabled', 'policy-sticky-timer', 'firewall', 'using-global-sticky-setting', 'reject-action', 'proxy', 'geo-action', 'user-firewall']
- Value-pattern observations per child field:
    - `alarm`: empty
    - `app-action`: free-text
    - `connection-rate`: boolean-numeric
    - `connection-rate-alarm`: empty
    - `description`: enum-large
    - `enable`: boolean-numeric
    - `firewall`: boolean-numeric
    - `geo-action`: free-text
    - `global-1to1-nat`: boolean-numeric
    - `global-dnat`: boolean-numeric
    - `idle-timeout`: boolean-numeric
    - `ips-monitor-enabled`: boolean-numeric
    - `log`: boolean-numeric
    - `log-for-report`: boolean-numeric
    - `name`: enum-large
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: description
- `observed_pattern`: enum-large
- `previously_known_pattern`: empty

<!-- ENGINE-OBSERVATION-END -->

### `<ras-user-group>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 15
- Distinct field shapes: 1
- Naming tokens: ['ras', 'user', 'group']
- Top child tags (by occurrence): ['global-idle-timeout', 'domain-name', 'wins-ip', 'version', 'expiry', 'auth-domain', 'dns-ip', 'description', 'eap-method', 'dns-mgmt']
- Value-pattern observations per child field:
    - `addr-grp-name`: free-text
    - `addr-mgmt`: boolean-numeric
    - `auth-domain`: free-text
    - `description`: empty
    - `dns-ip`: empty
    - `dns-mgmt`: boolean-numeric
    - `domain-name`: empty
    - `eap-method`: boolean-numeric
    - `expiry`: port
    - `global-idle-timeout`: port
    - `max-concurrent-logins`: boolean-numeric
    - `name`: free-text
    - `property`: port
    - `version`: boolean-numeric
    - `wins-ip`: empty
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: property
- `observed_pattern`: port
- `previously_known_pattern`: boolean-numeric

<!-- ENGINE-OBSERVATION-END -->

### `<ras-user-group>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 15
- Distinct field shapes: 1
- Naming tokens: ['ras', 'user', 'group']
- Top child tags (by occurrence): ['global-idle-timeout', 'domain-name', 'wins-ip', 'version', 'expiry', 'auth-domain', 'dns-ip', 'description', 'eap-method', 'dns-mgmt']
- Value-pattern observations per child field:
    - `addr-grp-name`: free-text
    - `addr-mgmt`: boolean-numeric
    - `auth-domain`: free-text
    - `description`: empty
    - `dns-ip`: empty
    - `dns-mgmt`: boolean-numeric
    - `domain-name`: empty
    - `eap-method`: boolean-numeric
    - `expiry`: port
    - `global-idle-timeout`: port
    - `max-concurrent-logins`: boolean-numeric
    - `name`: free-text
    - `property`: port
    - `version`: boolean-numeric
    - `wins-ip`: empty
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: version
- `observed_pattern`: boolean-numeric
- `previously_known_pattern`: port

<!-- ENGINE-OBSERVATION-END -->

### `<ras-user-group>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 15
- Distinct field shapes: 1
- Naming tokens: ['ras', 'user', 'group']
- Top child tags (by occurrence): ['global-idle-timeout', 'domain-name', 'wins-ip', 'version', 'expiry', 'auth-domain', 'dns-ip', 'description', 'eap-method', 'dns-mgmt']
- Value-pattern observations per child field:
    - `addr-grp-name`: free-text
    - `addr-mgmt`: boolean-numeric
    - `auth-domain`: free-text
    - `description`: empty
    - `dns-ip`: empty
    - `dns-mgmt`: boolean-numeric
    - `domain-name`: empty
    - `eap-method`: boolean-numeric
    - `expiry`: port
    - `global-idle-timeout`: port
    - `max-concurrent-logins`: boolean-numeric
    - `name`: free-text
    - `property`: port
    - `version`: boolean-numeric
    - `wins-ip`: empty
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: auth-domain
- `observed_pattern`: free-text
- `previously_known_pattern`: empty

<!-- ENGINE-OBSERVATION-END -->

### `<rule>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1835
- Distinct child element tags: 14
- Distinct field shapes: 18
- Naming tokens: ['rule']
- Top child tags (by occurrence): ['log', 'allow', 'name', 'pattern', 'string', 'value', 'enabled', 'strip', 'deny', 'scan']
- Value-pattern observations per child field:
    - `allow`: empty
    - `deny`: empty
    - `enabled`: boolean-text
    - `log`: enum-small
    - `name`: free-text
    - `pattern`: free-text
    - `recipient`: free-text
    - `regexp`: enum-small
    - `replace`: empty
    - `scan`: empty
    - `sender`: enum-small
    - `string`: free-text
    - `strip`: empty
    - `value`: port
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: enabled
- `observed_pattern`: boolean-text
- `previously_known_pattern`: enum-small

<!-- ENGINE-OBSERVATION-END -->

### `<terminal-service>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 1
- Distinct child element tags: 2
- Distinct field shapes: 1
- Naming tokens: ['terminal', 'service']
- Top child tags (by occurrence): ['enabled', 'session-idle-timeout']
- Value-pattern observations per child field:
    - `enabled`: boolean-numeric
    - `session-idle-timeout`: empty
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: enabled
- `observed_pattern`: boolean-numeric
- `previously_known_pattern`: empty

<!-- ENGINE-OBSERVATION-END -->

### `<webblocker>`

Source corpus entry: `phase1_merge_then_reuse`
Engine enabled-status: **unknown** — 🔴 Tier 1 (full triage)

<!-- ENGINE-OBSERVATION-BEGIN -->

**Structural facts (engine observations):**

- Instance count: 2
- Distinct child element tags: 11
- Distinct field shapes: 1
- Naming tokens: ['webblocker']
- Top child tags (by occurrence): ['cache-size', 'exceptions', 'categories', 'server-timeout-action', 'server-bypass-action', 'override', 'use-cloud-service', 'server-bypass', 'server-timeout', 'license-bypass']
- Value-pattern observations per child field:
    - `cache-size`: port
    - `license-bypass`: boolean-text
    - `server-bypass`: boolean-text
    - `server-list`: empty
    - `server-timeout`: port
    - `use-cloud-service`: boolean-text
- Observed in corpus files: ['phase1_merge_then_reuse']

**Engine-observed details:**

- `field`: server-bypass
- `observed_pattern`: boolean-text
- `previously_known_pattern`: enum-small

<!-- ENGINE-OBSERVATION-END -->
