# OPERATOR INTERVENTION REQUIRED

Source: phase1_merge_then_reuse
Test fixture for Phase 1 auto-reuse verification.

---

## Surface 1: `<Botnet>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

- Element tag: `Botnet`
- Test fixture for Phase 1 auto-reuse verification.

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

<!-- OPERATOR-AUTHORED-BEGIN -->

[X] **Q1: What does this element do?** (one sentence)

    Answer: Test-fixture surface for Phase 1 auto-reuse regression test.

    Source: https://example.com/docs/phase1-auto-reuse-test-fixture

[X] **Q2: Surface category from the toolkit's taxonomy?**

    Answer: administrative

    Source: Test fixture, declared category for regression test isolation.

[X] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    Answer: None — test fixture only.

    Source: Test fixture declaration.

[X] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: None — test fixture for regression testing only.

    Source: Test fixture declaration.

<!-- OPERATOR-AUTHORED-END -->
