# OPERATOR INTERVENTION REQUIRED

Generated: 2026-05-05T13:36:03.522615
Source: `TEMPLATE_FW`

---

## Critical: translation is BLOCKED for the surfaces below

The schema-learner identified element types in this source that are not yet in the existing schema. The engine has produced STRUCTURAL OBSERVATIONS about each one. **NO TRANSLATION CAN OCCUR** for any of them until the operator answers the research questions below with documented citations.

This is intentional. Silent incompleteness produces broken configurations at customer sites. The toolkit refuses to translate what no-one has researched.

---

## Surface 1: `<Botnet>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `Botnet`
- Naming tokens: ['botnet']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `IPS`: 0.276
  - `GAV`: 0.276
  - `IAV`: 0.276
  - `Engine`: 0.276
  - `DLP`: 0.275

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<Botnet>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 2: `<DLP>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `DLP`
- Naming tokens: ['dlp']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `dlp-enabled`: 0.291
  - `IPS`: 0.276
  - `GAV`: 0.276
  - `IAV`: 0.276
  - `Engine`: 0.276

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<DLP>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 3: `<Geolocation>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `Geolocation`
- Naming tokens: ['geolocation']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `IPS`: 0.276
  - `GAV`: 0.276
  - `IAV`: 0.276
  - `Engine`: 0.276
  - `DLP`: 0.275

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<Geolocation>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 4: `<account-id>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `account-id`
- Naming tokens: ['account', 'id']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `client-id`: 0.308
  - `rp-candidate`: 0.300
  - `ccl-name`: 0.300
  - `header-value`: 0.300
  - `restrict-user-access`: 0.300

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<account-id>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 5: `<accounting-client-ip>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `accounting-client-ip`
- Naming tokens: ['accounting', 'client', 'ip']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `ip`: 0.279
  - `secret`: 0.275
  - `group-attr-type`: 0.275
  - `exception-list`: 0.275
  - `agent-ip-list`: 0.260

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<accounting-client-ip>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 6: `<address-pool>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `address-pool`
- Naming tokens: ['address', 'pool']
- Instance count in source: 1
- Distinct child element tags observed: 2
- Child tags: `start-ip`, `end-ip`
- Value-pattern observations:
    - `end-ip`: ipv4
    - `start-ip`: ipv4

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `pool`: 0.391
  - `route`: 0.250
  - `dns-server-list`: 0.250
  - `ip-list`: 0.250
  - `resource-addr`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<address-pool>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 7: `<address-pool-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `address-pool-list`
- Naming tokens: ['address', 'pool', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `address-pool`

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `reserved-address-list`: 0.258
  - `address-pool`: 0.163
  - `pool-list`: 0.163
  - `address-group-list`: 0.133
  - `server-type`: 0.125

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<address-pool-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 8: `<aging-time>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `aging-time`
- Naming tokens: ['aging', 'time']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `hello-time`: 0.370
  - `time`: 0.291
  - `stp-enabled`: 0.270
  - `bridge-priority`: 0.270
  - `max-age`: 0.270

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<aging-time>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 9: `<aging-timeout>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `aging-timeout`
- Naming tokens: ['aging', 'timeout']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `retention-timeout`: 0.362
  - `session-idle-timeout`: 0.299
  - `keepalive-timeout`: 0.281
  - `session-timeout`: 0.269
  - `if-list`: 0.262

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<aging-timeout>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 10: `<app-group-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `app-group-list`
- Naming tokens: ['app', 'group', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `user-access-list`: 0.292
  - `ras-server-group-list`: 0.265
  - `muvpn-users-list`: 0.246
  - `account-list`: 0.232
  - `dh-group`: 0.232

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<app-group-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 11: `<attr-name-dns-ip>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `attr-name-dns-ip`
- Naming tokens: ['attr', 'name', 'dns', 'ip']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `attr-name-ip`: 0.463
  - `attr-name-ip-mask`: 0.440
  - `attr-name-wins-ip`: 0.440
  - `group-attr-name`: 0.405
  - `attr-name-sess-timeout`: 0.390

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<attr-name-dns-ip>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 12: `<attr-name-idle-timeout>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `attr-name-idle-timeout`
- Naming tokens: ['attr', 'name', 'idle', 'timeout']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `attr-name-sess-timeout`: 0.440
  - `group-attr-name`: 0.405
  - `attr-name-ip`: 0.405
  - `attr-name-ip-mask`: 0.390
  - `attr-name-dns-ip`: 0.390

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<attr-name-idle-timeout>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 13: `<attr-name-ip>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `attr-name-ip`
- Naming tokens: ['attr', 'name', 'ip']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `attr-name-ip-mask`: 0.463
  - `attr-name-dns-ip`: 0.463
  - `attr-name-wins-ip`: 0.463
  - `group-attr-name`: 0.423
  - `attr-name-sess-timeout`: 0.405

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<attr-name-ip>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 14: `<attr-name-ip-mask>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `attr-name-ip-mask`
- Naming tokens: ['attr', 'name', 'ip', 'mask']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `attr-name-ip`: 0.463
  - `attr-name-dns-ip`: 0.440
  - `attr-name-wins-ip`: 0.440
  - `group-attr-name`: 0.405
  - `attr-name-sess-timeout`: 0.390

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<attr-name-ip-mask>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 15: `<attr-name-sess-timeout>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `attr-name-sess-timeout`
- Naming tokens: ['attr', 'name', 'sess', 'timeout']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `attr-name-idle-timeout`: 0.440
  - `group-attr-name`: 0.405
  - `attr-name-ip`: 0.405
  - `attr-name-ip-mask`: 0.390
  - `attr-name-dns-ip`: 0.390

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<attr-name-sess-timeout>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 16: `<attr-name-wins-ip>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `attr-name-wins-ip`
- Naming tokens: ['attr', 'name', 'wins', 'ip']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `attr-name-ip`: 0.463
  - `attr-name-ip-mask`: 0.440
  - `attr-name-dns-ip`: 0.440
  - `group-attr-name`: 0.405
  - `attr-name-sess-timeout`: 0.390

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<attr-name-wins-ip>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 17: `<auth-domain-name-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `auth-domain-name-list`
- Naming tokens: ['auth', 'domain', 'name', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `name`
- Value-pattern observations:
    - `name`: enum-small

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `auth-group`: 0.326
  - `tls-profile`: 0.318
  - `ntp-server-list`: 0.308
  - `dlp-sensor`: 0.271
  - `user-group`: 0.269

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<auth-domain-name-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 18: `<auto-reboot>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `auto-reboot`
- Naming tokens: ['auto', 'reboot']
- Instance count in source: 1
- Distinct child element tags observed: 4
- Child tags: `enabled`, `day`, `minute`, `hour`
- Value-pattern observations:
    - `day`: port
    - `enabled`: boolean-numeric
    - `hour`: boolean-numeric
    - `minute`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `botnet-detection`: 0.337
  - `multicast`: 0.337
  - `daas-client`: 0.337
  - `multicast-if`: 0.308
  - `dns-forwarding`: 0.308

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<auto-reboot>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 19: `<auto-reconnect>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `auto-reconnect`
- Naming tokens: ['auto', 'reconnect']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `remember-connection`: 0.286
  - `networking-mode`: 0.286
  - `server-mode`: 0.286
  - `auto-start`: 0.282
  - `auto-negotiation`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<auto-reconnect>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 20: `<auto-redirect>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `auto-redirect`
- Naming tokens: ['auto', 'redirect']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `redirect-url`: 0.383
  - `mgmt-multi-rw-session`: 0.287
  - `hotspot-user-idle-timeout`: 0.287
  - `hotspot-user-session-timeout`: 0.287
  - `hotspot-max-guest-num`: 0.287

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<auto-redirect>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 21: `<beh_id>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `beh_id`
- Naming tokens: ['beh', 'id']
- Instance count in source: 33
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `cat_id`: 0.353
  - `app_id`: 0.352
  - `override-id-list`: 0.318
  - `card-id`: 0.250
  - `client-id`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<beh_id>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 22: `<br-protos>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `br-protos`
- Naming tokens: ['br', 'protos']
- Instance count in source: 1
- Distinct child element tags observed: 6
- Child tags: `aging-time`, `hello-time`, `bridge-priority`, `stp-enabled`, `forward-delay`, `max-age`
- Value-pattern observations:
    - `aging-time`: port
    - `bridge-priority`: port
    - `forward-delay`: port
    - `hello-time`: port
    - `max-age`: port
    - `stp-enabled`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `stp-port`: 0.263
  - `external-if`: 0.253
  - `mgmt-acct-lockout`: 0.248
  - `lockout`: 0.248
  - `blocked-port-list`: 0.245

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<br-protos>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 23: `<bridge-priority>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `bridge-priority`
- Naming tokens: ['bridge', 'priority']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `stp-enabled`: 0.270
  - `aging-time`: 0.270
  - `hello-time`: 0.270
  - `max-age`: 0.270
  - `forward-delay`: 0.270

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<bridge-priority>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 24: `<cipher>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `cipher`
- Naming tokens: ['cipher']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `dh`: 0.262
  - `hash`: 0.262
  - `force-auth-reconnect`: 0.262
  - `require-client-cert`: 0.262
  - `product-grade`: 0.150

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<cipher>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 25: `<client-to-client>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `client-to-client`
- Naming tokens: ['client', 'to', 'client']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `remote-routes`: 0.283
  - `wins`: 0.283
  - `redirect-gateway`: 0.283
  - `use-firebox-routes`: 0.283
  - `client-id`: 0.276

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<client-to-client>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 26: `<clientless-vpn>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `clientless-vpn`
- Naming tokens: ['clientless', 'vpn']
- Instance count in source: 1
- Distinct child element tags observed: 3
- Child tags: `settings`, `app-group-list`, `user-access-list`
- Value-pattern observations:
    - `app-group-list`: empty
    - `user-access-list`: empty

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `system-parameters`: 0.394
  - `gateway-wireless-controller`: 0.386
  - `signature-update`: 0.344
  - `logon-banner`: 0.324
  - `threat-correlation`: 0.324

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<clientless-vpn>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 27: `<compat-version>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `compat-version`
- Naming tokens: ['compat', 'version']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `rs-version`: 0.250
  - `for-version`: 0.250
  - `snmp-version`: 0.250
  - `view`: 0.245
  - `snmp-trap-version`: 0.232

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<compat-version>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 28: `<compression>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `compression`
- Naming tokens: ['compression']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `listen-to`: 0.275
  - `reneg-datachannel`: 0.275
  - `server-port`: 0.193
  - `host`: 0.191
  - `type`: 0.190

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<compression>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 29: `<config-change-log-enable>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `config-change-log-enable`
- Naming tokens: ['config', 'change', 'log', 'enable']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `traffic-log-enable`: 0.398
  - `event-log-level`: 0.341
  - `ike-decryp-pkt-trace`: 0.283
  - `debug-level`: 0.283
  - `local-enabled`: 0.283

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<config-change-log-enable>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 30: `<control-hostout-traffic>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `control-hostout-traffic`
- Naming tokens: ['control', 'hostout', 'traffic']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `syn-checking-enable`: 0.285
  - `vlan-forward`: 0.285
  - `log-in-out-broadcast`: 0.285
  - `auto-blocked-duration`: 0.285
  - `block-spoof-enabled`: 0.285

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<control-hostout-traffic>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 31: `<custom-background-image>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `custom-background-image`
- Naming tokens: ['custom', 'background', 'image']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `custom-css`: 0.363
  - `custom-header-logo`: 0.348
  - `custom-logo`: 0.344
  - `page-title`: 0.281
  - `session-timeout`: 0.256

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<custom-background-image>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 32: `<custom-css>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `custom-css`
- Naming tokens: ['custom', 'css']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `custom-header-logo`: 0.363
  - `custom-background-image`: 0.363
  - `custom-logo`: 0.362
  - `page-title`: 0.281
  - `session-timeout`: 0.256

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<custom-css>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 33: `<custom-header-logo>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `custom-header-logo`
- Naming tokens: ['custom', 'header', 'logo']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `custom-logo`: 0.425
  - `custom-css`: 0.363
  - `custom-background-image`: 0.348
  - `page-title`: 0.281
  - `session-timeout`: 0.256

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<custom-header-logo>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 34: `<custom-logo>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `custom-logo`
- Naming tokens: ['custom', 'logo']
- Instance count in source: 2
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `custom-header-logo`: 0.425
  - `custom-css`: 0.362
  - `custom-background-image`: 0.344
  - `page-title`: 0.262
  - `session-timeout`: 0.240

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<custom-logo>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 35: `<daas-client>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `daas-client`
- Naming tokens: ['daas', 'client']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `enabled`
- Value-pattern observations:
    - `enabled`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `multicast`: 0.746
  - `botnet-detection`: 0.741
  - `common-logging`: 0.465
  - `network-discovery`: 0.440
  - `dvcp-client`: 0.430

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<daas-client>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 36: `<daily>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `daily`
- Naming tokens: ['daily']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `op`: 0.188
  - `severity`: 0.152
  - `email-enable`: 0.152
  - `email-addr`: 0.152
  - `email-subject`: 0.152

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<daily>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 37: `<day>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `day`
- Naming tokens: ['day']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `day-of-week`: 0.265
  - `hour`: 0.250
  - `minute`: 0.250
  - `rp-candidate`: 0.237
  - `ccl-name`: 0.237

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<day>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 38: `<deactivate-count>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `deactivate-count`
- Naming tokens: ['deactivate', 'count']
- Instance count in source: 2
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `reactivate-count`: 0.350
  - `probe-interval`: 0.250
  - `repeat-count`: 0.250
  - `if-name`: 0.237
  - `ip`: 0.153

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<deactivate-count>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 39: `<deadtime>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `deadtime`
- Naming tokens: ['deadtime']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `search-base`: 0.290
  - `group-attr-name`: 0.290
  - `attr-name-ip`: 0.290
  - `attr-name-ip-mask`: 0.290
  - `attr-name-dns-ip`: 0.290

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<deadtime>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 40: `<device-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `device-list`
- Naming tokens: ['device', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `account-list`: 0.394
  - `l2tp-list`: 0.386
  - `hotspot-list`: 0.386
  - `probe-list`: 0.379
  - `traffic-mgmt-list`: 0.376

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<device-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 41: `<dh>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `dh`
- Naming tokens: ['dh']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `dh-group`: 0.291
  - `hash`: 0.262
  - `cipher`: 0.262
  - `force-auth-reconnect`: 0.262
  - `require-client-cert`: 0.262

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<dh>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 42: `<dlp-custom-rule>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `dlp-custom-rule`
- Naming tokens: ['dlp', 'custom', 'rule']
- Instance count in source: 1
- Distinct child element tags observed: 4
- Child tags: `name`, `description`, `terms`, `property`
- Value-pattern observations:
    - `description`: free-text
    - `name`: free-text
    - `property`: boolean-numeric
    - `terms`: empty

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `user-group`: 0.399
  - `https-exception-override`: 0.360
  - `geo-action`: 0.358
  - `auth-domain`: 0.354
  - `rule`: 0.353

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<dlp-custom-rule>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 43: `<dlp-custom-rule-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `dlp-custom-rule-list`
- Naming tokens: ['dlp', 'custom', 'rule', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `dlp-custom-rule`

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `dlp-sensor-list`: 0.252
  - `device-list`: 0.218
  - `account-list`: 0.215
  - `service-list`: 0.215
  - `nat-list`: 0.215

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<dlp-custom-rule-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 44: `<dns-domain>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `dns-domain`
- Naming tokens: ['dns', 'domain']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `domain-name-list`: 0.382
  - `domain`: 0.291
  - `dns-entry`: 0.250
  - `dns-mgmt`: 0.250
  - `dns-ip`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<dns-domain>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 45: `<dns-ip>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `dns-ip`
- Naming tokens: ['dns', 'ip']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `wins-ip`: 0.389
  - `dns-mgmt`: 0.375
  - `dns-forwarding`: 0.311
  - `ip`: 0.294
  - `attr-name-dns-ip`: 0.291

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<dns-ip>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 46: `<duration>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `duration`
- Naming tokens: ['duration']
- Instance count in source: 2
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `auto-blocked-duration`: 0.265
  - `failures`: 0.250
  - `lockouts`: 0.250
  - `rp-candidate`: 0.237
  - `ccl-name`: 0.237

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<duration>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 47: `<dxcp-client>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `dxcp-client`
- Naming tokens: ['dxcp', 'client']
- Instance count in source: 1
- Distinct child element tags observed: 6
- Child tags: `enabled`, `client-id`, `server-port`, `password`, `health-report-interval`, `server-list`
- Value-pattern observations:
    - `client-id`: empty
    - `enabled`: boolean-numeric
    - `health-report-interval`: port
    - `password`: empty
    - `server-list`: empty
    - `server-port`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `dvcp-client`: 0.541
  - `single-sign-on`: 0.423
  - `radius-sso`: 0.420
  - `ldap`: 0.398
  - `terminal-service`: 0.396

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<dxcp-client>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 48: `<end-ip>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `end-ip`
- Naming tokens: ['end', 'ip']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `ip`: 0.291
  - `gateway-ip`: 0.250
  - `use-ip`: 0.250
  - `ip-type`: 0.250
  - `ip-mask`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<end-ip>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 49: `<exception-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `exception-list`
- Naming tokens: ['exception', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `sso-exception-list`: 0.338
  - `ips-signature-exception-list`: 0.291
  - `if-list`: 0.281
  - `accounting-client-ip`: 0.275
  - `secret`: 0.275

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<exception-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 50: `<facility-map>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `facility-map`
- Naming tokens: ['facility', 'map']
- Instance count in source: 5
- Distinct child element tags observed: 2
- Child tags: `log-facility`, `log-type`
- Value-pattern observations:
    - `log-facility`: port
    - `log-type`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `blocked-port-list`: 0.250
  - `username`: 0.250
  - `timeout`: 0.250
  - `uri`: 0.250
  - `max-length`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<facility-map>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 51: `<facility-map-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `facility-map-list`
- Naming tokens: ['facility', 'map', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `facility-map`

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `facility-map`: 0.163

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<facility-map-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 52: `<failures>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `failures`
- Naming tokens: ['failures']
- Instance count in source: 2
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `lockouts`: 0.250
  - `duration`: 0.250
  - `rp-candidate`: 0.237
  - `ccl-name`: 0.237
  - `header-value`: 0.237

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<failures>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 53: `<fault_upload>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `fault_upload`
- Naming tokens: ['fault', 'upload']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `title`: 0.237
  - `feature-key-url`: 0.207
  - `rss-url`: 0.207
  - `staging-url`: 0.207
  - `rss-check`: 0.207

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<fault_upload>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 54: `<feedback>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `feedback`
- Naming tokens: ['feedback']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `product-grade`: 0.150
  - `rs-version`: 0.150
  - `using-cpm-profile`: 0.150
  - `for-version`: 0.150
  - `xml-purpose`: 0.150

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<feedback>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 55: `<firebox>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `firebox`
- Naming tokens: ['firebox']
- Instance count in source: 1
- Distinct child element tags observed: 2
- Child tags: `lockout`, `min-password-length`
- Value-pattern observations:
    - `min-password-length`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `nat-t-config`: 0.292
  - `gateway`: 0.271
  - `protocol`: 0.262
  - `ctspam`: 0.262
  - `blocked-port-list`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<firebox>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 56: `<flush-connections>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `flush-connections`
- Naming tokens: ['flush', 'connections']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `product-grade`: 0.150
  - `rs-version`: 0.150
  - `using-cpm-profile`: 0.150
  - `for-version`: 0.150
  - `xml-purpose`: 0.150

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<flush-connections>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 57: `<force-auth-reconnect>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `force-auth-reconnect`
- Naming tokens: ['force', 'auth', 'reconnect']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `dh`: 0.262
  - `hash`: 0.262
  - `cipher`: 0.262
  - `require-client-cert`: 0.262
  - `auth-algm`: 0.232

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<force-auth-reconnect>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 58: `<forward-delay>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `forward-delay`
- Naming tokens: ['forward', 'delay']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `stp-enabled`: 0.270
  - `bridge-priority`: 0.270
  - `aging-time`: 0.270
  - `hello-time`: 0.270
  - `max-age`: 0.270

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<forward-delay>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 59: `<gateway>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `gateway`
- Naming tokens: ['gateway']
- Instance count in source: 3
- Distinct child element tags observed: 9
- Child tags: `if-name`, `ip`, `port`, `compression`, `reneg-datachannel`, `mtu`, `ip-domain-list`, `protocol`, `listen-to`
- Value-pattern observations:
    - `compression`: boolean-numeric
    - `if-name`: enum-small
    - `ip`: empty
    - `listen-to`: empty
    - `mtu`: port
    - `port`: port
    - `protocol`: port
    - `reneg-datachannel`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `peer`: 0.297
  - `quarantine`: 0.280
  - `firebox`: 0.271
  - `nat-t-config`: 0.264
  - `radius-conf`: 0.264

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<gateway>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 60: `<gateway-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `gateway-list`
- Naming tokens: ['gateway', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `gateway`

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `geo-list`: 0.230
  - `alias-member-list`: 0.211
  - `gateway`: 0.200
  - `block-list`: 0.197
  - `if-item-list`: 0.190

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<gateway-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 61: `<group-attr-name>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `group-attr-name`
- Naming tokens: ['group', 'attr', 'name']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `attr-name-ip`: 0.423
  - `attr-name-ip-mask`: 0.405
  - `attr-name-dns-ip`: 0.405
  - `attr-name-wins-ip`: 0.405
  - `attr-name-sess-timeout`: 0.405

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<group-attr-name>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 62: `<group-attr-type>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `group-attr-type`
- Naming tokens: ['group', 'attr', 'type']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `group-attr-name`: 0.299
  - `proxy-type-attr`: 0.283
  - `accounting-client-ip`: 0.275
  - `secret`: 0.275
  - `exception-list`: 0.275

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<group-attr-type>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 63: `<hash>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `hash`
- Naming tokens: ['hash']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `dh`: 0.262
  - `cipher`: 0.262
  - `force-auth-reconnect`: 0.262
  - `require-client-cert`: 0.262
  - `product-grade`: 0.150

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<hash>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 64: `<header-value>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `header-value`
- Naming tokens: ['header', 'value']
- Instance count in source: 2
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `rp-candidate`: 0.300
  - `ccl-name`: 0.300
  - `account-id`: 0.300
  - `restrict-user-access`: 0.300
  - `value`: 0.291

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<header-value>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 65: `<health-report-interval>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `health-report-interval`
- Naming tokens: ['health', 'report', 'interval']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `lease-interval`: 0.290
  - `interval`: 0.263
  - `keepalive-interval`: 0.259
  - `keep-alive-interval`: 0.234
  - `launch-interval`: 0.232

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<health-report-interval>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 66: `<hello-time>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `hello-time`
- Naming tokens: ['hello', 'time']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `aging-time`: 0.370
  - `time`: 0.291
  - `stp-enabled`: 0.270
  - `bridge-priority`: 0.270
  - `max-age`: 0.270

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<hello-time>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 67: `<hotspot-max-guest-num>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `hotspot-max-guest-num`
- Naming tokens: ['hotspot', 'max', 'guest', 'num']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `hotspot-user-idle-timeout`: 0.338
  - `hotspot-user-session-timeout`: 0.338
  - `mgmt-multi-rw-session`: 0.287
  - `auto-redirect`: 0.287
  - `auth-user-timeout`: 0.283

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<hotspot-max-guest-num>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 68: `<hotspot-user-idle-timeout>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `hotspot-user-idle-timeout`
- Naming tokens: ['hotspot', 'user', 'idle', 'timeout']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `hotspot-user-session-timeout`: 0.438
  - `mgmt-user-idle-timeout`: 0.433
  - `auth-user-timeout`: 0.399
  - `auth-user-session-timeout`: 0.383
  - `mgmt-user-session-timeout`: 0.383

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<hotspot-user-idle-timeout>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 69: `<hotspot-user-session-timeout>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `hotspot-user-session-timeout`
- Naming tokens: ['hotspot', 'user', 'session', 'timeout']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `hotspot-user-idle-timeout`: 0.438
  - `auth-user-session-timeout`: 0.433
  - `mgmt-user-session-timeout`: 0.433
  - `auth-user-timeout`: 0.399
  - `mgmt-user-idle-timeout`: 0.383

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<hotspot-user-session-timeout>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 70: `<hour>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `hour`
- Naming tokens: ['hour']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `from-hour`: 0.291
  - `to-hour`: 0.291
  - `day`: 0.250
  - `minute`: 0.250
  - `rp-candidate`: 0.237

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<hour>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 71: `<if-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `if-list`
- Naming tokens: ['if', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `agent-ip-list`: 0.285
  - `exception-list`: 0.281
  - `exclude-ip-list`: 0.275
  - `if-property`: 0.267
  - `if-num`: 0.267

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<if-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 72: `<if-name>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `if-name`
- Naming tokens: ['if', 'name']
- Instance count in source: 4
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `if-dev-name`: 0.331
  - `name`: 0.291
  - `if-num`: 0.268
  - `if-property`: 0.267
  - `system-name`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<if-name>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 73: `<intra-vlan-inspection>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `intra-vlan-inspection`
- Naming tokens: ['intra', 'vlan', 'inspection']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `vlan-id`: 0.367
  - `intra-inspection`: 0.365
  - `vif-property`: 0.285
  - `vlan-forward`: 0.232
  - `ip-node-type`: 0.210

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<intra-vlan-inspection>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 74: `<ip-domain>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `ip-domain`
- Naming tokens: ['ip', 'domain']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `domain`: 0.291
  - `ip`: 0.291
  - `gateway-ip`: 0.250
  - `use-ip`: 0.250
  - `ip-type`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<ip-domain>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 75: `<ip-domain-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `ip-domain-list`
- Naming tokens: ['ip', 'domain', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `ip-domain`
- Value-pattern observations:
    - `ip-domain`: ipv4

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `ip-list`: 0.413
  - `dns-server-list`: 0.317
  - `route`: 0.250
  - `resource-addr`: 0.250
  - `address-pool`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<ip-domain-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 76: `<ip-node-type>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `ip-node-type`
- Naming tokens: ['ip', 'node', 'type']
- Instance count in source: 9
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `ip`: 0.407
  - `secondary-ip-list`: 0.360
  - `ip-type`: 0.313
  - `default-gateway`: 0.297
  - `auto-negotiation`: 0.294

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<ip-node-type>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 77: `<keepalive>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `keepalive`
- Naming tokens: ['keepalive']
- Instance count in source: 1
- Distinct child element tags observed: 2
- Child tags: `timeout`, `interval`
- Value-pattern observations:
    - `interval`: port
    - `timeout`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `protocol`: 0.258
  - `blocked-port-list`: 0.250
  - `username`: 0.250
  - `timeout`: 0.250
  - `uri`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<keepalive>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 78: `<keepalive-interval>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `keepalive-interval`
- Naming tokens: ['keepalive', 'interval']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `keepalive-timeout`: 0.375
  - `interval`: 0.289
  - `sso-through-bovpn`: 0.275
  - `sso-exception-list`: 0.275
  - `sso-agent-ip`: 0.269

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<keepalive-interval>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 79: `<keepalive-timeout>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `keepalive-timeout`
- Naming tokens: ['keepalive', 'timeout']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `keepalive-interval`: 0.375
  - `user-ip-cache-timeout`: 0.340
  - `session-idle-timeout`: 0.286
  - `aging-timeout`: 0.281
  - `retention-timeout`: 0.281

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<keepalive-timeout>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 80: `<listen-to>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `listen-to`
- Naming tokens: ['listen', 'to']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `compression`: 0.275
  - `reneg-datachannel`: 0.275
  - `to-hour`: 0.250
  - `to-min`: 0.250
  - `redirect-to`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<listen-to>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 81: `<load-balance>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `load-balance`
- Naming tokens: ['load', 'balance']
- Instance count in source: 1
- Distinct child element tags observed: 5
- Child tags: `name`, `description`, `property`, `gateway-list`, `algorithm`
- Value-pattern observations:
    - `algorithm`: port
    - `description`: empty
    - `name`: free-text
    - `property`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `user-group`: 0.363
  - `https-exception-override`: 0.339
  - `geo-action`: 0.338
  - `dlp-custom-rule`: 0.338
  - `auth-domain`: 0.335

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<load-balance>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 82: `<local-routes>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `local-routes`
- Naming tokens: ['local', 'routes']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `route`

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `remote-routes`: 0.233
  - `use-firebox-routes`: 0.215
  - `pool-list`: 0.133
  - `wins`: 0.133
  - `redirect-gateway`: 0.133

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<local-routes>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 83: `<lockout>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `lockout`
- Naming tokens: ['lockout']
- Instance count in source: 1
- Distinct child element tags observed: 4
- Child tags: `enabled`, `lockouts`, `duration`, `failures`
- Value-pattern observations:
    - `duration`: port
    - `enabled`: boolean-numeric
    - `failures`: port
    - `lockouts`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `mgmt-acct-lockout`: 0.715
  - `br-protos`: 0.248
  - `dos-item`: 0.247
  - `ctspam`: 0.245
  - `nat-t-config`: 0.241

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<lockout>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 84: `<lockouts>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `lockouts`
- Naming tokens: ['lockouts']
- Instance count in source: 2
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `failures`: 0.250
  - `duration`: 0.250
  - `rp-candidate`: 0.237
  - `ccl-name`: 0.237
  - `header-value`: 0.237

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<lockouts>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 85: `<log-deny>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `log-deny`
- Naming tokens: ['log', 'deny']
- Instance count in source: 4
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `deny`: 0.291
  - `log`: 0.291
  - `log-clean`: 0.250
  - `deny-message`: 0.250
  - `log-enabled`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<log-deny>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 86: `<log-facility>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `log-facility`
- Naming tokens: ['log', 'facility']
- Instance count in source: 5
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `log`: 0.291
  - `log-clean`: 0.250
  - `log-enabled`: 0.250
  - `log-type`: 0.250
  - `log-deny`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<log-facility>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 87: `<log-type>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `log-type`
- Naming tokens: ['log', 'type']
- Instance count in source: 5
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `type`: 0.291
  - `log`: 0.291
  - `port-type`: 0.250
  - `dos-type`: 0.250
  - `trace-type`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<log-type>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 88: `<logging-entry>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `logging-entry`
- Naming tokens: ['logging', 'entry']
- Instance count in source: 1
- Distinct child element tags observed: 6
- Child tags: `description`, `format`, `property`, `server-port`, `syslog`, `server-ip`
- Value-pattern observations:
    - `description`: empty
    - `format`: boolean-numeric
    - `property`: boolean-numeric
    - `server-ip`: ipv4
    - `server-port`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `common-logging`: 0.311
  - `remote-logging`: 0.289
  - `route-entry`: 0.277
  - `ike-action`: 0.267
  - `ipsec-proposal`: 0.266

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<logging-entry>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 89: `<login-id-attr>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `login-id-attr`
- Naming tokens: ['login', 'id', 'attr']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `group-attr-name`: 0.357
  - `attr-name-ip`: 0.357
  - `attr-name-ip-mask`: 0.348
  - `attr-name-dns-ip`: 0.348
  - `attr-name-wins-ip`: 0.348

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<login-id-attr>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 90: `<login-limit>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `login-limit`
- Naming tokens: ['login', 'limit']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `scan-limit`: 0.250
  - `login-option`: 0.250
  - `mss-maximum-limit`: 0.232
  - `login-id-attr`: 0.232
  - `product-grade`: 0.150

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<login-limit>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 91: `<login-option>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `login-option`
- Naming tokens: ['login', 'option']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `login-limit`: 0.250
  - `client-fallthrough-option`: 0.232
  - `server-fallthrough-option`: 0.232
  - `login-id-attr`: 0.232
  - `pptp-mppe-encryption-option`: 0.221

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<login-option>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 92: `<login-setting>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `login-setting`
- Naming tokens: ['login', 'setting']
- Instance count in source: 1
- Distinct child element tags observed: 2
- Child tags: `login-limit`, `login-option`
- Value-pattern observations:
    - `login-limit`: boolean-numeric
    - `login-option`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `misc-global-setting`: 0.330
  - `vpn-global-setting`: 0.317
  - `auth-global-setting`: 0.257
  - `snmp-trap`: 0.250
  - `ntp-conf`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<login-setting>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 93: `<logon-banner>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `logon-banner`
- Naming tokens: ['logon', 'banner']
- Instance count in source: 1
- Distinct child element tags observed: 4
- Child tags: `enable`, `message`, `title`, `custom-logo`
- Value-pattern observations:
    - `custom-logo`: boolean-numeric
    - `enable`: boolean-numeric
    - `message`: empty
    - `title`: empty

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `threat-correlation`: 0.397
  - `geolocation-blocking`: 0.394
  - `vpn-portal`: 0.354
  - `clientless-vpn`: 0.324
  - `system-parameters`: 0.321

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<logon-banner>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 94: `<loopback-if>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `loopback-if`
- Naming tokens: ['loopback', 'if']
- Instance count in source: 1
- Distinct child element tags observed: 8
- Child tags: `enabled`, `if-property`, `ip`, `netmask`, `if-dev-name`, `secondary-ip-list`, `if-num`, `ip-node-type`
- Value-pattern observations:
    - `enabled`: boolean-numeric
    - `if-dev-name`: free-text
    - `if-num`: boolean-numeric
    - `if-property`: boolean-numeric
    - `ip`: ipv4
    - `ip-node-type`: free-text
    - `netmask`: ipv4
    - `secondary-ip-list`: empty

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `vlan-if`: 0.597
  - `physical-if`: 0.539
  - `sslvpn`: 0.348
  - `multicast-if`: 0.327
  - `ipsec-action`: 0.266

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<loopback-if>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 95: `<max-age>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `max-age`
- Naming tokens: ['max', 'age']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `stp-enabled`: 0.270
  - `bridge-priority`: 0.270
  - `aging-time`: 0.270
  - `hello-time`: 0.270
  - `forward-delay`: 0.270

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<max-age>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 96: `<max-concurrent-logins>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `max-concurrent-logins`
- Naming tokens: ['max', 'concurrent', 'logins']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `dns-ip`: 0.289
  - `wins-ip`: 0.289
  - `eap-method`: 0.287
  - `addr-mgmt`: 0.287
  - `addr-grp-name`: 0.287

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<max-concurrent-logins>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 97: `<mgmt-acct-lockout>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `mgmt-acct-lockout`
- Naming tokens: ['mgmt', 'acct', 'lockout']
- Instance count in source: 1
- Distinct child element tags observed: 4
- Child tags: `enabled`, `lockouts`, `duration`, `failures`
- Value-pattern observations:
    - `duration`: port
    - `enabled`: boolean-numeric
    - `failures`: port
    - `lockouts`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `lockout`: 0.715
  - `br-protos`: 0.248
  - `dos-item`: 0.247
  - `ctspam`: 0.245
  - `nat-t-config`: 0.241

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<mgmt-acct-lockout>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 98: `<mgmt-multi-rw-session>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `mgmt-multi-rw-session`
- Naming tokens: ['mgmt', 'multi', 'rw', 'session']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `mgmt-user-session-timeout`: 0.383
  - `hotspot-user-session-timeout`: 0.338
  - `auth-user-session-timeout`: 0.333
  - `mgmt-user-idle-timeout`: 0.333
  - `hotspot-user-idle-timeout`: 0.287

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<mgmt-multi-rw-session>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 99: `<min-password-length>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `min-password-length`
- Naming tokens: ['min', 'password', 'length']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `password`: 0.232
  - `life-length`: 0.232
  - `from-min`: 0.232
  - `to-min`: 0.232
  - `match-length`: 0.232

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<min-password-length>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 100: `<minute>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `minute`
- Naming tokens: ['minute']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `day`: 0.250
  - `hour`: 0.250
  - `rp-candidate`: 0.237
  - `ccl-name`: 0.237
  - `header-value`: 0.237

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<minute>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 101: `<multicast>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `multicast`
- Naming tokens: ['multicast']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `enabled`
- Value-pattern observations:
    - `enabled`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `daas-client`: 0.746
  - `botnet-detection`: 0.741
  - `multicast-if`: 0.540
  - `common-logging`: 0.465
  - `network-discovery`: 0.440

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<multicast>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 102: `<network>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `network`
- Naming tokens: ['network']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `network-unreachable`: 0.291
  - `ip-network-addr`: 0.265
  - `ip`: 0.199
  - `vlan-id`: 0.197
  - `vif-property`: 0.197

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<network>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 103: `<network-discovery>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `network-discovery`
- Naming tokens: ['network', 'discovery']
- Instance count in source: 1
- Distinct child element tags observed: 5
- Child tags: `enabled`, `schedule`, `aging-timeout`, `if-list`, `retention-timeout`
- Value-pattern observations:
    - `aging-timeout`: numeric-int
    - `enabled`: boolean-numeric
    - `if-list`: empty
    - `retention-timeout`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `multicast`: 0.440
  - `daas-client`: 0.440
  - `botnet-detection`: 0.435
  - `common-logging`: 0.414
  - `vpn-global-setting`: 0.358

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<network-discovery>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 104: `<networking-mode>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `networking-mode`
- Naming tokens: ['networking', 'mode']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `server-mode`: 0.386
  - `mode`: 0.373
  - `key-mode`: 0.298
  - `remember-connection`: 0.286
  - `auto-reconnect`: 0.286

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<networking-mode>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 105: `<non-continuous>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `non-continuous`
- Naming tokens: ['non', 'continuous']
- Instance count in source: 1
- Distinct child element tags observed: 2
- Child tags: `interval`, `daily`
- Value-pattern observations:
    - `daily`: empty

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `non-inet-class`: 0.258
  - `system-parameters`: 0.250
  - `snmp-conf`: 0.250
  - `encryption`: 0.250
  - `terminal-service`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<non-continuous>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 106: `<page-title>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `page-title`
- Naming tokens: ['page', 'title']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `title`: 0.322
  - `custom-header-logo`: 0.281
  - `custom-background-image`: 0.281
  - `custom-css`: 0.281
  - `custom-logo`: 0.262

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<page-title>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 107: `<path-cost>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `path-cost`
- Naming tokens: ['path', 'cost']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `product-grade`: 0.150
  - `rs-version`: 0.150
  - `using-cpm-profile`: 0.150
  - `for-version`: 0.150
  - `xml-purpose`: 0.150

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<path-cost>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 108: `<peer>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `peer`
- Naming tokens: ['peer']
- Instance count in source: 1
- Distinct child element tags observed: 10
- Child tags: `local-routes`, `keepalive`, `dns`, `wins`, `redirect-gateway`, `remote-routes`, `dns-mgmt`, `client-to-client`, `use-firebox-routes`, `pool-list`
- Value-pattern observations:
    - `client-to-client`: boolean-numeric
    - `dns-mgmt`: port
    - `redirect-gateway`: boolean-numeric
    - `remote-routes`: empty
    - `use-firebox-routes`: boolean-numeric
    - `wins`: empty

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `peer-auth`: 0.315
  - `gateway`: 0.297
  - `dns-forwarding`: 0.270
  - `local-cert`: 0.264
  - `multicast-if`: 0.255

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<peer>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 109: `<pm-use-only>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `pm-use-only`
- Naming tokens: ['pm', 'use', 'only']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `feature-details-list`: 0.265
  - `cert-list`: 0.265
  - `global-settings`: 0.234
  - `use-ldap`: 0.232
  - `use-ip`: 0.232

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<pm-use-only>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 110: `<pool>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `pool`
- Naming tokens: ['pool']
- Instance count in source: 1
- Distinct child element tags observed: 2
- Child tags: `network`, `netmask`
- Value-pattern observations:
    - `netmask`: ipv4
    - `network`: ipv4

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `address-pool`: 0.391
  - `route`: 0.349
  - `dns-server-list`: 0.250
  - `ip-list`: 0.250
  - `resource-addr`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<pool>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 111: `<pool-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `pool-list`
- Naming tokens: ['pool', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `pool`

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `address-pool-list`: 0.163
  - `pool`: 0.141
  - `local-routes`: 0.133
  - `remote-routes`: 0.133
  - `wins`: 0.133

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<pool-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 112: `<port-priority>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `port-priority`
- Naming tokens: ['port', 'priority']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `port`: 0.291
  - `port-type`: 0.250
  - `port-unreachable`: 0.250
  - `server-port`: 0.250
  - `blocked-port`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<port-priority>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 113: `<pptp>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `pptp`
- Naming tokens: ['pptp']
- Instance count in source: 1
- Distinct child element tags observed: 5
- Child tags: `pptp-enabled`, `pptp-mppe-encryption-option`, `pptp-mru`, `pptp-ras-user-group`, `pptp-mtu`
- Value-pattern observations:
    - `pptp-enabled`: boolean-numeric
    - `pptp-mppe-encryption-option`: boolean-numeric
    - `pptp-mru`: port
    - `pptp-mtu`: port
    - `pptp-ras-user-group`: free-text

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `mss-adjustment`: 0.377
  - `auth-global-setting`: 0.375
  - `log-conf`: 0.333
  - `blocked-ports`: 0.328
  - `misc-global-setting`: 0.327

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<pptp>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 114: `<pptp-enabled>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `pptp-enabled`
- Naming tokens: ['pptp', 'enabled']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `pptp-mtu`: 0.362
  - `pptp-mru`: 0.362
  - `pptp-mppe-encryption-option`: 0.333
  - `pptp-ras-user-group`: 0.333
  - `enabled`: 0.291

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<pptp-enabled>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 115: `<pptp-mppe-encryption-option>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `pptp-mppe-encryption-option`
- Naming tokens: ['pptp', 'mppe', 'encryption', 'option']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `pptp-enabled`: 0.333
  - `pptp-mtu`: 0.333
  - `pptp-mru`: 0.333
  - `pptp-ras-user-group`: 0.312
  - `login-option`: 0.221

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<pptp-mppe-encryption-option>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 116: `<pptp-mru>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `pptp-mru`
- Naming tokens: ['pptp', 'mru']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `pptp-enabled`: 0.362
  - `pptp-mtu`: 0.362
  - `pptp-mppe-encryption-option`: 0.333
  - `pptp-ras-user-group`: 0.333
  - `product-grade`: 0.150

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<pptp-mru>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 117: `<pptp-mtu>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `pptp-mtu`
- Naming tokens: ['pptp', 'mtu']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `pptp-enabled`: 0.362
  - `pptp-mru`: 0.362
  - `pptp-mppe-encryption-option`: 0.333
  - `pptp-ras-user-group`: 0.333
  - `mtu`: 0.291

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<pptp-mtu>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 118: `<pptp-ras-user-group>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `pptp-ras-user-group`
- Naming tokens: ['pptp', 'ras', 'user', 'group']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `pptp-enabled`: 0.333
  - `pptp-mtu`: 0.333
  - `pptp-mru`: 0.333
  - `pptp-mppe-encryption-option`: 0.312
  - `ras-user-group-name`: 0.300

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<pptp-ras-user-group>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 119: `<probe>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `probe`
- Naming tokens: ['probe']
- Instance count in source: 2
- Distinct child element tags observed: 4
- Child tags: `reactivate-count`, `deactivate-count`, `if-name`, `probe-interval`
- Value-pattern observations:
    - `deactivate-count`: port
    - `if-name`: enum-small
    - `probe-interval`: numeric-int
    - `reactivate-count`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `gateway`: 0.247
  - `app`: 0.226
  - `message`: 0.217
  - `dlp-sensor`: 0.208
  - `blocked-port-list`: 0.204

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<probe>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 120: `<probe-interval>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `probe-interval`
- Naming tokens: ['probe', 'interval']
- Instance count in source: 2
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `interval`: 0.289
  - `deactivate-count`: 0.250
  - `reactivate-count`: 0.250
  - `lease-interval`: 0.250
  - `launch-interval`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<probe-interval>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 121: `<proxy-auto-gen>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `proxy-auto-gen`
- Naming tokens: ['proxy', 'auto', 'gen']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `proxy-referenced`: 0.362
  - `proxy-name`: 0.343
  - `proxy-description`: 0.343
  - `proxy-type-attr`: 0.328
  - `proxy-type`: 0.289

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<proxy-auto-gen>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 122: `<pvid-enabled>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `pvid-enabled`
- Naming tokens: ['pvid', 'enabled']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `enabled`: 0.294
  - `ntp-enabled`: 0.250
  - `local-enabled`: 0.250
  - `dlp-enabled`: 0.250
  - `dpd-enabled`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<pvid-enabled>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 123: `<radius-sso>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `radius-sso`
- Naming tokens: ['radius', 'sso']
- Instance count in source: 1
- Distinct child element tags observed: 7
- Child tags: `enabled`, `idle-timeout`, `secret`, `group-attr-type`, `session-timeout`, `accounting-client-ip`, `exception-list`
- Value-pattern observations:
    - `accounting-client-ip`: empty
    - `enabled`: boolean-numeric
    - `exception-list`: empty
    - `group-attr-type`: port
    - `idle-timeout`: port
    - `secret`: empty
    - `session-timeout`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `single-sign-on`: 0.424
  - `dxcp-client`: 0.420
  - `dvcp-client`: 0.405
  - `ldap`: 0.378
  - `terminal-service`: 0.374

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<radius-sso>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 124: `<reactivate-count>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `reactivate-count`
- Naming tokens: ['reactivate', 'count']
- Instance count in source: 2
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `deactivate-count`: 0.350
  - `probe-interval`: 0.250
  - `repeat-count`: 0.250
  - `if-name`: 0.237
  - `ip`: 0.153

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<reactivate-count>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 125: `<redirect-gateway>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `redirect-gateway`
- Naming tokens: ['redirect', 'gateway']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `remote-routes`: 0.283
  - `wins`: 0.283
  - `use-firebox-routes`: 0.283
  - `client-to-client`: 0.283
  - `gateway-ip`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<redirect-gateway>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 126: `<regTimeout>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `regTimeout`
- Naming tokens: ['regtimeout']
- Instance count in source: 1
- Distinct child element tags observed: 2
- Child tags: `action`, `value`
- Value-pattern observations:
    - `value`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `timeout`: 0.610
  - `backlog`: 0.600
  - `max-line-length`: 0.600
  - `filename`: 0.600
  - `line`: 0.600

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<regTimeout>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 127: `<remember-connection>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `remember-connection`
- Naming tokens: ['remember', 'connection']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `auto-reconnect`: 0.286
  - `networking-mode`: 0.286
  - `server-mode`: 0.286
  - `connection-rate`: 0.273
  - `connection-rate-alarm`: 0.255

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<remember-connection>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 128: `<remote-logging>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `remote-logging`
- Naming tokens: ['remote', 'logging']
- Instance count in source: 1
- Distinct child element tags observed: 2
- Child tags: `enabled`, `remote-logging-list`
- Value-pattern observations:
    - `enabled`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `common-logging`: 0.394
  - `botnet-detection`: 0.391
  - `multicast`: 0.391
  - `daas-client`: 0.391
  - `multicast-if`: 0.350

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<remote-logging>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 129: `<remote-logging-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `remote-logging-list`
- Naming tokens: ['remote', 'logging', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `logging-entry`

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `geo-action-list`: 0.217
  - `agent-ip-list`: 0.173
  - `local-remote-pair-list`: 0.170
  - `remote-logging`: 0.163
  - `if-list`: 0.157

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<remote-logging-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 130: `<remote-routes>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `remote-routes`
- Naming tokens: ['remote', 'routes']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `use-firebox-routes`: 0.365
  - `wins`: 0.283
  - `redirect-gateway`: 0.283
  - `client-to-client`: 0.283
  - `remote-enable`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<remote-routes>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 131: `<reneg-datachannel>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `reneg-datachannel`
- Naming tokens: ['reneg', 'datachannel']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `listen-to`: 0.275
  - `compression`: 0.275
  - `server-port`: 0.193
  - `host`: 0.191
  - `type`: 0.190

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<reneg-datachannel>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 132: `<require-client-cert>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `require-client-cert`
- Naming tokens: ['require', 'client', 'cert']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `dh`: 0.262
  - `hash`: 0.262
  - `cipher`: 0.262
  - `force-auth-reconnect`: 0.262
  - `client-to-client`: 0.253

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<require-client-cert>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 133: `<reserved-address-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `reserved-address-list`
- Naming tokens: ['reserved', 'address', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `server-type`: 0.275
  - `backup-server-list`: 0.270
  - `lease-time`: 0.266
  - `address`: 0.265
  - `wins-server-list`: 0.262

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<reserved-address-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 134: `<restrict-user-access>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `restrict-user-access`
- Naming tokens: ['restrict', 'user', 'access']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `rp-candidate`: 0.300
  - `ccl-name`: 0.300
  - `header-value`: 0.300
  - `account-id`: 0.300
  - `user-ip-cache-timeout`: 0.291

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<restrict-user-access>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 135: `<retention-timeout>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `retention-timeout`
- Naming tokens: ['retention', 'timeout']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `aging-timeout`: 0.362
  - `session-idle-timeout`: 0.299
  - `keepalive-timeout`: 0.281
  - `session-timeout`: 0.269
  - `if-list`: 0.262

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<retention-timeout>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 136: `<scan>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `scan`
- Naming tokens: ['scan']
- Instance count in source: 34
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `strip`: 0.299
  - `allow`: 0.297
  - `scan-limit`: 0.295
  - `replace`: 0.294
  - `scan-mode`: 0.291

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<scan>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 137: `<search-base>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `search-base`
- Naming tokens: ['search', 'base']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `search-user-dn`: 0.372
  - `search-user-pwd`: 0.372
  - `group-attr-name`: 0.290
  - `attr-name-ip`: 0.290
  - `attr-name-ip-mask`: 0.290

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<search-base>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 138: `<search-user-dn>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `search-user-dn`
- Naming tokens: ['search', 'user', 'dn']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `search-user-pwd`: 0.423
  - `search-base`: 0.372
  - `group-attr-name`: 0.290
  - `attr-name-ip`: 0.290
  - `attr-name-ip-mask`: 0.290

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<search-user-dn>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 139: `<search-user-pwd>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `search-user-pwd`
- Naming tokens: ['search', 'user', 'pwd']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `search-user-dn`: 0.423
  - `search-base`: 0.372
  - `group-attr-name`: 0.290
  - `attr-name-ip`: 0.290
  - `attr-name-ip-mask`: 0.290

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<search-user-pwd>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 140: `<secret>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `secret`
- Naming tokens: ['secret']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `accounting-client-ip`: 0.275
  - `group-attr-type`: 0.275
  - `exception-list`: 0.275
  - `session-timeout`: 0.242
  - `rp-candidate`: 0.211

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<secret>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 141: `<server-ip>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `server-ip`
- Naming tokens: ['server', 'ip']
- Instance count in source: 2
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `attr-name-ip`: 0.356
  - `attr-name-ip-mask`: 0.345
  - `attr-name-dns-ip`: 0.345
  - `attr-name-wins-ip`: 0.345
  - `ldap-server-ip`: 0.313

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<server-ip>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 142: `<server-mode>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `server-mode`
- Naming tokens: ['server', 'mode']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `networking-mode`: 0.386
  - `mode`: 0.373
  - `key-mode`: 0.298
  - `remember-connection`: 0.286
  - `auto-reconnect`: 0.286

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<server-mode>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 143: `<session-timeout>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `session-timeout`
- Naming tokens: ['session', 'timeout']
- Instance count in source: 2
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `session-idle-timeout`: 0.347
  - `auth-user-session-timeout`: 0.291
  - `mgmt-user-session-timeout`: 0.291
  - `hotspot-user-session-timeout`: 0.291
  - `aging-timeout`: 0.269

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<session-timeout>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 144: `<sslvpn>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `sslvpn`
- Naming tokens: ['sslvpn']
- Instance count in source: 2
- Distinct child element tags observed: 12
- Child tags: `name`, `description`, `property`, `auth`, `peer`, `mode`, `enable`, `auto-reconnect`, `remember-connection`, `gateway`, `networking-mode`, `server-mode`
- Value-pattern observations:
    - `auto-reconnect`: boolean-numeric
    - `description`: empty
    - `enable`: boolean-numeric
    - `mode`: port
    - `name`: free-text
    - `networking-mode`: boolean-numeric
    - `property`: boolean-numeric
    - `remember-connection`: boolean-numeric
    - `server-mode`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `ipsec-action`: 0.445
  - `ike-action`: 0.410
  - `policy`: 0.380
  - `ike-policy-group`: 0.367
  - `schedule`: 0.366

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<sslvpn>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 145: `<sso-exception-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `sso-exception-list`
- Naming tokens: ['sso', 'exception', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `sso-through-bovpn`: 0.342
  - `exception-list`: 0.338
  - `sso-agent-ip`: 0.336
  - `exclude-ip-list`: 0.323
  - `keepalive-interval`: 0.275

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<sso-exception-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 146: `<sso-through-bovpn>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `sso-through-bovpn`
- Naming tokens: ['sso', 'through', 'bovpn']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `sso-exception-list`: 0.342
  - `sso-agent-ip`: 0.336
  - `keepalive-interval`: 0.275
  - `keepalive-timeout`: 0.275
  - `user-ip-cache-timeout`: 0.269

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<sso-through-bovpn>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 147: `<start>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `start`
- Naming tokens: ['start']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `auto-start`: 0.291
  - `start-ip`: 0.291
  - `auto-start-tunnel`: 0.265
  - `start-server-port`: 0.265
  - `product-grade`: 0.150

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<start>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 148: `<start-ip>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `start-ip`
- Naming tokens: ['start', 'ip']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `ip`: 0.291
  - `start`: 0.291
  - `gateway-ip`: 0.250
  - `use-ip`: 0.250
  - `ip-type`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<start-ip>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 149: `<stp-enabled>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `stp-enabled`
- Naming tokens: ['stp', 'enabled']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `enabled`: 0.291
  - `bridge-priority`: 0.270
  - `aging-time`: 0.270
  - `hello-time`: 0.270
  - `max-age`: 0.270

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<stp-enabled>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 150: `<stp-port>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `stp-port`
- Naming tokens: ['stp', 'port']
- Instance count in source: 1
- Distinct child element tags observed: 2
- Child tags: `port-priority`, `path-cost`
- Value-pattern observations:
    - `path-cost`: boolean-numeric
    - `port-priority`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `external-if`: 0.285
  - `br-protos`: 0.263
  - `blocked-port-list`: 0.258
  - `mss-adjustment`: 0.250
  - `trace-item`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<stp-port>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 151: `<syslog>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `syslog`
- Naming tokens: ['syslog']
- Instance count in source: 1
- Distinct child element tags observed: 3
- Child tags: `serial`, `facility-map-list`, `timestamp`
- Value-pattern observations:
    - `serial`: boolean-numeric
    - `timestamp`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `dns-forwarding`: 0.315
  - `multicast-if`: 0.304
  - `vpn-tunnel-sharing`: 0.280
  - `ike-policy-group`: 0.276
  - `remote-action`: 0.268

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<syslog>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 152: `<tcp-mtu-probing>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `tcp-mtu-probing`
- Naming tokens: ['tcp', 'mtu', 'probing']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `syn-checking-enable`: 0.285
  - `vlan-forward`: 0.285
  - `log-in-out-broadcast`: 0.285
  - `auto-blocked-duration`: 0.285
  - `block-spoof-enabled`: 0.285

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<tcp-mtu-probing>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 153: `<terms>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `terms`
- Naming tokens: ['terms']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `geo-list`: 0.300
  - `dns-forwarding`: 0.283
  - `proxy-arp`: 0.266
  - `anti-replay-window`: 0.266
  - `on-off`: 0.266

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<terms>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 154: `<threat-correlation>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `threat-correlation`
- Naming tokens: ['threat', 'correlation']
- Instance count in source: 1
- Distinct child element tags observed: 2
- Child tags: `enabled`, `account-id`
- Value-pattern observations:
    - `account-id`: empty
    - `enabled`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `geolocation-blocking`: 0.510
  - `logon-banner`: 0.397
  - `clientless-vpn`: 0.324
  - `system-parameters`: 0.321
  - `signature-update`: 0.321

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<threat-correlation>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 155: `<timestamp>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `timestamp`
- Naming tokens: ['timestamp']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `feature-key-url`: 0.190
  - `rss-url`: 0.190
  - `staging-url`: 0.190
  - `rss-check`: 0.190
  - `feature-key-auto-sync`: 0.190

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<timestamp>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 156: `<title>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `title`
- Naming tokens: ['title']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `page-title`: 0.322
  - `fault_upload`: 0.237
  - `custom-logo`: 0.202
  - `feature-key-url`: 0.183
  - `rss-url`: 0.183

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<title>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 157: `<traffic-flow-conf>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `traffic-flow-conf`
- Naming tokens: ['traffic', 'flow', 'conf']
- Instance count in source: 1
- Distinct child element tags observed: 1
- Child tags: `flush-connections`
- Value-pattern observations:
    - `flush-connections`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `ntp-conf`: 0.473
  - `log-conf`: 0.470
  - `multicast`: 0.396
  - `daas-client`: 0.396
  - `icmp-error-handling`: 0.391

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<traffic-flow-conf>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 158: `<use-firebox-routes>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `use-firebox-routes`
- Naming tokens: ['use', 'firebox', 'routes']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `remote-routes`: 0.365
  - `wins`: 0.283
  - `redirect-gateway`: 0.283
  - `client-to-client`: 0.283
  - `use-ldap`: 0.232

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<use-firebox-routes>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 159: `<user-access-list>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `user-access-list`
- Naming tokens: ['user', 'access', 'list']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `app-group-list`: 0.292
  - `ras-user-list`: 0.283
  - `restrict-user-access`: 0.283
  - `user`: 0.265
  - `muvpn-users-list`: 0.246

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<user-access-list>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 160: `<vif-property>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `vif-property`
- Naming tokens: ['vif', 'property']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `if-property`: 0.305
  - `property`: 0.291
  - `vlan-id`: 0.285
  - `intra-vlan-inspection`: 0.285
  - `ip-node-type`: 0.210

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<vif-property>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 161: `<vlan-id>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `vlan-id`
- Naming tokens: ['vlan', 'id']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `intra-vlan-inspection`: 0.367
  - `vif-property`: 0.285
  - `card-id`: 0.250
  - `client-id`: 0.250
  - `vlan-forward`: 0.250

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<vlan-id>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 162: `<vlan-if>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `vlan-if`
- Naming tokens: ['vlan', 'if']
- Instance count in source: 1
- Distinct child element tags observed: 11
- Child tags: `member-list`, `ip`, `vlan-id`, `netmask`, `dhcp-server`, `vif-property`, `br-protos`, `if-dev-name`, `if-num`, `ip-node-type`, `intra-vlan-inspection`
- Value-pattern observations:
    - `if-dev-name`: free-text
    - `if-num`: boolean-numeric
    - `intra-vlan-inspection`: boolean-numeric
    - `ip`: ipv4
    - `ip-node-type`: free-text
    - `netmask`: ipv4
    - `vif-property`: boolean-numeric
    - `vlan-id`: boolean-numeric

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `loopback-if`: 0.597
  - `physical-if`: 0.493
  - `sslvpn`: 0.362
  - `multicast-if`: 0.304
  - `ike-policy-group`: 0.253

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<vlan-if>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 163: `<vpn-portal>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `vpn-portal`
- Naming tokens: ['vpn', 'portal']
- Instance count in source: 1
- Distinct child element tags observed: 9
- Child tags: `port`, `idle-timeout`, `custom-logo`, `page-title`, `auth-domain-name-list`, `session-timeout`, `custom-background-image`, `custom-css`, `custom-header-logo`
- Value-pattern observations:
    - `custom-background-image`: boolean-numeric
    - `custom-css`: boolean-numeric
    - `custom-header-logo`: boolean-numeric
    - `custom-logo`: boolean-numeric
    - `idle-timeout`: port
    - `page-title`: empty
    - `port`: port
    - `session-timeout`: port

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `logon-banner`: 0.354
  - `threat-correlation`: 0.321
  - `geolocation-blocking`: 0.318
  - `clientless-vpn`: 0.296
  - `signature-update`: 0.282

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<vpn-portal>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 164: `<wins>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `wins`
- Naming tokens: ['wins']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `wins-ip`: 0.305
  - `remote-routes`: 0.283
  - `redirect-gateway`: 0.283
  - `use-firebox-routes`: 0.283
  - `client-to-client`: 0.283

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<wins>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 165: `<wins-ip>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `wins-ip`
- Naming tokens: ['wins', 'ip']
- Instance count in source: 1
- Distinct child element tags observed: 0

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `dns-ip`: 0.389
  - `wins`: 0.305
  - `ip`: 0.294
  - `attr-name-wins-ip`: 0.291
  - `max-concurrent-logins`: 0.289

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<wins-ip>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Surface 166: `<youtube-for-school>`

<!-- ENGINE-OBSERVATION-BEGIN -->

### Engine observations (structural facts only)

These are descriptions of what's in the XML. They are NOT claims about meaning. The engine makes no semantic claim, suggests no category, hints at no vendor mapping.

- Element tag: `youtube-for-school`
- Naming tokens: ['youtube', 'for', 'school']
- Instance count in source: 2
- Distinct child element tags observed: 2
- Child tags: `enabled`, `header-value`
- Value-pattern observations:
    - `enabled`: boolean-text
    - `header-value`: empty

**Structural similarity to existing elements:**

Note: structural similarity reflects shared child tags, value patterns, and naming tokens. It does NOT indicate semantic kinship. Use as research context, not as a substitute for declaration.

  - `authentication`: 0.318
  - `acl`: 0.302
  - `starttls`: 0.275
  - `terminal-service`: 0.271
  - `errors`: 0.270

<!-- ENGINE-OBSERVATION-END -->

### Required operator declarations

Research the following questions using vendor documentation, RFCs, lab testing, or your field experience. Document your sources. The toolkit will not proceed without all answers and citations.

<!-- OPERATOR-AUTHORED-BEGIN -->

[ ] **Q1: What does this element do?** (one sentence)

    Answer: __________________________________________

    Source (vendor doc URL, RFC, field experience): ___

[ ] **Q2: Surface category from the toolkit's taxonomy?**

    Choose one: network-plumbing | policy-access-control |
    object-library | tunnel-vpn | html-web-app |
    threat-detection | authentication-infrastructure |
    device-management | administrative

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q3: Does the source vendor (SonicWall) have an equivalent feature?**

    If yes, what is it? If no, what's the operator action?

    Answer: __________________________________________

    Source: __________________________________________

[ ] **Q4: Security or operational considerations** for migration_notes.md?

    Answer: __________________________________________

    Source: __________________________________________

<!-- OPERATOR-AUTHORED-END -->

### Until all declarations are made and cited

The toolkit will refuse to merge any rule for `<youtube-for-school>`. Source configs containing data that would map to this surface will produce a hard-error advisory in migration_notes.md.

---

## Summary

166 surface(s) require operator intervention before translation is possible. Until each surface has all questions answered with citations, the toolkit will:

- Refuse to write any wg_xml_schema.ini entry for the surface
- Refuse to write any concept_map.ini entry for the surface
- Refuse to write any xml_emit_config.ini emit rule
- Block any source-config translation that touches the surface, with hard-error advisory in migration_notes.md