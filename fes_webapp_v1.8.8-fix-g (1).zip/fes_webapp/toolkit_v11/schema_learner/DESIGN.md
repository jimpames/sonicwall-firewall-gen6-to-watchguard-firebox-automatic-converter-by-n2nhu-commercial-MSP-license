# Design: Schema-Learner & Corpus-Scorer Subsystem

**Status:** Design locked, ready to build
**Author:** Jim Ames + Claude (collaborative design across multiple sessions)
**Date:** 2026-05-05
**Project:** SonicWall→WatchGuard Migration Toolkit (extends to ANY→ANY platform)

---

## Founding Principle

> **No claim without provenance.**
>
> Every assertion the toolkit makes — about element semantics, surface
> categories, vendor mappings, value validity, cross-reference targets,
> or operator guidance — must trace back to an observed artifact: a
> working config export, a published vendor specification, a documented
> attack reference, or recorded field experience.
>
> When ground truth is not available, the toolkit must say so
> explicitly. It must not infer, pattern-match, or guess. It must
> surface the gap to the operator and refuse to proceed.

This principle is the moat. The toolkit is trustworthy because it
refuses to fabricate. Every other design decision in this document
serves this principle.

---

## Two Missions

### Mission A — Schema Learner

Given a new XML config, identify what's structurally novel relative to
the existing schema, present the operator with structured findings
that include only OBSERVATIONS (never semantic claims), and require
operator declarations (with citations) before any merge into the INI
bundles.

### Mission B — Corpus Scorer

Given an emit-output XML, score it against a CLUSTER of known-good
references (rather than one), producing richer confidence signals:
distance to centroid, nearest neighbor, convex-hull membership, and
per-reference scores.

Both missions share the same feature-extraction substrate. Build once,
use twice.

---

## Feature Vector — Seven Slots

Every element type extracted from JSON-converted XML gets a feature
vector with seven slots. The first six are computed; the seventh is
operator-declared.

### Slot 1: Children bag-of-tags
Sparse binary vector indexed by the universe of all known child-tag
names. Captures "what kinds of children does this element have."

### Slot 2: Field-shape signature
Sparse binary vector over the set of distinct child-tag tuples
observed for this element type across the corpus. Captures shape
variation within an element type.

### Slot 3: Naming tokens
Bag-of-tokens vector after splitting tag names on `-` and `_`. Cosine
similarity in this space captures naming-convention proximity.

### Slot 4: Value-pattern fingerprint
Histogram over value classifications: `uuid`, `ipv4`, `ipv6`, `mac`,
`port`, `boolean-numeric`, `boolean-text`, `enum-small` (≤8 distinct),
`enum-large`, `free-text`, `numeric-int`, `empty`.

### Slot 5: Structural neighborhood
Bag-of-sibling-tags vector. What elements sit next to this one under
the same parent.

### Slot 6: Reference-edge signature
Bag-of-target-element-types vector. What other elements does this
element reference (cross-references, member lists).

### Slot 7: Surface-category — OPERATOR-DECLARED
Functional category from a fixed taxonomy:
  - `network-plumbing` — interfaces, routing, NAT
  - `policy-access-control` — firewall rules, aliases, schedules
  - `object-library` — services, address objects, address groups
  - `tunnel-vpn` — IPsec, IKE, BOVPN, mobile-IKEv2
  - `html-web-app` — VPN portals, access portals, anything serving
    HTML to a browser
  - `threat-detection` — DLP, geolocation-blocking, threat-correlation
  - `authentication-infrastructure` — auth domains, RADIUS, LDAP
  - `device-management` — device-list, signature-update
  - `administrative` — logon-banner, revision-history

The engine NEVER assigns Slot 7. The operator declares it during
proposal review and provides a citation source.

---

## Similarity Metric — Carefully Worded

Per-slot cosine similarity, weighted aggregate per `placement_rules.ini`:

```
structural_similarity(A, B) = Σᵢ wᵢ · cosine(A.slotᵢ, B.slotᵢ)
                              [for slots 1-6 only]
```

### CRITICAL WORDING

The output of this calculation is **structural similarity**. Per the
founding principle, structural similarity is a measurable fact. It is
NOT semantic kinship.

The engine reports:
> "Element A has 0.92 structural similarity to Element B"

The engine does NOT report:
> "Element A and Element B are in the same family"

Semantic kinship is an operator declaration based on Slot 7 plus
provenance.

Slot 7 is NOT part of the structural similarity calculation. It is a
classification dimension used to FILTER comparisons. Once the operator
has declared Slot 7 for an element, future structural comparisons can
be scoped to same-category neighbors only.

---

## Four Finding Categories

Decreasing structural impact:

1. **Novel element type** — element doesn't exist in current schema
2. **New shape of known element** — element exists, new field
   combination observed
3. **New field within known shape** — element exists, this shape
   exists, but a new field appears
4. **New value within known field** — usually enum expansion

Findings are presented in order of impact so the operator focuses
attention where it matters most.

---

## Confidence Scoring

Each structural placement proposal carries a confidence:

- **High (>0.85):** strong structural match, low ambiguity
- **Medium (0.50–0.85):** plausible match, operator should review
  carefully
- **Low (<0.50):** engine uncertain, multiple competing matches

**Confidence is about structural similarity, not semantic correctness.**
A finding with confidence 0.95 means "this element looks structurally
similar to existing element X" — it does NOT mean "this element is in
the same family as X." Family assignment is an operator declaration.

Findings below threshold (default 0.40) get no automatic structural
proposal — operator must classify manually.

---

## OPERATOR_INTERVENTION_REQUIRED.md — The Action Contract

Generated per-proposal-batch, operator-facing, structured for action.
Per-finding section structure:

```markdown
## Surface: <vpn-portal>

### Engine observations (structural facts only)

These are descriptions of what's in the XML, NOT claims about meaning:

- Appears at /profile/vpn-portal (top-level)
- Has 12 child element types
- Structural similarity to existing elements:
    - clientless-vpn: 0.92 (shared children: enabled, address-pool;
      similar value patterns)
    - sslvpn-list: 0.81 (shared parent context, partial child overlap)
    - muvpn-list: 0.74
- Field <enabled> uses boolean-numeric pattern (0/1)
- Contains 3 children that don't appear in any existing schema entry:
  customization, branding, published-app-list

The engine makes NO claim about what this element does or where it
fits semantically. That is the operator's job to declare.

### Required operator declarations

The following questions must be answered with citations before this
finding can be merged into any INI bundle. The toolkit will not
proceed without all answers and all citations.

[ ] What is this element? (one sentence)
[ ] Source of your answer:
    [ ] Vendor documentation URL: ___________
    [ ] Field experience: name + years on this vendor: ___________
    [ ] Other (explain): ___________

[ ] Functional category from the fixed taxonomy:
    [ ] network-plumbing
    [ ] policy-access-control
    [ ] object-library
    [ ] tunnel-vpn
    [ ] html-web-app
    [ ] threat-detection
    [ ] authentication-infrastructure
    [ ] device-management
    [ ] administrative

[ ] Source of category determination:
    [ ] Vendor documentation URL: ___________
    [ ] Field experience: ___________

[ ] SonicWall equivalent feature(s) (or "none — net-new on WatchGuard"):
    ___________

[ ] Source of equivalence claim:
    [ ] Operator field experience with both vendors: ___________
    [ ] Vendor migration documentation URL: ___________
    [ ] Statistical inference from corpus (engine observation, NOT a
        claim — operator confirms): ___________

### Until all declarations are made and cited

The toolkit will:
- Refuse to write any wg_xml_schema.ini entry for this surface
- Refuse to write any concept_map.ini entry for this surface
- Refuse to write any xml_emit_config.ini emit rule for this surface
- Block any source config translation that touches this surface,
  with hard-error advisory in migration_notes.md
```

This is the contract. No declaration, no merge. No citation, no
declaration. No exceptions.

---

## Statistical Inference from Corpus — When Allowed

When the corpus contains both SonicWall and WatchGuard configs that
share customer/deployment context, the engine MAY observe correlations:

> "3 of 5 SonicWall configs in the corpus have an `sslvpn-server`
> directive when the corresponding WG export has `<vpn-portal>`
> populated."

Such observations are presented to the operator as **CONTEXT**, never
as **CLAIMS**. The operator may use the observation to narrow their
research, but the operator still must:

1. Verify the equivalence claim against vendor documentation or field
   experience
2. Cite the source of their verified equivalence
3. Declare the equivalence themselves

The engine never writes "sslvpn-server maps to vpn-portal" without
operator declaration. Statistical inference is a research aid, not a
substitute for declaration.

---

## Inline Warning Blurbs — Three-Pronged Enforcement

When schema-learner applies an approved Category-1 (novel element)
proposal, three places get warning text:

### In `concept_map/concept_map.ini`:

```ini
# === ⚠ SCHEMA LEARNED 2026-05-05 — TRANSLATION BLOCKED ⚠ ===
# WatchGuard element <vpn-portal> was learned from TEMPLATE_FW.xml.
# The SonicWall side of this concept is NOT YET MAPPED.
# Operator declarations: Jim Ames, 2026-05-05 (cited: WG help center
#   docs URL ..., field experience 25y both vendors)
# Surface category: html-web-app (cited: WG Access Portal docs URL ...)
#
# ⛔ Translation BLOCKED until SonicWall mapping authored.
#    See OPERATOR_INTERVENTION_REQUIRED.md for next steps.
[concept.vpn_portal]
description = (TO BE AUTHORED — operator must declare)
canonical_term = vpn_portal
category = html-web-app
sonicwall = ⚠ NOT MAPPED — operator must author this field ⚠
watchguard = vpn-portal
```

### In `sonicwall_parser/parser_config.ini`:

```ini
# === ⚠ TRANSLATION GAP — SonicWall parser pattern needed ⚠ ===
# WatchGuard <vpn-portal> learned 2026-05-05 from TEMPLATE_FW.xml.
# Surface category: html-web-app
# SonicWall directive that captures this feature is unknown.
#
# Operator action: add a [parse.<section>] block here.
# 📖 See OPERATOR_INTERVENTION_REQUIRED.md (proposal 2026-05-05_TEMPLATE_FW)
# 🛑 Until added, configs with this feature emit hard errors.
```

### In `xml_emitter/xml_emit_config.ini`:

```ini
# === ⚠ EMIT RULE NEEDED — WG <vpn-portal> learned but unmapped ⚠ ===
# Schema entry exists in wg_xml_schema.ini.
# SonicWall mapping NOT authored.
# Surface category: html-web-app (operator-declared by Jim Ames)
#
# 📖 See OPERATOR_INTERVENTION_REQUIRED.md (proposal 2026-05-05_TEMPLATE_FW)
# 🔍 Nearest existing emit rule by surface category: [emit.muvpn_clientless]
#    (NOTE: structural similarity 0.74; operator must verify semantic kinship
#     before using as template)
```

Warnings are searchable (`grep -r "TRANSLATION BLOCKED"`), GUI-visible,
and structurally inert.

---

## Hard-Block Enforcement

Two enforcement points in the existing pipeline:

### At parse time (Phase 1)

Operator-declared blocking via warning blurbs (Option B for v1). The
parser doesn't try to detect blocked surfaces in the SonicWall source;
the operator's awareness via the intervention doc is the safeguard.

Future enhancement (post-v1): corpus-driven inference of likely
SonicWall directives for blocked surfaces — presented as observations,
not claims.

### At emit time (Phase 2)

If `xml_emit_config.ini` lacks an `[emit.<surface>]` rule for a
schema-learned WG element AND the source config contains data that
would map to that surface, the emitter writes a prominent advisory:

```markdown
## ⛔ TRANSLATION BLOCKED — vpn-portal surface

This source config contains references to a WatchGuard surface
(<vpn-portal>) that was schema-learned on 2026-05-05 but does NOT
have a complete SonicWall→WatchGuard mapping authored.

THE OUTPUT XML IS INCOMPLETE. Do not import to production until:
  1. The mapping is authored (see OPERATOR_INTERVENTION_REQUIRED.md)
  2. The toolkit is re-run on this source
  3. This advisory is no longer present in migration_notes.md
```

---

## Reference Corpus

```
schema_learner/corpus/
├── _corpus_index.ini
├── T30jpa1.xml
├── TEMPLATE_FW.xml
└── (future configs)
```

`_corpus_index.ini` per-entry roles:

- `reference` — populated config, used as diff-scoring anchor
- `schema_source` — used for schema learning (templates qualify)
- `scoring_anchor` — high-quality, lab-verified, in convex hull
- `vendor_documentation` — links to authoritative vendor docs cited
  in operator declarations

A single corpus entry can have multiple roles.

---

## INI-Driven Engine Configuration

Following the algebraic-design discipline, the schema-learner is
itself driven by INI:

```
schema_learner/
├── learn_config.ini               Driving config
├── learn_config.schema.ini        Meta-schema
├── placement_rules.ini            Vector-math weights and thresholds
├── placement_rules.schema.ini
├── intervention_templates.ini     Per-category intervention doc
│                                  templates (keeps text out of code)
├── intervention_templates.schema.ini
└── corpus/
```

Every weight, threshold, behavior, warning text, and intervention
template is INI-controlled. Tune from outside, never from code.

---

## Mission B — Corpus Scorer Output

Replaces today's single-reference diff-score:

```
Corpus-Aggregate Score: 0.94
  Reference cluster size: 4 configs (filtered to role=reference)
  Candidate distance from centroid: 0.07
  Nearest reference: T30jpa1 (dist 0.04)
  Within convex hull: yes
  Per-reference scores:
    T30jpa1                0.9567
    Customer_M270_2024     0.9211
    Lab_Firebox_T15        0.9483
    TEMPLATE_FW            (excluded — role=schema_source not
                            reference; templates aren't valid
                            scoring anchors)
```

Outlier detection becomes possible: a candidate outside the reference
convex hull warrants extra operator attention even if its
nearest-neighbor score is high.

---

## Test Discipline

The schema-learner adds these regression tests to `harness/`:

1. **Round-trip determinism** — same input produces same findings on
   every run
2. **Empty-input** — XML identical to corpus produces zero findings
3. **Synthetic novelty** — injected known-novel element gets
   identified and classified at the right Category 1-4 level
4. **Confidence-threshold** — tuning weights produces predictable
   threshold behavior
5. **Merge-then-validate** — applying an approved proposal produces
   INI bundles that still pass schema validation
6. **Backup-restore** — rollback produces byte-identical pre-merge
   state
7. **Hard-block enforcement** — INI bundle with warning-blurb
   sections + no authored mapping produces hard-error advisory in
   migration_notes.md
8. **Operator declaration required** — schema-learner refuses to
   merge any proposal lacking required declarations or citations

### Plus the principle-policing test (the meta-test)

9. **Provenance audit** — scan all generated docs (proposals,
   migration_notes, intervention docs) for unsourced claims. Flag
   any sentence that asserts a semantic fact without a citation
   marker. The toolkit polices itself for the founding principle.

This test enforces "no claim without provenance" as a regression
gate. If a future change introduces a code path that fabricates,
the test catches it.

---

## What v1 Excludes (Tractability)

- No NumPy dependency. Pure Python, explicit loops with
  vector-op comments.
- No ML embeddings, no neural nets. Hand-crafted features only.
  Explainable to a senior engineer.
- No automatic conflict resolution. Conflicts → operator review.
- No firmware-version-aware merging.
- No auto-apply for any finding, regardless of confidence.
- No corpus-driven SonicWall-side inference. (Post-v1; presented as
  observations not claims.)

---

## Build Order

1. **Foundation:** feature-vector module (consumed by both missions)
2. **Mission A:** schema-learner with operator-review proposal flow
3. **Mission A:** intervention doc generation + warning blurb
   insertion + hard-block enforcement
4. **Test discipline:** all 9 tests above
5. **Mission B:** corpus-scorer (small effort once feature-vectors
   exist)
6. **GUI integration:** new "Pending Proposals" tab (post-v1)

---

## Decisions Locked

Across the design conversation, the following are now locked:

✅ Two missions sharing one feature-extraction substrate
✅ Seven feature slots (six computed, one operator-declared)
✅ Vector math for STRUCTURAL similarity only — never semantic kinship
✅ Four finding categories
✅ Confidence scoring for structural placement only
✅ Three-pronged enforcement (intervention doc + inline warnings + hard block)
✅ Option B for parse-time blocking in v1 (operator-declared via blurbs)
✅ Corpus-driven inference allowed only as observations, never claims
✅ Pure Python, no NumPy dependency
✅ Operator approval required for every change
✅ Schema-learner produces schema proposals only; emit-rule authoring
   is operator work
✅ OPERATOR_INTERVENTION_REQUIRED.md is the action contract
✅ Provenance-audit test polices the founding principle
✅ Mission A first, Mission B second

---

## Decisions Deferred (Post-v1)

- Corpus-driven SonicWall-side inference (as observations)
- GUI "Pending Proposals" tab
- Firmware-version-aware learning
- Auto-tuning of placement weights from operator feedback
- ML-based feature embeddings (only if hand-crafted features prove
  insufficient at scale)
