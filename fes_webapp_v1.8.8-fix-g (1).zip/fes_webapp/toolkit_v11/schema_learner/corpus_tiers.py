#!/usr/bin/env python3
"""
corpus_tiers.py
================

Phase 2 of the schema_learner subsystem (DESIGN_team_scale_addendum.md).
Manages the two new corpus tiers introduced by the team-scale reframe:

  Tier 2: Banned corpus
    Storage of (h)armful classifications. Drafts that match a banned
    entry by structural similarity above threshold are suppressed
    before reaching any operator.
    
    Storage path: schema_learner/banned/_banned_index.ini
                  schema_learner/banned/<entry_id>.md
  
  Tier 3: Sideline queue
    Storage of (s)idelined surfaces awaiting deep research. Per-surface
    markdown files plus a queue index sorted by occurrence frequency.
    
    Storage path: schema_learner/sideline/_sideline_queue.ini
                  schema_learner/sideline/<surface_id>.md

Founding principle binding (no claim without provenance):

    Every entry in either tier carries:
      - operator name
      - timestamp
      - reason (free-text, mandatory for banned, encouraged for sideline)
      - structural fingerprint (allows similarity-match lookup)
      - the LLM draft text being banned/sidelined (so future drafts
        can be compared against it)
    
    The banned tier specifically stores NEGATIVE provenance: this is
    the operator-authored claim "this draft is wrong" with full
    audit trail. Future LLM drafts that match are suppressed by
    transitive operator authority.

Tier 1 (approved corpus) lives in wg_xml_schema.ini etc. and is
managed by the existing merge_engine.py — not this module.
"""
from __future__ import annotations

import configparser
import datetime as _dt
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))


# Markers from intervention docs (must match schema_learner.py)
OBS_OPEN = "<!-- ENGINE-OBSERVATION-BEGIN -->"
OBS_CLOSE = "<!-- ENGINE-OBSERVATION-END -->"
OP_OPEN = "<!-- OPERATOR-AUTHORED-BEGIN -->"
OP_CLOSE = "<!-- OPERATOR-AUTHORED-END -->"


# ---------------------------------------------------------------------------
# Banned-corpus dataclass
# ---------------------------------------------------------------------------

@dataclass
class BannedEntry:
    """One (h)armful classification in the banned corpus.
    
    Contains the operator's authored reason for banning, the LLM
    draft text that was banned (or empty if no LLM draft existed —
    direct-from-engine ban), and the structural fingerprint used for
    similarity lookup against future drafts.
    """
    entry_id: str  # surface_tag + timestamp slug
    surface_tag: str
    operator: str
    timestamp: str  # ISO
    reason: str  # mandatory free-text
    
    # The draft text (or finding text) that was banned.
    # Future drafts structurally similar to this are suppressed.
    banned_draft_text: str = ""
    
    # Structural fingerprint: top-children-tags as a sorted list,
    # value-pattern-categories as sorted list. Stored as comma-separated
    # strings for INI compatibility. Used by the suppression check
    # (see check_suppression below).
    children_tags_fingerprint: str = ""
    value_patterns_fingerprint: str = ""
    naming_tokens_fingerprint: str = ""
    
    # Source proposal directory (audit trail)
    source_proposal: str = ""
    
    # Appeal status (per addendum risk management)
    # 'active' (default): suppression enforced
    # 'held': appeal in progress, suppression NOT enforced during review
    # 'restored': appeal resolved, ban remains in force
    # 'unbanned': appeal resolved, ban removed
    status: str = "active"
    
    # If unbanned, who unbanned and when (for audit)
    unbanned_by: str = ""
    unbanned_at: str = ""
    unban_reason: str = ""


# ---------------------------------------------------------------------------
# Sideline-queue dataclass
# ---------------------------------------------------------------------------

@dataclass
class SidelineEntry:
    """One (s)idelined surface awaiting deep research.
    
    Per the addendum SLA tiers:
      Tier 1 (1-2 occurrences): indefinite
      Tier 2 (3-9 occurrences):  30-day SLA
      Tier 3 (10+ occurrences):   7-day SLA
    
    occurrence_count is incremented each time a structurally-similar
    surface is sidelined again (i.e., the system detects the same
    or similar pattern in another customer config).
    """
    entry_id: str
    surface_tag: str
    operator: str  # who first sidelined
    timestamp: str  # when first sidelined
    reason: str  # operator note
    
    # Queue management
    occurrence_count: int = 1
    first_seen_in: str = ""  # source corpus/config label
    last_seen_in: str = ""   # most recent source label
    last_seen_at: str = ""   # ISO timestamp
    
    # SLA tier (computed from occurrence_count)
    # 1: 1-2 occurrences, indefinite
    # 2: 3-9 occurrences, 30-day SLA
    # 3: 10+ occurrences, 7-day SLA
    sla_tier: int = 1
    
    # Lifecycle
    # 'open': awaiting deep research
    # 'in_research': senior engineer has claimed it
    # 'resolved': promoted to approved corpus
    # 'banned': promoted to banned corpus instead
    status: str = "open"
    assigned_to: str = ""  # operator who claimed it for deep research
    assigned_at: str = ""
    
    # Structural fingerprint for similarity match-back
    children_tags_fingerprint: str = ""
    value_patterns_fingerprint: str = ""
    naming_tokens_fingerprint: str = ""
    
    # Source proposal (where first sidelined)
    source_proposal: str = ""


# ---------------------------------------------------------------------------
# Banned-corpus storage
# ---------------------------------------------------------------------------

def _banned_root() -> Path:
    p = _TOOLKIT_ROOT / "schema_learner" / "banned"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _banned_index_path() -> Path:
    return _banned_root() / "_banned_index.ini"


def write_banned_entry(entry: BannedEntry) -> Path:
    """Write a banned entry: append to the index, write the markdown.
    
    Returns the path of the markdown detail file.
    """
    # Append to index
    index_path = _banned_index_path()
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    if index_path.is_file():
        cp.read(index_path, encoding='utf-8')
    
    # Index section
    section = entry.entry_id
    if not cp.has_section(section):
        cp.add_section(section)
    cp.set(section, 'surface_tag', entry.surface_tag)
    cp.set(section, 'operator', entry.operator)
    cp.set(section, 'timestamp', entry.timestamp)
    cp.set(section, 'status', entry.status)
    cp.set(section, 'reason_summary', entry.reason[:120])
    cp.set(section, 'children_tags_fingerprint',
           entry.children_tags_fingerprint)
    cp.set(section, 'value_patterns_fingerprint',
           entry.value_patterns_fingerprint)
    cp.set(section, 'naming_tokens_fingerprint',
           entry.naming_tokens_fingerprint)
    cp.set(section, 'source_proposal', entry.source_proposal)
    if entry.unbanned_by:
        cp.set(section, 'unbanned_by', entry.unbanned_by)
        cp.set(section, 'unbanned_at', entry.unbanned_at)
        cp.set(section, 'unban_reason', entry.unban_reason[:120])
    
    with index_path.open('w', encoding='utf-8') as f:
        f.write(
            "; Banned-corpus index — Phase 2 (DESIGN_team_scale_addendum.md)\n"
            "; Each section is one banned classification.\n"
            "; Drafts structurally similar to these entries are\n"
            "; suppressed by the schema-learner before operator review.\n"
            "; Appeal mechanism: change status to 'held' to disable\n"
            "; suppression during senior-engineer review.\n\n"
        )
        cp.write(f)
    
    # Markdown detail file (full reason + banned-draft text)
    md_path = _banned_root() / f"{entry.entry_id}.md"
    md_lines = [
        f"# Banned classification: `<{entry.surface_tag}>`",
        "",
        f"Entry ID: `{entry.entry_id}`",
        f"Banned by: {entry.operator}",
        f"Banned at: {entry.timestamp}",
        f"Status: {entry.status}",
        f"Source proposal: `{entry.source_proposal}`",
        "",
        OBS_OPEN,
        "## Structural fingerprint (engine observation)",
        "",
        f"- children_tags_fingerprint: `{entry.children_tags_fingerprint}`",
        f"- value_patterns_fingerprint: `{entry.value_patterns_fingerprint}`",
        f"- naming_tokens_fingerprint: `{entry.naming_tokens_fingerprint}`",
        OBS_CLOSE,
        "",
        OP_OPEN,
        "## Operator-authored reason (mandatory)",
        "",
        entry.reason,
        OP_CLOSE,
        "",
    ]
    if entry.banned_draft_text:
        md_lines.extend([
            OBS_OPEN,
            "## Banned draft text (engine observation)",
            "",
            "The following draft was classified as harmful by the operator.",
            "Future drafts structurally similar to this text will be",
            "suppressed before being shown to any operator.",
            "",
            "```",
            entry.banned_draft_text,
            "```",
            OBS_CLOSE,
            "",
        ])
    if entry.status == "unbanned":
        md_lines.extend([
            OP_OPEN,
            "## Appeal resolved — ban removed",
            "",
            f"Unbanned by: {entry.unbanned_by}",
            f"Unbanned at: {entry.unbanned_at}",
            "",
            f"Reason: {entry.unban_reason}",
            OP_CLOSE,
        ])
    md_path.write_text("\n".join(md_lines), encoding='utf-8')
    return md_path


def load_banned_entries() -> list[BannedEntry]:
    """Load all banned entries from the index."""
    index_path = _banned_index_path()
    if not index_path.is_file():
        return []
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(index_path, encoding='utf-8')
    entries = []
    for section in cp.sections():
        entries.append(BannedEntry(
            entry_id=section,
            surface_tag=cp.get(section, 'surface_tag', fallback=''),
            operator=cp.get(section, 'operator', fallback=''),
            timestamp=cp.get(section, 'timestamp', fallback=''),
            reason=cp.get(section, 'reason_summary', fallback=''),
            status=cp.get(section, 'status', fallback='active'),
            children_tags_fingerprint=cp.get(
                section, 'children_tags_fingerprint', fallback=''),
            value_patterns_fingerprint=cp.get(
                section, 'value_patterns_fingerprint', fallback=''),
            naming_tokens_fingerprint=cp.get(
                section, 'naming_tokens_fingerprint', fallback=''),
            source_proposal=cp.get(section, 'source_proposal', fallback=''),
            unbanned_by=cp.get(section, 'unbanned_by', fallback=''),
            unbanned_at=cp.get(section, 'unbanned_at', fallback=''),
            unban_reason=cp.get(section, 'unban_reason', fallback=''),
        ))
    return entries


# ---------------------------------------------------------------------------
# Sideline-queue storage
# ---------------------------------------------------------------------------

def _sideline_root() -> Path:
    p = _TOOLKIT_ROOT / "schema_learner" / "sideline"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _sideline_queue_path() -> Path:
    return _sideline_root() / "_sideline_queue.ini"


def compute_sla_tier(occurrence_count: int) -> int:
    """Per addendum Decision #4: 1-2 / 3-9 / 10+ tiers."""
    if occurrence_count >= 10:
        return 3
    if occurrence_count >= 3:
        return 2
    return 1


def write_sideline_entry(entry: SidelineEntry) -> Path:
    """Write a sideline entry: append/update queue index, write detail md.
    
    If an entry for this surface_tag already exists (matched by entry_id),
    the occurrence_count is incremented and last_seen_* fields are
    updated. Otherwise a new entry is created.
    """
    queue_path = _sideline_queue_path()
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    if queue_path.is_file():
        cp.read(queue_path, encoding='utf-8')
    
    section = entry.entry_id
    if cp.has_section(section):
        # Update existing entry — bump occurrence, update last_seen
        existing_count = cp.getint(section, 'occurrence_count', fallback=1)
        new_count = existing_count + 1
        cp.set(section, 'occurrence_count', str(new_count))
        cp.set(section, 'sla_tier', str(compute_sla_tier(new_count)))
        cp.set(section, 'last_seen_in', entry.last_seen_in or entry.first_seen_in)
        cp.set(section, 'last_seen_at', entry.last_seen_at or entry.timestamp)
    else:
        # New entry
        cp.add_section(section)
        cp.set(section, 'surface_tag', entry.surface_tag)
        cp.set(section, 'operator', entry.operator)
        cp.set(section, 'timestamp', entry.timestamp)
        cp.set(section, 'occurrence_count', '1')
        cp.set(section, 'sla_tier', '1')
        cp.set(section, 'first_seen_in', entry.first_seen_in)
        cp.set(section, 'last_seen_in', entry.last_seen_in or entry.first_seen_in)
        cp.set(section, 'last_seen_at',
               entry.last_seen_at or entry.timestamp)
        cp.set(section, 'status', entry.status)
        cp.set(section, 'children_tags_fingerprint',
               entry.children_tags_fingerprint)
        cp.set(section, 'value_patterns_fingerprint',
               entry.value_patterns_fingerprint)
        cp.set(section, 'naming_tokens_fingerprint',
               entry.naming_tokens_fingerprint)
        cp.set(section, 'source_proposal', entry.source_proposal)
        cp.set(section, 'reason_summary', entry.reason[:120])
    
    with queue_path.open('w', encoding='utf-8') as f:
        f.write(
            "; Sideline queue — Phase 2 (DESIGN_team_scale_addendum.md)\n"
            "; Surfaces awaiting deep research.\n"
            "; SLA tiers (Decision #4):\n"
            ";   tier 1 (1-2 occurrences):  indefinite\n"
            ";   tier 2 (3-9 occurrences):  30-day SLA\n"
            ";   tier 3 (10+ occurrences):   7-day SLA\n"
            "; Senior engineer owns queue burndown (Phase 4 workflow).\n\n"
        )
        cp.write(f)
    
    # Markdown detail file (operator's note about why sidelined)
    md_path = _sideline_root() / f"{entry.entry_id}.md"
    if md_path.is_file():
        # Append occurrence note to existing detail
        md_lines = [md_path.read_text(encoding='utf-8'), ""]
        md_lines.extend([
            f"---",
            f"",
            f"## Re-sidelined occurrence at {entry.last_seen_at or entry.timestamp}",
            f"",
            f"By: {entry.operator}",
            f"In source: {entry.last_seen_in or entry.first_seen_in}",
            "",
        ])
        md_path.write_text("\n".join(md_lines), encoding='utf-8')
    else:
        # New detail file
        md_lines = [
            f"# Sideline: `<{entry.surface_tag}>`",
            "",
            f"Entry ID: `{entry.entry_id}`",
            f"First sidelined by: {entry.operator}",
            f"First sidelined at: {entry.timestamp}",
            f"Status: {entry.status}",
            f"Source proposal: `{entry.source_proposal}`",
            "",
            OBS_OPEN,
            "## Structural fingerprint (engine observation)",
            "",
            f"- children_tags_fingerprint: `{entry.children_tags_fingerprint}`",
            f"- value_patterns_fingerprint: `{entry.value_patterns_fingerprint}`",
            f"- naming_tokens_fingerprint: `{entry.naming_tokens_fingerprint}`",
            OBS_CLOSE,
            "",
            OP_OPEN,
            "## Operator's reason for sideline",
            "",
            entry.reason or "(no reason provided)",
            OP_CLOSE,
            "",
        ]
        md_path.write_text("\n".join(md_lines), encoding='utf-8')
    return md_path


def load_sideline_queue() -> list[SidelineEntry]:
    """Load all sideline entries, sorted by occurrence_count desc
    (highest-impact surfaces first)."""
    queue_path = _sideline_queue_path()
    if not queue_path.is_file():
        return []
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(queue_path, encoding='utf-8')
    entries = []
    for section in cp.sections():
        entries.append(SidelineEntry(
            entry_id=section,
            surface_tag=cp.get(section, 'surface_tag', fallback=''),
            operator=cp.get(section, 'operator', fallback=''),
            timestamp=cp.get(section, 'timestamp', fallback=''),
            reason=cp.get(section, 'reason_summary', fallback=''),
            occurrence_count=cp.getint(
                section, 'occurrence_count', fallback=1),
            first_seen_in=cp.get(section, 'first_seen_in', fallback=''),
            last_seen_in=cp.get(section, 'last_seen_in', fallback=''),
            last_seen_at=cp.get(section, 'last_seen_at', fallback=''),
            sla_tier=cp.getint(section, 'sla_tier', fallback=1),
            status=cp.get(section, 'status', fallback='open'),
            assigned_to=cp.get(section, 'assigned_to', fallback=''),
            assigned_at=cp.get(section, 'assigned_at', fallback=''),
            children_tags_fingerprint=cp.get(
                section, 'children_tags_fingerprint', fallback=''),
            value_patterns_fingerprint=cp.get(
                section, 'value_patterns_fingerprint', fallback=''),
            naming_tokens_fingerprint=cp.get(
                section, 'naming_tokens_fingerprint', fallback=''),
            source_proposal=cp.get(section, 'source_proposal', fallback=''),
        ))
    entries.sort(key=lambda e: (-e.occurrence_count, e.surface_tag))
    return entries


# ---------------------------------------------------------------------------
# Fingerprint helpers
# ---------------------------------------------------------------------------

def fingerprint_from_feature_vector(fv) -> dict[str, str]:
    """Compute a structural fingerprint from a feature vector.
    
    Returns a dict with three string fingerprints suitable for
    storing in INI fields:
      children_tags_fingerprint: comma-separated, sorted top-20
      value_patterns_fingerprint: comma-separated key:value pairs
      naming_tokens_fingerprint: comma-separated tokens
    
    These are the inputs to the suppression-similarity check.
    """
    children = sorted(fv.children_tags.keys())[:20] if fv.children_tags else []
    values = sorted(f"{k}:{v}" for k, v in fv.value_patterns.items())[:20]
    tokens = list(fv.naming_tokens)
    return {
        'children_tags_fingerprint': ', '.join(children),
        'value_patterns_fingerprint': ', '.join(values),
        'naming_tokens_fingerprint': ', '.join(tokens),
    }


def _jaccard_similarity(a_csv: str, b_csv: str) -> float:
    """Jaccard set similarity between two comma-separated strings."""
    if not a_csv and not b_csv:
        return 0.0
    a = {x.strip() for x in a_csv.split(',') if x.strip()}
    b = {x.strip() for x in b_csv.split(',') if x.strip()}
    if not a and not b:
        return 0.0
    union = a | b
    if not union:
        return 0.0
    return len(a & b) / len(union)


def banned_suppression_similarity(
    candidate_fingerprint: dict[str, str],
    banned_entry: BannedEntry,
) -> float:
    """Compute aggregate similarity between a candidate's fingerprint
    and a banned entry. Used by the suppression check.
    
    Aggregate: weighted Jaccard across the three fingerprint dimensions,
    with weights re-normalized when a dimension is empty on BOTH sides
    (i.e., uninformative for this comparison). For leaf XML elements
    with no children, the children/values dimensions are empty by
    nature; without renormalization those zero contributions would
    artificially deflate the aggregate, making suppression impossible
    on naming alone.
    
    Naming tokens are weighted slightly higher because surface-name
    similarity is the strongest banned-pattern signal.
    
    Returns float in [0, 1]. Compare against
    config.banned_suppress_threshold (default 0.80, Decision #2).
    """
    # Per-dimension Jaccard scores
    children_sim = _jaccard_similarity(
        candidate_fingerprint['children_tags_fingerprint'],
        banned_entry.children_tags_fingerprint)
    values_sim = _jaccard_similarity(
        candidate_fingerprint['value_patterns_fingerprint'],
        banned_entry.value_patterns_fingerprint)
    naming_sim = _jaccard_similarity(
        candidate_fingerprint['naming_tokens_fingerprint'],
        banned_entry.naming_tokens_fingerprint)
    
    # Default weights
    w_children, w_values, w_naming = 0.30, 0.30, 0.40
    
    # Renormalize: if a dimension is empty on BOTH candidate and banned,
    # it's uninformative — drop its weight from the average.
    candidate_has_children = bool(
        candidate_fingerprint['children_tags_fingerprint'])
    banned_has_children = bool(banned_entry.children_tags_fingerprint)
    candidate_has_values = bool(
        candidate_fingerprint['value_patterns_fingerprint'])
    banned_has_values = bool(banned_entry.value_patterns_fingerprint)
    
    active_weight_total = w_naming  # naming is always considered
    weighted_sum = w_naming * naming_sim
    
    if candidate_has_children or banned_has_children:
        active_weight_total += w_children
        weighted_sum += w_children * children_sim
    if candidate_has_values or banned_has_values:
        active_weight_total += w_values
        weighted_sum += w_values * values_sim
    
    if active_weight_total == 0:
        return 0.0
    return weighted_sum / active_weight_total


def check_banned_suppression(
    candidate_fingerprint: dict[str, str],
    candidate_surface_tag: str,
    threshold: float = 0.80,
) -> tuple[BannedEntry, float] | None:
    """Check whether a candidate matches any active banned entry above
    threshold. Returns the matched entry and similarity, or None on miss.
    
    Per addendum disambiguation: a draft is suppressed only if BOTH
    the surface tag matches AND the structural fingerprint exceeds
    threshold. Prevents "draft was wrong for surface A" from
    suppressing similar draft for surface B.
    """
    banned_entries = load_banned_entries()
    best: tuple[BannedEntry, float] | None = None
    best_sim = 0.0
    for entry in banned_entries:
        if entry.status != 'active':
            continue  # held / unbanned / restored entries don't suppress
        if entry.surface_tag != candidate_surface_tag:
            # Surface tag must match (per addendum disambiguation rule)
            continue
        sim = banned_suppression_similarity(candidate_fingerprint, entry)
        if sim >= threshold and sim > best_sim:
            best_sim = sim
            best = (entry, sim)
    return best


# ---------------------------------------------------------------------------
# Sideline match-back (re-occurrence detection)
# ---------------------------------------------------------------------------

def find_existing_sideline_entry(
    surface_tag: str,
    fingerprint: dict[str, str],
    similarity_threshold: float = 0.80,
) -> SidelineEntry | None:
    """Check if a sidelined surface already exists for this tag with
    similar fingerprint. Used to bump occurrence_count instead of
    creating a duplicate sideline entry."""
    queue = load_sideline_queue()
    for entry in queue:
        if entry.surface_tag != surface_tag:
            continue
        sim = (
            _jaccard_similarity(
                fingerprint['children_tags_fingerprint'],
                entry.children_tags_fingerprint) * 0.30
            + _jaccard_similarity(
                fingerprint['value_patterns_fingerprint'],
                entry.value_patterns_fingerprint) * 0.30
            + _jaccard_similarity(
                fingerprint['naming_tokens_fingerprint'],
                entry.naming_tokens_fingerprint) * 0.40
        )
        if sim >= similarity_threshold:
            return entry
    return None


def find_deferred_sideline_entry(
    surface_tag: str,
    fingerprint: dict[str, str],
    similarity_threshold: float = 0.80,
) -> SidelineEntry | None:
    """Phase 6.5: find a sideline entry that was Phase-6-deferred for
    this surface tag with similar fingerprint.
    
    Only matches entries with status='deferred_disabled_in_source'.
    Other sideline statuses (open, in_research, etc) are NOT candidates
    for auto-promotion — those are operator-driven and require
    operator-driven resolution.
    
    Scoring nuance: when a fingerprint dimension is empty on BOTH the
    candidate and the entry (e.g., both surfaces have no children
    tags), we treat that dimension as 'agreement' rather than '0.0
    similarity.' Empty-vs-empty in Jaccard is mathematically undefined
    (0/0); the principled fix is to drop empty-on-both dimensions from
    the score and renormalize the remaining weights to sum to 1.0.
    
    This handles the common simple-leaf case correctly: a deferred
    <Botnet> (no children, no value patterns, tokens='botnet') and a
    new <Botnet>1</Botnet> (same shape) match on the only
    discriminating dimension (tokens) with full weight, not 40%.
    """
    queue = load_sideline_queue()
    
    # Slot weights matching the original three-dimension scoring
    base_weights = {
        'children_tags_fingerprint': 0.30,
        'value_patterns_fingerprint': 0.30,
        'naming_tokens_fingerprint': 0.40,
    }
    
    for entry in queue:
        if entry.surface_tag != surface_tag:
            continue
        if entry.status != 'deferred_disabled_in_source':
            continue
        
        # Score with empty-on-both-dimensions dropped + renormalized
        entry_values = {
            'children_tags_fingerprint': entry.children_tags_fingerprint,
            'value_patterns_fingerprint': entry.value_patterns_fingerprint,
            'naming_tokens_fingerprint': entry.naming_tokens_fingerprint,
        }
        active_weights: dict[str, float] = {}
        for slot, weight in base_weights.items():
            cand_empty = not fingerprint[slot].strip()
            entry_empty = not entry_values[slot].strip()
            if cand_empty and entry_empty:
                # Empty on both — drop from scoring (agreement, not
                # 0.0 similarity)
                continue
            active_weights[slot] = weight
        
        if not active_weights:
            # Both fingerprints are entirely empty. Only the
            # surface_tag matched. That's still a legitimate match —
            # there's no discriminating info to argue against it.
            return entry
        
        # Renormalize so active weights sum to 1.0
        weight_sum = sum(active_weights.values())
        sim = 0.0
        for slot, weight in active_weights.items():
            normalized_weight = weight / weight_sum
            sim += _jaccard_similarity(
                fingerprint[slot], entry_values[slot]) * normalized_weight
        
        if sim >= similarity_threshold:
            return entry
    return None


def transition_sideline_status(
    entry_id: str,
    new_status: str,
    transition_note: str = "",
) -> bool:
    """Phase 6.5: change a sideline entry's status. Used by the
    auto-promotion machinery to mark a previously-deferred entry as
    'pending_triage' so it doesn't get re-promoted on subsequent runs.
    
    Returns True if transition succeeded, False if entry not found.
    
    The transition note is appended to the existing reason_summary
    so the audit trail captures WHY the status changed.
    """
    queue_path = _sideline_queue_path()
    if not queue_path.is_file():
        return False
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(queue_path, encoding='utf-8')
    if not cp.has_section(entry_id):
        return False
    cp.set(entry_id, 'status', new_status)
    if transition_note:
        existing_reason = cp.get(entry_id, 'reason_summary', fallback='')
        cp.set(entry_id, 'reason_summary',
               f"{existing_reason} | TRANSITION: {transition_note}"[:500])
    with queue_path.open('w', encoding='utf-8') as f:
        f.write(
            "; Sideline queue — Phase 2/6 (DESIGN_team_scale_addendum.md)\n"
            "; Surfaces awaiting deep research or auto-promoted from\n"
            "; Phase 6 deferral. Status field is authoritative for the\n"
            "; lifecycle stage of each entry.\n\n"
        )
        cp.write(f)
    return True


# ---------------------------------------------------------------------------
# Entry ID generation
# ---------------------------------------------------------------------------

def make_entry_id(surface_tag: str, kind: str = "ban") -> str:
    """Generate a unique entry ID from surface tag and timestamp.
    Suitable for filesystem use."""
    import re
    safe_tag = re.sub(r'[^a-zA-Z0-9_-]', '_', surface_tag)
    ts = _dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    return f"{kind}_{safe_tag}_{ts}"
