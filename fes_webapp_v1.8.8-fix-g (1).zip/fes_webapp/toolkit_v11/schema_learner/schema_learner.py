#!/usr/bin/env python3
"""
schema_learner.py
=================

Mission A engine from DESIGN.md. Given a new XML config, identifies
what's structurally novel relative to the existing schema, presents
findings to the operator with structural observations only (no semantic
claims), and requires operator declarations + citations before any
merge into the INI bundles.

Founding principle (binds every line of this module):

    No claim without provenance.
    
    Every observation reported by this engine is a STRUCTURAL FACT
    about the XML — a count, a similarity score, a presence/absence.
    The engine NEVER claims semantic meaning, NEVER suggests vendor
    mappings, NEVER hints at categories. Those determinations are
    operator-authored with cited sources.

Architectural model (from algebraic-design discipline):

    NewXML × ExistingSchema = Findings
    Findings + OperatorDeclarations + Citations = ApprovedMerge
    
    The engine produces Findings (structural).
    The operator produces Declarations (semantic).
    The engine refuses to merge until both exist with citations.

Run:
    python3 schema_learner.py --config learn_config.ini --input corpus/TEMPLATE_FW.xml

Output:
    proposals/<date>_<source>/
        findings.md                          (technical summary)
        findings.json                        (machine-readable)
        OPERATOR_INTERVENTION_REQUIRED.md    (the action contract)
        proposed_diff.md                     (summary of INI changes)
        merge_preview/                       (staged INI changes
                                              awaiting approval)
"""
from __future__ import annotations

import argparse
import configparser
import datetime as _dt
import json
import sys
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Make schema_lib importable when running from this directory
_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))
from schema_lib import validate_at_startup  # noqa: E402

# Local imports
from feature_vectors import (  # noqa: E402
    ElementFeatureVector,
    Vocabulary,
    extract_features_from_file,
    extract_features_from_tree,
    structural_similarity_sparse,
    vectorize_sparse,
)


# Markers from test_schema_learner_provenance.py — the engine MUST
# wrap structural observations in these markers so the audit knows
# they're observations, not claims.
OBS_OPEN = "<!-- ENGINE-OBSERVATION-BEGIN -->"
OBS_CLOSE = "<!-- ENGINE-OBSERVATION-END -->"
OP_OPEN = "<!-- OPERATOR-AUTHORED-BEGIN -->"
OP_CLOSE = "<!-- OPERATOR-AUTHORED-END -->"


# ---------------------------------------------------------------------------
# Finding dataclass
# ---------------------------------------------------------------------------

@dataclass
class Finding:
    """One structural observation about a novel or changed element.
    
    Per DESIGN.md, four categories:
    
        1. novel_element_type — element doesn't exist in current schema
        2. new_shape          — element exists, new field combination
        3. new_field          — element exists, this shape exists,
                                but a new field appears in this shape
        4. new_value          — element exists, field exists, but a
                                value is observed that's not in the
                                known set (typically enum expansion)
    
    A finding contains STRUCTURAL OBSERVATIONS only. It contains
    NO semantic claims. Operator declarations are added later.
    """
    category: str  # one of the four above
    element_tag: str
    source_file: str  # which corpus entry surfaced this finding
    
    # For categories 2/3/4: which shape / field / value is new
    detail: dict[str, Any] = field(default_factory=dict)
    
    # Structural neighbors: top-K elements with highest structural
    # similarity in the existing schema. Presented to operator as
    # CONTEXT, never as a kinship claim.
    neighbors: list[tuple[str, float, dict[str, float]]] = field(
        default_factory=list)
    
    # Confidence in the structural placement proposal (0.0 if no
    # placement is being proposed because all neighbors below threshold)
    placement_confidence: float = 0.0
    
    # The feature vector itself, for proposal-time analysis
    feature_vector: ElementFeatureVector | None = None

    # Phase 6: tier filtering metadata. Computed by the engine from
    # observed XML data alone (no HTML required). One of:
    #
    #   "enabled"  — observed evidence the surface is ACTIVE in the
    #                source config. Examples: leaf <Tag>1</Tag> with
    #                value 1/true/yes/on; populated container with
    #                at least one enabled child.
    #
    #   "disabled" — observed evidence the surface is INACTIVE in the
    #                source. Examples: leaf <Tag>0</Tag>; explicit
    #                <enabled>false</enabled> child; empty container.
    #
    #   "unknown"  — no clear enabled signal detected. Most surfaces
    #                fall here (free-text values, complex containers
    #                without clear on/off semantics). Operator triages
    #                normally — Phase 6 makes no claim either way.
    #
    # tier_suggestion follows from enabled_status:
    #   1 — enabled or unknown: full triage recommended
    #   2 — disabled with substantive config: defer triage, emitter
    #       must preserve settings byte-for-byte
    #   3 — disabled with no substantive config: auto-skip OK
    enabled_status: str = "unknown"
    tier_suggestion: int = 1
    enabled_status_evidence: str = ""


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

@dataclass
class LearnerConfig:
    """Driving config, loaded from learn_config.ini."""
    corpus_dir: Path
    existing_schema_path: Path
    proposals_dir: Path
    findings_format: str
    auto_propose_minimum: float
    high_confidence: float
    medium_confidence: float
    top_k_neighbors: int
    neighbor_minimum_similarity: float
    # Phase 1 — approved-corpus auto-reuse
    auto_reuse_threshold: float
    auto_reuse_emit_provenance: bool
    auto_reuse_report_findings: bool
    # Phase 2 — banned-corpus suppression
    banned_suppress_threshold: float
    require_operator_approval: bool
    report_unplaceable_findings: bool
    backup_before_merge: bool

    @classmethod
    def from_ini(cls, config_path: Path) -> "LearnerConfig":
        cp = configparser.ConfigParser(interpolation=None,
                                       inline_comment_prefixes=(';',))
        cp.optionxform = str
        cp.read(config_path, encoding='utf-8')
        base = config_path.parent

        def _path(s: str) -> Path:
            p = Path(s)
            return p if p.is_absolute() else (base / p).resolve()

        return cls(
            corpus_dir=_path(cp.get('io', 'corpus_dir')),
            existing_schema_path=_path(cp.get('io', 'existing_schema_path')),
            proposals_dir=_path(cp.get('io', 'proposals_dir')),
            findings_format=cp.get('io', 'findings_format'),
            auto_propose_minimum=cp.getfloat(
                'thresholds', 'auto_propose_minimum'),
            high_confidence=cp.getfloat('thresholds', 'high_confidence'),
            medium_confidence=cp.getfloat('thresholds', 'medium_confidence'),
            top_k_neighbors=cp.getint('reporting', 'top_k_neighbors'),
            neighbor_minimum_similarity=cp.getfloat(
                'reporting', 'neighbor_minimum_similarity'),
            auto_reuse_threshold=cp.getfloat(
                'auto_reuse', 'similarity_threshold'),
            auto_reuse_emit_provenance=cp.getboolean(
                'auto_reuse', 'emit_provenance_comment'),
            auto_reuse_report_findings=cp.getboolean(
                'auto_reuse', 'report_auto_reused_findings'),
            banned_suppress_threshold=cp.getfloat(
                'banned_suppression', 'similarity_threshold'),
            require_operator_approval=cp.getboolean(
                'behavior', 'require_operator_approval'),
            report_unplaceable_findings=cp.getboolean(
                'behavior', 'report_unplaceable_findings'),
            backup_before_merge=cp.getboolean(
                'behavior', 'backup_before_merge'),
        )


class SchemaLearner:
    """The Mission A engine.
    
    Process:
      1. Load existing-schema element types (the baseline).
      2. Load corpus features (existing observations of those types
         across the corpus, used as the reference for novelty detection).
      3. Extract features from the input XML.
      4. For each element type in the input:
           - Is it in the existing schema? If not -> Category 1.
           - If yes: are its shapes new? If so -> Category 2.
           - For known shapes: are there new fields? -> Category 3.
           - For known fields: are there new values? -> Category 4.
      5. For each Category-1 finding, compute top-K structural neighbors
         from the existing corpus.
      6. Write findings.md, findings.json, OPERATOR_INTERVENTION_REQUIRED.md,
         proposed_diff.md, and merge_preview/ to a dated proposal dir.
    """

    def __init__(self, config: LearnerConfig) -> None:
        self.config = config
        self.vocab = Vocabulary()

        # Features observed across the corpus (for similarity comparisons)
        self.corpus_features: dict[str, ElementFeatureVector] = {}

        # Element types present in the existing schema (baseline for novelty)
        self.existing_schema_tags: set[str] = set()
        self.existing_allowed_fields: dict[str, set[str]] = {}

    def load_existing_schema(self) -> None:
        """Read wg_xml_schema.ini and record which element types and
        which fields-per-element are currently known."""
        cp = configparser.ConfigParser(interpolation=None,
                                       inline_comment_prefixes=(';',))
        cp.optionxform = str
        cp.read(self.config.existing_schema_path, encoding='utf-8')

        # Auto-detect the element-section prefix. The toolkit's
        # wg_xml_schema uses 'element.<tag>' but other vendor schemas
        # might use 'xml_element.<tag>' or similar. Look for the most
        # common prefix.
        from collections import Counter as _Counter
        prefixes = _Counter()
        for sect in cp.sections():
            if '.' in sect:
                prefix = sect.split('.', 1)[0]
                if prefix != 'meta':
                    prefixes[prefix] += 1
        # Use the dominant prefix
        if not prefixes:
            return
        element_prefix = prefixes.most_common(1)[0][0] + '.'

        for sect in cp.sections():
            if not sect.startswith(element_prefix):
                continue
            tag = sect[len(element_prefix):]
            self.existing_schema_tags.add(tag)
            # Extract allowed_fields if declared
            if cp.has_option(sect, 'allowed_fields'):
                fields_str = cp.get(sect, 'allowed_fields')
                fields = {f.strip() for f in fields_str.replace('\n', ',').split(',')
                          if f.strip()}
                self.existing_allowed_fields[tag] = fields

    def load_corpus(self) -> None:
        """Load corpus index and extract features from each entry
        flagged with role 'reference' or 'schema_source'.
        
        If the corpus index file doesn't exist or is empty, log
        the situation and continue with an empty corpus. This is
        a valid first-run state for a fresh team:
        
          - schema validation will still work (uses wg_xml_schema.ini)
          - novelty detection will still work (every surface is novel)
          - auto-reuse will simply have nothing to reuse from
        
        The first real customer config processed becomes the seed
        for the corpus once its findings are merged.
        """
        index_path = self.config.corpus_dir / '_corpus_index.ini'
        if not index_path.is_file():
            print(f"[schema_learner]   no corpus index at "
                  f"{index_path.name} — treating as empty corpus")
            print(f"[schema_learner]   (this is normal for a fresh team; "
                  f"the index gets populated as configs are merged)")
            return

        cp = configparser.ConfigParser(interpolation=None,
                                       inline_comment_prefixes=(';',))
        cp.optionxform = str
        cp.read(index_path, encoding='utf-8')

        if not cp.sections():
            print(f"[schema_learner]   corpus index is empty "
                  f"({index_path.name})")
            return

        loaded_count = 0
        for entry_name in cp.sections():
            if entry_name == 'meta':
                continue
            if not cp.has_option(entry_name, 'roles'):
                continue
            roles = {r.strip() for r in
                     cp.get(entry_name, 'roles').split(',') if r.strip()}
            # We learn from both reference AND schema_source corpus entries
            if not (roles & {'reference', 'schema_source'}):
                continue
            file_rel = cp.get(entry_name, 'file')
            xml_path = self.config.corpus_dir / file_rel
            if not xml_path.is_file():
                print(f"  [warn] corpus file missing: {xml_path}",
                      file=sys.stderr)
                continue

            features = extract_features_from_file(xml_path,
                                                   source_label=entry_name)
            for tag, fv in features.items():
                # Merge feature vectors across corpus entries:
                # if the same tag appears in multiple corpus entries,
                # we accumulate observations.
                if tag in self.corpus_features:
                    self._merge_feature_vector(
                        self.corpus_features[tag], fv)
                else:
                    self.corpus_features[tag] = fv
                self.vocab.absorb(fv)
            loaded_count += 1
        print(f"[schema_learner]   loaded {loaded_count} corpus entries, "
              f"{len(self.corpus_features)} unique element types observed")

    @staticmethod
    def _merge_feature_vector(
        accumulator: ElementFeatureVector,
        new: ElementFeatureVector,
    ) -> None:
        """Merge structural observations from a second corpus entry
        into the accumulated feature vector. Counts add; sets union."""
        accumulator.instance_count += new.instance_count
        accumulator.children_tags.update(new.children_tags)
        accumulator.field_shapes.update(new.field_shapes)
        accumulator.siblings.update(new.siblings)
        accumulator.reference_targets.update(new.reference_targets)
        # value_patterns: keep the existing entries, add new ones
        for k, v in new.value_patterns.items():
            if k not in accumulator.value_patterns:
                accumulator.value_patterns[k] = v
        for src in new.source_files:
            if src not in accumulator.source_files:
                accumulator.source_files.append(src)
        # Phase 6: merge enabled-status signal data
        for val in new.sample_own_text_values:
            if val not in accumulator.sample_own_text_values:
                if len(accumulator.sample_own_text_values) < 8:
                    accumulator.sample_own_text_values.append(val)
        accumulator.leaf_with_value_count += new.leaf_with_value_count

    @staticmethod
    def _compute_enabled_status(
        fv: ElementFeatureVector,
    ) -> tuple[str, int, str]:
        """Phase 6: derive (enabled_status, tier_suggestion, evidence)
        from the feature vector.
        
        Three patterns checked, in order of confidence:
        
          Pattern A — leaf-with-boolean-value:
            Element has no children, observed text values are
            boolean-style (0/1, true/false, yes/no, enabled/disabled,
            on/off). Direct read of enabled status.
          
          Pattern B — empty container:
            Element has no children AND no observed text. Treated as
            disabled-no-config (Tier 3 candidate).
          
          Pattern C — populated container:
            Element has children. Cannot infer enabled status from
            the container alone; defer to operator. Tier 1.
        
        Returns ("enabled"|"disabled"|"unknown", tier_int, evidence_str).
        Evidence is a short string suitable for findings output.
        """
        # Pattern A: leaf with boolean-style values
        if fv.sample_own_text_values and not fv.children_tags:
            values_lower = [v.lower() for v in fv.sample_own_text_values]
            enabled_markers = {'1', 'true', 'yes', 'on', 'enabled', 'enable'}
            disabled_markers = {'0', 'false', 'no', 'off',
                                 'disabled', 'disable'}
            
            all_enabled = all(v in enabled_markers for v in values_lower)
            all_disabled = all(v in disabled_markers for v in values_lower)
            
            if all_enabled and not all_disabled:
                return ("enabled", 1,
                        f"leaf value={fv.sample_own_text_values[0]!r}")
            if all_disabled and not all_enabled:
                return ("disabled", 3,
                        f"leaf value={fv.sample_own_text_values[0]!r}; "
                        f"no nested config")
            # Mixed: some instances enabled, some disabled — operator
            # must distinguish; treat as Tier 1
            if any(v in enabled_markers for v in values_lower) and \
                    any(v in disabled_markers for v in values_lower):
                return ("unknown", 1,
                        f"mixed values observed: "
                        f"{fv.sample_own_text_values[:3]}")
        
        # Pattern B: empty container (no children, no text)
        if not fv.children_tags and not fv.sample_own_text_values:
            return ("disabled", 3,
                    "empty container (no children, no text values)")
        
        # Pattern C: populated container or free-text leaf
        # We can't easily infer enabled status; defer to operator
        return ("unknown", 1, "no enabled/disabled signal detected")

    def detect_findings(
        self,
        input_xml: Path,
        source_label: str,
    ) -> list[Finding]:
        """Run the four-category novelty detection against the input XML.
        
        Phase 1 (auto-reuse): before classifying a novel surface as
        Category 1, check whether it matches an approved-corpus entry
        by structural similarity. If so, mark auto_reused.
        
        Phase 2 (banned-suppression): when no auto-reuse match, check
        whether the surface matches a banned-corpus entry. If so,
        route directly to the sideline queue (no Category-1 finding,
        no operator triage shown).
        
        Returns a list of Findings, ordered by category (auto-reuse
        and banned-suppressed first as informational, then 1-4).
        """
        # Lazy import to avoid circular dependency at module load
        from corpus_tiers import (
            check_banned_suppression,
            fingerprint_from_feature_vector,
            find_existing_sideline_entry,
            find_deferred_sideline_entry,
            make_entry_id,
            SidelineEntry,
            transition_sideline_status,
            write_sideline_entry,
        )

        input_features = extract_features_from_file(
            input_xml, source_label=source_label)
        for fv in input_features.values():
            self.vocab.absorb(fv)

        findings: list[Finding] = []

        # Threshold for banned suppression — Decision #2: 0.80
        banned_threshold = getattr(
            self.config, 'banned_suppress_threshold', 0.80)

        for tag, fv in input_features.items():
            # Phase 1: auto-reuse check
            if tag not in self.existing_schema_tags:
                auto_reuse_match = self._check_auto_reuse(tag, fv)
                if auto_reuse_match is not None:
                    matched_tag, similarity = auto_reuse_match
                    findings.append(Finding(
                        category='auto_reused',
                        element_tag=tag,
                        source_file=source_label,
                        detail={
                            'matched_approved_corpus_entry': matched_tag,
                            'structural_similarity': round(similarity, 4),
                            'reuse_reason': (
                                f'aggregate structural similarity '
                                f'{similarity:.4f} >= threshold '
                                f'{self.config.auto_reuse_threshold}'
                            ),
                        },
                        feature_vector=fv,
                        placement_confidence=similarity,
                    ))
                    continue

                # Phase 2: banned-corpus suppression check
                fingerprint = fingerprint_from_feature_vector(fv)
                banned_match = check_banned_suppression(
                    fingerprint, tag, threshold=banned_threshold)
                if banned_match is not None:
                    banned_entry, banned_sim = banned_match
                    # Route to sideline queue (don't show operator the
                    # banned draft; route surface for deep research)
                    sideline_id = (
                        find_existing_sideline_entry(tag, fingerprint).entry_id
                        if find_existing_sideline_entry(tag, fingerprint)
                        else make_entry_id(tag, 'sl')
                    )
                    sideline_entry = SidelineEntry(
                        entry_id=sideline_id,
                        surface_tag=tag,
                        operator='schema_learner_engine',
                        timestamp=_dt.datetime.now().isoformat(),
                        reason=(
                            f'auto-routed from banned-corpus suppression '
                            f'(matched banned entry {banned_entry.entry_id}, '
                            f'similarity {banned_sim:.3f}). '
                            f'Needs deep research to produce non-banned '
                            f'classification.'
                        ),
                        first_seen_in=source_label,
                        last_seen_in=source_label,
                        last_seen_at=_dt.datetime.now().isoformat(),
                        source_proposal=source_label,
                        children_tags_fingerprint=fingerprint[
                            'children_tags_fingerprint'],
                        value_patterns_fingerprint=fingerprint[
                            'value_patterns_fingerprint'],
                        naming_tokens_fingerprint=fingerprint[
                            'naming_tokens_fingerprint'],
                    )
                    write_sideline_entry(sideline_entry)
                    findings.append(Finding(
                        category='banned_suppressed',
                        element_tag=tag,
                        source_file=source_label,
                        detail={
                            'banned_entry_id': banned_entry.entry_id,
                            'banned_by': banned_entry.operator,
                            'banned_at': banned_entry.timestamp,
                            'suppression_similarity': round(banned_sim, 4),
                            'routed_to_sideline': sideline_id,
                            'suppression_reason': (
                                f'structural similarity {banned_sim:.4f} '
                                f'to active banned entry exceeds threshold '
                                f'{banned_threshold}'
                            ),
                        },
                        feature_vector=fv,
                        placement_confidence=banned_sim,
                    ))
                    continue

                # Phase 6.5: auto-promotion check — was this surface
                # previously deferred (Phase 6) because it was disabled
                # in some prior source config? If so, AND the current
                # appearance is not clearly disabled, promote it back
                # into active triage with the original deferral context.
                status, tier, evidence = self._compute_enabled_status(fv)
                if status != 'disabled':
                    deferred_match = find_deferred_sideline_entry(
                        tag, fingerprint)
                    if deferred_match is not None:
                        # Transition the sideline entry so it doesn't
                        # auto-promote again on subsequent runs.
                        transition_sideline_status(
                            deferred_match.entry_id,
                            new_status='pending_triage',
                            transition_note=(
                                f'auto-promoted in {source_label}: '
                                f'enabled_status={status}, '
                                f'evidence={evidence[:80]}'
                            ),
                        )
                        finding = Finding(
                            category='auto_promoted_from_deferred',
                            element_tag=tag,
                            source_file=source_label,
                            detail={
                                'sideline_entry_id': deferred_match.entry_id,
                                'original_deferral_reason': (
                                    deferred_match.reason[:300]),
                                'original_source_proposal': (
                                    deferred_match.source_proposal),
                                'original_deferred_at': (
                                    deferred_match.timestamp),
                                'new_status_evidence': evidence,
                            },
                            feature_vector=fv,
                            enabled_status=status,
                            tier_suggestion=tier,
                            enabled_status_evidence=evidence,
                        )
                        self._compute_neighbors(finding, fv)
                        findings.append(finding)
                        continue

                # No auto-reuse, no banned suppression, no deferred
                # promotion — Category 1 (novel)
                finding = Finding(
                    category='novel_element_type',
                    element_tag=tag,
                    source_file=source_label,
                    feature_vector=fv,
                    enabled_status=status,
                    tier_suggestion=tier,
                    enabled_status_evidence=evidence,
                )
                self._compute_neighbors(finding, fv)
                findings.append(finding)
                continue

            # Element exists in schema. Check for new shapes (Category 2).
            existing_fv = self.corpus_features.get(tag)
            if existing_fv is None:
                continue

            for shape in fv.field_shapes:
                if shape not in existing_fv.field_shapes:
                    findings.append(Finding(
                        category='new_shape',
                        element_tag=tag,
                        source_file=source_label,
                        detail={
                            'new_shape_fields': list(shape),
                            'known_shapes': [
                                list(s) for s in existing_fv.field_shapes
                            ],
                        },
                        feature_vector=fv,
                    ))

            new_fields = set(fv.children_tags) - set(existing_fv.children_tags)
            for new_field in new_fields:
                findings.append(Finding(
                    category='new_field',
                    element_tag=tag,
                    source_file=source_label,
                    detail={'new_field': new_field},
                    feature_vector=fv,
                ))

            for field_name, pattern in fv.value_patterns.items():
                existing_pattern = existing_fv.value_patterns.get(field_name)
                if existing_pattern and existing_pattern != pattern:
                    findings.append(Finding(
                        category='new_value',
                        element_tag=tag,
                        source_file=source_label,
                        detail={
                            'field': field_name,
                            'observed_pattern': pattern,
                            'previously_known_pattern': existing_pattern,
                        },
                        feature_vector=fv,
                    ))

        # Sort: auto-reused/banned-suppressed first (informational),
        # then auto-promoted-from-deferred (Phase 6.5: previously
        # deferred surfaces now needing attention), then Category 1-4
        category_order = {
            'auto_reused':                 -3,
            'banned_suppressed':           -2,
            'auto_promoted_from_deferred': -1,
            'novel_element_type':           0,
            'new_shape':                    1,
            'new_field':                    2,
            'new_value':                    3,
        }
        findings.sort(key=lambda f: (category_order[f.category],
                                      f.element_tag))

        if not self.config.auto_reuse_report_findings:
            findings = [f for f in findings if f.category != 'auto_reused']

        return findings

    def _check_auto_reuse(
        self,
        tag: str,
        fv: ElementFeatureVector,
    ) -> tuple[str, float] | None:
        """Phase 1: check whether a novel surface matches any element
        already in the existing schema (the approved corpus) by
        structural similarity above threshold.
        
        Returns (matched_tag, similarity) on hit, None on miss.
        
        Per DESIGN_team_scale_addendum.md:
          - Threshold 0.85 (Decision #1)
          - Compare to ALL elements in existing schema, including those
            we have feature vectors for via corpus_features
          - The match is the highest-similarity entry above threshold
        
        This is what makes the team-scale value proposition real:
        every previously-classified surface stops re-appearing as
        intervention-required for subsequent customer configs.
        """
        # Vectorize the candidate
        target_vec = vectorize_sparse(fv, self.vocab)
        
        # Build/use cached vectorization of approved-corpus entries.
        # We only consider tags that are BOTH in the existing schema AND
        # have feature vectors observed in the corpus. Tags in the schema
        # without feature vectors (rare — would only happen if the schema
        # was hand-edited) cannot be similarity-matched.
        if not hasattr(self, '_approved_corpus_vec_cache'):
            self._approved_corpus_vec_cache = {
                t: vectorize_sparse(self.corpus_features[t], self.vocab)
                for t in self.existing_schema_tags
                if t in self.corpus_features
            }
        
        threshold = self.config.auto_reuse_threshold
        best_match: tuple[str, float] | None = None
        best_similarity = 0.0
        
        for known_tag, known_vec in self._approved_corpus_vec_cache.items():
            breakdown = structural_similarity_sparse(target_vec, known_vec)
            aggr = breakdown['aggregate']
            if aggr >= threshold and aggr > best_similarity:
                best_similarity = aggr
                best_match = (known_tag, aggr)
        
        return best_match

    def _compute_neighbors(
        self,
        finding: Finding,
        fv: ElementFeatureVector,
    ) -> None:
        """For a novel element finding, compute top-K structurally
        similar elements from the existing corpus and attach them to
        the finding as CONTEXT (not as kinship claims).
        """
        target_vec = vectorize_sparse(fv, self.vocab)
        # Use cached corpus sparse vectors if available, build them
        # once if not. Building the cache is the expensive step;
        # comparing against the cache is fast.
        if not hasattr(self, '_corpus_vec_cache'):
            self._corpus_vec_cache = {
                tag: vectorize_sparse(known_fv, self.vocab)
                for tag, known_fv in self.corpus_features.items()
            }
        sims: list[tuple[str, float, dict[str, float]]] = []
        for known_tag, known_vec in self._corpus_vec_cache.items():
            if known_tag == finding.element_tag:
                continue
            breakdown = structural_similarity_sparse(target_vec, known_vec)
            aggr = breakdown['aggregate']
            if aggr < self.config.neighbor_minimum_similarity:
                continue
            sims.append((known_tag, aggr, breakdown))
        sims.sort(key=lambda s: s[1], reverse=True)
        finding.neighbors = sims[: self.config.top_k_neighbors]
        # Placement confidence: top-1 aggregate similarity
        finding.placement_confidence = sims[0][1] if sims else 0.0


# ---------------------------------------------------------------------------
# Output writers
# ---------------------------------------------------------------------------

def write_findings_json(findings: list[Finding], path: Path) -> None:
    """Machine-readable findings dump."""
    serializable = []
    for f in findings:
        entry = {
            'category': f.category,
            'element_tag': f.element_tag,
            'source_file': f.source_file,
            'detail': f.detail,
            'placement_confidence': round(f.placement_confidence, 4),
            # Phase 6: tier-filtering metadata
            'enabled_status': f.enabled_status,
            'tier_suggestion': f.tier_suggestion,
            'enabled_status_evidence': f.enabled_status_evidence,
            'neighbors': [
                {
                    'tag': tag,
                    'aggregate_similarity': round(aggr, 4),
                    'per_slot': {k: round(v, 4) for k, v in
                                 breakdown.items()},
                }
                for tag, aggr, breakdown in f.neighbors
            ],
        }
        if f.feature_vector is not None:
            fv = f.feature_vector
            entry['structural_facts'] = {
                'instance_count': fv.instance_count,
                'distinct_children_tags': len(fv.children_tags),
                'distinct_field_shapes': len(fv.field_shapes),
                'naming_tokens': fv.naming_tokens,
                'top_children_tags': [
                    [tag, count] for tag, count
                    in fv.children_tags.most_common(20)
                ],
                'value_pattern_summary': dict(fv.value_patterns),
                'observed_in_corpus_files': fv.source_files,
            }
        serializable.append(entry)

    path.write_text(
        json.dumps({'findings': serializable,
                    'generated_at': _dt.datetime.now().isoformat(),
                    'finding_count': len(findings)},
                   indent=2),
        encoding='utf-8',
    )


def write_findings_md(
    findings: list[Finding],
    path: Path,
    config: LearnerConfig,
) -> None:
    """Human-readable findings document. Wraps all engine-produced
    structural facts in OBSERVATION-BEGIN/END markers so the
    provenance audit treats them as structural observations, not
    semantic claims."""
    lines: list[str] = []
    lines.append("# Schema-Learner Findings")
    lines.append("")
    lines.append(f"Generated: {_dt.datetime.now().isoformat()}")
    lines.append(f"Total findings: {len(findings)}")
    lines.append("")
    lines.append("This document contains STRUCTURAL OBSERVATIONS produced "
                 "by the schema-learner engine. The engine reports what "
                 "it observed in the XML — counts, similarities, "
                 "presence/absence. The engine makes NO claim about "
                 "semantic meaning, vendor mapping, or surface category. "
                 "Those determinations are operator-authored with "
                 "citations. See OPERATOR_INTERVENTION_REQUIRED.md for "
                 "the required operator declarations.")
    lines.append("")
    lines.append("---")
    lines.append("")

    # Group by category
    by_cat: dict[str, list[Finding]] = {}
    for f in findings:
        by_cat.setdefault(f.category, []).append(f)

    cat_titles = {
        'auto_reused':        'Phase 1 — Auto-Reused (Approved Corpus Match)',
        'banned_suppressed':  'Phase 2 — Banned-Suppressed (Routed to Sideline)',
        'novel_element_type': 'Category 1 — Novel Element Types',
        'new_shape':          'Category 2 — New Shapes of Known Elements',
        'new_field':          'Category 3 — New Fields Within Known Elements',
        'new_value':          'Category 4 — New Value Patterns',
    }

    for cat in ('auto_reused', 'banned_suppressed',
                'novel_element_type', 'new_shape',
                'new_field', 'new_value'):
        if cat not in by_cat:
            continue
        lines.append(f"## {cat_titles[cat]}")
        lines.append("")
        lines.append(f"Count: {len(by_cat[cat])}")
        lines.append("")
        for f in by_cat[cat]:
            lines.extend(_render_finding_md(f, config))
            lines.append("")

    path.write_text("\n".join(lines), encoding='utf-8')


def _render_finding_md(f: Finding, config: LearnerConfig) -> list[str]:
    """Render one finding as markdown. All structural data is wrapped
    in OBSERVATION markers."""
    lines: list[str] = []
    lines.append(f"### `<{f.element_tag}>`")
    lines.append("")
    lines.append(f"Source corpus entry: `{f.source_file}`")
    
    # Phase 6: tier suggestion (one-line, in observation block)
    tier_marker = {1: "🔴 Tier 1 (full triage)",
                   2: "🟡 Tier 2 (defer with config)",
                   3: "🟢 Tier 3 (auto-skip OK)"}.get(
        f.tier_suggestion, "Tier ?")
    lines.append(f"Engine enabled-status: **{f.enabled_status}** "
                 f"— {tier_marker}")
    if f.enabled_status_evidence:
        lines.append(f"Evidence: {f.enabled_status_evidence}")
    lines.append("")
    lines.append(OBS_OPEN)
    lines.append("")

    if f.feature_vector is not None:
        fv = f.feature_vector
        lines.append("**Structural facts (engine observations):**")
        lines.append("")
        lines.append(f"- Instance count: {fv.instance_count}")
        lines.append(f"- Distinct child element tags: {len(fv.children_tags)}")
        lines.append(f"- Distinct field shapes: {len(fv.field_shapes)}")
        lines.append(f"- Naming tokens: {fv.naming_tokens}")
        if fv.children_tags:
            top = fv.children_tags.most_common(10)
            lines.append(f"- Top child tags (by occurrence): "
                         f"{[t for t, _ in top]}")
        if fv.value_patterns:
            lines.append("- Value-pattern observations per child field:")
            for field_name, pattern in sorted(fv.value_patterns.items())[:15]:
                lines.append(f"    - `{field_name}`: {pattern}")
        lines.append(f"- Observed in corpus files: {fv.source_files}")
        lines.append("")

    if f.neighbors:
        lines.append("**Top structurally-similar existing elements "
                     "(engine observations):**")
        lines.append("")
        lines.append(f"Note: these are STRUCTURAL similarity scores. They "
                     f"indicate which existing elements share child tags, "
                     f"value patterns, naming tokens, etc. They do NOT "
                     f"indicate semantic kinship. Operator must declare "
                     f"semantic relationships separately, with citations.")
        lines.append("")
        lines.append("| Existing element | Aggregate | Children | Naming | Values | Siblings |")
        lines.append("|---|---|---|---|---|---|")
        for tag, aggr, breakdown in f.neighbors:
            lines.append(
                f"| `{tag}` | {aggr:.3f} | "
                f"{breakdown.get('slot1_children', 0):.3f} | "
                f"{breakdown.get('slot3_naming_tokens', 0):.3f} | "
                f"{breakdown.get('slot4_value_patterns', 0):.3f} | "
                f"{breakdown.get('slot5_siblings', 0):.3f} |"
            )
        lines.append("")
        if f.placement_confidence >= config.high_confidence:
            confidence = "high"
        elif f.placement_confidence >= config.medium_confidence:
            confidence = "medium"
        elif f.placement_confidence >= config.auto_propose_minimum:
            confidence = "low"
        else:
            confidence = "below threshold — operator must classify manually"
        lines.append(f"**Placement confidence (top-1 structural):** "
                     f"{f.placement_confidence:.3f} ({confidence})")
        lines.append("")

    if f.detail:
        lines.append("**Engine-observed details:**")
        lines.append("")
        for k, v in f.detail.items():
            lines.append(f"- `{k}`: {v}")
        lines.append("")

    lines.append(OBS_CLOSE)
    return lines


def write_intervention_md(
    findings: list[Finding],
    path: Path,
    config: LearnerConfig,
    source_label: str,
) -> None:
    """Generate the OPERATOR_INTERVENTION_REQUIRED.md document — the
    structured questionnaire the operator fills in with citations.
    Operator-fillable sections wrapped in OPERATOR-AUTHORED markers."""
    lines: list[str] = []
    lines.append("# OPERATOR INTERVENTION REQUIRED")
    lines.append("")
    lines.append(f"Generated: {_dt.datetime.now().isoformat()}")
    lines.append(f"Source: `{source_label}`")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("## Critical: translation is BLOCKED for the surfaces below")
    lines.append("")
    lines.append("The schema-learner identified element types in this source "
                 "that are not yet in the existing schema. The engine has "
                 "produced STRUCTURAL OBSERVATIONS about each one. **NO "
                 "TRANSLATION CAN OCCUR** for any of them until the "
                 "operator answers the research questions below with "
                 "documented citations.")
    lines.append("")
    lines.append("This is intentional. Silent incompleteness produces "
                 "broken configurations at customer sites. The toolkit "
                 "refuses to translate what no-one has researched.")
    lines.append("")
    lines.append("---")
    lines.append("")

    # Filter to only Category 1 (novel elements) for the intervention doc.
    # Categories 2-4 are tracked but don't typically require full
    # SonicWall-side authoring (they're refinements of existing rules).
    cat1 = [f for f in findings if f.category == 'novel_element_type']

    if not cat1:
        lines.append("No Category-1 findings (novel element types) in this run.")
        lines.append("Categories 2-4 may still require schema updates; "
                     "see findings.md.")
        path.write_text("\n".join(lines), encoding='utf-8')
        return

    for i, f in enumerate(cat1, 1):
        lines.extend(_render_intervention_section(i, f, config))
        lines.append("")
        lines.append("---")
        lines.append("")

    lines.append("## Summary")
    lines.append("")
    lines.append(f"{len(cat1)} surface(s) require operator intervention "
                 f"before translation is possible. Until each surface has "
                 f"all questions answered with citations, the toolkit will:")
    lines.append("")
    lines.append("- Refuse to write any wg_xml_schema.ini entry for the surface")
    lines.append("- Refuse to write any concept_map.ini entry for the surface")
    lines.append("- Refuse to write any xml_emit_config.ini emit rule")
    lines.append("- Block any source-config translation that touches the "
                 "surface, with hard-error advisory in migration_notes.md")

    path.write_text("\n".join(lines), encoding='utf-8')


def _render_intervention_section(
    i: int, f: Finding, config: LearnerConfig,
) -> list[str]:
    """Render one intervention section per Category-1 finding."""
    lines: list[str] = []
    lines.append(f"## Surface {i}: `<{f.element_tag}>`")
    lines.append("")

    # Engine observations (wrapped in OBSERVATION markers)
    lines.append(OBS_OPEN)
    lines.append("")
    lines.append("### Engine observations (structural facts only)")
    lines.append("")
    lines.append("These are descriptions of what's in the XML. They are "
                 "NOT claims about meaning. The engine makes no semantic "
                 "claim, suggests no category, hints at no vendor mapping.")
    lines.append("")
    if f.feature_vector is not None:
        fv = f.feature_vector
        lines.append(f"- Element tag: `{f.element_tag}`")
        lines.append(f"- Naming tokens: {fv.naming_tokens}")
        lines.append(f"- Instance count in source: {fv.instance_count}")
        lines.append(f"- Distinct child element tags observed: "
                     f"{len(fv.children_tags)}")
        if fv.children_tags:
            children_list = ", ".join(
                f"`{t}`" for t, _ in fv.children_tags.most_common(20))
            lines.append(f"- Child tags: {children_list}")
        if fv.value_patterns:
            lines.append("- Value-pattern observations:")
            for fname, ptn in sorted(fv.value_patterns.items())[:15]:
                lines.append(f"    - `{fname}`: {ptn}")
        lines.append("")

    if f.neighbors:
        lines.append("**Structural similarity to existing elements:**")
        lines.append("")
        lines.append("Note: structural similarity reflects shared child "
                     "tags, value patterns, and naming tokens. It does "
                     "NOT indicate semantic kinship. Use as research "
                     "context, not as a substitute for declaration.")
        lines.append("")
        for tag, aggr, _ in f.neighbors[:5]:
            lines.append(f"  - `{tag}`: {aggr:.3f}")
        lines.append("")

    lines.append(OBS_CLOSE)
    lines.append("")

    # Operator-authored declarations (wrapped in OPERATOR markers)
    lines.append("### Required operator declarations")
    lines.append("")
    lines.append("Research the following questions using vendor "
                 "documentation, RFCs, lab testing, or your field "
                 "experience. Document your sources. The toolkit will "
                 "not proceed without all answers and citations.")
    lines.append("")
    lines.append(OP_OPEN)
    lines.append("")
    lines.append("[ ] **Q1: What does this element do?** (one sentence)")
    lines.append("")
    lines.append("    Answer: __________________________________________")
    lines.append("")
    lines.append("    Source (vendor doc URL, RFC, field experience): ___")
    lines.append("")
    lines.append("[ ] **Q2: Surface category from the toolkit's taxonomy?**")
    lines.append("")
    lines.append("    Choose one: network-plumbing | policy-access-control |")
    lines.append("    object-library | tunnel-vpn | html-web-app |")
    lines.append("    threat-detection | authentication-infrastructure |")
    lines.append("    device-management | administrative")
    lines.append("")
    lines.append("    Answer: __________________________________________")
    lines.append("")
    lines.append("    Source: __________________________________________")
    lines.append("")
    lines.append("[ ] **Q3: Does the source vendor (SonicWall) have an "
                 "equivalent feature?**")
    lines.append("")
    lines.append("    If yes, what is it? If no, what's the operator action?")
    lines.append("")
    lines.append("    Answer: __________________________________________")
    lines.append("")
    lines.append("    Source: __________________________________________")
    lines.append("")
    lines.append("[ ] **Q4: Security or operational considerations** for "
                 "migration_notes.md?")
    lines.append("")
    lines.append("    Answer: __________________________________________")
    lines.append("")
    lines.append("    Source: __________________________________________")
    lines.append("")
    lines.append(OP_CLOSE)
    lines.append("")
    lines.append("### Until all declarations are made and cited")
    lines.append("")
    lines.append(f"The toolkit will refuse to merge any rule for "
                 f"`<{f.element_tag}>`. Source configs containing data "
                 f"that would map to this surface will produce a "
                 f"hard-error advisory in migration_notes.md.")
    return lines


def write_proposed_diff_md(
    findings: list[Finding],
    path: Path,
) -> None:
    """High-level summary of what would change in the INI bundles
    if the operator approves the proposal."""
    lines: list[str] = []
    lines.append("# Proposed INI Changes")
    lines.append("")
    lines.append(f"Generated: {_dt.datetime.now().isoformat()}")
    lines.append("")
    lines.append("This document summarizes what the schema-learner would "
                 "change in the INI bundles if the operator approves the "
                 "merge. Actual file diffs are in merge_preview/.")
    lines.append("")
    lines.append("**Engine produces SCHEMA proposals only.** Concept-map "
                 "entries, parser patterns, and emit rules require "
                 "operator authoring with cited sources. See "
                 "OPERATOR_INTERVENTION_REQUIRED.md.")
    lines.append("")

    cat_titles = {
        'auto_reused':        'Auto-reused from approved corpus (no merge needed)',
        'banned_suppressed':  'Banned-suppressed (routed to sideline queue)',
        'novel_element_type': 'New schema entries (wg_xml_schema.ini)',
        'new_shape':          'Schema rule extensions (new shapes for existing elements)',
        'new_field':          'Schema rule extensions (new allowed fields)',
        'new_value':          'Schema rule extensions (value-pattern updates)',
    }

    by_cat: dict[str, list[Finding]] = {}
    for f in findings:
        by_cat.setdefault(f.category, []).append(f)

    for cat in ('auto_reused', 'banned_suppressed',
                'novel_element_type', 'new_shape',
                'new_field', 'new_value'):
        if cat not in by_cat:
            continue
        lines.append(f"## {cat_titles[cat]}")
        lines.append("")
        for f in by_cat[cat]:
            lines.append(f"- `<{f.element_tag}>`")
            if f.detail:
                for k, v in f.detail.items():
                    summary = str(v)[:80]
                    lines.append(f"    - {k}: {summary}")
        lines.append("")

    path.write_text("\n".join(lines), encoding='utf-8')


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    # Default config lives next to the engine modules. Users can
    # override with --config <path>. Keeps "config in one place" —
    # consistent with triage.py default.
    default_config = Path(__file__).resolve().parent / "learn_config.ini"
    ap.add_argument('--config', default=default_config, type=Path,
                    help=f"Path to learn_config.ini "
                         f"(default: {default_config})")
    ap.add_argument('--input', required=True, type=Path,
                    help="Path to new XML config to learn from")
    ap.add_argument('--source-label', default=None,
                    help="Label for the input (defaults to filename)")
    ap.add_argument('--strict', action='store_true',
                    help="Exit non-zero if engine config schema "
                         "validation fails")
    ap.add_argument('--no-validate', action='store_true',
                    help="Skip engine config schema validation at startup")
    args = ap.parse_args(argv)

    # Defensive: ConfigParser silently swallows missing files and then
    # raises NoSectionError on any section access — gives operators
    # cryptic errors. Check early and emit an actionable message.
    if not args.config.is_file():
        print(f"[schema_learner] ERROR: config file not found: "
              f"{args.config}")
        print(f"[schema_learner]")
        print(f"[schema_learner]   Looked for an absolute path or a "
              f"path relative to your current directory.")
        print(f"[schema_learner]   Current working directory: "
              f"{Path.cwd()}")
        print(f"[schema_learner]")
        print(f"[schema_learner]   The canonical config lives at:")
        default_config = Path(__file__).resolve().parent / "learn_config.ini"
        print(f"[schema_learner]     {default_config}")
        print(f"[schema_learner]")
        print(f"[schema_learner]   If that file exists, omit --config "
              f"to use it (it's the default).")
        return 2

    # Validate engine config at startup (matches every other engine)
    if not args.no_validate:
        validate_at_startup(args.config,
                            engine_name="schema_learner",
                            strict=args.strict)

    config = LearnerConfig.from_ini(args.config)
    source_label = args.source_label or args.input.stem

    # Engine
    learner = SchemaLearner(config)
    print(f"[schema_learner] Loading existing schema: "
          f"{config.existing_schema_path}")
    learner.load_existing_schema()
    print(f"[schema_learner]   {len(learner.existing_schema_tags)} "
          f"element types in existing schema")

    print(f"[schema_learner] Loading corpus: {config.corpus_dir}")
    learner.load_corpus()
    print(f"[schema_learner]   {len(learner.corpus_features)} "
          f"element types observed across corpus")

    print(f"[schema_learner] Detecting findings in: {args.input}")
    findings = learner.detect_findings(args.input, source_label)
    print(f"[schema_learner]   {len(findings)} finding(s)")
    by_cat: dict[str, int] = {}
    for f in findings:
        by_cat[f.category] = by_cat.get(f.category, 0) + 1
    for cat, n in by_cat.items():
        print(f"[schema_learner]     {cat}: {n}")
    
    # Phase 6: tier-suggestion summary (Category-1 findings only)
    cat1 = [f for f in findings if f.category == 'novel_element_type']
    if cat1:
        tier_counts: dict[int, int] = {1: 0, 2: 0, 3: 0}
        status_counts: dict[str, int] = {
            'enabled': 0, 'disabled': 0, 'unknown': 0}
        for f in cat1:
            tier_counts[f.tier_suggestion] = \
                tier_counts.get(f.tier_suggestion, 0) + 1
            status_counts[f.enabled_status] = \
                status_counts.get(f.enabled_status, 0) + 1
        print(f"[schema_learner]   Phase 6 tier suggestions (cat-1 only):")
        print(f"[schema_learner]     enabled-status: "
              f"{status_counts.get('enabled', 0)} enabled, "
              f"{status_counts.get('disabled', 0)} disabled, "
              f"{status_counts.get('unknown', 0)} unknown")
        print(f"[schema_learner]     tier 1 (full triage):    "
              f"{tier_counts.get(1, 0):>4}")
        print(f"[schema_learner]     tier 2 (defer w/config): "
              f"{tier_counts.get(2, 0):>4}")
        print(f"[schema_learner]     tier 3 (auto-skip):      "
              f"{tier_counts.get(3, 0):>4}")

    # Write proposal
    timestamp = _dt.datetime.now().strftime('%Y-%m-%d_%H%M%S')
    proposal_dir = config.proposals_dir / f"{timestamp}_{source_label}"
    proposal_dir.mkdir(parents=True, exist_ok=True)

    findings_md = proposal_dir / "findings.md"
    findings_json = proposal_dir / "findings.json"
    intervention_md = proposal_dir / "OPERATOR_INTERVENTION_REQUIRED.md"
    proposed_diff_md = proposal_dir / "proposed_diff.md"

    if config.findings_format in ('markdown', 'both'):
        write_findings_md(findings, findings_md, config)
        print(f"[schema_learner] Wrote: {findings_md}")
    if config.findings_format in ('json', 'both'):
        write_findings_json(findings, findings_json)
        print(f"[schema_learner] Wrote: {findings_json}")

    write_intervention_md(findings, intervention_md, config, source_label)
    print(f"[schema_learner] Wrote: {intervention_md}")

    write_proposed_diff_md(findings, proposed_diff_md)
    print(f"[schema_learner] Wrote: {proposed_diff_md}")

    print()
    print(f"Proposal directory: {proposal_dir}")
    print(f"Next step: review OPERATOR_INTERVENTION_REQUIRED.md and "
          f"answer the research questions with citations.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
