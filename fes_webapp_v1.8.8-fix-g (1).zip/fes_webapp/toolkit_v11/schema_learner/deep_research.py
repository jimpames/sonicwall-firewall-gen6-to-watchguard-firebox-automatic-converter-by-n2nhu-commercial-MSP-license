#!/usr/bin/env python3
"""
deep_research.py
=================

Phase 4 of the schema_learner subsystem (DESIGN_team_scale_addendum.md).
Senior-engineer workflow for resolving sideline-queue entries with
mandatory lab verification, plus the quarterly deprecation registry.

Per Decision #7 (resolved May 2026):

    Every deep-research classification entering the approved corpus
    must be lab-verified on a real Firebox round-trip. No exceptions,
    no impact-tier carve-outs. Lab access is a real constraint but
    the cost of an unverified deep-research classification silently
    entering the corpus is operationally higher than the cost of
    slower queue burndown.

Per Decision #5:

    Quarterly review of the approved corpus against vendor release
    notes from the prior quarter. Newly-deprecated features are
    marked with timestamp + vendor citation in the `deprecated`
    field reserved by Phase 1.

This module provides:

  - SidelineClaim: mark a sideline entry as 'in_research' with
    senior engineer's identity and timestamp
  - LabVerification: structured capture of round-trip test result
  - DeepResearchPromotion: validation wrapper that enforces:
      (a) two-citation rule per claim
      (b) lab verification populated and PASS
      (c) at least one peer-reviewer acknowledgment
      Then promotes the sideline entry to approved corpus
  - Deprecation: mark approved-corpus entries deprecated with
    vendor citation; list deprecations; identify proposals/customer
    configs that translated using deprecated features

Storage paths (created on first use):

  schema_learner/lab_verifications/<surface_id>.md   — verification artifacts
  schema_learner/deprecation_log.ini                 — deprecation history
"""
from __future__ import annotations

import configparser
import datetime as _dt
import json
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))

# Same provenance markers as the rest of the toolkit
OBS_OPEN = "<!-- ENGINE-OBSERVATION-BEGIN -->"
OBS_CLOSE = "<!-- ENGINE-OBSERVATION-END -->"
OP_OPEN = "<!-- OPERATOR-AUTHORED-BEGIN -->"
OP_CLOSE = "<!-- OPERATOR-AUTHORED-END -->"


# ---------------------------------------------------------------------------
# Lab verification — per Decision #7, mandatory for deep research
# ---------------------------------------------------------------------------

@dataclass
class LabVerification:
    """Round-trip test result on a real Firebox. Mandatory for deep
    research promotion per Decision #7."""

    firebox_model: str = ""        # e.g. "T-30", "M270", "M370"
    firmware_version: str = ""     # e.g. "12.11.0"
    verified_by: str = ""          # senior engineer name
    verified_at: str = ""          # ISO timestamp
    test_result: str = ""          # "PASS" | "PARTIAL" | "FAIL"
    test_notes: str = ""           # free-text observations
    artifact_path: str = ""        # path to lab_verifications/<id>.md

    def is_complete(self) -> tuple[bool, list[str]]:
        """Per Decision #7: every field except artifact_path is required.
        artifact_path is recommended but the verification is valid even
        without a separate detail markdown if test_notes is substantial.
        """
        missing: list[str] = []
        if not self.firebox_model.strip():
            missing.append("firebox_model")
        if not self.firmware_version.strip():
            missing.append("firmware_version")
        if not self.verified_by.strip():
            missing.append("verified_by")
        if not self.verified_at.strip():
            missing.append("verified_at")
        if self.test_result not in ("PASS", "PARTIAL", "FAIL"):
            missing.append("test_result (must be PASS/PARTIAL/FAIL)")
        if not self.test_notes.strip() or len(self.test_notes.strip()) < 20:
            missing.append("test_notes (must be substantive, 20+ chars)")
        return (not missing, missing)

    def to_field_string(self) -> str:
        """Serialize to a compact string suitable for an INI field.
        Format: model=X;firmware=Y;by=Z;at=ISO;result=PASS;notes=...;artifact=..."""
        parts = [
            f"model={self.firebox_model}",
            f"firmware={self.firmware_version}",
            f"by={self.verified_by}",
            f"at={self.verified_at}",
            f"result={self.test_result}",
            # Notes truncated for the field; full text lives in artifact md
            f"notes={self.test_notes[:200].replace(';', ',').replace('=', ':')}",
        ]
        if self.artifact_path:
            parts.append(f"artifact={self.artifact_path}")
        return ";".join(parts)

    @classmethod
    def from_field_string(cls, s: str) -> "LabVerification":
        """Parse a compact field string back into a LabVerification."""
        v = cls()
        if not s:
            return v
        for pair in s.split(";"):
            if "=" not in pair:
                continue
            k, val = pair.split("=", 1)
            k = k.strip().lower()
            val = val.strip()
            if k == "model":
                v.firebox_model = val
            elif k == "firmware":
                v.firmware_version = val
            elif k == "by":
                v.verified_by = val
            elif k == "at":
                v.verified_at = val
            elif k == "result":
                v.test_result = val
            elif k == "notes":
                v.test_notes = val
            elif k == "artifact":
                v.artifact_path = val
        return v


def _lab_verifications_root() -> Path:
    p = _TOOLKIT_ROOT / "schema_learner" / "lab_verifications"
    p.mkdir(parents=True, exist_ok=True)
    return p


def write_lab_verification_artifact(
    surface_tag: str,
    verification: LabVerification,
    additional_notes: str = "",
) -> Path:
    """Write the detailed markdown artifact for a lab verification.
    Returns the artifact path; populates verification.artifact_path."""
    safe_tag = re.sub(r'[^a-zA-Z0-9_-]', '_', surface_tag)
    ts = _dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    fname = f"{safe_tag}_{ts}.md"
    path = _lab_verifications_root() / fname

    lines: list[str] = []
    lines.append(f"# Lab verification: `<{surface_tag}>`")
    lines.append("")
    lines.append(f"Verified by: {verification.verified_by}")
    lines.append(f"Verified at: {verification.verified_at}")
    lines.append(f"Firebox:     {verification.firebox_model}")
    lines.append(f"Firmware:    {verification.firmware_version}")
    lines.append(f"Result:      **{verification.test_result}**")
    lines.append("")
    lines.append(OBS_OPEN)
    lines.append("## Round-trip test observations (engine + lab)")
    lines.append("")
    lines.append(verification.test_notes or "(none)")
    if additional_notes:
        lines.append("")
        lines.append("### Additional notes")
        lines.append("")
        lines.append(additional_notes)
    lines.append(OBS_CLOSE)

    path.write_text("\n".join(lines), encoding='utf-8')
    verification.artifact_path = str(path.relative_to(_TOOLKIT_ROOT))
    return path


# ---------------------------------------------------------------------------
# Deep-research promotion validation
# ---------------------------------------------------------------------------

@dataclass
class DeepResearchPromotion:
    """Wraps the operator-declarations + lab verification + peer review
    into a single artifact that gets validated before promotion."""

    surface_tag: str
    sideline_entry_id: str

    # Operator declarations (same as merge_engine.OperatorDeclaration
    # but with stricter requirements: two citations per claim).
    purpose: str = ""
    purpose_source_1: str = ""
    purpose_source_2: str = ""

    category: str = ""
    category_source_1: str = ""
    category_source_2: str = ""

    sonicwall_equivalent: str = ""
    sonicwall_source_1: str = ""
    sonicwall_source_2: str = ""

    operational_notes: str = ""
    operational_source_1: str = ""
    operational_source_2: str = ""

    # Lab verification (mandatory per Decision #7)
    lab_verification: LabVerification = field(default_factory=LabVerification)

    # Peer review (at least one acknowledgment required)
    peer_reviewer: str = ""
    peer_reviewed_at: str = ""
    peer_review_notes: str = ""

    # Engineer authoring this promotion
    deep_researcher: str = ""
    deep_research_at: str = ""

    def validate(self) -> tuple[bool, list[str]]:
        """Stricter than operator-time validation:
        - Two citations per claim (where available; one is the minimum
          for claims like 'Field experience' that don't have URL backing)
        - Lab verification complete with PASS or PARTIAL result
        - Peer reviewer named with non-empty notes
        """
        errors: list[str] = []

        # Q1-Q4: each claim plus at minimum one source; second source
        # is encouraged but not absolutely required (some claims like
        # field-experience have no URL backing — but having two
        # corroborating field-experience signoffs is also valuable).
        if not self.purpose.strip():
            errors.append("Q1 purpose: empty")
        if not self.purpose_source_1.strip():
            errors.append("Q1 purpose_source_1: empty (mandatory)")
        if not self.purpose_source_2.strip():
            errors.append("Q1 purpose_source_2: empty "
                          "(deep research requires two citations)")

        if not self.category.strip():
            errors.append("Q2 category: empty")
        if not self.category_source_1.strip():
            errors.append("Q2 category_source_1: empty (mandatory)")
        if not self.category_source_2.strip():
            errors.append("Q2 category_source_2: empty "
                          "(deep research requires two citations)")

        if not self.sonicwall_equivalent.strip():
            errors.append("Q3 sonicwall_equivalent: empty")
        if not self.sonicwall_source_1.strip():
            errors.append("Q3 sonicwall_source_1: empty (mandatory)")
        if not self.sonicwall_source_2.strip():
            errors.append("Q3 sonicwall_source_2: empty "
                          "(deep research requires two citations)")

        if not self.operational_notes.strip():
            errors.append("Q4 operational_notes: empty")
        if not self.operational_source_1.strip():
            errors.append("Q4 operational_source_1: empty (mandatory)")
        if not self.operational_source_2.strip():
            errors.append("Q4 operational_source_2: empty "
                          "(deep research requires two citations)")

        # Lab verification — Decision #7 mandatory
        ok, missing = self.lab_verification.is_complete()
        if not ok:
            for m in missing:
                errors.append(f"lab_verification.{m}: missing or invalid")
        elif self.lab_verification.test_result == "FAIL":
            errors.append(
                "lab_verification.test_result: FAIL — cannot promote a "
                "deep-research classification that failed lab verification. "
                "Either fix the classification or accept that this surface "
                "cannot be reliably translated.")

        # Peer review
        if not self.peer_reviewer.strip():
            errors.append("peer_reviewer: empty (mandatory per addendum)")
        if not self.peer_reviewed_at.strip():
            errors.append("peer_reviewed_at: empty")
        if not self.peer_review_notes.strip():
            errors.append("peer_review_notes: empty "
                          "(reviewer must explicitly acknowledge)")

        # Researcher identity
        if not self.deep_researcher.strip():
            errors.append("deep_researcher: empty (mandatory provenance)")

        return (not errors, errors)


# ---------------------------------------------------------------------------
# Deprecation registry — Decision #5: quarterly sweep
# ---------------------------------------------------------------------------

@dataclass
class DeprecationEntry:
    """One deprecation record. Stored in the deprecation_log.ini and
    also written as the `deprecated` field on the corresponding
    approved-corpus entry."""

    surface_tag: str
    deprecated_at: str         # ISO date
    deprecated_by: str         # senior engineer who marked it
    vendor_citation: str       # URL to vendor release notes
    deprecation_reason: str    # free-text from vendor docs
    replacement_feature: str = ""  # e.g. "use 'foo' instead" if vendor specifies


def _deprecation_log_path() -> Path:
    return _TOOLKIT_ROOT / "schema_learner" / "deprecation_log.ini"


def write_deprecation_entry(entry: DeprecationEntry) -> Path:
    """Append/update a deprecation entry. Returns the log path."""
    path = _deprecation_log_path()
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    if path.is_file():
        cp.read(path, encoding='utf-8')

    section = entry.surface_tag
    if not cp.has_section(section):
        cp.add_section(section)
    cp.set(section, 'deprecated_at', entry.deprecated_at)
    cp.set(section, 'deprecated_by', entry.deprecated_by)
    cp.set(section, 'vendor_citation', entry.vendor_citation)
    cp.set(section, 'deprecation_reason',
           entry.deprecation_reason[:300])  # bound for INI
    if entry.replacement_feature:
        cp.set(section, 'replacement_feature', entry.replacement_feature)

    with path.open('w', encoding='utf-8') as f:
        f.write(
            "; Deprecation log — Phase 4 (DESIGN_team_scale_addendum.md)\n"
            "; Each section is one deprecated surface tag.\n"
            "; Decision #5: quarterly sweep against vendor release notes.\n"
            "; The merge engine refuses to translate using deprecated\n"
            "; features without explicit operator override.\n\n"
        )
        cp.write(f)
    return path


def load_deprecation_log() -> dict[str, DeprecationEntry]:
    """Load all deprecation entries, keyed by surface tag."""
    path = _deprecation_log_path()
    if not path.is_file():
        return {}
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(path, encoding='utf-8')
    result: dict[str, DeprecationEntry] = {}
    for section in cp.sections():
        result[section] = DeprecationEntry(
            surface_tag=section,
            deprecated_at=cp.get(section, 'deprecated_at', fallback=''),
            deprecated_by=cp.get(section, 'deprecated_by', fallback=''),
            vendor_citation=cp.get(section, 'vendor_citation',
                                   fallback=''),
            deprecation_reason=cp.get(section, 'deprecation_reason',
                                      fallback=''),
            replacement_feature=cp.get(section, 'replacement_feature',
                                       fallback=''),
        )
    return result


def find_proposals_referencing_surface(
    surface_tag: str,
    proposals_root: Path | None = None,
) -> list[Path]:
    """Find proposals/customer configs that referenced a now-deprecated
    surface. Used by deprecation propagation: when feature X is marked
    deprecated, scan past proposals to identify customers needing review.
    
    Phase 4 implementation: scans findings.json files for the tag.
    Phase 5 will extend this with merge-manifest awareness so we know
    which translations actually USED the deprecated feature in their
    output."""
    if proposals_root is None:
        proposals_root = _TOOLKIT_ROOT / "schema_learner" / "proposals"
    if not proposals_root.is_dir():
        return []
    matching: list[Path] = []
    for proposal_dir in proposals_root.iterdir():
        if not proposal_dir.is_dir():
            continue
        findings = proposal_dir / 'findings.json'
        if not findings.is_file():
            continue
        try:
            data = json.loads(findings.read_text(encoding='utf-8'))
        except (json.JSONDecodeError, OSError):
            continue
        for f in data.get('findings', []):
            if f.get('element_tag') == surface_tag:
                matching.append(proposal_dir)
                break
    return matching


# ---------------------------------------------------------------------------
# SLA aging — Decision #4 visibility
# ---------------------------------------------------------------------------

def days_since_iso(iso_string: str) -> float | None:
    """Compute days since the ISO timestamp. Returns None on parse failure."""
    if not iso_string:
        return None
    try:
        ts = _dt.datetime.fromisoformat(iso_string)
    except ValueError:
        return None
    delta = _dt.datetime.now() - ts
    return delta.total_seconds() / 86400.0


def is_sla_overdue(tier: int, age_days: float | None) -> tuple[bool, str]:
    """Per Decision #4 SLA tiers:
      Tier 1 (1-2 occurrences):   indefinite
      Tier 2 (3-9 occurrences):   30 days
      Tier 3 (10+ occurrences):    7 days
    
    Returns (is_overdue, label_for_display)."""
    if age_days is None:
        return False, "(age unknown)"
    if tier == 1:
        return False, f"({age_days:.0f}d, indefinite)"
    if tier == 2:
        if age_days > 30:
            return True, f"⚠ OVERDUE Tier 2 ({age_days:.0f}d / 30d)"
        return False, f"({age_days:.0f}d / 30d)"
    if tier == 3:
        if age_days > 7:
            return True, f"⚠ OVERDUE Tier 3 ({age_days:.0f}d / 7d)"
        return False, f"({age_days:.0f}d / 7d)"
    return False, f"({age_days:.0f}d)"


# ---------------------------------------------------------------------------
# Sideline claim/promote helpers
# ---------------------------------------------------------------------------

def claim_sideline_entry(
    entry_id: str,
    senior_engineer: str,
) -> tuple[bool, str]:
    """Mark a sideline entry as 'in_research' with engineer's identity.
    Returns (success, message). Refuses if entry doesn't exist or is
    already claimed."""
    from corpus_tiers import (
        load_sideline_queue, _sideline_queue_path, write_sideline_entry,
    )
    queue = load_sideline_queue()
    target = next((e for e in queue if e.entry_id == entry_id), None)
    if target is None:
        return False, f"entry {entry_id!r} not found in sideline queue"
    if target.status == 'in_research':
        return False, (f"entry {entry_id!r} already claimed by "
                       f"{target.assigned_to or 'unknown'} at "
                       f"{target.assigned_at}")
    if target.status not in ('open',):
        return False, (f"entry {entry_id!r} has status {target.status!r}, "
                       f"only 'open' entries can be claimed")
    # Update the queue index in-place
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(_sideline_queue_path(), encoding='utf-8')
    if not cp.has_section(entry_id):
        return False, f"queue index missing section for {entry_id!r}"
    cp.set(entry_id, 'status', 'in_research')
    cp.set(entry_id, 'assigned_to', senior_engineer)
    cp.set(entry_id, 'assigned_at', _dt.datetime.now().isoformat())
    with _sideline_queue_path().open('w', encoding='utf-8') as f:
        f.write(
            "; Sideline queue — Phase 2 (DESIGN_team_scale_addendum.md)\n"
            "; Surfaces awaiting deep research.\n"
            "; SLA tiers (Decision #4):\n"
            ";   tier 1 (1-2 occurrences):  indefinite\n"
            ";   tier 2 (3-9 occurrences):  30-day SLA\n"
            ";   tier 3 (10+ occurrences):   7-day SLA\n"
            "; Senior engineer owns queue burndown (Phase 4 workflow).\n\n"
        )
        cp.write(f)
    return True, (f"sideline entry {entry_id!r} claimed by "
                  f"{senior_engineer}")


def mark_sideline_status(
    entry_id: str,
    new_status: str,
) -> tuple[bool, str]:
    """Update a sideline entry's status (e.g. 'in_research' → 'resolved').
    Used after deep-research promotion completes."""
    from corpus_tiers import _sideline_queue_path
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    if not _sideline_queue_path().is_file():
        return False, "sideline queue empty"
    cp.read(_sideline_queue_path(), encoding='utf-8')
    if not cp.has_section(entry_id):
        return False, f"entry {entry_id!r} not found"
    cp.set(entry_id, 'status', new_status)
    with _sideline_queue_path().open('w', encoding='utf-8') as f:
        f.write(
            "; Sideline queue — Phase 2 (DESIGN_team_scale_addendum.md)\n"
            "; Surfaces awaiting deep research.\n"
            "; SLA tiers (Decision #4):\n"
            ";   tier 1 (1-2 occurrences):  indefinite\n"
            ";   tier 2 (3-9 occurrences):  30-day SLA\n"
            ";   tier 3 (10+ occurrences):   7-day SLA\n"
            "; Senior engineer owns queue burndown (Phase 4 workflow).\n\n"
        )
        cp.write(f)
    return True, f"entry {entry_id!r} status → {new_status!r}"
