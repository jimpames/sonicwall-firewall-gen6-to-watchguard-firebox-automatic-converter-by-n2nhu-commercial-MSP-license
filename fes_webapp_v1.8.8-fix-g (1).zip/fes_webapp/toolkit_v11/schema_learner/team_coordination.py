#!/usr/bin/env python3
"""
team_coordination.py
=====================

Phase 5 of the schema_learner subsystem (DESIGN_team_scale_addendum.md).
The final feature phase: makes multi-engineer parallel work safe.

Per Decision #3 (resolved May 2026): senior operators only — no
role-based access control. Authenticated identity is enough.

This module provides four coordination primitives:

  1. Operator roster  — engineers.ini lists authenticated team
     members. Toolkit refuses operator names not in the roster.
  
  2. Audit log       — append-only record of every state-mutating
     action with operator, timestamp, action_type, target, detail.
  
  3. Locks           — prevent two engineers from triaging the same
     (surface_tag, proposal_dir) simultaneously. Timeout-based
     auto-release so abandoned sessions don't permanently block.
  
  4. Disagreement   — when engineer B believes engineer A's prior
     flags        classification was wrong, file a flag, route to a
                  review queue, capture senior resolution.

Storage paths:

  team_config/engineers.ini                  — roster, hand-edited
  schema_learner/audit/<year>-<month>.log    — append-only INI
  schema_learner/locks/<lock_id>.lock        — per-(surface,proposal)
  schema_learner/disagreements/_index.ini    — disagreement queue
  schema_learner/disagreements/<flag_id>.md  — per-flag detail

Founding-principle binding:

    All audit-log entries are append-only and carry full provenance
    (operator + timestamp + action). The audit log is the team's
    forensic record — never modified, never deleted. Provenance for
    Phase 5 actions ITSELF gets provenance.
"""
from __future__ import annotations

import configparser
import datetime as _dt
import json
import re
import sys
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_TOOLKIT_ROOT = Path(__file__).resolve().parent.parent
if str(_TOOLKIT_ROOT) not in sys.path:
    sys.path.insert(0, str(_TOOLKIT_ROOT))


OBS_OPEN = "<!-- ENGINE-OBSERVATION-BEGIN -->"
OBS_CLOSE = "<!-- ENGINE-OBSERVATION-END -->"
OP_OPEN = "<!-- OPERATOR-AUTHORED-BEGIN -->"
OP_CLOSE = "<!-- OPERATOR-AUTHORED-END -->"


# ---------------------------------------------------------------------------
# Operator roster (Decision #3: senior-only, no role split)
# ---------------------------------------------------------------------------

@dataclass
class TeamMember:
    """One authenticated operator. All members have full triage rights
    (Decision #3: senior operators only)."""
    name: str             # operator name used as --operator flag
    email: str = ""
    added_at: str = ""
    added_by: str = ""    # who added them to roster
    notes: str = ""


def _engineers_ini_path() -> Path:
    """Roster lives at team_config/engineers.ini, alongside other
    institutional config rather than under schema_learner/ which is
    primarily engine-internal."""
    p = _TOOLKIT_ROOT / "team_config"
    p.mkdir(parents=True, exist_ok=True)
    return p / "engineers.ini"


def load_team_roster() -> dict[str, TeamMember]:
    """Load the team roster. Returns dict keyed by member name.
    Returns an empty dict if the roster file doesn't exist yet —
    callers should treat that as 'roster not configured' and either
    refuse to proceed or operate in a bootstrap mode."""
    path = _engineers_ini_path()
    if not path.is_file():
        return {}
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(path, encoding='utf-8')
    members: dict[str, TeamMember] = {}
    for section in cp.sections():
        members[section] = TeamMember(
            name=section,
            email=cp.get(section, 'email', fallback=''),
            added_at=cp.get(section, 'added_at', fallback=''),
            added_by=cp.get(section, 'added_by', fallback=''),
            notes=cp.get(section, 'notes', fallback=''),
        )
    return members


def write_team_member(member: TeamMember) -> Path:
    """Add or update a team member in the roster."""
    path = _engineers_ini_path()
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    if path.is_file():
        cp.read(path, encoding='utf-8')
    section = member.name
    if not cp.has_section(section):
        cp.add_section(section)
    cp.set(section, 'email', member.email)
    cp.set(section, 'added_at', member.added_at
           or _dt.datetime.now().isoformat())
    cp.set(section, 'added_by', member.added_by)
    if member.notes:
        cp.set(section, 'notes', member.notes)
    with path.open('w', encoding='utf-8') as f:
        f.write(
            "; Team roster — Phase 5 (DESIGN_team_scale_addendum.md)\n"
            "; Each section is one authenticated team member.\n"
            "; Per Decision #3: senior operators only, no role split.\n"
            "; All members have full triage rights.\n"
            "; The toolkit refuses --operator names not in this roster.\n\n"
        )
        cp.write(f)
    return path


def remove_team_member(name: str) -> bool:
    """Remove a member from the roster. Returns True if removed."""
    path = _engineers_ini_path()
    if not path.is_file():
        return False
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(path, encoding='utf-8')
    if not cp.has_section(name):
        return False
    cp.remove_section(name)
    with path.open('w', encoding='utf-8') as f:
        f.write(
            "; Team roster — Phase 5 (DESIGN_team_scale_addendum.md)\n"
            "; Each section is one authenticated team member.\n"
            "; Per Decision #3: senior operators only, no role split.\n"
            "; All members have full triage rights.\n"
            "; The toolkit refuses --operator names not in this roster.\n\n"
        )
        cp.write(f)
    return True


def is_authenticated_operator(name: str, *, allow_bootstrap: bool = True) -> bool:
    """Check whether an operator name is in the roster.
    
    If allow_bootstrap=True and the roster is empty, returns True for
    any non-empty name. This lets the team bootstrap their first member
    without chicken-and-egg trouble. As soon as ONE member exists, the
    bootstrap allowance ends — subsequent operators must be in roster.
    
    Production callers should pass allow_bootstrap=True. Test code can
    pass False to verify hard enforcement.
    """
    if not name or not name.strip():
        return False
    roster = load_team_roster()
    if not roster and allow_bootstrap:
        return True  # bootstrap: empty roster accepts any name
    return name in roster


def require_authenticated_operator(
    name: str, *, allow_bootstrap: bool = True,
) -> tuple[bool, str]:
    """Returns (ok, message). Designed for CLI gates."""
    if not name or not name.strip():
        return False, "operator name is empty"
    if is_authenticated_operator(name, allow_bootstrap=allow_bootstrap):
        return True, "ok"
    roster = load_team_roster()
    if not roster:
        return False, ("operator roster is empty and bootstrap was "
                       "disabled. Add at least one team member to "
                       "team_config/engineers.ini first.")
    return False, (f"operator {name!r} not in team roster. "
                   f"Members: {sorted(roster.keys())}. "
                   f"To add this operator, run: "
                   f"team add --name {name} --added-by <existing-member>")


# ---------------------------------------------------------------------------
# Audit log (append-only, monthly rotation)
# ---------------------------------------------------------------------------

def _audit_root() -> Path:
    p = _TOOLKIT_ROOT / "schema_learner" / "audit"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _current_audit_log_path() -> Path:
    """Audit logs rotate monthly. Returns the current month's file."""
    ym = _dt.datetime.now().strftime('%Y-%m')
    return _audit_root() / f"{ym}.log"


@dataclass
class AuditEntry:
    """One audit-log record. Append-only, never modified."""
    action_id: str            # UUID for this entry
    timestamp: str            # ISO
    operator: str
    action_type: str          # e.g. 'triage_correct', 'merge_apply', 'sideline_claim'
    target: str               # surface tag, entry id, or merge id
    source_proposal: str = "" # which proposal (if applicable)
    detail: str = ""          # free-text additional context


def write_audit_entry(entry: AuditEntry) -> Path:
    """Append an entry to the current month's audit log.
    
    The audit log is APPEND-ONLY. We do not load → mutate → write
    because that race-condition-amplifies and risks losing entries.
    Instead we open in append mode and write a single section block.
    """
    path = _current_audit_log_path()
    is_new = not path.is_file()
    with path.open('a', encoding='utf-8') as f:
        if is_new:
            f.write(
                f"; Audit log — {_dt.datetime.now().strftime('%Y-%m')}\n"
                "; Phase 5 (DESIGN_team_scale_addendum.md)\n"
                "; APPEND-ONLY. Do not edit existing entries. Each\n"
                "; section is one state-mutating action. The audit log\n"
                "; is the team's forensic record.\n\n"
            )
        f.write(f"[{entry.action_id}]\n")
        f.write(f"timestamp = {entry.timestamp}\n")
        f.write(f"operator = {entry.operator}\n")
        f.write(f"action_type = {entry.action_type}\n")
        f.write(f"target = {entry.target}\n")
        if entry.source_proposal:
            f.write(f"source_proposal = {entry.source_proposal}\n")
        if entry.detail:
            # Bound detail to keep INI parsable
            f.write(f"detail = {entry.detail[:300].replace(chr(10), ' ')}\n")
        f.write("\n")
    return path


def log_action(
    operator: str,
    action_type: str,
    target: str,
    source_proposal: str = "",
    detail: str = "",
) -> AuditEntry:
    """Convenience wrapper. Builds the entry and writes it. Returns
    the entry so callers can reference its action_id."""
    entry = AuditEntry(
        action_id=f"audit_{uuid.uuid4().hex[:12]}",
        timestamp=_dt.datetime.now().isoformat(),
        operator=operator,
        action_type=action_type,
        target=target,
        source_proposal=source_proposal,
        detail=detail,
    )
    write_audit_entry(entry)
    return entry


def load_audit_log(
    year_month: str | None = None,
) -> list[AuditEntry]:
    """Load audit entries from a month's log file. If no year_month
    given, loads current month."""
    if year_month is None:
        year_month = _dt.datetime.now().strftime('%Y-%m')
    path = _audit_root() / f"{year_month}.log"
    if not path.is_file():
        return []
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(path, encoding='utf-8')
    entries: list[AuditEntry] = []
    for section in cp.sections():
        entries.append(AuditEntry(
            action_id=section,
            timestamp=cp.get(section, 'timestamp', fallback=''),
            operator=cp.get(section, 'operator', fallback=''),
            action_type=cp.get(section, 'action_type', fallback=''),
            target=cp.get(section, 'target', fallback=''),
            source_proposal=cp.get(section, 'source_proposal', fallback=''),
            detail=cp.get(section, 'detail', fallback=''),
        ))
    # Order by timestamp ascending
    entries.sort(key=lambda e: e.timestamp)
    return entries


# ---------------------------------------------------------------------------
# Lock management (prevent concurrent classification of same surface)
# ---------------------------------------------------------------------------

LOCK_TIMEOUT_HOURS_DEFAULT = 4


def _locks_root() -> Path:
    p = _TOOLKIT_ROOT / "schema_learner" / "locks"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _lock_id(surface_tag: str, proposal_dir: str) -> str:
    """Compute a deterministic lock ID for (surface, proposal)."""
    safe_surface = re.sub(r'[^a-zA-Z0-9_-]', '_', surface_tag)
    safe_prop = re.sub(r'[^a-zA-Z0-9_-]', '_', proposal_dir)
    return f"{safe_surface}__{safe_prop}"


def _lock_path(surface_tag: str, proposal_dir: str) -> Path:
    return _locks_root() / f"{_lock_id(surface_tag, proposal_dir)}.lock"


@dataclass
class LockInfo:
    surface_tag: str
    proposal_dir: str
    held_by: str
    acquired_at: str
    expires_at: str = ""

    def is_expired(self, timeout_hours: int = LOCK_TIMEOUT_HOURS_DEFAULT) -> bool:
        if not self.acquired_at:
            return True
        try:
            t = _dt.datetime.fromisoformat(self.acquired_at)
        except ValueError:
            return True
        age = _dt.datetime.now() - t
        return age.total_seconds() > timeout_hours * 3600


def _read_lock(surface_tag: str, proposal_dir: str) -> LockInfo | None:
    """Read existing lock if any. Returns None if no lock file."""
    p = _lock_path(surface_tag, proposal_dir)
    if not p.is_file():
        return None
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    try:
        cp.read(p, encoding='utf-8')
    except configparser.Error:
        return None
    if not cp.has_section('lock'):
        return None
    return LockInfo(
        surface_tag=cp.get('lock', 'surface_tag', fallback=surface_tag),
        proposal_dir=cp.get('lock', 'proposal_dir', fallback=proposal_dir),
        held_by=cp.get('lock', 'held_by', fallback=''),
        acquired_at=cp.get('lock', 'acquired_at', fallback=''),
        expires_at=cp.get('lock', 'expires_at', fallback=''),
    )


def _write_lock(info: LockInfo) -> Path:
    p = _lock_path(info.surface_tag, info.proposal_dir)
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.add_section('lock')
    cp.set('lock', 'surface_tag', info.surface_tag)
    cp.set('lock', 'proposal_dir', info.proposal_dir)
    cp.set('lock', 'held_by', info.held_by)
    cp.set('lock', 'acquired_at', info.acquired_at)
    cp.set('lock', 'expires_at', info.expires_at)
    with p.open('w', encoding='utf-8') as f:
        f.write(
            "; Triage lock — Phase 5 (DESIGN_team_scale_addendum.md)\n"
            "; Prevents concurrent classification of the same surface\n"
            "; in the same proposal by two engineers. Auto-expires\n"
            "; after the configured timeout (default 4 hours).\n\n"
        )
        cp.write(f)
    return p


def acquire_lock(
    surface_tag: str,
    proposal_dir: str,
    operator: str,
    timeout_hours: int = LOCK_TIMEOUT_HOURS_DEFAULT,
) -> tuple[bool, str, LockInfo | None]:
    """Try to acquire the lock. Returns (success, message, current_lock).
    
    On success, current_lock is the new lock just acquired.
    On contention, current_lock is the existing lock (if expired,
    we forcibly reclaim and return success; if active and held by
    a DIFFERENT operator, we refuse).
    
    Re-acquiring your own lock is always allowed (idempotent).
    """
    existing = _read_lock(surface_tag, proposal_dir)
    now = _dt.datetime.now()

    if existing is not None:
        if existing.held_by == operator:
            # Idempotent re-acquire — refresh timestamps
            new_info = LockInfo(
                surface_tag=surface_tag,
                proposal_dir=proposal_dir,
                held_by=operator,
                acquired_at=now.isoformat(),
                expires_at=(now + _dt.timedelta(hours=timeout_hours)).isoformat(),
            )
            _write_lock(new_info)
            return True, f"lock refreshed for {operator}", new_info

        if existing.is_expired(timeout_hours):
            # Stale lock — reclaim
            new_info = LockInfo(
                surface_tag=surface_tag,
                proposal_dir=proposal_dir,
                held_by=operator,
                acquired_at=now.isoformat(),
                expires_at=(now + _dt.timedelta(hours=timeout_hours)).isoformat(),
            )
            _write_lock(new_info)
            return True, (f"reclaimed expired lock from "
                          f"{existing.held_by} (was acquired at "
                          f"{existing.acquired_at})"), new_info

        # Active lock held by someone else — refuse
        return False, (f"lock held by {existing.held_by} since "
                       f"{existing.acquired_at}. "
                       f"Wait or work on a different surface."), existing

    # No existing lock — acquire fresh
    new_info = LockInfo(
        surface_tag=surface_tag,
        proposal_dir=proposal_dir,
        held_by=operator,
        acquired_at=now.isoformat(),
        expires_at=(now + _dt.timedelta(hours=timeout_hours)).isoformat(),
    )
    _write_lock(new_info)
    return True, f"lock acquired for {operator}", new_info


def release_lock(
    surface_tag: str,
    proposal_dir: str,
    operator: str,
) -> tuple[bool, str]:
    """Release a lock. Refuses if the lock is held by a different
    operator (use force_release_lock to break)."""
    existing = _read_lock(surface_tag, proposal_dir)
    if existing is None:
        return True, "no lock to release"
    if existing.held_by != operator:
        return False, (f"lock held by {existing.held_by}, not {operator}. "
                       f"Use force_release_lock if reclaiming.")
    p = _lock_path(surface_tag, proposal_dir)
    p.unlink()
    return True, "lock released"


def force_release_lock(
    surface_tag: str,
    proposal_dir: str,
    operator: str,
) -> tuple[bool, str, str]:
    """Forcibly release a lock regardless of who holds it. Logs the
    prior holder for audit trail. Returns (success, message, prior_holder)."""
    existing = _read_lock(surface_tag, proposal_dir)
    if existing is None:
        return True, "no lock to release", ""
    p = _lock_path(surface_tag, proposal_dir)
    p.unlink()
    return True, (f"forcibly released lock previously held by "
                  f"{existing.held_by}"), existing.held_by


def list_active_locks(
    timeout_hours: int = LOCK_TIMEOUT_HOURS_DEFAULT,
) -> list[LockInfo]:
    """List all currently-active (non-expired) locks."""
    locks: list[LockInfo] = []
    for p in _locks_root().glob("*.lock"):
        cp = configparser.ConfigParser(interpolation=None,
                                       inline_comment_prefixes=(';',))
        cp.optionxform = str
        try:
            cp.read(p, encoding='utf-8')
        except configparser.Error:
            continue
        if not cp.has_section('lock'):
            continue
        info = LockInfo(
            surface_tag=cp.get('lock', 'surface_tag', fallback=''),
            proposal_dir=cp.get('lock', 'proposal_dir', fallback=''),
            held_by=cp.get('lock', 'held_by', fallback=''),
            acquired_at=cp.get('lock', 'acquired_at', fallback=''),
            expires_at=cp.get('lock', 'expires_at', fallback=''),
        )
        if not info.is_expired(timeout_hours):
            locks.append(info)
    return locks


# ---------------------------------------------------------------------------
# Disagreement flags (cross-engineer review of approved-corpus entries)
# ---------------------------------------------------------------------------

@dataclass
class DisagreementFlag:
    """One flag filed by an engineer questioning a prior corpus entry."""
    flag_id: str                # disagreement_<surface>_<timestamp>
    surface_tag: str
    flagged_by: str             # engineer who filed
    flagged_at: str             # ISO
    flagged_reason: str         # free-text — why they disagree

    # Lifecycle
    # 'open': awaiting senior review
    # 'in_review': claimed by a reviewer
    # 'resolved_keep': reviewed and original classification stands
    # 'resolved_amend': reviewed, classification was amended (amendment
    #                   tracked separately via merge_engine)
    # 'resolved_revoke': reviewed, classification removed entirely
    status: str = "open"

    # Reviewer (set when resolved)
    reviewer: str = ""
    reviewed_at: str = ""
    review_notes: str = ""


def _disagreements_root() -> Path:
    p = _TOOLKIT_ROOT / "schema_learner" / "disagreements"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _disagreements_index_path() -> Path:
    return _disagreements_root() / "_index.ini"


def file_disagreement_flag(
    surface_tag: str,
    flagged_by: str,
    reason: str,
) -> DisagreementFlag:
    """File a flag against a prior approved-corpus classification.
    Returns the new flag entry."""
    safe_tag = re.sub(r'[^a-zA-Z0-9_-]', '_', surface_tag)
    ts = _dt.datetime.now().strftime('%Y%m%d_%H%M%S')
    flag_id = f"disagreement_{safe_tag}_{ts}"

    flag = DisagreementFlag(
        flag_id=flag_id,
        surface_tag=surface_tag,
        flagged_by=flagged_by,
        flagged_at=_dt.datetime.now().isoformat(),
        flagged_reason=reason,
        status="open",
    )

    # Append to index
    index_path = _disagreements_index_path()
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    if index_path.is_file():
        cp.read(index_path, encoding='utf-8')
    cp.add_section(flag_id)
    cp.set(flag_id, 'surface_tag', surface_tag)
    cp.set(flag_id, 'flagged_by', flagged_by)
    cp.set(flag_id, 'flagged_at', flag.flagged_at)
    cp.set(flag_id, 'reason_summary', reason[:200])
    cp.set(flag_id, 'status', flag.status)
    with index_path.open('w', encoding='utf-8') as f:
        f.write(
            "; Disagreement flags — Phase 5 (DESIGN_team_scale_addendum.md)\n"
            "; Cross-engineer review of approved-corpus entries.\n"
            "; When engineer B believes engineer A's prior\n"
            "; classification was wrong, a flag goes here.\n"
            "; Senior engineer resolves: keep / amend / revoke.\n\n"
        )
        cp.write(f)

    # Detail markdown
    md_path = _disagreements_root() / f"{flag_id}.md"
    md_lines = [
        f"# Disagreement: `<{surface_tag}>`",
        "",
        f"Flag ID: `{flag_id}`",
        f"Filed by: {flagged_by}",
        f"Filed at: {flag.flagged_at}",
        f"Status: {flag.status}",
        "",
        OP_OPEN,
        "## Engineer's reason for disagreement",
        "",
        reason,
        OP_CLOSE,
        "",
    ]
    md_path.write_text("\n".join(md_lines), encoding='utf-8')
    return flag


def load_disagreement_flags() -> list[DisagreementFlag]:
    """Load all disagreement flags from the index."""
    index_path = _disagreements_index_path()
    if not index_path.is_file():
        return []
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(index_path, encoding='utf-8')
    flags: list[DisagreementFlag] = []
    for section in cp.sections():
        flags.append(DisagreementFlag(
            flag_id=section,
            surface_tag=cp.get(section, 'surface_tag', fallback=''),
            flagged_by=cp.get(section, 'flagged_by', fallback=''),
            flagged_at=cp.get(section, 'flagged_at', fallback=''),
            flagged_reason=cp.get(section, 'reason_summary', fallback=''),
            status=cp.get(section, 'status', fallback='open'),
            reviewer=cp.get(section, 'reviewer', fallback=''),
            reviewed_at=cp.get(section, 'reviewed_at', fallback=''),
            review_notes=cp.get(section, 'review_notes', fallback=''),
        ))
    return flags


def resolve_disagreement(
    flag_id: str,
    reviewer: str,
    resolution: str,
    notes: str,
) -> tuple[bool, str]:
    """Resolve a disagreement flag.
    
    resolution must be one of:
      'keep'   — original classification stands
      'amend'  — classification was amended (amendment tracked elsewhere)
      'revoke' — classification removed entirely
    """
    if resolution not in ('keep', 'amend', 'revoke'):
        return False, f"resolution must be keep/amend/revoke, got {resolution!r}"
    if not notes or len(notes.strip()) < 20:
        return False, "review notes must be substantive (20+ chars)"

    index_path = _disagreements_index_path()
    if not index_path.is_file():
        return False, "no disagreement index"
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(index_path, encoding='utf-8')
    if not cp.has_section(flag_id):
        return False, f"flag {flag_id!r} not found"

    new_status = f"resolved_{resolution}"
    cp.set(flag_id, 'status', new_status)
    cp.set(flag_id, 'reviewer', reviewer)
    cp.set(flag_id, 'reviewed_at', _dt.datetime.now().isoformat())
    cp.set(flag_id, 'review_notes', notes[:300])
    with index_path.open('w', encoding='utf-8') as f:
        f.write(
            "; Disagreement flags — Phase 5 (DESIGN_team_scale_addendum.md)\n"
            "; Cross-engineer review of approved-corpus entries.\n"
            "; When engineer B believes engineer A's prior\n"
            "; classification was wrong, a flag goes here.\n"
            "; Senior engineer resolves: keep / amend / revoke.\n\n"
        )
        cp.write(f)

    # Append resolution to detail markdown
    md_path = _disagreements_root() / f"{flag_id}.md"
    if md_path.is_file():
        with md_path.open('a', encoding='utf-8') as f:
            f.write("\n---\n")
            f.write(f"\n## Resolution\n\n")
            f.write(f"Reviewer: {reviewer}\n")
            f.write(f"Reviewed at: {_dt.datetime.now().isoformat()}\n")
            f.write(f"Resolution: **{resolution}**\n\n")
            f.write(OP_OPEN)
            f.write("\n")
            f.write(notes)
            f.write("\n")
            f.write(OP_CLOSE)
            f.write("\n")
    return True, f"disagreement resolved: {new_status}"


def claim_disagreement(
    flag_id: str,
    reviewer: str,
) -> tuple[bool, str]:
    """Mark a disagreement flag in_review (claimed by a reviewer)."""
    index_path = _disagreements_index_path()
    if not index_path.is_file():
        return False, "no disagreement index"
    cp = configparser.ConfigParser(interpolation=None,
                                   inline_comment_prefixes=(';',))
    cp.optionxform = str
    cp.read(index_path, encoding='utf-8')
    if not cp.has_section(flag_id):
        return False, f"flag {flag_id!r} not found"
    current_status = cp.get(flag_id, 'status', fallback='')
    if current_status != 'open':
        return False, (f"flag is in status {current_status!r}, "
                       f"only 'open' flags can be claimed")
    cp.set(flag_id, 'status', 'in_review')
    cp.set(flag_id, 'reviewer', reviewer)
    cp.set(flag_id, 'reviewed_at', _dt.datetime.now().isoformat())
    with index_path.open('w', encoding='utf-8') as f:
        f.write(
            "; Disagreement flags — Phase 5 (DESIGN_team_scale_addendum.md)\n"
            "; Cross-engineer review of approved-corpus entries.\n"
            "; When engineer B believes engineer A's prior\n"
            "; classification was wrong, a flag goes here.\n"
            "; Senior engineer resolves: keep / amend / revoke.\n\n"
        )
        cp.write(f)
    return True, f"flag claimed by {reviewer}"
