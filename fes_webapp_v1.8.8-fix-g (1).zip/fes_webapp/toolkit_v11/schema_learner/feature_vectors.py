#!/usr/bin/env python3
"""
feature_vectors.py
==================

Foundation module for the schema-learner subsystem. Extracts STRUCTURAL
feature vectors from XML element types (after JSON conversion) and
computes structural similarity between them.

This module produces ONLY structural observations. It makes NO claim
about semantic meaning, vendor mapping, or surface category. Per the
founding principle: "no claim without provenance."

Used by:
  - schema_learner.py        (Mission A: schema learning)
  - corpus_scorer.py         (Mission B: reference cluster scoring)

The seven feature slots from DESIGN.md:

  Slot 1: Children bag-of-tags
            Sparse binary vector indexed by all known child-tag names.
            Captures: what kinds of children does this element have.
  
  Slot 2: Field-shape signature
            Sparse binary vector over distinct child-tag tuples.
            Captures: shape variation within an element type.
  
  Slot 3: Naming tokens
            Bag-of-tokens vector after splitting tag names on - and _.
            Captures: naming-convention proximity.
  
  Slot 4: Value-pattern fingerprint
            Histogram over value classifications (uuid, ipv4, port,
            boolean-numeric, enum-small, free-text, etc.).
            Captures: value-pattern signature of the element.
  
  Slot 5: Structural neighborhood
            Bag-of-sibling-tags vector.
            Captures: what other elements live next to this one.
  
  Slot 6: Reference-edge signature
            Bag-of-target-element-types vector for cross-references.
            Captures: what other elements does this element reference.
  
  Slot 7: Surface-category — NOT COMPUTED HERE.
            This slot is operator-declared during proposal review.
            See schema_learner.py for the operator-declaration flow.

Similarity metric:

  structural_similarity(A, B) = sum over i in 1..6 of:
                                  weight[i] * cosine(A.slot_i, B.slot_i)

  Weights live in placement_rules.ini and are tuned empirically.
  Output is in [0.0, 1.0]. This is STRUCTURAL similarity, not semantic
  kinship.
"""
from __future__ import annotations

import math
import re
import xml.etree.ElementTree as ET
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Value-pattern classifier
# ---------------------------------------------------------------------------

_UUID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
_IPV4_RE = re.compile(r"^(?:\d{1,3}\.){3}\d{1,3}(?:/\d{1,2})?$")
_IPV6_RE = re.compile(r"^[0-9a-fA-F:]+(?:/\d{1,3})?$")
_MAC_RE = re.compile(r"^(?:[0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}$")
_PORT_RE = re.compile(r"^\d{1,5}$")
_INT_RE = re.compile(r"^-?\d+$")


VALUE_PATTERN_CATEGORIES = (
    "uuid", "ipv4", "ipv6", "mac", "port",
    "boolean-numeric", "boolean-text",
    "enum-small", "enum-large",
    "free-text", "numeric-int", "empty",
)


def classify_value(text: str | None) -> str:
    """Classify a single text value into one of the categories above.
    
    This is a STRUCTURAL observation about the value, not a claim
    about its meaning.
    """
    if text is None:
        return "empty"
    s = text.strip()
    if s == "":
        return "empty"
    if _UUID_RE.match(s):
        return "uuid"
    if _IPV4_RE.match(s):
        # 0/1 also matches IPV4 prefix-style — disambiguate
        if s in ("0", "1"):
            return "boolean-numeric"
        return "ipv4"
    # Booleans (numeric and text)
    if s in ("0", "1"):
        return "boolean-numeric"
    if s.lower() in ("true", "false", "yes", "no", "on", "off",
                     "enabled", "disabled"):
        return "boolean-text"
    if _MAC_RE.match(s):
        return "mac"
    if _IPV6_RE.match(s) and ":" in s:
        return "ipv6"
    # Numeric (int)
    if _INT_RE.match(s):
        # Distinguish small numerics (likely ports) from larger
        n = int(s)
        if 0 <= n <= 65535 and len(s) <= 5:
            # Could be port or just a number; we'll call it port for
            # short numerics and numeric-int for others.
            # This isn't perfect but is consistent.
            return "port"
        return "numeric-int"
    # Default: free-text
    return "free-text"


def classify_field_value_distribution(values: list[str | None]) -> str:
    """Given all observed values for a field across instances, return
    the dominant category. If multiple categories appear, returns the
    most common; for enum detection, looks at distinct-value count.
    """
    if not values:
        return "empty"
    # Detect enum: small set of distinct values, all free-text-ish
    distinct = set(v.strip() if v else "" for v in values)
    distinct.discard("")
    if 2 <= len(distinct) <= 8 and all(
            classify_value(v) in ("free-text", "numeric-int", "boolean-text")
            for v in distinct):
        return "enum-small"
    if 9 <= len(distinct) <= 50 and all(
            classify_value(v) in ("free-text", "numeric-int")
            for v in distinct):
        return "enum-large"
    # Otherwise: most common per-value classification
    cats = Counter(classify_value(v) for v in values)
    return cats.most_common(1)[0][0]


# ---------------------------------------------------------------------------
# Naming-token tokenizer
# ---------------------------------------------------------------------------

def tokenize_tag_name(tag: str) -> list[str]:
    """Split a tag name into tokens for naming-similarity comparisons.
    
    'vpn-portal' -> ['vpn', 'portal']
    'ike_policy_group_list' -> ['ike', 'policy', 'group', 'list']
    'absMUVPN' -> ['absmuvpn']  (no camelCase split — keep simple)
    
    This is a STRUCTURAL operation. It says nothing about what the
    tokens MEAN.
    """
    return [t for t in re.split(r"[-_]", tag.lower()) if t]


# ---------------------------------------------------------------------------
# Feature vector dataclass
# ---------------------------------------------------------------------------

@dataclass
class ElementFeatureVector:
    """Structural feature vector for one element TYPE (not one instance).
    
    Aggregated across all instances of this element type observed in
    the input XML. Slots 1-6 are computed from observation; slot 7 is
    operator-declared and stored elsewhere (see DESIGN.md).
    """
    # The element tag, e.g. "vpn-portal"
    tag: str
    
    # How many instances of this tag were observed
    instance_count: int
    
    # Slot 1: children bag-of-tags
    # tag_name -> count of instances that have at least one child of this tag
    children_tags: Counter[str] = field(default_factory=Counter)
    
    # Slot 2: field-shape signatures
    # Each unique tuple of sorted-child-tags is one shape; count of occurrences
    field_shapes: Counter[tuple[str, ...]] = field(default_factory=Counter)
    
    # Slot 3: naming tokens (from this element's own tag name)
    naming_tokens: list[str] = field(default_factory=list)
    
    # Slot 4: value-pattern fingerprint
    # field_name -> dominant value category for that field
    value_patterns: dict[str, str] = field(default_factory=dict)
    
    # Slot 5: structural neighborhood
    # sibling tag -> count of times this element type appeared next to it
    siblings: Counter[str] = field(default_factory=Counter)
    
    # Slot 6: reference-edge signature (CROSS-REFERENCE TARGETS)
    # Populated by reference-detection logic (see DESIGN.md cross-reference
    # rules). For v1, we leave this empty and let the schema-learner
    # populate it when it integrates with wg_xml_references.ini.
    # NOTE: keeping this as a Counter for now; will populate post-v1.
    reference_targets: Counter[str] = field(default_factory=Counter)
    
    # Source of this feature vector — which corpus entry produced it.
    # Critical for provenance: every feature observation is traceable
    # to the corpus file it came from.
    source_files: list[str] = field(default_factory=list)

    # Phase 6: sample text values observed for THIS element's own text
    # (not its children's). Used by enabled-status detection to identify
    # leaf-with-boolean-value patterns like <Botnet>1</Botnet>. Bounded
    # to the first 8 distinct values to keep feature vectors small.
    # Empty string represents an element with no text content.
    sample_own_text_values: list[str] = field(default_factory=list)
    
    # Phase 6: count of instances where this element has NO children
    # AND has at least one non-empty text value. Used as a tier-input
    # signal: leaf elements with on/off-style values are the strongest
    # candidates for direct enabled-status read.
    leaf_with_value_count: int = 0


# ---------------------------------------------------------------------------
# Feature extraction from XML
# ---------------------------------------------------------------------------

def extract_features_from_tree(
    root: ET.Element,
    source_label: str,
) -> dict[str, ElementFeatureVector]:
    """Walk an XML tree and produce one feature vector per element type.
    
    Args:
        root: the root <profile> (or whatever) XML element
        source_label: identifier of the source file (for provenance).
                      Stored in the feature vector so every observation
                      traces back to where it was observed.
    
    Returns:
        dict mapping element-tag-name to ElementFeatureVector
    
    This function PRODUCES STRUCTURAL OBSERVATIONS only. It does not
    classify, categorize, name, or interpret the elements it sees.
    """
    by_tag: dict[str, ElementFeatureVector] = {}
    
    # Walk every element and aggregate structural data
    # We'll need to know parent-of-each-element for the sibling slot.
    # ElementTree doesn't track parents, so we build a parent map.
    parent_map: dict[ET.Element, ET.Element | None] = {root: None}
    for parent in root.iter():
        for child in parent:
            parent_map[child] = parent
    
    # First pass: collect raw data per element type
    # For value patterns, we need ALL values for each (parent_tag, field_tag)
    # combination, not just one example.
    field_values: dict[tuple[str, str], list[str | None]] = {}
    
    for elem in root.iter():
        tag = elem.tag
        if tag not in by_tag:
            by_tag[tag] = ElementFeatureVector(
                tag=tag,
                instance_count=0,
                naming_tokens=tokenize_tag_name(tag),
                source_files=[source_label],
            )
        else:
            if source_label not in by_tag[tag].source_files:
                by_tag[tag].source_files.append(source_label)
        
        fv = by_tag[tag]
        fv.instance_count += 1
        
        # Slot 1: children tags (one count per instance — count how
        # many INSTANCES have at least one child of each tag, not
        # how many children appear total)
        child_tags_in_this_instance = set(c.tag for c in elem)
        for ct in child_tags_in_this_instance:
            fv.children_tags[ct] += 1
        
        # Slot 2: field-shape signature
        shape = tuple(sorted(child_tags_in_this_instance))
        fv.field_shapes[shape] += 1
        
        # Slot 4: value-pattern data collection
        # For LEAF elements (no children), classify the text value.
        # For INTERMEDIATE elements, classify each direct-child text value.
        is_leaf = not list(elem)
        own_text = (elem.text or '').strip() if elem.text else ''
        if is_leaf:
            # Leaf: this element's text value goes into the field
            # statistics for its parent context
            parent = parent_map.get(elem)
            if parent is not None:
                key = (parent.tag, tag)
                field_values.setdefault(key, []).append(elem.text)
        
        # Phase 6: capture sample own-text values for enabled-status
        # detection. Limited to 8 distinct values per tag to keep the
        # feature vector small. Empty text contributes empty string.
        if own_text and own_text not in fv.sample_own_text_values:
            if len(fv.sample_own_text_values) < 8:
                fv.sample_own_text_values.append(own_text)
        if is_leaf and own_text:
            fv.leaf_with_value_count += 1
        
        # Slot 5: siblings
        parent = parent_map.get(elem)
        if parent is not None:
            for sib in parent:
                if sib is elem:
                    continue
                fv.siblings[sib.tag] += 1
    
    # Second pass: compute per-field value-pattern dominant category
    # and assign to the parent element's value_patterns dict.
    for (parent_tag, field_tag), values in field_values.items():
        if parent_tag not in by_tag:
            continue
        dominant = classify_field_value_distribution(values)
        by_tag[parent_tag].value_patterns[field_tag] = dominant
    
    return by_tag


def extract_features_from_file(
    xml_path: Path,
    source_label: str | None = None,
) -> dict[str, ElementFeatureVector]:
    """Convenience wrapper: parse an XML file and extract features."""
    label = source_label or xml_path.name
    tree = ET.parse(xml_path)
    return extract_features_from_tree(tree.getroot(), label)


# ---------------------------------------------------------------------------
# Vocabulary management — mapping symbolic tags to vector indices
# ---------------------------------------------------------------------------

@dataclass
class Vocabulary:
    """Maps symbolic strings (tag names, tokens, shapes) to dense
    integer indices, so we can build vectors over a finite domain.
    
    Built up incrementally as we observe new symbols across corpus
    entries. Once built, used to compute cosine similarity in a
    common vector space.
    """
    children_tag_index: dict[str, int] = field(default_factory=dict)
    naming_token_index: dict[str, int] = field(default_factory=dict)
    sibling_tag_index: dict[str, int] = field(default_factory=dict)
    field_shape_index: dict[tuple[str, ...], int] = field(default_factory=dict)
    value_pattern_index: dict[str, int] = field(
        default_factory=lambda: {cat: i for i, cat in
                                 enumerate(VALUE_PATTERN_CATEGORIES)})
    reference_target_index: dict[str, int] = field(default_factory=dict)
    
    def _ensure(self, name: str, index: dict[Any, int]) -> int:
        if name not in index:
            index[name] = len(index)
        return index[name]
    
    def absorb(self, fv: ElementFeatureVector) -> None:
        """Add all new symbols from this feature vector to the vocabulary."""
        for ct in fv.children_tags:
            self._ensure(ct, self.children_tag_index)
        for tok in fv.naming_tokens:
            self._ensure(tok, self.naming_token_index)
        for sib in fv.siblings:
            self._ensure(sib, self.sibling_tag_index)
        for shape in fv.field_shapes:
            self._ensure(shape, self.field_shape_index)
        for ref in fv.reference_targets:
            self._ensure(ref, self.reference_target_index)


# ---------------------------------------------------------------------------
# Vectorization
# ---------------------------------------------------------------------------

def _to_dense_vector(
    counter: Counter,
    vocab: dict[Any, int],
) -> list[float]:
    """Convert a Counter to a dense float vector indexed by vocab."""
    vec = [0.0] * len(vocab)
    for symbol, count in counter.items():
        if symbol in vocab:
            vec[vocab[symbol]] = float(count)
    return vec


def _to_dense_vector_from_list(
    items: list[str],
    vocab: dict[str, int],
) -> list[float]:
    """Convert a list of items (with possible repeats) to dense vector."""
    counts = Counter(items)
    return _to_dense_vector(counts, vocab)


def _value_pattern_to_dense(
    patterns: dict[str, str],
    vocab: dict[str, int],
) -> list[float]:
    """Convert per-field value-pattern dict to a histogram vector
    over value-pattern categories."""
    vec = [0.0] * len(vocab)
    for field_name, category in patterns.items():
        if category in vocab:
            vec[vocab[category]] += 1.0
    return vec


def vectorize(
    fv: ElementFeatureVector,
    vocab: Vocabulary,
) -> dict[str, list[float]]:
    """Convert one feature vector into six dense slot-vectors.
    
    Slot 7 (surface-category) is NOT included — that's operator-declared
    and lives outside this structural pipeline.
    """
    return {
        "slot1_children":       _to_dense_vector(
            fv.children_tags, vocab.children_tag_index),
        "slot2_field_shapes":   _to_dense_vector(
            fv.field_shapes, vocab.field_shape_index),
        "slot3_naming_tokens":  _to_dense_vector_from_list(
            fv.naming_tokens, vocab.naming_token_index),
        "slot4_value_patterns": _value_pattern_to_dense(
            fv.value_patterns, vocab.value_pattern_index),
        "slot5_siblings":       _to_dense_vector(
            fv.siblings, vocab.sibling_tag_index),
        "slot6_references":     _to_dense_vector(
            fv.reference_targets, vocab.reference_target_index),
    }


def _counter_to_sparse(
    counter: Counter,
    vocab: dict[Any, int],
) -> dict[int, float]:
    """Convert a Counter to {index: float} using vocab."""
    return {vocab[k]: float(v) for k, v in counter.items() if k in vocab}


def _list_to_sparse(
    items: list[str],
    vocab: dict[str, int],
) -> dict[int, float]:
    counts = Counter(items)
    return _counter_to_sparse(counts, vocab)


def _value_pattern_to_sparse(
    patterns: dict[str, str],
    vocab: dict[str, int],
) -> dict[int, float]:
    out: dict[int, float] = {}
    for category in patterns.values():
        if category in vocab:
            out[vocab[category]] = out.get(vocab[category], 0.0) + 1.0
    return out


def vectorize_sparse(
    fv: ElementFeatureVector,
    vocab: Vocabulary,
) -> dict[str, tuple[dict[int, float], float]]:
    """Sparse version of vectorize. Returns per-slot
    (sparse_vector, precomputed_norm) tuples.
    
    Used by the schema-learner when comparing one novel element
    against many corpus elements. Saves ~10x time vs dense iteration
    over 900-dim vectors that are mostly zero.
    """
    slots = {
        "slot1_children":       _counter_to_sparse(
            fv.children_tags, vocab.children_tag_index),
        "slot2_field_shapes":   _counter_to_sparse(
            fv.field_shapes, vocab.field_shape_index),
        "slot3_naming_tokens":  _list_to_sparse(
            fv.naming_tokens, vocab.naming_token_index),
        "slot4_value_patterns": _value_pattern_to_sparse(
            fv.value_patterns, vocab.value_pattern_index),
        "slot5_siblings":       _counter_to_sparse(
            fv.siblings, vocab.sibling_tag_index),
        "slot6_references":     _counter_to_sparse(
            fv.reference_targets, vocab.reference_target_index),
    }
    # Precompute norms — major savings when the same vector is
    # compared against many others
    return {
        slot: (vec, math.sqrt(sum(v * v for v in vec.values())))
        for slot, vec in slots.items()
    }


def structural_similarity_sparse(
    vec_a: dict[str, tuple[dict[int, float], float]],
    vec_b: dict[str, tuple[dict[int, float], float]],
    weights: dict[str, float] | None = None,
) -> dict[str, float]:
    """Sparse-aware structural similarity. Same contract as
    structural_similarity, but uses precomputed sparse vectors
    and norms.
    
    NAMING DISCIPLINE: still STRUCTURAL similarity, never semantic.
    """
    w = weights or DEFAULT_SLOT_WEIGHTS
    breakdown: dict[str, float] = {}
    aggregate = 0.0
    weight_total = 0.0
    for slot_name, weight in w.items():
        if slot_name not in vec_a or slot_name not in vec_b:
            continue
        vec_a_data, norm_a = vec_a[slot_name]
        vec_b_data, norm_b = vec_b[slot_name]
        sim = cosine_similarity_sparse(
            vec_a_data, vec_b_data, norm_a, norm_b)
        breakdown[slot_name] = sim
        aggregate += weight * sim
        weight_total += weight
    if weight_total > 0:
        aggregate = aggregate / weight_total
    breakdown["aggregate"] = aggregate
    return breakdown


# ---------------------------------------------------------------------------
# Cosine similarity (pure Python — no NumPy dependency)
# ---------------------------------------------------------------------------

def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two equal-length vectors. Returns 0.0
    if either vector is all-zero (degenerate case)."""
    if len(a) != len(b):
        raise ValueError(
            f"vector length mismatch: {len(a)} vs {len(b)}")
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def cosine_similarity_sparse(
    a: dict[int, float],
    b: dict[int, float],
    norm_a: float,
    norm_b: float,
) -> float:
    """Cosine similarity computed in sparse form. Inputs are
    {index: value} dicts; norms are precomputed.

    Performance equivalent to dense cosine for these vectors:
    most slot vectors have <100 nonzeros out of 900 dimensions,
    so sparse iteration touches ~10% of the entries.
    """
    if norm_a == 0 or norm_b == 0:
        return 0.0
    # Iterate the smaller dict for speed
    if len(a) > len(b):
        a, b = b, a
    dot = 0.0
    for idx, val in a.items():
        bv = b.get(idx)
        if bv is not None:
            dot += val * bv
    return dot / (norm_a * norm_b)


# ---------------------------------------------------------------------------
# Aggregate structural similarity
# ---------------------------------------------------------------------------

# Default weights from DESIGN.md. Override via placement_rules.ini.
DEFAULT_SLOT_WEIGHTS = {
    "slot1_children":       0.20,
    "slot2_field_shapes":   0.15,
    "slot3_naming_tokens":  0.20,
    "slot4_value_patterns": 0.25,
    "slot5_siblings":       0.15,
    "slot6_references":     0.05,
}


def structural_similarity(
    vec_a: dict[str, list[float]],
    vec_b: dict[str, list[float]],
    weights: dict[str, float] | None = None,
) -> dict[str, float]:
    """Compute weighted aggregate structural similarity plus per-slot
    breakdowns.
    
    IMPORTANT — naming discipline:
    
        This function returns STRUCTURAL similarity. It does NOT
        return semantic kinship. A high score means "these two
        elements share structural properties." It does NOT mean
        "these two elements are in the same family." Family
        determination is an operator declaration (slot 7), not
        something this math can produce.
    
    Returns:
        {
          "aggregate":            float in [0, 1],
          "slot1_children":       per-slot cosine,
          "slot2_field_shapes":   per-slot cosine,
          ...
        }
    """
    w = weights or DEFAULT_SLOT_WEIGHTS
    breakdown: dict[str, float] = {}
    aggregate = 0.0
    weight_total = 0.0
    for slot_name, weight in w.items():
        if slot_name not in vec_a or slot_name not in vec_b:
            continue
        sim = cosine_similarity(vec_a[slot_name], vec_b[slot_name])
        breakdown[slot_name] = sim
        aggregate += weight * sim
        weight_total += weight
    if weight_total > 0:
        # Normalize so weights don't have to sum to exactly 1.0
        aggregate = aggregate / weight_total
    breakdown["aggregate"] = aggregate
    return breakdown


# ---------------------------------------------------------------------------
# Public API summary
# ---------------------------------------------------------------------------
#
# Typical usage (from the schema-learner):
#
#   # Build vocabulary from corpus
#   vocab = Vocabulary()
#   corpus_features = {}
#   for xml_file in corpus_files:
#       fvs = extract_features_from_file(xml_file)
#       for tag, fv in fvs.items():
#           vocab.absorb(fv)
#           corpus_features[(xml_file.name, tag)] = fv
#
#   # Extract features from new XML
#   new_fvs = extract_features_from_file(new_xml)
#   for fv in new_fvs.values():
#       vocab.absorb(fv)
#
#   # Compare each new element to each known one
#   for new_tag, new_fv in new_fvs.items():
#       new_vec = vectorize(new_fv, vocab)
#       for (corpus_file, corpus_tag), corpus_fv in corpus_features.items():
#           corpus_vec = vectorize(corpus_fv, vocab)
#           sim = structural_similarity(new_vec, corpus_vec)
#           # sim["aggregate"] is the headline structural similarity
#           # The schema-learner reports this to the operator as
#           # an OBSERVATION, not a claim about kinship.
