#!/usr/bin/env python3
"""
ref_integrity_validator.py — verify every named cross-reference in a
candidate XML points to an actually-defined object.

The trap this catches: a <policy> says <service>Any</service> but no
<service><name>Any</name></service> exists in <service-list>. Firebox
rejects:
   "Service 'Any' does not exist."

REFERENCE RULES (each entry: ref_xpath, target_list, target_name_tag)
   - <service> under policy/abs-policy must exist in service-list
   - <ike-action> under ipsec-action must exist in ike-action-list
   - <ipsec-action> under abs-policy must exist in ipsec-action-list
   - <ipsec-proposal>/<member> under ipsec-action must exist in
     ipsec-proposal-list
   - etc.

USAGE
   python3 ref_integrity_validator.py <candidate.xml>
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET


# Cross-reference rules. Each: (where_referenced_xpath_glob, target_list,
# target_name_tag). The "where_referenced" is matched as a substring of
# the leaf's XPath from root.
REF_RULES = [
    # /policy-list/policy/service -> service-list/service/name
    ('/policy-list/policy/service',         'service-list',         'name'),
    ('/abs-policy-list/abs-policy/service', 'service-list',         'name'),
    # Alias references — policies' from/to-alias-list/alias must resolve
    # to an entry in alias-list OR interface-list (both kinds register
    # alias names the Firebox recognizes).
    ('/policy-list/policy/from-alias-list/alias', 'alias-list', 'name'),
    ('/policy-list/policy/to-alias-list/alias',   'alias-list', 'name'),
    ('/abs-policy-list/abs-policy/from-alias-list/alias',
     'alias-list', 'name'),
    ('/abs-policy-list/abs-policy/to-alias-list/alias',
     'alias-list', 'name'),
    # IKE/IPSec cross-refs
    ('/ipsec-action-list/ipsec-action/ike-policy',
     'ike-policy-list', 'name'),
    # Site-to-site BOVPN: ipsec-action references ike-policy-group, not
    # ike-policy directly. Verified against jpa: bovpntunnel.1 ipsec-
    # action references bovpngateway.1 ike-policy-group. The WG Web UI
    # Branch Office VPN panel only displays tunnels where this ref
    # resolves to an actual ike-policy-group entry.
    ('/ipsec-action-list/ipsec-action/ike-policy-group',
     'ike-policy-group-list', 'name'),
    ('/ipsec-action-list/ipsec-action/ipsec-proposal/member',
     'ipsec-proposal-list', 'name'),
    ('/abs-policy-list/abs-policy/ipsec-action',
     'ipsec-action-list', 'name'),
    ('/abs-policy-list/abs-policy/ike-action',
     'ike-action-list',  'name'),
    ('/ike-policy-list/ike-policy/ike-action',
     'ike-action-list',  'name'),
    # ike-policy.peer-addr must resolve to an address-group whose <name>
    # equals the IP literal used. Verified against lab T-30 12.5.9:
    #   "The remote gateway IP address '14.14.14.14' does not exist."
    # The exception 'Any' is the WG mobile-VPN dynamic-peer pattern
    # and is accepted as a literal; ignored by the value-skip logic.
    ('/ike-policy-list/ike-policy/peer-addr',
     'address-group-list', 'name'),
]


# Values that are well-known WG literals and don't need a defining
# address-group. These get skipped during ref-integrity checking.
PEER_ADDR_LITERAL_EXEMPTIONS = frozenset(['Any', '0.0.0.0', ''])


def _is_ip_literal(s: str) -> bool:
    """True if string parses as IPv4/IPv6 literal.

    NOTE (2026-06-11): This helper is currently UNUSED. It was added
    based on an incorrect read of WG peer-addr semantics — I thought
    WG accepted name labels in <peer-addr> without a backing address-
    group. The lab disproved that:
       "Restore Failed: 400 The remote gateway IP address
        'FakePriIPSECGwNameORAdrClaude' does not exist."
    Every <peer-addr> value (IP or name) needs a matching
    <address-group> entry. The toolkit now emits a backing group for
    name-form values with a 0.0.0.0 placeholder member; the strict
    dangling-ref check is back in force above. Helper kept for
    future diagnostics use."""
    if not s:
        return False
    import ipaddress
    try:
        ipaddress.ip_address(s.strip())
        return True
    except (ValueError, TypeError):
        return False


# Some target lists store names across MULTIPLE source lists. For alias
# references, the alias name might live in alias-list OR interface-list
# (interface names are usable as alias references in policies).
EXTRA_TARGET_LISTS = {
    'alias-list': ['interface-list'],  # interface names also valid as aliases
}


def build_xpath(elem: ET.Element, parent_map: dict) -> str:
    parts = [elem.tag]
    cur = elem
    while id(cur) in parent_map:
        cur = parent_map[id(cur)]
        parts.append(cur.tag)
    return '/' + '/'.join(reversed(parts))


def index_target_names(root: ET.Element, target_list: str,
                       name_tag: str) -> set:
    target = root.find(target_list)
    if target is None:
        return set()
    return {
        n.text.strip() for n in target.iter(name_tag)
        if n.text and n.text.strip()
    }


def validate(candidate: Path) -> int:
    try:
        root = ET.parse(candidate).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: candidate parse failed: {e}', file=sys.stderr)
        return 2

    parent_map = {id(c): p for p in root.iter() for c in p}

    # Index all target lists once. For target lists with EXTRA_TARGET_LISTS,
    # union the names from extra lists too (e.g. an alias reference may
    # point to either alias-list or interface-list).
    target_indexes: dict[tuple, set] = {}
    for _, target_list, name_tag in REF_RULES:
        key = (target_list, name_tag)
        if key in target_indexes:
            continue
        names = index_target_names(root, target_list, name_tag)
        for extra_list in EXTRA_TARGET_LISTS.get(target_list, []):
            names |= index_target_names(root, extra_list, name_tag)
        target_indexes[key] = names

    findings = []
    found_count = 0
    for elem in root.iter():
        if list(elem):
            continue
        text = (elem.text or '').strip() if elem.text else ''
        if not text:
            continue
        xpath = build_xpath(elem, parent_map)
        for ref_path, target_list, name_tag in REF_RULES:
            if not xpath.endswith(ref_path):
                continue
            # peer-addr exemptions: WG accepts these specific literals
            # without a backing address-group ('Any' = mobile-VPN any
            # peer; '0.0.0.0' = dynamic peer; '' = empty).
            # EVERY OTHER value, whether IP literal or name label, MUST
            # have a matching address-group entry in address-group-list.
            #
            # Lab T-30 12.5.9 rejection confirms this:
            #   "Restore Failed: 400 The remote gateway IP address
            #    'FakePriIPSECGwNameORAdrClaude' does not exist."
            # — the Firebox restore-time check is strict for BOTH IP
            # literals and name labels. An earlier version of this
            # validator incorrectly exempted name labels from the
            # dangling-ref check; that exemption let the rejection
            # slip through to the lab. The validator should be the
            # safety net — re-enabling strict checking here.
            if (ref_path.endswith('/peer-addr')
                    and text in PEER_ADDR_LITERAL_EXEMPTIONS):
                break
            found_count += 1
            valid_names = target_indexes[(target_list, name_tag)]
            if text not in valid_names:
                # Try case-insensitive nearest match for hint
                lower = text.lower()
                nearest = None
                for v in valid_names:
                    if v.lower() == lower:
                        nearest = v
                        break
                msg = (f'value {text!r} at {xpath} does not exist in '
                       f'<{target_list}> (target field <{name_tag}>). '
                       f'Firebox will reject: "Service/Object {text!r} '
                       f'does not exist."')
                if nearest:
                    msg += f' Did you mean {nearest!r}?'
                findings.append((xpath, text, target_list, msg))
            break  # matched a rule, stop scanning

    print(f'ref_integrity_validator')
    print(f'  candidate: {candidate}')
    print('=' * 72)
    print(f'  references checked: {found_count}')
    print(f'  DANGLING references: {len(findings)}')
    print()
    if findings:
        # Group by (target_list, value)
        grouped = defaultdict(list)
        for xp, text, target, msg in findings:
            grouped[(target, text)].append(xp)
        print('=' * 72)
        print(f'DANGLING references (grouped):')
        print('=' * 72)
        for (target, text), xpaths in grouped.items():
            print(f'\n  {text!r} -> <{target}> ({len(xpaths)} reference(s))')
            for xp in xpaths[:3]:
                print(f'    {xp}')
            if len(xpaths) > 3:
                print(f'    ... and {len(xpaths)-3} more')
    return 0 if not findings else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('candidate', type=Path)
    args = p.parse_args()
    return validate(args.candidate)


if __name__ == '__main__':
    sys.exit(main())
