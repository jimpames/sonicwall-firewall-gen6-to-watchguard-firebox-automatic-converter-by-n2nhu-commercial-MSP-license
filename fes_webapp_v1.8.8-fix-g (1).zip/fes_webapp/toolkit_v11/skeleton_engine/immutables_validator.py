#!/usr/bin/env python3
"""
immutables_validator.py — verify candidate XML respects every immutable
classified by immutables_classifier.py.

CHECKS
   1. FROZEN scalar tags: candidate's text MUST exactly match jpa's
   2. STRUCTURAL_LOCK lists:
      - cardinality (count of direct children) MUST match jpa's
      - the set of <name> values MUST match jpa's (no adds, no drops,
        no renames)

These catch the class of hardware-property drift that produced:
   "You must configure exactly 5 physical interfaces for model T30"
   (caused by appending an extra interface to interface-list)

USAGE
   python3 immutables_validator.py <candidate.xml>
                                    [--reference jpa.xml]
                                    [--immutables immutables.json]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
import xml.etree.ElementTree as ET


def validate(candidate: Path, reference: Path,
             immutables_path: Path) -> int:
    if not immutables_path.is_file():
        print(f'ERROR: immutables map not found: {immutables_path}',
              file=sys.stderr)
        return 2
    try:
        cand_root = ET.parse(candidate).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: candidate parse failed: {e}', file=sys.stderr)
        return 2
    try:
        ref_root = ET.parse(reference).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: reference parse failed: {e}', file=sys.stderr)
        return 2
    immut = json.loads(immutables_path.read_text(encoding='utf-8'))
    cls_map = immut['classification']

    hard = []

    # 1. FROZEN scalar leaves must match jpa exactly
    for tag, info in cls_map.items():
        if info['class'] != 'FROZEN':
            continue
        ref_elem = ref_root.find(tag)
        cand_elem = cand_root.find(tag)
        if ref_elem is None:
            continue
        # Only frozen-scalar check applies to leaves
        if list(ref_elem):
            continue
        ref_text = (ref_elem.text or '').strip()
        cand_text = ((cand_elem.text or '').strip()
                     if cand_elem is not None else None)
        if cand_elem is None:
            hard.append((tag, '',
                         f'FROZEN <{tag}> missing in candidate '
                         f'(jpa has {ref_text!r})'))
            continue
        if cand_text != ref_text:
            hard.append((tag, cand_text,
                         f'FROZEN <{tag}> = {cand_text!r}, '
                         f'jpa has {ref_text!r} — must match exactly '
                         f'(hardware/firmware identifier)'))

    # 2. STRUCTURAL_LOCK lists: cardinality + names must match exactly,
    # EXCEPT for interface-list where the lock applies only to PHYSICAL
    # interfaces (item-type=1) and LOGICAL ALIASES (no item-type).
    # VPN-VIRTUAL interfaces (item-type=4) are user-created and may be
    # legitimately scrubbed when their tunnel is scrubbed.
    for tag, info in cls_map.items():
        if info['class'] != 'STRUCTURAL_LOCK':
            continue
        ref_elem = ref_root.find(tag)
        cand_elem = cand_root.find(tag)
        if ref_elem is None or cand_elem is None:
            continue

        def _is_added_logical_interface(intf_elem):
            """Return True if this <interface> is a logical/virtual add
            (item-type 2=VLAN, 4=VPN tunnel) and therefore exempt from
            the STRUCTURAL_LOCK on <interface-list>.

            Provenance:
              - item-type=4 (VPN tunnel): excluded since the BOVPN
                feature adds tunnel interfaces dynamically.
              - item-type=2 (VLAN sub-interface): excluded for the same
                reason — VLAN sub-interfaces are operator-configurable
                logical additions, not hardware ports. Golden ref
                line 18190-18213 shows vlanconfig77forClaude as a
                separate <interface> with item-type=2. The Firebox
                schema permits these additions; only PHYSICAL interface
                cardinality is hardware-locked.
            """
            iil = intf_elem.find('if-item-list')
            if iil is None:
                return False
            for it in iil.iter('item-type'):
                if it.text in ('2', '4'):
                    return True
            return False

        # For interface-list, exclude logical/virtual interfaces (VLAN
        # sub-interfaces, VPN tunnels) from the lock-set comparison.
        # The lock applies only to physical hardware ports.
        if tag == 'interface-list':
            ref_kids = [k for k in ref_elem if not _is_added_logical_interface(k)]
            cand_kids = [k for k in cand_elem if not _is_added_logical_interface(k)]
        else:
            ref_kids = list(ref_elem)
            cand_kids = list(cand_elem)

        ref_names = []
        for k in ref_kids:
            n = k.find('name')
            if n is not None and n.text:
                ref_names.append(n.text)
        cand_names = []
        for k in cand_kids:
            n = k.find('name')
            if n is not None and n.text:
                cand_names.append(n.text)
        # Cardinality check
        if len(cand_kids) != len(ref_kids):
            hard.append((tag, '',
                         f'STRUCTURAL_LOCK <{tag}> cardinality drift: '
                         f'candidate has {len(cand_kids)} entries, '
                         f'jpa has {len(ref_kids)} '
                         f'(VLAN-logical + VPN-virtual excluded from check; '
                         f'{info["rationale"]})'))
        # Name-set check
        ref_set = set(ref_names)
        cand_set = set(cand_names)
        missing = ref_set - cand_set
        extra = cand_set - ref_set
        if missing:
            hard.append((tag, '',
                         f'STRUCTURAL_LOCK <{tag}> MISSING required '
                         f'entries: {sorted(missing)}'))
        if extra:
            hard.append((tag, '',
                         f'STRUCTURAL_LOCK <{tag}> has EXTRA entries '
                         f'not in jpa: {sorted(extra)} '
                         f'(adding to locked list breaks hardware '
                         f'contract — Firebox will reject)'))

    print(f'immutables_validator')
    print(f'  candidate: {candidate}')
    print(f'  reference: {reference}')
    print('=' * 72)
    print(f'  HARD findings: {len(hard)}')
    if hard:
        print()
        for tag, val, msg in hard:
            print(f'  <{tag}>: {msg}')
    return 0 if not hard else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('candidate', type=Path)
    p.add_argument('--reference', type=Path,
                   default=Path(__file__).parent.parent
                          / 'schema_learner' / 'corpus' / 'T30jpa1.xml')
    p.add_argument('--immutables', type=Path,
                   default=Path(__file__).parent / 'output'
                          / 'immutables.json')
    args = p.parse_args()
    return validate(args.candidate, args.reference, args.immutables)


if __name__ == '__main__':
    sys.exit(main())
