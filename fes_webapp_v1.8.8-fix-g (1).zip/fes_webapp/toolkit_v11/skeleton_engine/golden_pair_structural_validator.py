#!/usr/bin/env python3
"""
golden_pair_structural_validator.py — structural fidelity score vs WG ref.

QUESTION
   Does the emit produce the same TYPES of things at the same PLACES as
   the hand-built WG reference, even when specific values differ?

WHAT IT MEASURES
   Structural completeness — the emit must have the same XML element
   skeleton as the reference. Missing elements indicate incomplete
   shape emission; extra elements (where allowed) indicate the toolkit
   is being thorougher than the reference.

WHAT IT DOESN'T MEASURE
   - Whether VALUES match (that's value_validator)
   - Whether the emit conforms to jpa schema (qualities/jpa_diff)

INPUTS
   - WG reference XML (path from golden_pair_config.ini)
   - Emit XML (CLI arg)
   - leaves_quality.json (per-XPath weight derivation)
   - golden_pair_config.ini (fuzzy rules + weights + thresholds)

OUTPUT
   Per-list structural score + composite [0.0, 1.0]:
     - XPath coverage (how many ref XPaths exist in emit)
     - Weighted by load-bearing vs cosmetic
     - Order-insensitive comparison for declared lists
     - Cardinality check for STRUCTURAL_LOCK lists

EXIT
   0 if score >= pass threshold; 1 otherwise; 2 on config error.
"""
from __future__ import annotations

import argparse
import configparser
import json
import sys
from collections import defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET


def _load_cfg(path: Path) -> dict:
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp.read(path, encoding='utf-8')
    cfg: dict = {
        'wg_ref': cp.get('golden_pair', 'wg_ref', fallback=''),
        'wg_ref_sha256': cp.get('golden_pair', 'wg_ref_sha256', fallback=''),
        'pass_threshold': cp.getfloat('thresholds',
                                       'structural_fidelity_pass',
                                       fallback=0.85),
        'warning_threshold': cp.getfloat('thresholds',
                                          'structural_fidelity_warning',
                                          fallback=0.65),
        'weight_load_bearing': cp.getfloat('weights', 'load_bearing',
                                            fallback=1.0),
        'weight_mixed': cp.getfloat('weights', 'mixed', fallback=0.5),
        'weight_cosmetic': cp.getfloat('weights', 'cosmetic', fallback=0.1),
        'cosmetic_leaves': set(),
        'order_insensitive_lists': set(),
        'order_sensitive_lists': set(),
        'allow_emit_supersetting_ref': True,
    }
    if cp.has_section('cosmetic_leaves'):
        cfg['cosmetic_leaves'] = {
            s.strip() for s in
            cp.get('cosmetic_leaves', 'names', fallback='').split()
            if s.strip()
        }
    if cp.has_section('fuzzy_rules'):
        cfg['order_insensitive_lists'] = {
            s.strip() for s in
            cp.get('fuzzy_rules', 'order_insensitive_lists',
                    fallback='').split()
            if s.strip()
        }
        cfg['order_sensitive_lists'] = {
            s.strip() for s in
            cp.get('fuzzy_rules', 'order_sensitive_lists',
                    fallback='').split()
            if s.strip()
        }
        cfg['allow_emit_supersetting_ref'] = cp.getboolean(
            'fuzzy_rules', 'allow_emit_supersetting_ref', fallback=True
        )
    return cfg


def _classify_xpath(xpath: str, quality_entry: dict | None,
                     cosmetic_leaves: set[str]) -> str:
    """Return 'load_bearing' | 'mixed' | 'cosmetic' for an XPath."""
    leaf = xpath.rsplit('/', 1)[-1]
    if leaf in cosmetic_leaves:
        return 'cosmetic'
    if not quality_entry:
        return 'mixed'  # unknown XPath gets middle weight
    # Load-bearing heuristics:
    # - closed_enum (Firebox parses the value as an enum)
    # - integer-typed (numeric semantic)
    # - empty-not-allowed AND only one distinct value (placeholder critical)
    if quality_entry.get('closed_enum'):
        return 'load_bearing'
    if quality_entry.get('dominant_type') == 'integer':
        return 'load_bearing'
    # Cosmetic heuristics:
    # - empty_allowed=true (placeholder OK) AND many distinct values
    if quality_entry.get('empty_allowed') and \
            quality_entry.get('distinct_value_count', 0) > 5:
        return 'cosmetic'
    return 'mixed'


def _build_xpath_set(root: ET.Element, prefix: str = '') -> set[str]:
    """Walk tree, return set of all XPaths (no indices, leaf-only).
    XPath format matches leaves_quality.json keys."""
    paths: set[str] = set()
    base = prefix or f'/{root.tag}'
    if not list(root):
        # leaf
        paths.add(base)
    else:
        for child in root:
            paths |= _build_xpath_set(child, base + '/' + child.tag)
    return paths


def _list_child_names(list_elem: ET.Element) -> set[str]:
    """For a list element (e.g. <alias-list>), return the set of
    <name> values of its direct children. Used for order-insensitive
    comparison."""
    names = set()
    for child in list_elem:
        n = child.find('name')
        if n is not None and n.text:
            names.add(n.text)
    return names


def _list_child_count(list_elem: ET.Element) -> int:
    """Direct child count (not <name>-based)."""
    return len(list(list_elem))


def score_structural(ref_root: ET.Element, emit_root: ET.Element,
                       quality_matrix: dict, cfg: dict
                       ) -> tuple[float, dict]:
    """Compute weighted structural-fidelity score.

    Returns (score, detail_dict).
    """
    ref_paths = _build_xpath_set(ref_root)
    emit_paths = _build_xpath_set(emit_root)

    matched: list[tuple[str, float]] = []
    missing: list[tuple[str, float]] = []

    for xp in ref_paths:
        cls = _classify_xpath(xp, quality_matrix.get(xp),
                                cfg['cosmetic_leaves'])
        weight = {
            'load_bearing': cfg['weight_load_bearing'],
            'mixed':         cfg['weight_mixed'],
            'cosmetic':      cfg['weight_cosmetic'],
        }[cls]
        if xp in emit_paths:
            matched.append((xp, weight))
        else:
            missing.append((xp, weight))

    total_weight = sum(w for _, w in matched) + sum(w for _, w in missing)
    matched_weight = sum(w for _, w in matched)
    xpath_score = matched_weight / total_weight if total_weight > 0 else 0.0

    # List-level analysis (order-insensitive matching for declared lists,
    # cardinality check for declared sensitive lists).
    list_findings: dict[str, dict] = {}

    # Process order-insensitive lists: presence of expected child names
    for list_tag in cfg['order_insensitive_lists']:
        ref_list = ref_root.find(list_tag)
        emit_list = emit_root.find(list_tag)
        if ref_list is None:
            continue
        ref_names = _list_child_names(ref_list)
        emit_names = _list_child_names(emit_list) if emit_list is not None else set()
        if not ref_names:
            continue
        in_both = ref_names & emit_names
        missing_in_emit = ref_names - emit_names
        extra_in_emit = emit_names - ref_names
        coverage = len(in_both) / len(ref_names) if ref_names else 1.0
        list_findings[list_tag] = {
            'kind': 'order-insensitive',
            'ref_count': len(ref_names),
            'emit_count': len(emit_names),
            'in_both': len(in_both),
            'missing': sorted(missing_in_emit),
            'extra':   sorted(extra_in_emit),
            'coverage': coverage,
        }

    # Process order-sensitive lists: cardinality check
    for list_tag in cfg['order_sensitive_lists']:
        ref_list = ref_root.find(list_tag)
        emit_list = emit_root.find(list_tag)
        if ref_list is None:
            continue
        ref_n = _list_child_count(ref_list)
        emit_n = _list_child_count(emit_list) if emit_list is not None else 0
        list_findings[list_tag] = {
            'kind': 'cardinality',
            'ref_count': ref_n,
            'emit_count': emit_n,
            'match': ref_n == emit_n,
            'coverage': 1.0 if ref_n == emit_n else (
                min(ref_n, emit_n) / max(ref_n, emit_n) if max(ref_n, emit_n) else 1.0
            ),
        }

    detail = {
        'xpath_score': xpath_score,
        'matched_xpaths': len(matched),
        'missing_xpaths': len(missing),
        'total_ref_xpaths': len(ref_paths),
        'total_emit_xpaths': len(emit_paths),
        'matched_weight': matched_weight,
        'total_weight': total_weight,
        'list_findings': list_findings,
        'missing_load_bearing': sorted(
            xp for xp, w in missing
            if w >= cfg['weight_load_bearing'] - 0.01
        )[:15],  # top 15
    }
    return xpath_score, detail


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve().parent
    p.add_argument('emit_xml', type=Path,
                    help='Path to emitted configuration.xml')
    p.add_argument('--config', type=Path,
                    default=here / 'golden_pair_config.ini')
    p.add_argument('--matrix', type=Path,
                    default=here / 'output' / 'leaves_quality.json')
    p.add_argument('--wg-ref', type=Path,
                    help='Override WG ref path (default: from config)')
    p.add_argument('--quiet', action='store_true')
    args = p.parse_args()

    if not args.config.is_file():
        print(f'ERROR: config not found: {args.config}', file=sys.stderr)
        return 2
    cfg = _load_cfg(args.config)

    toolkit_root = args.config.resolve().parent.parent
    wg_ref_path = args.wg_ref or (toolkit_root / cfg['wg_ref'])
    if not wg_ref_path.is_file():
        print(f'ERROR: WG ref not found: {wg_ref_path}', file=sys.stderr)
        return 2
    if not args.emit_xml.is_file():
        print(f'ERROR: emit XML not found: {args.emit_xml}', file=sys.stderr)
        return 2

    # Provenance check on the WG ref
    if cfg['wg_ref_sha256']:
        import hashlib
        actual = hashlib.sha256(wg_ref_path.read_bytes()).hexdigest()
        if actual != cfg['wg_ref_sha256']:
            print(f'WARNING: WG ref SHA mismatch.', file=sys.stderr)
            print(f'  expected: {cfg["wg_ref_sha256"]}', file=sys.stderr)
            print(f'  actual:   {actual}', file=sys.stderr)

    try:
        ref_root = ET.parse(wg_ref_path).getroot()
        emit_root = ET.parse(args.emit_xml).getroot()
    except ET.ParseError as e:
        print(f'ERROR: XML parse failed: {e}', file=sys.stderr)
        return 2

    matrix: dict = {}
    if args.matrix.is_file():
        matrix = json.loads(args.matrix.read_text(encoding='utf-8'))

    score, detail = score_structural(ref_root, emit_root, matrix, cfg)

    print('=' * 72)
    print(' golden_pair_structural_validator — structural fidelity vs WG ref')
    print('=' * 72)
    print(f'  WG ref:   {wg_ref_path}')
    print(f'  emit:     {args.emit_xml}')
    print(f'  ref XPaths:   {detail["total_ref_xpaths"]}')
    print(f'  emit XPaths:  {detail["total_emit_xpaths"]}')
    print(f'  matched:      {detail["matched_xpaths"]}')
    print(f'  missing:      {detail["missing_xpaths"]}')
    print(f'  weighted XPath coverage: {detail["matched_weight"]:.2f} / '
          f'{detail["total_weight"]:.2f}')
    print()

    if not args.quiet and detail['list_findings']:
        print('  List-level findings:')
        for list_tag, finding in sorted(detail['list_findings'].items()):
            if finding['kind'] == 'order-insensitive':
                cov = finding['coverage']
                icon = '✓' if cov >= 0.99 else ('~' if cov >= 0.5 else '✗')
                print(f'    {icon} {list_tag} (set, '
                       f'{finding["in_both"]}/{finding["ref_count"]} '
                       f'ref names present, '
                       f'+{len(finding["extra"])} extra)')
                if finding['missing'] and not args.quiet:
                    for name in finding['missing'][:5]:
                        print(f'        missing: {name}')
                    if len(finding['missing']) > 5:
                        print(f'        ... and {len(finding["missing"]) - 5} more')
            elif finding['kind'] == 'cardinality':
                icon = '✓' if finding['match'] else '✗'
                print(f'    {icon} {list_tag} (cardinality): '
                       f'ref={finding["ref_count"]}, '
                       f'emit={finding["emit_count"]}')
        print()

    if not args.quiet and detail['missing_load_bearing']:
        print('  Top missing load-bearing XPaths (first 15):')
        for xp in detail['missing_load_bearing']:
            print(f'    - {xp}')
        print()

    print('=' * 72)
    print(f'  structural fidelity score: {score:.4f}')
    print(f'  pass threshold:            {cfg["pass_threshold"]:.4f}')
    print('=' * 72)

    return 0 if score >= cfg['pass_threshold'] else 1


if __name__ == '__main__':
    sys.exit(main())
