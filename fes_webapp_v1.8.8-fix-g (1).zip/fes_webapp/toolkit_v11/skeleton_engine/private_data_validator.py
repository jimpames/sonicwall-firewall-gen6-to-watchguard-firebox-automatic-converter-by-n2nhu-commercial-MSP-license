#!/usr/bin/env python3
"""
private_data_validator.py — backstop validator. Reads the [private_strings]
section of scrub_config.ini and scans the emitted XML for any of those
strings anywhere in the body.

If ANY private string is found, validation fails HARD. This catches
incomplete factory classifications and any future regression where a
filler accidentally inserts a jpa-customer-private value.

INVOCATION
   python3 private_data_validator.py <candidate.xml> [--config scrub.ini]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Reuse the loader from jpa_scrubber
from jpa_scrubber import load_scrub_config


def validate(candidate: Path, config_path: Path) -> int:
    if not candidate.is_file():
        print(f'ERROR: candidate not found: {candidate}', file=sys.stderr)
        return 2
    if not config_path.is_file():
        print(f'ERROR: config not found: {config_path}', file=sys.stderr)
        return 2

    config = load_scrub_config(config_path)
    private_strings = config['private_strings']

    body = candidate.read_text(encoding='utf-8', errors='replace')
    findings = []
    for s in private_strings:
        if not s:
            continue
        # Count occurrences and grab first few line numbers
        count = body.count(s)
        if count > 0:
            # Find line numbers
            lines = []
            for i, line in enumerate(body.splitlines(), start=1):
                if s in line:
                    lines.append(i)
                    if len(lines) >= 5:
                        break
            findings.append((s, count, lines))

    print(f'private_data_validator')
    print(f'  candidate: {candidate}')
    print(f'  config:    {config_path}')
    print(f'  scanning for {len(private_strings)} known-private strings')
    print('=' * 72)
    print(f'  HARD findings (jpa-customer-private data leaked): '
          f'{len(findings)}')
    if findings:
        print()
        for s, count, lines in findings:
            print(f'  LEAKED {s!r}: {count} occurrence(s), '
                  f'first at lines {lines}')
        print()
        print('  This jpa-customer-private data MUST be scrubbed before')
        print('  shipping. Run jpa_scrubber.py or extend scrub_config.ini')
        print('  factory_names / factory_patterns to remove these entries.')
    return 0 if not findings else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('candidate', type=Path)
    p.add_argument('--config', type=Path,
                   default=Path(__file__).parent / 'scrub_config.ini')
    args = p.parse_args()
    return validate(args.candidate, args.config)


if __name__ == '__main__':
    sys.exit(main())
