#!/usr/bin/env python3
"""
leaves_quality_extractor.py — extract a per-XPath quality matrix from
jpa.xml, the authoritative ground truth.

For every leaf element in jpa.xml, captures EVERY observable quality:
  - Full XPath (root to leaf, with positional indexing collapsed)
  - Exact distinct values observed (the closed enum, if any)
  - Value-type: integer / token / hostname / ip / cidr / mac / hex /
                quoted-string / freetext / empty-only / mixed
  - Casing pattern: lower / Upper / Title / UPPER / Mixed / N/A
  - Length: min / max / median
  - Empty-allowed: whether jpa shows an empty value at this path
  - Format signature: a stable structural fingerprint (capitalization
                      class per character, separator positions). Used
                      to match new values to the right format pattern.
  - Total observations: how often jpa shows this path

OUTPUT
  leaves_quality.json: {xpath: {qualities...}}

PHILOSOPHY
  jpa.xml is the export of a working Firebox. Every leaf there is in a
  form WG TEC accepts. Our emitted XML must produce values matching the
  SAME qualities at the SAME XPath. No generalization across paths,
  no inferring type systems. Per-path, per-leaf, exact-form-match.

USAGE
  python3 leaves_quality_extractor.py [--reference jpa.xml]
                                       [--output leaves_quality.json]
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET
from statistics import median


# Regex catalog for value-type detection — ordered most-specific first.
# Order matters: integer must beat token must beat freetext.
_RE_INTEGER   = re.compile(r'^-?\d+$')
_RE_HEX       = re.compile(r'^(?:0x)?[0-9a-fA-F]+$')
_RE_IP4       = re.compile(r'^\d{1,3}(?:\.\d{1,3}){3}$')
_RE_CIDR4     = re.compile(r'^\d{1,3}(?:\.\d{1,3}){3}/\d{1,2}$')
_RE_IP6       = re.compile(r'^[0-9a-fA-F:]+(?::[0-9a-fA-F]+)+$')
_RE_MAC       = re.compile(r'^[0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){5}$')
_RE_HOSTNAME  = re.compile(r'^[A-Za-z][A-Za-z0-9\-\.]*$')
_RE_TOKEN     = re.compile(r'^[A-Za-z][A-Za-z0-9 _\-]*$')
_RE_QUOTED    = re.compile(r'^".*"$|^\'.*\'$')


def classify_value(text: str) -> str:
    """Return a canonical type token for a value string."""
    if text == '':
        return 'empty'
    if _RE_INTEGER.match(text):
        return 'integer'
    if _RE_CIDR4.match(text):
        return 'cidr4'
    if _RE_IP4.match(text):
        # Validate octets
        try:
            parts = [int(p) for p in text.split('.')]
            if all(0 <= p <= 255 for p in parts):
                return 'ip4'
        except ValueError:
            pass
    if _RE_MAC.match(text):
        return 'mac'
    if _RE_IP6.match(text) and ':' in text:
        return 'ip6'
    if _RE_QUOTED.match(text):
        return 'quoted'
    if _RE_HEX.match(text) and len(text) >= 4:
        return 'hex'
    if _RE_HOSTNAME.match(text):
        return 'hostname'
    if _RE_TOKEN.match(text):
        return 'token'
    return 'freetext'


def casing_pattern(text: str) -> str:
    """Return a casing token for a string value:
       lower / Upper (first letter upper, rest lower) / UPPER / Title /
       Mixed / N/A (numeric or empty)."""
    if not text:
        return 'N/A'
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return 'N/A'
    if all(c.islower() for c in letters):
        return 'lower'
    if all(c.isupper() for c in letters):
        return 'UPPER'
    # Title case: every word starts upper, rest lower
    words = re.split(r'[\s_\-/]+', text)
    if all(w[0].isupper() and (len(w) == 1 or w[1:].islower())
           for w in words if w and w[0].isalpha()):
        if text[0].isupper() and not text.isupper():
            return 'Title'
    # Upper-first: first letter upper, rest mixed/lower
    if text[0].isupper() and any(c.islower() for c in letters[1:]):
        return 'Upper-first'
    return 'Mixed'


def format_signature(text: str) -> str:
    """Return a stable structural fingerprint of a string's shape.
    Character classes: A=upper, a=lower, 9=digit, .=dot, :=colon,
    /=slash, _=underscore, -=dash, space=space, ?=other.
    Consecutive same-class chars collapse with `+`. This lets us
    compare 'Any', 'Allow', 'Trusted' all matching the 'A+' / 'Aa+'
    pattern, and distinguish '192.168.1.1' from 'host.example.com'.
    """
    if not text:
        return ''
    out = []
    last = None
    for c in text:
        if c.isupper():
            cls = 'A'
        elif c.islower():
            cls = 'a'
        elif c.isdigit():
            cls = '9'
        elif c == '.':
            cls = '.'
        elif c == ':':
            cls = ':'
        elif c == '/':
            cls = '/'
        elif c == '_':
            cls = '_'
        elif c == '-':
            cls = '-'
        elif c == ' ':
            cls = ' '
        else:
            cls = '?'
        if cls == last:
            out.append(cls)
        else:
            out.append(cls)
            last = cls
    # Collapse runs: AAAAaaa -> A+a+
    raw = ''.join(out)
    collapsed = []
    i = 0
    while i < len(raw):
        c = raw[i]
        j = i
        while j < len(raw) and raw[j] == c:
            j += 1
        run_len = j - i
        if run_len >= 2:
            collapsed.append(c + '+')
        else:
            collapsed.append(c)
        i = j
    return ''.join(collapsed)


def build_xpath(elem: ET.Element, parent_map: dict) -> str:
    """Build a positional-free XPath: /profile/policy-list/policy/service.
    Note: instance-level positional indexing is intentionally collapsed
    so all instances of <policy> share one XPath bucket."""
    parts = [elem.tag]
    cur = elem
    while id(cur) in parent_map:
        cur = parent_map[id(cur)]
        parts.append(cur.tag)
    return '/' + '/'.join(reversed(parts))


def profile_leaf(values: list[str], total: int) -> dict:
    """Build the quality profile for a single XPath given all observed
    values at that path."""
    if not values:
        return {}
    non_empty = [v for v in values if v != '']
    empty_count = total - len(non_empty)
    distinct = Counter(non_empty)
    types = Counter(classify_value(v) for v in non_empty)
    casings = Counter(casing_pattern(v) for v in non_empty)
    sigs = Counter(format_signature(v) for v in non_empty)
    lengths = [len(v) for v in non_empty]
    profile = {
        'total_observations': total,
        'empty_count': empty_count,
        'empty_allowed': empty_count > 0,
        'distinct_value_count': len(distinct),
        # Top-50 cap to keep matrix size sane on freetext fields
        'distinct_values': sorted(distinct.keys())[:50] if len(distinct) <= 200 else None,
        'value_types': dict(types),
        'dominant_type': types.most_common(1)[0][0] if types else 'empty',
        'casing_patterns': dict(casings),
        'dominant_casing': casings.most_common(1)[0][0] if casings else 'N/A',
        'format_signatures': dict(sigs.most_common(20)),
        'dominant_signature': sigs.most_common(1)[0][0] if sigs else '',
        'length_min': min(lengths) if lengths else 0,
        'length_max': max(lengths) if lengths else 0,
        'length_median': int(median(lengths)) if lengths else 0,
    }
    # Closed-enum heuristic — only when we have strong evidence:
    #   - small finite set of distinct values (<=25)
    #   - lots of observations relative to distinct count (>=3x)
    #   - at least 4 distinct values seen
    #   - dominant type is string-shaped (not raw integer where the
    #     real schema is 0..N range that jpa just happens to undersample)
    is_string_shaped = types.get('integer', 0) < len(non_empty) // 2
    if (len(distinct) <= 25 and total >= 3 * len(distinct)
            and len(distinct) >= 4 and is_string_shaped):
        profile['closed_enum'] = True
        profile['enum_values'] = sorted(distinct.keys())
    else:
        profile['closed_enum'] = False
    # If pure-integer and the distinct values look like a CLOSED range
    # (saturated AND well-sampled, both required, not either), capture
    # as enforceable constraint. Saturated alone isn't enough if total
    # sample size is small — could just be undersampled coverage.
    if types.get('integer', 0) == len(non_empty) and non_empty:
        ints = sorted({int(v) for v in non_empty})
        profile['integer_min_observed'] = ints[0]
        profile['integer_max_observed'] = ints[-1]
        profile['integer_distinct'] = ints[:50] if len(ints) <= 50 else None
        implied_range = ints[-1] - ints[0] + 1
        saturated = len(ints) == implied_range
        well_sampled = total >= 3 * implied_range
        # Both conditions AND distinct >= 4 to claim closed range
        if saturated and well_sampled and len(ints) >= 4:
            profile['integer_min'] = ints[0]
            profile['integer_max'] = ints[-1]
            profile['integer_range_confidence'] = 'saturated+well-sampled'
    return profile


def extract(reference: Path, output: Path) -> int:
    if not reference.is_file():
        print(f'ERROR: reference not found: {reference}', file=sys.stderr)
        return 2
    try:
        root = ET.parse(reference).getroot()
    except ET.ParseError as e:
        print(f'ERROR: jpa.xml parse failed: {e}', file=sys.stderr)
        return 2

    parent_map = {id(c): p for p in root.iter() for c in p}

    # Gather (xpath, value) for every leaf
    by_xpath: dict[str, list[str]] = defaultdict(list)
    for elem in root.iter():
        if list(elem):
            continue  # not a leaf
        xpath = build_xpath(elem, parent_map)
        text = (elem.text or '').strip() if elem.text else ''
        by_xpath[xpath].append(text)

    # Profile each XPath
    matrix = {}
    for xpath, values in by_xpath.items():
        matrix[xpath] = profile_leaf(values, len(values))

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(matrix, indent=2, sort_keys=True),
                      encoding='utf-8')

    # Summary
    print(f'leaves-quality matrix extracted')
    print(f'  reference: {reference}')
    print(f'  output:    {output}')
    print(f'  distinct XPaths: {len(matrix)}')
    print(f'  total leaf observations: '
          f'{sum(p["total_observations"] for p in matrix.values())}')
    closed = sum(1 for p in matrix.values() if p.get('closed_enum'))
    print(f'  closed-enum XPaths: {closed}')
    print(f'  open-form XPaths:   {len(matrix) - closed}')
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--reference', type=Path,
                   default=Path(__file__).parent.parent
                          / 'schema_learner' / 'corpus' / 'T30jpa1.xml')
    p.add_argument('--output', type=Path,
                   default=Path(__file__).parent / 'output'
                          / 'leaves_quality.json')
    args = p.parse_args()
    return extract(args.reference, args.output)


if __name__ == '__main__':
    sys.exit(main())
