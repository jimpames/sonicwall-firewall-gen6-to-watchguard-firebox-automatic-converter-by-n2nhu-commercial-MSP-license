#!/usr/bin/env python3
"""
build_pipeline.py — run the full skeleton-based migration pipeline.

STAGES
  1. sonicwall_parser → parsed canonical JSON
  2. enricher          → enriched customer records
  3. skeleton_extractor → skeleton.xml + templates.json
                          (only if matrix is missing or jpa changed)
  4. leaves_quality_extractor → leaves_quality.json
                          (only if missing or jpa changed)
  5. skeleton_filler   → fill skeleton with customer records
  6. qualities_validator → check leaves against quality matrix
  7. jpa_diff          → structural diff against jpa.xml

Each stage halts on fatal error. Final report prints HARD/SOFT counts.

USAGE
  python3 build_pipeline.py [--input sonicwall_parser/input/nsa3600.txt]
                            [--full-rebuild]
"""
from __future__ import annotations

import argparse
import json
import hashlib
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent.parent
JPA = ROOT / 'schema_learner' / 'corpus' / 'T30jpa1.xml'


def _utf8_env():
    """Return an env dict forcing UTF-8 for child Python processes.
    
    On Windows, the default stdio encoding for subprocesses is cp1252
    (or whatever the OEM code page is). When build_pipeline captures
    stdout from a child with text=True, Python decodes those bytes
    using the parent's preferred encoding. If a child writes Unicode
    characters like ✓, ✗, em-dashes, etc., the child crashes with
    UnicodeEncodeError trying to write them to the captured pipe.
    
    PYTHONIOENCODING=utf-8 forces the child's stdin/stdout/stderr to
    UTF-8 regardless of locale. PYTHONUTF8=1 enables UTF-8 mode for
    the child interpreter (Python 3.7+). Together they make subprocess
    output deterministic across Linux, macOS, and Windows.
    """
    env = os.environ.copy()
    env['PYTHONIOENCODING'] = 'utf-8'
    env['PYTHONUTF8'] = '1'
    return env


def run(cmd: list, cwd: Path = ROOT, desc: str = '') -> int:
    if desc:
        print(f'  {desc}')
    result = subprocess.run(cmd, cwd=cwd, capture_output=True,
                              text=True, encoding='utf-8',
                              env=_utf8_env())
    if result.returncode != 0:
        print(f'  FAILED ({result.returncode}):')
        print(result.stdout[-2000:] if result.stdout else '')
        print(result.stderr[-2000:] if result.stderr else '')
    return result.returncode


def maybe_rebuild_skeleton_assets(force: bool) -> int:
    """Rebuild classifier + skeleton + matrix only if jpa.xml is newer,
    or if forced, or if scrub_config.ini has changed."""
    skel = ROOT / 'skeleton_engine' / 'output' / 'skeleton.xml'
    tmpl = ROOT / 'skeleton_engine' / 'output' / 'templates.json'
    matrix = ROOT / 'skeleton_engine' / 'output' / 'leaves_quality.json'
    immut = ROOT / 'skeleton_engine' / 'output' / 'immutables.json'
    scrub_cfg = ROOT / 'skeleton_engine' / 'scrub_config.ini'

    if not force and all(p.is_file() for p in [skel, tmpl, matrix, immut]):
        jpa_mtime = JPA.stat().st_mtime
        scrub_mtime = scrub_cfg.stat().st_mtime if scrub_cfg.is_file() else 0
        cutoff = max(jpa_mtime, scrub_mtime)
        if all(p.stat().st_mtime > cutoff
               for p in [skel, tmpl, matrix, immut]):
            print('  [skip] skeleton+matrix+immutables up-to-date '
                  'with jpa.xml + scrub_config.ini')
            return 0

    rc = run([sys.executable, 'skeleton_engine/immutables_classifier.py'],
             desc='[3a] classify immutables from jpa.xml')
    if rc != 0:
        return rc
    rc = run([sys.executable, 'skeleton_engine/skeleton_extractor.py'],
             desc='[3b] extract skeleton + templates from jpa.xml')
    if rc != 0:
        return rc
    # Scrub jpa-customer-private entries out of the skeleton BEFORE the
    # filler runs. Without this step, the previous customer's address
    # book, NAT rules, schedules, and policies leak through into the
    # new customer's box. Verified against lab T-30 12.5.9: aliases
    # named 'FAKECO-VPN-1', 'BOGUS', 'snat demo.snat', etc. — all from
    # jpa.xml's customer — were visible in the Web UI alias panel of
    # the imported config.
    rc = run([sys.executable, 'skeleton_engine/jpa_scrubber.py'],
             desc='[3c] scrub jpa-customer-private entries from skeleton')
    if rc != 0:
        return rc
    rc = run([sys.executable, 'skeleton_engine/leaves_quality_extractor.py'],
             desc='[4] extract leaves-quality matrix from jpa.xml')
    return rc


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input', type=Path,
                   default=ROOT / 'sonicwall_parser' / 'input' / 'nsa3600.txt')
    p.add_argument('--full-rebuild', action='store_true',
                   help='Force re-extraction of skeleton + matrix')
    args = p.parse_args()

    if not args.input.is_file():
        print(f'ERROR: input not found: {args.input}', file=sys.stderr)
        return 2

    print('=' * 72)
    print('BUILD PIPELINE')
    print('=' * 72)
    print(f'  input: {args.input}')
    print(f'  jpa:   {JPA}')

    # Stage 1: parse
    # Clear stale parser output first
    parser_out = ROOT / 'sonicwall_parser' / 'output'
    for f in parser_out.glob('*.json'):
        f.unlink()
    enricher_out = ROOT / 'enricher' / 'output'
    for f in enricher_out.glob('*.json'):
        f.unlink()
    rc = run([sys.executable, 'sonicwall_parser/sonicwall_parser.py',
              '--config', 'sonicwall_parser/parser_config.ini',
              '--input', str(args.input)],
             desc='[1] parse SonicOS config')
    if rc != 0:
        return rc

    # Stage 2: enrich
    rc = run([sys.executable, 'enricher.py'],
             cwd=ROOT / 'enricher',
             desc='[2] enrich to canonical records')
    if rc != 0:
        return rc

    # Stage 3+4: skeleton + matrix (cached)
    rc = maybe_rebuild_skeleton_assets(args.full_rebuild)
    if rc != 0:
        return rc

    # Stage 5: fill
    rc = run([sys.executable, 'skeleton_engine/skeleton_filler.py'],
             desc='[5] fill skeleton with customer data')
    if rc != 0:
        return rc

    # Stage 6: qualities validator
    print('[6] qualities_validator')
    result = subprocess.run(
        [sys.executable, 'skeleton_engine/qualities_validator.py',
         'skeleton_engine/output/configuration.xml'],
        cwd=ROOT, capture_output=True,
        text=True, encoding='utf-8', env=_utf8_env()
    )
    print(result.stdout[:1500])
    qv_rc = result.returncode

    # Stage 6b: referential integrity
    print('[6b] ref_integrity_validator')
    result = subprocess.run(
        [sys.executable, 'skeleton_engine/ref_integrity_validator.py',
         'skeleton_engine/output/configuration.xml'],
        cwd=ROOT, capture_output=True,
        text=True, encoding='utf-8', env=_utf8_env()
    )
    print(result.stdout)
    ri_rc = result.returncode

    # Stage 6c: immutables validator — verify no drift on FROZEN scalars
    # or STRUCTURAL_LOCK list cardinalities/names. Catches lab T-30 error:
    #   "You must configure exactly 5 physical interfaces for model T30"
    print('[6c] immutables_validator')
    result = subprocess.run(
        [sys.executable, 'skeleton_engine/immutables_validator.py',
         'skeleton_engine/output/configuration.xml'],
        cwd=ROOT, capture_output=True,
        text=True, encoding='utf-8', env=_utf8_env()
    )
    print(result.stdout)
    im_rc = result.returncode

    # Stage 6d: customer fidelity — verify every enricher record is
    # actually present in the emitted XML. Catches the class of failure
    # where a filler is missing and customer data silently drops.
    print('[6d] customer_fidelity_validator')
    result = subprocess.run(
        [sys.executable, 'skeleton_engine/customer_fidelity_validator.py',
         'skeleton_engine/output/configuration.xml'],
        cwd=ROOT, capture_output=True,
        text=True, encoding='utf-8', env=_utf8_env()
    )
    print(result.stdout)
    cf_rc = result.returncode

    # Stage 6e: schema shape — verify every parent/child tag pair in
    # the emit is also observed in jpa. Catches the class of failure
    # where the filler invents a tag name the WG schema doesn't allow.
    # Verified against lab T-30 12.5.9 import error:
    #   "Element 'network-addr': This element is not expected.
    #    Expected is one of (host-ip-addr, ip-network-addr, ...)"
    # which fired because the filler created <network-addr> when the
    # correct tag was <ip-network-addr>. Any future invented tag at
    # any path is caught the same way.
    print('[6e] schema_shape_validator')
    result = subprocess.run(
        [sys.executable, 'skeleton_engine/schema_shape_validator.py',
         'skeleton_engine/output/configuration.xml'],
        cwd=ROOT, capture_output=True,
        text=True, encoding='utf-8', env=_utf8_env()
    )
    print(result.stdout)
    ss_rc = result.returncode

    # Stage 6f: private-data leak check — backstop scan for any known
    # jpa-customer-private string anywhere in the emit. Catches the
    # privacy/correctness failure where jpa.xml's previous customer's
    # data (FAKECO-VPN-1, BOGUS, snat demo, 174.62.83.243, etc.) leaks
    # into the new customer's box.
    print('[6f] private_data_validator')
    result = subprocess.run(
        [sys.executable, 'skeleton_engine/private_data_validator.py',
         'skeleton_engine/output/configuration.xml'],
        cwd=ROOT, capture_output=True,
        text=True, encoding='utf-8', env=_utf8_env()
    )
    print(result.stdout)
    pd_rc = result.returncode

    # Stage 6g: required-children — predictive check for containers
    # that the WG schema requires to have at least one of N specific
    # children. Catches the class of failure where cascade-delete or
    # any other transform leaves a parent empty. Verified against lab
    # T-30 12.5.9 import error:
    #   "Element 'item': Missing child element(s). Expected is one of
    #    (physical-if, vlan-if, if-name, ipsec-action, sslvpn, ...)"
    print('[6g] required_children_validator')
    result = subprocess.run(
        [sys.executable, 'skeleton_engine/required_children_validator.py',
         'skeleton_engine/output/configuration.xml'],
        cwd=ROOT, capture_output=True,
        text=True, encoding='utf-8', env=_utf8_env()
    )
    print(result.stdout)
    rc_rc = result.returncode

    # Stage 7: jpa_diff
    print('[7] jpa_diff')
    result = subprocess.run(
        [sys.executable, 'wg_validator/jpa_diff.py',
         'skeleton_engine/output/configuration.xml'],
        cwd=ROOT, capture_output=True,
        text=True, encoding='utf-8', env=_utf8_env()
    )
    for line in result.stdout.splitlines():
        if 'findings' in line.lower() or 'comparing' in line.lower() \
                or line.startswith('==='):
            print('  ' + line)
    jd_rc = result.returncode

    # Stage 8: marker_pairing — empirical end-to-end shape pairing check
    # Reads marker_mapping.ini for the SW↔WG shape catalog derived from
    # two real working configs. For every SW-side shape detected, asserts
    # the expected WG counterpart(s) exist in the emit. Provenance-based
    # completeness metric. Exit 0 only when 100% paired.
    print('[8] marker_pairing_validator')
    result = subprocess.run(
        [sys.executable, 'skeleton_engine/marker_pairing_validator.py',
         '--sw-config', str(args.input),
         '--wg-xml', 'skeleton_engine/output/configuration.xml'],
        cwd=ROOT, capture_output=True,
        text=True, encoding='utf-8', env=_utf8_env()
    )
    for line in result.stdout.splitlines():
        if 'pair rate' in line.lower() or 'HARD findings' in line \
                or line.startswith('==='):
            print('  ' + line)
    mp_rc = result.returncode

    # Stage 9: golden_pair_validator — composite fidelity score against
    # the canonical golden reference pair (SW input + WG reference). Two
    # sub-scores combined:
    #   - value fidelity: how many SW marker values land at predicted
    #     WG XPath in emit
    #   - structural fidelity: how many WG ref XPaths exist in emit,
    #     weighted by load-bearing vs cosmetic
    # The composite is the one-number summary of overall toolkit fidelity.
    print('[9] golden_pair_validator')
    result = subprocess.run(
        [sys.executable, 'skeleton_engine/golden_pair_validator.py',
         'skeleton_engine/output/configuration.xml'],
        cwd=ROOT, capture_output=True,
        text=True, encoding='utf-8', env=_utf8_env()
    )
    for line in result.stdout.splitlines():
        if ('Sub-scores' in line or 'fidelity' in line.lower()
                or 'Composite score' in line or 'Verdict' in line
                or line.startswith('===')):
            print('  ' + line)
    gp_rc = result.returncode

    # Final report
    cfg = ROOT / 'skeleton_engine' / 'output' / 'configuration.xml'
    if cfg.is_file():
        data = cfg.read_bytes()
        sha = hashlib.sha256(data).hexdigest()
        print()
        print('=' * 72)
        print('FINAL FILE')
        print('=' * 72)
        print(f'  path:   {cfg}')
        print(f'  size:   {len(data):,} bytes / {data.count(chr(10).encode())+1:,} lines')
        print(f'  SHA256: {sha}')
        print(f'  qualities_validator exit:     {qv_rc}')
        print(f'  ref_integrity_validator exit: {ri_rc}')
        print(f'  immutables_validator exit:    {im_rc}')
        print(f'  customer_fidelity exit:       {cf_rc}')
        print(f'  schema_shape exit:            {ss_rc}')
        print(f'  private_data exit:            {pd_rc}')
        print(f'  required_children exit:       {rc_rc}')
        print(f'  jpa_diff exit:                {jd_rc}')
        print(f'  marker_pairing exit:          {mp_rc}')
        print(f'  golden_pair exit:             {gp_rc}')
        print(f'  push to lab if ALL TEN are 0; otherwise inspect findings')
    return max(qv_rc, ri_rc, im_rc, cf_rc, ss_rc, pd_rc, rc_rc, jd_rc, mp_rc, gp_rc)


if __name__ == '__main__':
    sys.exit(main())
