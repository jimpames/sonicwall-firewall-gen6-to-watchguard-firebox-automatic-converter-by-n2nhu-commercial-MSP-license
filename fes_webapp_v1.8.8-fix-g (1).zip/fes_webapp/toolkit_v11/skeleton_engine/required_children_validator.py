#!/usr/bin/env python3
"""
required_children_validator.py — predictive check for "Element X:
Missing child element(s). Expected is one of (...)" failures.

DERIVES rules from jpa.xml empirically, NOT from a hardcoded list.

For each (parent_tag, child_tag) pair seen in jpa.xml:
  - Find every instance of that <child> under that <parent>
  - Compute the set of grandchild tags present in EACH instance
  - The INTERSECTION of those sets is the "always present" grandchildren
  - If a grandchild appears in 100% of jpa instances, it's REQUIRED
  - The validator then checks every candidate <child> under <parent>
    has at least one of: (any required grandchild set OR a union pattern
    if jpa shows variability with required-one-of behavior)

This catches schema requirements derived from jpa empirically, instead
of waiting for a Firebox rejection to add a hardcoded rule.

Two error classes:
  HARD - missing ALL of jpa's always-present grandchildren
  WARN - has a different mix than any jpa instance ever showed

USAGE
   python3 required_children_validator.py <candidate.xml>
                                           [--reference jpa.xml]
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET


# Empirically-verified exceptions: WG-valid shapes that jpa.xml corpus
# didn't exercise. Adding these here is INI-IN-CODE provenance; in a
# future sprint these move to an INI file. For each rule key
# (grandparent_tag, parent_tag, child_tag), an exception either drops
# the rule entirely or conditionally drops it based on what OTHER
# siblings are present.
#
# Format: {rule_key: 'always_drop' OR predicate}
# Predicate is a function (kid_tags: set) -> bool: True means "skip
# the requirement when kid_tags satisfies the predicate."
EMPIRICAL_EXCEPTIONS = {
    # When <peer-auth> uses FQDN form (has <domain-name>),
    # <ip-addr> is NOT required.
    # Key format: (grandparent_tag, parent_tag, elem_tag) where elem
    # is the container being checked for required children.
    # Provenance: golden_pair/wg_reference.xml lines 2977-2981 show
    # <peer-auth> with peer-auth-mask=4, domain-name, NO ip-addr.
    # Lab T-30 12.5.9 loaded and rendered this shape correctly.
    # jpa corpus didn't include any FQDN-form peer-auth.
    ('ike-policy-list', 'ike-policy', 'peer-auth'):
        lambda kids: 'domain-name' in kids,
}


def _check_exception(rule_key, kid_tags):
    """Return True if the rule should be SKIPPED for this candidate."""
    exc = EMPIRICAL_EXCEPTIONS.get(rule_key)
    if exc is None:
        return False
    if exc == 'always_drop':
        return True
    if callable(exc):
        try:
            return exc(kid_tags)
        except Exception:
            return False
    return False


def derive_required_children(reference_root) -> dict:
    """For every (grandparent_tag, parent_tag, child_tag) tuple in jpa,
    compute:
       - 'required_grandchildren': set of grandchild tags present
         in EVERY instance (intersection)
       - 'sometimes_grandchildren': union minus intersection
       - 'instance_count': how many instances jpa had

    Key now includes GRANDPARENT to disambiguate context. Same tag in
    different contexts has different rules:
       - <policy> in <policy-list>: a full policy entry (~20 children)
       - <policy> in <abs-policy/policy-list>: a back-ref leaf
       - <member> in <addr-group-member>: needs an address-bearing child
       - <member> in <service-item>: needs port/protocol fields
       - <member> in <ipsec-proposal>: just a name string

    Returns { (gp_tag, p_tag, child_tag): {required, sometimes, count} }
    """
    parent_map = {id(c): p for p in reference_root.iter() for c in p}
    instances: dict = defaultdict(list)
    for elem in reference_root.iter():
        parent = parent_map.get(id(elem))
        if parent is None:
            continue
        grandparent = parent_map.get(id(parent))
        gp_tag = grandparent.tag if grandparent is not None else '_root_'
        kid_tags = {c.tag for c in elem}
        if not kid_tags:
            continue  # leaf
        instances[(gp_tag, parent.tag, elem.tag)].append(kid_tags)

    rules = {}
    for key, kid_sets in instances.items():
        if not kid_sets:
            continue
        required = set.intersection(*kid_sets) if len(kid_sets) > 1 \
                   else set(kid_sets[0])
        union = set.union(*kid_sets) if len(kid_sets) > 1 \
                else set(kid_sets[0])
        sometimes = union - required
        rules[key] = {
            'required': required,
            'sometimes': sometimes,
            'count': len(kid_sets),
        }
    return rules


def validate(candidate: Path, reference: Path) -> int:
    try:
        cand_root = ET.parse(candidate).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: candidate parse failed: {e}', file=sys.stderr)
        return 2
    try:
        ref_root = ET.parse(reference).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: reference parse failed: {e}', file=sys.stderr)
        return 2

    rules = derive_required_children(ref_root)
    parent_map = {id(c): p for p in cand_root.iter() for c in p}

    findings = []
    for elem in cand_root.iter():
        parent = parent_map.get(id(elem))
        if parent is None:
            continue
        grandparent = parent_map.get(id(parent))
        gp_tag = grandparent.tag if grandparent is not None else '_root_'
        key = (gp_tag, parent.tag, elem.tag)
        rule = rules.get(key)
        if rule is None:
            continue
        if rule['count'] < 2:
            continue
        if not rule['required']:
            continue
        kid_tags = {c.tag for c in elem}
        # Check empirically-verified exceptions (WG-valid shapes that
        # jpa corpus didn't exercise). When an exception applies, skip
        # the requirement entirely.
        if _check_exception(key, kid_tags):
            continue
        # If the candidate element is itself EMPTY (no children, no
        # text), AND jpa's same-context instances also sometimes leave
        # this container empty (i.e. the rule is "if you have any
        # children, here are the required ones"), don't flag. The
        # detection: only flag when the candidate HAS some children
        # but is missing the required ones, OR when the candidate is
        # empty AND jpa NEVER showed an empty instance.
        if not kid_tags:
            # Empty container. Check if jpa ever had empty instances
            # at this XPath — if so, empty is legitimate (e.g.
            # template-internal subtrees that the customer didn't fill).
            # Build the parent's own emptiness pattern from instances.
            ref_pmap = {id(c): p for p in ref_root.iter() for c in p}
            saw_empty = False
            for ref_elem in ref_root.iter(elem.tag):
                rp = ref_pmap.get(id(ref_elem))
                if rp is None or rp.tag != parent.tag:
                    continue
                rgp = ref_pmap.get(id(rp))
                rgp_tag = rgp.tag if rgp is not None else '_root_'
                if rgp_tag != gp_tag:
                    continue
                if not list(ref_elem):
                    saw_empty = True
                    break
            if saw_empty:
                continue  # legitimate emptiness pattern
        missing = rule['required'] - kid_tags
        if missing:
            container_name = ''
            gp = parent_map.get(id(parent))
            while gp is not None:
                n = gp.find('name')
                if n is not None and n.text:
                    container_name = n.text.strip()
                    break
                gp = parent_map.get(id(gp))
            findings.append({
                'context': f'{gp_tag}/{parent.tag}/{elem.tag}',
                'in_container': container_name,
                'present_children': sorted(kid_tags),
                'missing_required': sorted(missing),
                'jpa_instances': rule['count'],
            })

    print(f'required_children_validator')
    print(f'  candidate: {candidate}')
    print(f'  reference: {reference}')
    print('=' * 72)
    print(f'  jpa-derived rules: {len(rules)}')
    print(f'  HARD findings (missing required children): {len(findings)}')
    if findings:
        print()
        for f in findings[:50]:
            ctx_info = (f' in <{f["in_container"]}>' if f['in_container']
                        else '')
            print(f'  {f["context"]}{ctx_info}:')
            print(f'    present: {f["present_children"]}')
            print(f'    MISSING (required by jpa, '
                  f'{f["jpa_instances"]} instances): '
                  f'{f["missing_required"]}')
        if len(findings) > 50:
            print(f'  ... +{len(findings)-50} more')
    return 0 if not findings else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('candidate', type=Path)
    p.add_argument('--reference', type=Path,
                   default=Path(__file__).parent.parent
                          / 'schema_learner' / 'corpus' / 'T30jpa1.xml')
    args = p.parse_args()
    return validate(args.candidate, args.reference)


if __name__ == '__main__':
    sys.exit(main())
