#!/usr/bin/env python3
"""
template_prefs.py — read template_preferences.ini for preferred jpa
template names per shape class.

API:
    get(friendly_name) -> str
        Return the preferred jpa entry name for the given shape class.
        Raises KeyError if friendly_name isn't declared.

PROVENANCE
   Names declared in template_preferences.ini, not hardcoded here.
"""
from __future__ import annotations

import configparser
from pathlib import Path

_INI_PATH = Path(__file__).resolve().parent / 'template_preferences.ini'
_CACHE: dict[str, str] | None = None


def _load() -> dict[str, str]:
    global _CACHE
    if _CACHE is not None:
        return _CACHE
    if not _INI_PATH.is_file():
        raise FileNotFoundError(
            f'template_prefs: template_preferences.ini not found at {_INI_PATH}'
        )
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp.read(_INI_PATH, encoding='utf-8')
    if not cp.has_section('templates'):
        raise KeyError(
            f'template_prefs: [templates] section missing from {_INI_PATH}'
        )
    _CACHE = {k: v.strip() for k, v in cp.items('templates')}
    return _CACHE


def get(friendly_name: str) -> str:
    """Return preferred jpa template name. Raises KeyError on miss."""
    prefs = _load()
    if friendly_name not in prefs:
        raise KeyError(
            f'template_prefs: friendly name {friendly_name!r} not declared '
            f'in [templates]. Available: {sorted(prefs)}'
        )
    return prefs[friendly_name]


def all_prefs() -> dict[str, str]:
    """Full map (for diagnostics)."""
    return dict(_load())
