#!/usr/bin/env python3
"""
skeleton_filler.py — fill the jpa-derived skeleton with customer data.

INPUT
   skeleton.xml: jpa.xml with customer lists wiped, factory parts intact
   templates.json: per-list template instances captured from jpa.xml
   enricher/output/*.json: customer data from the SonicWall→canonical
                            pipeline (parser + enricher)

PHILOSOPHY
   Never invent XML shape. Every customer entry is a CLONE of a jpa
   template instance with its leaf values replaced by customer values.
   If the customer has shape jpa doesn't, we pick the closest jpa
   template variant and add only the leaves the customer needs.
   The result is XML that, by construction, has the same shape as
   jpa.xml — which the Firebox accepts.

USAGE
   python3 skeleton_filler.py --customer-dir <enricher/output>
                              --skeleton skeleton.xml
                              --templates templates.json
                              --output configuration.xml
"""
from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

# Make the enricher's sw_field_extractor module importable.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'enricher'))

# WG name-suffix conventions (e.g. '.1.alm', '-00', '_bo') are declared
# in marker_mapping.ini → [suffix_conventions], NOT hardcoded here.
from wg_suffixes import get as wg_suffix

# SonicWall → WatchGuard zone mapping is declared in zone_mapping.ini,
# NOT hardcoded here. See skeleton_engine/zone_mapper.py for the loader.
import zone_mapper

# Preferred jpa template names per shape class are declared in
# template_preferences.ini, NOT hardcoded here.
from template_prefs import get as preferred_template

# WG XML numeric enum codes (<type>1</type>, <property>16</property>, ...)
# are declared in wg_enums.ini, NOT hardcoded here. wg_enum.code() returns
# the numeric code (as str) for a human-readable friendly name.
from wg_enum import code as wg_enum_code, code_int as wg_enum_code_int

# SonicOS token strings ('fqdn-assignment ', 'remote name ', etc.) are
# declared in enricher/sw_field_extractors.ini, NOT hardcoded here.
# Generic engine reads the INI; new SonicOS versions add their token
# variants by editing the INI, no code change required.
from sw_field_extractor import has_token as sw_has_token, after_prefix as sw_after_prefix


# ----------------------------------------------------------------------------
# Per-list filler functions. Each takes:
#   list_elem: the ET element to populate (currently empty)
#   templates: dict with 'shape_variants' from templates.json
#   customer_records: list of dicts from enricher output
#   ctx: shared context (e.g. for cross-list refs)
# Returns: number of entries added.
# ----------------------------------------------------------------------------

def _existing_names(list_elem, name_tag='name') -> set:
    """Return the set of <name> values already present in a list.
    Used for dedupe-on-append: customer entries with names that already
    exist in jpa (e.g. 'Any', 'HTTP', 'DNS') are skipped — jpa's
    definition wins. Customer-specific entries get appended."""
    seen = set()
    for child in list_elem:
        n = child.find(name_tag)
        if n is not None and n.text:
            seen.add(n.text.strip())
    return seen


def _set_leaf(parent: ET.Element, tag: str, value) -> None:
    """Find <tag> child and set its text. If multiple, set first."""
    if value is None:
        return
    elem = parent.find(tag)
    if elem is None:
        return
    elem.text = str(value)
    """Find <tag> child and set its text. If multiple, set first."""
    if value is None:
        return
    elem = parent.find(tag)
    if elem is None:
        return  # tag not in template; skip silently
    elem.text = str(value)


def _set_nested(parent: ET.Element, path: str, value) -> None:
    """Set leaf at relative path like 'a/b/c'."""
    if value is None:
        return
    parts = path.split('/')
    cur = parent
    for p in parts[:-1]:
        nxt = cur.find(p)
        if nxt is None:
            return
        cur = nxt
    _set_leaf(cur, parts[-1], value)


def _clone_template(template_xml: str) -> ET.Element:
    """Parse a template XML string into a fresh element."""
    return ET.fromstring(template_xml)


def _wipe_value(elem: ET.Element) -> None:
    """Recursively wipe text from all leaves (preserves structure)."""
    if list(elem):
        for c in elem:
            _wipe_value(c)
    else:
        elem.text = '' if elem.text else elem.text


def _pick_variant(variants: list, prefer_shape: set | None = None) -> dict:
    """Choose a shape variant. If prefer_shape (set of tags) is given,
    pick the variant whose shape best contains those tags."""
    if prefer_shape:
        best = None
        best_score = -1
        for v in variants:
            shape_set = set(v['shape'])
            score = len(shape_set & prefer_shape)
            if score > best_score:
                best_score = score
                best = v
        if best is not None:
            return best
    return variants[0]


# ---------------------------------------------------------------------------
# VPN selector resolution (FES v1.8.7+, Fix F)
# ---------------------------------------------------------------------------
# SonicWall VPN blocks reference tunnel selectors by GROUP NAME or
# ADDRESS-OBJECT NAME, not direct IPs:
#   network local group "LAN Subnets"               <- built-in dynamic group
#   network remote name tz300addressobject2wanzone   <- customer address-obj
#
# The resolver below converts these references into one or more concrete
# members (host-ip or ip-network) for the WG side's .1.tlc / .1.trm
# address-groups.
#
# Resolution sources (in order):
#   1. Built-in dynamic groups (sw_builtin_dynamic_groups.ini) — walk
#      interfaces.json by zone, aggregate subnets or IPs.
#   2. Customer address-groups (address_groups.json) — walk members,
#      resolve each via address_objects.json.
#   3. Customer address-objects (address_objects.json) — resolve to host
#      or network.
#   4. Unresolved (DNS label like 'monkeybusiness' or a name FES doesn't
#      have a record for) — emit unresolved marker; caller decides how
#      to handle (placeholder + warn for now).
#
# Provenance: Captain Jim Ames lab cycle 2026-06-13 QA finding — TZ-300
# tunnel Phase 2 showed `192.168.1.0/24` (placeholder) for local and
# `22.22.22.223` (IKE peer ID, wrong) for remote, instead of the SW
# source's `network local group "LAN Subnets"` (= 192.168.168.0/24 +
# 192.168.88.0/24) and `network remote name tz300addressobject2wanzone`
# (= host 192.168.88.11). Same bug found on NSA-3600 (DNS-label path
# emitted 192.168.1.0/24 + 0.0.0.0). Both corpora improved by this fix.
# ---------------------------------------------------------------------------

def _load_sw_builtin_dynamic_groups(customer_dir):
    """Load sw_builtin_dynamic_groups.ini if present. Returns a dict
    with two keys:
        'exact':    {name: spec} — exact-name matches (zone-based)
        'patterns': [(compiled_regex, spec), ...] — pattern-based matches
                    (per-interface built-ins)
    Empty dict if the INI is missing.

    Section conventions:
        [group."NAME"]         -> exact-name match (LAN Subnets, etc.)
        [group_pattern.KEY]    -> pattern match (per-interface built-ins)
    """
    import configparser as _cp_bg
    import re as _re_bg
    ini_path = customer_dir.parent.parent / 'enricher' / 'sw_builtin_dynamic_groups.ini'
    if not ini_path.is_file():
        return {'exact': {}, 'patterns': []}
    cp = _cp_bg.ConfigParser()
    cp.optionxform = str
    try:
        cp.read(ini_path, encoding='utf-8')
    except _cp_bg.Error:
        return {'exact': {}, 'patterns': []}
    exact = {}
    patterns = []
    for sect in cp.sections():
        if sect.startswith('group.'):
            # Strip 'group.' prefix and surrounding quotes
            name = sect[len('group.'):].strip()
            if len(name) >= 2 and name[0] == name[-1] and name[0] in ('"', "'"):
                name = name[1:-1]
            exact[name] = {
                'resolution': cp.get(sect, 'resolution', fallback='').strip(),
                'zone': cp.get(sect, 'zone', fallback='').strip(),
                'description': cp.get(sect, 'description', fallback='').strip(),
            }
        elif sect.startswith('group_pattern.'):
            pat_src = cp.get(sect, 'pattern_regex', fallback='').strip()
            if not pat_src:
                continue
            try:
                rx = _re_bg.compile(pat_src)
            except _re_bg.error:
                continue
            patterns.append((rx, {
                'section': sect,
                'resolution': cp.get(sect, 'resolution', fallback='').strip(),
                'description': cp.get(sect, 'description', fallback='').strip(),
            }))
    return {'exact': exact, 'patterns': patterns}


def _load_records(customer_dir, fname):
    """Helper to load a records JSON file (handles {entries: [...]}
    envelope or bare list)."""
    fpath = customer_dir / fname
    if not fpath.is_file():
        # Try the parser output as fallback
        fpath = customer_dir.parent.parent / 'sonicwall_parser' / 'output' / fname
        if not fpath.is_file():
            return []
    try:
        data = json.loads(fpath.read_text(encoding='utf-8'))
    except (json.JSONDecodeError, OSError):
        return []
    if isinstance(data, dict):
        return data.get('entries', []) if 'entries' in data else list(data.values())
    return data if isinstance(data, list) else []


def _resolve_addr_object(name, addr_objects):
    """Resolve a customer-defined SW address-object name to a member dict.

    Returns:
      {'type': 'host', 'value': IP}                if host-form
      {'type': 'network', 'value': NETWORK, 'mask': MASK}  if network-form
      None if name not found in addr_objects
    """
    for o in addr_objects:
        if str(o.get('_id') or o.get('name') or '').strip() == name:
            host = o.get('host')
            if host:
                return {'type': 'host', 'value': str(host).strip()}
            net = o.get('network')
            mask = o.get('netmask') or o.get('mask')
            if net and mask:
                return {'type': 'network',
                        'value': str(net).strip(),
                        'mask': str(mask).strip()}
            # Object exists but has no resolvable address — treat as
            # unresolved label (probably a DNS-name address-object)
            return None
    return None


def _resolve_addr_group(name, addr_objects, addr_groups, _depth=0):
    """Resolve a customer-defined SW address-group name into a list of
    member dicts. Recursively expands nested group members. Caps recursion
    at depth 5 (cycle protection)."""
    if _depth > 5:
        return []
    out = []
    for g in addr_groups:
        if str(g.get('_id') or g.get('name') or '').strip() != name:
            continue
        # SW address-group has 'address-object' = list of strings like
        # 'ipv4 NAME' OR 'ipv6 NAME'. There may also be nested
        # 'address-group' members.
        for ao_ref in (g.get('address-object') or []):
            if not isinstance(ao_ref, str):
                continue
            parts = ao_ref.strip().split(None, 1)
            if len(parts) == 2 and parts[0] in ('ipv4', 'ipv6'):
                ao_name = parts[1].strip().strip('"')
                resolved = _resolve_addr_object(ao_name, addr_objects)
                if resolved:
                    out.append(resolved)
        for ag_ref in (g.get('address-group') or []):
            if not isinstance(ag_ref, str):
                continue
            parts = ag_ref.strip().split(None, 1)
            if len(parts) == 2 and parts[0] in ('ipv4', 'ipv6'):
                ag_name = parts[1].strip().strip('"')
                out.extend(_resolve_addr_group(
                    ag_name, addr_objects, addr_groups, _depth=_depth + 1
                ))
        return out
    return out


def _resolve_builtin_group(spec, interfaces, intf_name=None):
    """Resolve a SonicOS built-in dynamic group against interfaces.

    Two modes:
      1. ZONE-based (exact-name groups like 'LAN Subnets'): spec['zone']
         filters interfaces by zone; returns members from all matching
         interfaces. intf_name is None.
      2. PER-INTERFACE (pattern-matched groups like 'X1 IP'): spec
         resolution is one of:
            interface_specific_subnet
            interface_specific_ip
            interface_specific_default_gateway
         intf_name is the specific interface name (e.g. 'X1', 'X2:V88',
         'MGMT') extracted from the regex match. Returns a single-member
         list with that interface's value.

    spec is a dict from sw_builtin_dynamic_groups.ini. Returns list of
    member dicts.
    """
    if not spec or not interfaces:
        return []
    res = spec.get('resolution', '')
    out = []

    # -------------------------------------------------------------
    # PER-INTERFACE resolution modes (intf_name supplied by caller)
    # -------------------------------------------------------------
    if intf_name and res in ('interface_specific_subnet',
                              'interface_specific_ip',
                              'interface_specific_default_gateway'):
        # Find the specific interface in interfaces.json
        target = None
        for intf in interfaces:
            if str(intf.get('_id') or intf.get('name') or '').strip() == intf_name:
                target = intf
                break
        if target is None:
            return []
        ipa = target.get('ip-assignment')
        if not isinstance(ipa, dict):
            return []
        intf_ip = ipa.get('ip')
        intf_mask = ipa.get('netmask')
        intf_gw = ipa.get('gateway') or ipa.get('default-gateway')

        if res == 'interface_specific_subnet' and intf_ip and intf_mask:
            try:
                ip_int = sum(int(x) << (24 - 8 * i)
                             for i, x in enumerate(intf_ip.split('.')))
                mask_int = sum(int(x) << (24 - 8 * i)
                               for i, x in enumerate(intf_mask.split('.')))
                net_int = ip_int & mask_int
                net = '.'.join(str((net_int >> s) & 0xFF)
                                for s in (24, 16, 8, 0))
            except (ValueError, IndexError):
                net = intf_ip
            out.append({'type': 'network', 'value': net, 'mask': intf_mask})
        elif res == 'interface_specific_ip' and intf_ip:
            out.append({'type': 'host', 'value': intf_ip})
        elif res == 'interface_specific_default_gateway' and intf_gw:
            out.append({'type': 'host', 'value': intf_gw})
        return out

    # -------------------------------------------------------------
    # ZONE-based resolution modes (legacy — unchanged from v1.8.7)
    # -------------------------------------------------------------
    zone = spec.get('zone', '').upper()
    for intf in interfaces:
        ipa = intf.get('ip-assignment')
        if not isinstance(ipa, dict):
            continue
        # The zone is the first token of ipa['_args'] (e.g. 'LAN static')
        args_parts = (ipa.get('_args') or '').split()
        intf_zone = args_parts[0].upper() if args_parts else ''
        if intf_zone != zone:
            continue
        intf_ip = ipa.get('ip')
        intf_mask = ipa.get('netmask')
        if not intf_ip:
            continue
        if res == 'interface_zone_subnets':
            if intf_mask:
                # Convert IP to network base (zero out host bits)
                try:
                    ip_int = sum(int(x) << (24 - 8 * i)
                                 for i, x in enumerate(intf_ip.split('.')))
                    mask_int = sum(int(x) << (24 - 8 * i)
                                   for i, x in enumerate(intf_mask.split('.')))
                    net_int = ip_int & mask_int
                    net = '.'.join(str((net_int >> s) & 0xFF)
                                    for s in (24, 16, 8, 0))
                except (ValueError, IndexError):
                    net = intf_ip
                out.append({
                    'type': 'network',
                    'value': net,
                    'mask': intf_mask,
                })
        elif res == 'interface_zone_ips':
            out.append({'type': 'host', 'value': intf_ip})
    return out


def _match_builtin_group_pattern(name, builtin_groups):
    """Try to pattern-match a name against the per-interface built-in
    catalog patterns. Returns (spec, intf_name) on match, (None, None)
    otherwise.

    Example:
        name = 'X1 IP'
        patterns include rx=^(?P<intf>X\\d+|U\\d+|MGMT)\\s+IP$ with
        resolution='interface_specific_ip'
        → returns (spec_dict, 'X1')

        name = 'X2:V88 Subnet'
        patterns include rx=^(?P<intf>X\\d+):V(?P<vlan>\\d+)\\s+Subnet$
        → returns (spec_dict, 'X2:V88')  # full match used as intf-name
    """
    if not isinstance(builtin_groups, dict):
        return (None, None)
    patterns = builtin_groups.get('patterns') or []
    for rx, spec in patterns:
        m = rx.match(name)
        if not m:
            continue
        # Compose the interface name. For physical/USB/MGMT this is the
        # 'intf' capture group. For VLAN sub-interfaces, it's the
        # interface name + ':V' + vlan id (e.g. 'X2:V88') — that's the
        # convention used as the _id in interfaces_vlan.json.
        gd = m.groupdict()
        intf_name = gd.get('intf') or ''
        vlan = gd.get('vlan')
        if vlan:
            intf_name = f'{intf_name}:V{vlan}'
        return (spec, intf_name)
    return (None, None)


def _resolve_vpn_selector(token, customer_dir, ctx):
    """Resolve a SW VPN selector token like:
       'local group "LAN Subnets"'
       'local network 10.0.0.0 255.255.255.0'
       'local host 10.0.0.1'
       'remote name tz300addressobject2wanzone'
       'remote group "Some Group"'
       'remote network ...'
       'remote host ...'

    Returns: (side, members, unresolved_label)
       side             : 'local' | 'remote' | None
       members          : list of dicts [{type, value, mask?}, ...]
       unresolved_label : str (name we couldn't resolve) or None

    Lazy-loads records on first call and caches in ctx.
    """
    if not isinstance(token, str):
        return (None, [], None)
    t = token.strip()
    if t.startswith('local '):
        side = 'local'
        rest = t[len('local '):].strip()
    elif t.startswith('remote '):
        side = 'remote'
        rest = t[len('remote '):].strip()
    else:
        return (None, [], None)

    # Cache records in ctx for performance across calls in same pipeline run
    cache_key = '_vpn_selector_cache'
    if cache_key not in ctx:
        # interfaces.json holds physical interfaces; interfaces_vlan.json
        # holds VLAN sub-interfaces. Both can be LAN-zone (matter for
        # "LAN Subnets" resolution), WAN-zone (rare for VLANs but
        # supported), etc. Concatenate so the resolver sees all of them.
        ctx[cache_key] = {
            'addr_objects': _load_records(customer_dir, 'address_objects.json'),
            'addr_groups':  _load_records(customer_dir, 'address_groups.json'),
            'interfaces':   (_load_records(customer_dir, 'interfaces.json')
                             + _load_records(customer_dir,
                                             'interfaces_vlan.json')),
            'builtin_groups': _load_sw_builtin_dynamic_groups(customer_dir),
        }
    cache = ctx[cache_key]

    # Form 1: 'network IP MASK'
    if rest.startswith('network '):
        parts = rest[len('network '):].strip().split()
        if len(parts) >= 2:
            return (side,
                    [{'type': 'network', 'value': parts[0], 'mask': parts[1]}],
                    None)

    # Form 2: 'host IP'
    if rest.startswith('host '):
        ip = rest[len('host '):].strip().split()[0] if rest[len('host '):].strip() else ''
        if ip:
            return (side, [{'type': 'host', 'value': ip}], None)

    # Form 3: 'group "NAME"' or 'group NAME'
    if rest.startswith('group '):
        name = rest[len('group '):].strip().strip('"')
        builtins = cache['builtin_groups']
        # Built-in dynamic group? Try exact-name match first.
        exact = builtins.get('exact') if isinstance(builtins, dict) else {}
        if name in exact:
            members = _resolve_builtin_group(
                exact[name], cache['interfaces']
            )
            return (side, members, None if members else name)
        # Per-interface pattern match (X1 IP, X0 Subnet, MGMT IP, etc.)
        spec, intf_name = _match_builtin_group_pattern(name, builtins)
        if spec is not None:
            members = _resolve_builtin_group(
                spec, cache['interfaces'], intf_name=intf_name
            )
            return (side, members, None if members else name)
        # Customer-defined group?
        members = _resolve_addr_group(
            name, cache['addr_objects'], cache['addr_groups']
        )
        return (side, members, None if members else name)

    # Form 4: 'name NAME'
    if rest.startswith('name '):
        name = rest[len('name '):].strip().strip('"')
        # Try address-object first
        resolved = _resolve_addr_object(name, cache['addr_objects'])
        if resolved:
            return (side, [resolved], None)
        # Try per-interface built-in pattern (e.g. NAT translated-source
        # name "X1 IP" → resolves to host 88.88.88.88)
        builtins = cache['builtin_groups']
        spec, intf_name = _match_builtin_group_pattern(name, builtins)
        if spec is not None:
            members = _resolve_builtin_group(
                spec, cache['interfaces'], intf_name=intf_name
            )
            if members:
                return (side, members, None)
        # Try exact-name built-in (rare for 'name' form but covered)
        exact = builtins.get('exact') if isinstance(builtins, dict) else {}
        if name in exact:
            members = _resolve_builtin_group(
                exact[name], cache['interfaces']
            )
            if members:
                return (side, members, None)
        # Fall through to group (occasionally SW uses 'name' for groups too)
        members = _resolve_addr_group(
            name, cache['addr_objects'], cache['addr_groups']
        )
        if members:
            return (side, members, None)
        # Unresolved — likely a DNS-label that needs WG Web UI edit post-import
        return (side, [], name)

    return (side, [], None)


# ---- service-list ----------------------------------------------------------

def fill_services(list_elem, templates, records, ctx):
    variants = templates.get('service-list', {}).get('shape_variants', [])
    if not variants or not records:
        return 0
    existing = _existing_names(list_elem)
    n_added = 0
    n_skipped = 0
    for r in records:
        name = r.get('name') or r.get('_id')
        if not name:
            continue
        # Skip if jpa already defines a service with this name (jpa wins
        # on collision — preserves WG built-ins like 'Any', 'HTTP', 'DNS').
        # Case-insensitive check to avoid duplicates like 'http' vs 'HTTP'.
        if name in existing or name.lower() in {e.lower() for e in existing}:
            n_skipped += 1
            continue
        variant = _pick_variant(variants)
        clone = _clone_template(variant['template_xml'])
        _set_leaf(clone, 'name', name)
        _set_leaf(clone, 'description', r.get('description', ''))
        members = r.get('members') or []
        if members:
            si = clone.find('service-item')
            if si is not None:
                member_template = si.find('member')
                if member_template is not None:
                    for m in list(si.findall('member')):
                        si.remove(m)
                    for mrec in members:
                        m = copy.deepcopy(member_template)
                        _set_leaf(m, 'type', mrec.get('type', 1))
                        _set_leaf(m, 'protocol', mrec.get('protocol', 6))
                        port = mrec.get('server-port')
                        if port is not None:
                            _set_leaf(m, 'server-port', port)
                        si.append(m)
        list_elem.append(clone)
        existing.add(name)
        n_added += 1
    if n_skipped:
        print(f'         (skipped {n_skipped} duplicates — jpa names win)')
    return n_added


# ---- alias-list ------------------------------------------------------------

def fill_aliases(list_elem, templates, records, ctx):
    variants = templates.get('alias-list', {}).get('shape_variants', [])
    if not variants or not records:
        return 0
    existing = _existing_names(list_elem)
    n_added = 0
    n_skipped = 0
    for r in records:
        name = r.get('name') or r.get('_id')
        if not name:
            continue
        # jpa-wins dedupe: preserves built-in aliases 'Any', 'External',
        # 'Trusted', 'Firebox', etc. that policies reference.
        if name in existing or name.lower() in {e.lower() for e in existing}:
            n_skipped += 1
            continue
        variant = _pick_variant(variants)
        clone = _clone_template(variant['template_xml'])
        _set_leaf(clone, 'name', name)
        _set_leaf(clone, 'description', r.get('description', ''))
        aml = clone.find('alias-member-list')
        if aml is not None and r.get('members'):
            for m in list(aml):
                aml.remove(m)
            for member_val in r['members']:
                am = ET.SubElement(aml, 'alias-member')
                am.text = str(member_val)
        list_elem.append(clone)
        existing.add(name)
        n_added += 1
    if n_skipped:
        print(f'         (skipped {n_skipped} duplicates — jpa names win)')
    return n_added


# ---- schedule-list ---------------------------------------------------------

def fill_schedules(list_elem, templates, records, ctx):
    variants = templates.get('schedule-list', {}).get('shape_variants', [])
    if not variants or not records:
        return 0
    existing = _existing_names(list_elem)
    n = 0
    n_skipped = 0
    for r in records:
        name = r.get('name') or r.get('_id')
        if not name:
            continue
        if name in existing or str(name).lower() in {e.lower() for e in existing}:
            n_skipped += 1
            continue
        wg_schedule = r.get('wg_schedule') or []
        if not wg_schedule:
            continue
        schedule_type = r.get('wg_schedule_type', 'recurring')
        clone = _clone_template(variants[0]['template_xml'])
        _set_leaf(clone, 'name', name)
        _set_leaf(clone, 'description', r.get('description', ''))
        _set_leaf(clone, 'type',
                   wg_enum_code_int('schedule.type', 'always-on')
                   if schedule_type == 'always_on'
                   else wg_enum_code_int('schedule.type', 'time-restricted'))
        sched_container = clone.find('schedule')
        if sched_container is not None:
            member_template = sched_container.find('member')
            if member_template is not None:
                for m in list(sched_container.findall('member')):
                    sched_container.remove(m)
                for day_entry in wg_schedule:
                    m = copy.deepcopy(member_template)
                    _set_leaf(m, 'day-of-week', day_entry['day_of_week'])
                    period = m.find('period')
                    if period is not None:
                        period_member_template = period.find('member')
                        if period_member_template is not None:
                            for pm in list(period.findall('member')):
                                period.remove(pm)
                            for pdef in day_entry.get('periods', []):
                                pm = copy.deepcopy(period_member_template)
                                _set_leaf(pm, 'from-hour', pdef.get('from_h', 0))
                                _set_leaf(pm, 'from-min', pdef.get('from_m', 0))
                                _set_leaf(pm, 'to-hour', pdef.get('to_h', 24))
                                _set_leaf(pm, 'to-min', pdef.get('to_m', 0))
                                _set_leaf(pm, 'on-flag',
                                           wg_enum_code_int('period_member.on-flag', 'active'))
                                period.append(pm)
                    sched_container.append(m)
        list_elem.append(clone)
        existing.add(name)
        n += 1
    if n_skipped:
        print(f'         (skipped {n_skipped} duplicates — jpa schedules win)')
    return n


# ---- interface-list --------------------------------------------------------

_INTERFACE_DEFAULTS_CACHE = None

def _load_interface_defaults():
    """Load interface_defaults.ini. Returns dict with three keys:
       'unused_default_state' : {tag: value} applied to unused interfaces
       'vlan_host_slots'      : set of interface names that are VLAN hosts
       'vlan_host_state'      : {tag: value} applied to VLAN-host interfaces

    Cached at module level so the INI is parsed once per pipeline run.

    Without this INI the toolkit silently inherits jpa template's example
    values (192.168.10.1 etc.) on unused interfaces. Lab v1.8.1 found
    that exact bug. Provenance lives inside interface_defaults.ini.
    """
    global _INTERFACE_DEFAULTS_CACHE
    if _INTERFACE_DEFAULTS_CACHE is not None:
        return _INTERFACE_DEFAULTS_CACHE
    import configparser
    from pathlib import Path
    ini_path = Path(__file__).parent / 'interface_defaults.ini'
    result = {
        'unused_default_state': {},
        'vlan_host_slots': set(),
        'vlan_host_state': {},
    }
    if ini_path.is_file():
        p = configparser.ConfigParser()
        p.optionxform = str  # preserve case in keys
        p.read(ini_path, encoding='utf-8')
        if p.has_section('interface.unused_default_state'):
            for k, v in p.items('interface.unused_default_state'):
                result['unused_default_state'][k] = v.strip()
        if p.has_section('interface.vlan_host_slots'):
            for k, _ in p.items('interface.vlan_host_slots'):
                result['vlan_host_slots'].add(k)
        if p.has_section('interface.vlan_host_state'):
            for k, v in p.items('interface.vlan_host_state'):
                result['vlan_host_state'][k] = v.strip()
    _INTERFACE_DEFAULTS_CACHE = result
    return result


def _normalize_unused_interfaces(list_elem, assigned: set):
    """Apply interface_defaults.ini rules to every WG physical interface
    that wasn't assigned customer SW data. This clears jpa template's
    example IPs and sets the correct enabled/if-property state per the
    golden_pair convention:
       - Unused regular interfaces: enabled=0, if-property=3, ip=0.0.0.0
       - VLAN host slots (e.g. Optional-1): enabled=1, if-property=5,
                                            ip=0.0.0.0

    Touches ONLY physical-if leaves listed in the INI; does NOT touch
    interface NAME, hardware properties (if-num, if-dev-name, mtu, mac),
    or other deep template values. Idempotent and safe to run multiple
    times — applies declared values regardless of starting state.

    Provenance: lab v1.8.1 caught 192.168.10.1 leaking onto Optional-2
    (from jpa.xml line 18347) and Optional-1 missing its VLAN-host
    designation. The convention is set in interface_defaults.ini with
    full provenance comments there.
    """
    defaults = _load_interface_defaults()
    unused_state = defaults['unused_default_state']
    vlan_slots = defaults['vlan_host_slots']
    vlan_state = defaults['vlan_host_state']
    if not unused_state and not vlan_state:
        return 0  # No rules configured — silent no-op
    n_normalized = 0
    for intf in list_elem.findall('interface'):
        name_el = intf.find('name')
        if name_el is None or not name_el.text:
            continue
        name = name_el.text
        # Choose which rule applies: VLAN-host or unused-default.
        if name in vlan_slots:
            state = vlan_state
        elif name not in assigned:
            state = unused_state
        else:
            continue  # Customer SW data already applied — leave alone
        if not state:
            continue
        # Apply the state to the FIRST physical-if (item-type=1).
        # interface-list/interface/if-item-list/item/physical-if
        phys = intf.find('.//physical-if')
        if phys is None:
            continue
        for tag, value in state.items():
            leaf = phys.find(tag)
            if leaf is not None:
                leaf.text = value
            else:
                ET.SubElement(phys, tag).text = value
        n_normalized += 1
    return n_normalized


def fill_interfaces(list_elem, templates, records, ctx):
    """STRUCTURAL_LOCK fill: interface-list cardinality and names are
    immutable hardware properties. We MUST NOT add, remove, or rename
    any interface. The filler only PATCHES touchable leaves inside
    physical interfaces with the customer's actual IP/netmask/gateway.

    Touchable leaves (per immutables.json):
       description, ip, netmask, default-gateway, mtu
    Everything else in jpa stays exactly as jpa wrote it.

    The customer's SonicWall interfaces (X0, X1, etc.) are mapped to
    WG physical interface names by zone token (LAN -> Trusted, WAN ->
    External, DMZ/Opt -> Optional-1/2/3). Customer interfaces with no
    mapping target (or extras like SonicWall's separate MGMT port that
    T-30 doesn't have) are SILENTLY DROPPED. Their IPs are noted in
    the manifest sidecar for operator review.
    """
    if not records:
        return 0

    # SonicWall zone → WG physical interface candidates is declared in
    # zone_mapping.ini, NOT hardcoded here. Multiple LAN zones go to
    # Trusted, Optional-1, Optional-2, Optional-3 in order. To target
    # a different Firebox model (e.g. M-series with more interfaces),
    # edit zone_mapping.ini — no code change required.

    # Build name -> existing-interface-element map from jpa skeleton
    existing = {}
    for child in list_elem:
        n = child.find('name')
        if n is not None and n.text:
            existing[n.text] = child

    # Track which WG names we've already assigned customer data to
    assigned: set = set()
    dropped = []
    n_patched = 0

    for r in records:
        sw_id = r.get('_id') or r.get('id') or 'Unknown'
        ipa = r.get('ip-assignment')
        if not isinstance(ipa, dict) or not ipa.get('ip'):
            continue  # no IP to apply

        # Find the right WG physical interface name for this zone
        zone_token = (ipa.get('_args', '') or '').split()[0].lower() \
                     if ipa.get('_args') else ''
        candidates = zone_mapper.get_interface_candidates(zone_token)
        target_name = None
        for c in candidates:
            if c not in assigned and c in existing:
                target_name = c
                break

        if target_name is None:
            # No available slot — drop with note. SonicWall has more
            # physical ports than T-30; this is expected for some
            # interfaces (e.g. SonicWall's separate MGMT port).
            dropped.append({
                'sw_id': sw_id,
                'zone_args': ipa.get('_args'),
                'ip': ipa.get('ip'),
                'reason': (f'no WG slot available for zone={zone_token!r}; '
                           f'all candidates {candidates} already assigned'),
            })
            continue

        # Patch the jpa interface's touchable leaves with customer values
        intf = existing[target_name]
        # description: the SonicWall 'management fqdn-assignment <NAME>'
        # value is the customer's friendly name for the interface
        # (preserved as the WG <description> so it shows in the Web UI).
        # Falls back to the SonicWall 'comment' field if no fqdn-assignment.
        # Token pattern declared in sw_field_extractors.ini.
        description_value = None
        mgmt = r.get('management')
        if isinstance(mgmt, list):
            for item in mgmt:
                captured = sw_after_prefix(item, 'interface_friendly_name')
                if captured is not None:
                    description_value = captured
                    break
        if not description_value:
            description_value = r.get('comment')
        if description_value:
            d = intf.find('description')
            if d is not None:
                d.text = description_value
        # ip, netmask, default-gateway inside physical-if
        phys = intf.find('.//physical-if')
        if phys is not None:
            for tag, val in [('ip',              ipa.get('ip')),
                              ('netmask',         ipa.get('netmask')),
                              ('default-gateway', ipa.get('gateway'))]:
                if val and val is not False:
                    leaf = phys.find(tag)
                    if leaf is not None:
                        leaf.text = str(val)
                    else:
                        ET.SubElement(phys, tag).text = str(val)

        # ----------------------------------------------------------------
        # external-type patching (FES v1.8.5+).
        #
        # The jpa template ships <external-type>2</external-type> (DHCP)
        # as the default. SonicWall e-CLI declares the actual addressing
        # mode in the ip-assignment _args field — e.g. 'WAN static',
        # 'WAN dynamic', 'WAN pppoe'. Without this patch, every emit
        # ships External as DHCP regardless of what SW had — the IP and
        # netmask are correct but the Web UI labels the interface as
        # DHCP. Lab-discovered TZ-300 cycle 2026-06-13 (was hidden bug
        # on NSA-3600 too, masked by Firebox tolerance).
        #
        # Mapping (via wg_enums.ini [enum.external_if.external-type]):
        #   static          -> 1
        #   dynamic | dhcp  -> 2
        #   pppoe           -> 3
        # The mode is the 2nd token of ipa['_args'] (1st is the zone).
        # Only applies when the WG interface has an <external-if> block,
        # i.e. it's the External (WAN) slot.
        # ----------------------------------------------------------------
        external_if = intf.find('.//external-if')
        if external_if is not None:
            zone_args_parts = (ipa.get('_args') or '').split()
            mode_token = zone_args_parts[1].lower() if len(zone_args_parts) >= 2 else ''
            # Normalize to enum-key forms
            if mode_token in ('static',):
                enum_key = 'static'
            elif mode_token in ('dynamic', 'dhcp'):
                enum_key = 'dhcp'
            elif mode_token in ('pppoe',):
                enum_key = 'pppoe'
            else:
                enum_key = None
            if enum_key is not None:
                code = wg_enum_code('external_if.external-type', enum_key)
                if code:
                    et_leaf = external_if.find('external-type')
                    if et_leaf is None:
                        et_leaf = ET.SubElement(external_if, 'external-type')
                    et_leaf.text = str(code)
        assigned.add(target_name)
        n_patched += 1

    if dropped:
        print(f'         (dropped {len(dropped)} customer interface(s) '
              f'with no T-30 slot; see manifest)')
        ctx.setdefault('dropped_interfaces', []).extend(dropped)

    # Normalize ALL interfaces the SW config didn't configure: clear
    # jpa template's example IPs, apply the convention (unused=neutral,
    # Optional-1=VLAN-host) declared in interface_defaults.ini.
    # Lab v1.8.1 caught 192.168.10.1 leaking onto Optional-2 because
    # jpa's example was inherited; this pass is the surgical fix.
    n_normalized = _normalize_unused_interfaces(list_elem, assigned)
    if n_normalized:
        print(f'         (normalized {n_normalized} unused/VLAN-slot '
              f'interfaces per interface_defaults.ini)')

    print(f'         (patched {n_patched} jpa physical interfaces '
          f'with customer IPs; '
          f'{len(existing)} total interfaces preserved structurally)')
    return n_patched


# ---- address-group-list (host/network addresses) --------------------------

def fill_address_groups(list_elem, templates, records, ctx):
    """Customer SonicWall address groups -> WG aliases.

    In WatchGuard, an alias IS the address object the customer sees in
    the Web UI. Each user-facing alias pairs with an internal
    address-group named '<alias-name>.1.alm' that carries the IP
    members. The customer never sees the .1.alm — they see the alias.

    For each customer record:
      - Emit an <alias> in alias-list with the customer's name
      - If the record has IP members, emit a paired address-group named
        '<name>.1.alm' in address-group-list carrying the IPs
      - The alias's <alias-member> points at the .1.alm group (type=1)
      - If the record has group-member references (other aliases), emit
        them as type=2 alias-members directly in the alias

    list_elem here is address-group-list (where I'm registered), but I
    write predominantly to alias-list. Use ctx['_root'] to reach it.
    """
    if not records:
        return 0
    root = ctx.get('_root') if ctx else None
    if root is None:
        # Walk up: list_elem.getparent isn't available in stdlib ET, so
        # find root by iterating the tree.
        # Easier: caller passes root via ctx['_root'] now.
        return 0
    alias_list = root.find('alias-list')
    if alias_list is None:
        return 0

    alias_existing = _existing_names(alias_list)
    ag_existing = _existing_names(list_elem)
    n_added = 0
    n_skipped = 0

    for r in records:
        name = r.get('name') or r.get('_id')
        if not name:
            continue
        # jpa-wins dedupe
        if name in alias_existing or \
                str(name).lower() in {e.lower() for e in alias_existing}:
            n_skipped += 1
            continue

        # 1. Build the alias entry
        new_alias = ET.SubElement(alias_list, 'alias')
        ET.SubElement(new_alias, 'name').text = name
        desc = r.get('description', '') or name
        ET.SubElement(new_alias, 'description').text = desc
        # <property> is REQUIRED per jpa (all 49 aliases have it).
        ET.SubElement(new_alias, 'property').text = wg_enum_code('alias.property', 'user-defined')
        aml = ET.SubElement(new_alias, 'alias-member-list')

        # Customer SW address-groups have TWO forms of member specification:
        #   1. 'members': pre-resolved IPs/CIDRs (from enricher inline expansion)
        #   2. 'address-object': list of address-object NAMES to resolve
        # The toolkit handles both — name references are resolved via
        # the address-object catalog loaded into ctx (host IP, CIDR, range).
        # Decoded from golden_pair: SW `address-group adrgrpforClaude`
        # references `address-object someremotepeerfakeadrobj4Claude`
        # which is `host 14.14.14.14`. Without resolution, the WG `.1.alm`
        # companion would be empty (no marker_pairing for ADRGRP).
        members = r.get('members') or []
        addr_obj_refs = r.get('address-object') or []
        if addr_obj_refs and ctx is not None:
            ao_lookup = ctx.get('_addr_object_lookup', {})
            for ref in addr_obj_refs:
                if not isinstance(ref, str):
                    continue
                ref_name = ref.strip()
                ao_rec = ao_lookup.get(ref_name)
                if ao_rec is None:
                    continue
                # Resolve to the address-object's actual host IP / CIDR.
                # SonicWall address-object forms (per parser):
                #   host <IP>           -> single host
                #   network <NET> <MASK>-> subnet (rare here)
                #   range <FROM> <TO>   -> range (rare)
                host_ip = ao_rec.get('host')
                if host_ip:
                    members.append(host_ip)
                elif ao_rec.get('network'):
                    net = ao_rec.get('network')
                    if isinstance(net, str) and '/' in net:
                        members.append(net)
        if members:
            # Build paired internal address-group with the IP members.
            # WG convention: <ALIAS_NAME>.1.alm holds the actual member IPs
            # (suffix declared in marker_mapping.ini [suffix_conventions]).
            paired_ag_name = f'{name}{wg_suffix("addr_group_companion")}'
            if paired_ag_name not in ag_existing:
                new_ag = ET.SubElement(list_elem, 'address-group')
                ET.SubElement(new_ag, 'name').text = paired_ag_name
                ET.SubElement(new_ag, 'description').text = ''
                ET.SubElement(new_ag, 'property').text = wg_enum_code('address_group.property', 'user-defined')
                ag_mem = ET.SubElement(new_ag, 'addr-group-member')
                for mrec in members:
                    m = ET.SubElement(ag_mem, 'member')
                    if isinstance(mrec, dict):
                        # Dict format: {'type': N, 'host-ip-addr': X, ...}
                        for k, v in mrec.items():
                            ET.SubElement(m, k).text = str(v)
                    elif isinstance(mrec, str) and '/' in mrec:
                        # Network in CIDR — split
                        net, prefix = mrec.split('/', 1)
                        try:
                            p = int(prefix)
                            bits = (0xFFFFFFFF << (32 - p)) & 0xFFFFFFFF
                            mask = '.'.join(str((bits >> s) & 0xFF)
                                            for s in (24, 16, 8, 0))
                        except ValueError:
                            mask = '255.255.255.0'
                        ET.SubElement(m, 'type').text = wg_enum_code('addr_group_member.type', 'ip-network')
                        ET.SubElement(m, 'ip-network-addr').text = net
                        ET.SubElement(m, 'ip-mask').text = mask
                    else:
                        # Bare host IP
                        ET.SubElement(m, 'type').text = wg_enum_code('addr_group_member.type', 'host-ip')
                        ET.SubElement(m, 'host-ip-addr').text = str(mrec)
                ag_existing.add(paired_ag_name)
            # Add alias-member pointing at the paired address-group
            am = ET.SubElement(aml, 'alias-member')
            ET.SubElement(am, 'type').text = wg_enum_code('alias_member.type', 'host-or-named')
            ET.SubElement(am, 'user').text = 'Any'
            ET.SubElement(am, 'address').text = paired_ag_name
            ET.SubElement(am, 'interface').text = 'Any'
            ET.SubElement(am, 'device').text = 'Any'
        else:
            # No IP members — empty alias (a placeholder; WG accepts).
            # The customer may have created an empty group in SonicWall.
            am = ET.SubElement(aml, 'alias-member')
            ET.SubElement(am, 'type').text = wg_enum_code('alias_member.type', 'host-or-named')
            ET.SubElement(am, 'user').text = 'Any'
            ET.SubElement(am, 'address').text = 'Any'
            ET.SubElement(am, 'interface').text = 'Any'
            ET.SubElement(am, 'device').text = 'Any'

        alias_existing.add(name)
        n_added += 1

    if n_skipped:
        print(f'         (skipped {n_skipped} duplicates — jpa wins)')
    return n_added


def fill_user_address_objects(list_elem, templates, records, ctx):
    """Customer SonicWall user-defined address-objects → WG alias + .1.alm companion.

    Distinct from `fill_address_groups` (which handles SW address-groups
    that may reference address-objects): this filler processes the
    address-objects themselves as standalone entries.

    For each SW user address-object with a host IP (or network CIDR):
       - Emit <alias><name>NAME</name> with member pointing at NAME.1.alm
       - Emit <address-group><name>NAME.1.alm</name> with the host-ip-addr

    Provenance: lab v1.8.1 test showed that user address-objects
    (e.g. someremotepeerfakeadrobj4Claude with host 14.14.14.14)
    were silently dropped from the WG emit. The previous marker_mapping
    catalog comment said "name dropped by design — IP embedded in
    consumer's group", which was wrong: standalone address-objects
    need to come over as their own aliases so the operator can see
    them in WG Aliases panel and reference them from new policies.

    list_elem here is address-group-list (where I'm registered, since
    we write the .1.alm companion there); we also write to alias-list
    via ctx['_root'].
    """
    if not records:
        return 0
    root = ctx.get('_root') if ctx else None
    if root is None:
        return 0
    alias_list = root.find('alias-list')
    if alias_list is None:
        return 0

    alias_existing = _existing_names(alias_list)
    ag_existing = _existing_names(list_elem)
    n_added = 0
    n_skipped = 0

    for r in records:
        if not isinstance(r, dict):
            continue
        name = r.get('name') or r.get('_id')
        if not name:
            continue
        # Skip implicit objects — they're handled by fill_aliases via
        # the implicit_address_objects.json feed.
        if r.get('_implicit'):
            continue
        # jpa-wins dedupe + don't re-emit if SW group filler already
        # emitted the alias for this name.
        if name in alias_existing or \
                str(name).lower() in {e.lower() for e in alias_existing}:
            n_skipped += 1
            continue

        # Emit the alias entry
        new_alias = ET.SubElement(alias_list, 'alias')
        ET.SubElement(new_alias, 'name').text = name
        ET.SubElement(new_alias, 'description').text = r.get('description', '') or name
        ET.SubElement(new_alias, 'property').text = wg_enum_code('alias.property', 'user-defined')
        aml = ET.SubElement(new_alias, 'alias-member-list')

        # Resolve to host IP or network CIDR
        host_ip = r.get('host')
        network = r.get('network')

        # Emit the .1.alm companion
        paired_ag_name = f'{name}{wg_suffix("addr_group_companion")}'
        if paired_ag_name not in ag_existing:
            new_ag = ET.SubElement(list_elem, 'address-group')
            ET.SubElement(new_ag, 'name').text = paired_ag_name
            ET.SubElement(new_ag, 'description').text = ''
            ET.SubElement(new_ag, 'property').text = wg_enum_code('address_group.property', 'user-defined')
            ag_mem = ET.SubElement(new_ag, 'addr-group-member')
            mem = ET.SubElement(ag_mem, 'member')
            if host_ip:
                ET.SubElement(mem, 'type').text = wg_enum_code('addr_group_member.type', 'host-ip')
                ET.SubElement(mem, 'host-ip-addr').text = str(host_ip)
            elif network and isinstance(network, str):
                # SW network format: "192.168.1.0 255.255.255.0" (space-separated)
                # or CIDR "192.168.1.0/24"
                if '/' in network:
                    net, prefix = network.split('/', 1)
                    try:
                        p = int(prefix)
                        bits = (0xFFFFFFFF << (32 - p)) & 0xFFFFFFFF
                        mask = '.'.join(str((bits >> s) & 0xFF) for s in (24, 16, 8, 0))
                    except ValueError:
                        mask = '255.255.255.0'
                    ET.SubElement(mem, 'type').text = wg_enum_code('addr_group_member.type', 'ip-network')
                    ET.SubElement(mem, 'ip-network-addr').text = net
                    ET.SubElement(mem, 'ip-mask').text = mask
                elif ' ' in network:
                    net, mask = network.split(None, 1)
                    ET.SubElement(mem, 'type').text = wg_enum_code('addr_group_member.type', 'ip-network')
                    ET.SubElement(mem, 'ip-network-addr').text = net
                    ET.SubElement(mem, 'ip-mask').text = mask.strip()
                else:
                    # bare network address, assume /24
                    ET.SubElement(mem, 'type').text = wg_enum_code('addr_group_member.type', 'ip-network')
                    ET.SubElement(mem, 'ip-network-addr').text = network
                    ET.SubElement(mem, 'ip-mask').text = '255.255.255.0'
            else:
                # No IP source — placeholder
                ET.SubElement(mem, 'type').text = wg_enum_code('addr_group_member.type', 'host-ip')
                ET.SubElement(mem, 'host-ip-addr').text = '0.0.0.0'
            ag_existing.add(paired_ag_name)

        # Connect alias to the .1.alm companion
        am = ET.SubElement(aml, 'alias-member')
        ET.SubElement(am, 'type').text = wg_enum_code('alias_member.type', 'host-or-named')
        ET.SubElement(am, 'user').text = 'Any'
        ET.SubElement(am, 'address').text = paired_ag_name
        ET.SubElement(am, 'interface').text = 'Any'
        ET.SubElement(am, 'device').text = 'Any'

        alias_existing.add(name)
        n_added += 1

    if n_skipped:
        print(f'         (skipped {n_skipped} duplicates — jpa wins)')
    return n_added


# ---- policy-list -----------------------------------------------------------

def _load_proxy_mapping():
    """Load proxy_mapping.ini. Returns (proxy_map, service_aliases,
    action_codes). Case-insensitive keys.

    Cached at module level so the INI is parsed once per pipeline run.
    """
    global _PROXY_MAPPING_CACHE
    if '_PROXY_MAPPING_CACHE' in globals():
        return _PROXY_MAPPING_CACHE
    import configparser
    from pathlib import Path
    ini_path = Path(__file__).parent / 'proxy_mapping.ini'
    proxy_map = {}
    service_aliases = {}
    action_codes = {'allow': '1', 'permit': '1', 'accept': '1',
                     'deny': '2', 'drop': '2', 'block': '2',
                     'reject': '2'}
    if ini_path.is_file():
        p = configparser.ConfigParser()
        # Preserve case in keys (ConfigParser lowercases by default)
        p.optionxform = str
        p.read(ini_path, encoding='utf-8')
        if p.has_section('proxy_services'):
            for k, v in p.items('proxy_services'):
                proxy_map[k.lower().strip()] = v.strip()
        if p.has_section('service_aliases'):
            for k, v in p.items('service_aliases'):
                service_aliases[k.lower().strip()] = v.strip()
        if p.has_section('firewall_actions'):
            for k, v in p.items('firewall_actions'):
                action_codes[k.lower().strip()] = v.strip()
    _PROXY_MAPPING_CACHE = (proxy_map, service_aliases, action_codes)
    return _PROXY_MAPPING_CACHE


def _resolve_service_and_proxy(service_name):
    """For a customer service name, return (wg_service, proxy_action,
    firewall_code_numeric, firewall_string).

    If the service maps to a WG proxy: returns (svc, proxy_action, '4',
    'Proxy').
    Otherwise: returns (svc, None, '1', 'Allow') — a packet-filter
    policy with no proxy.

    Verified against jpa policy shapes: <proxy>NAME</proxy> with
    firewall=4/Proxy for proxy policies, <proxy /> with firewall=1/Allow
    for packet filters.
    """
    proxy_map, service_aliases, _ = _load_proxy_mapping()
    if not service_name:
        return ('Any', None, '1', 'Allow')
    raw = str(service_name).strip()
    key = raw.lower()
    # Apply service alias if any
    wg_service = service_aliases.get(key, raw)
    # Look up proxy by both the WG service name and the raw key
    lookup_key = wg_service.lower()
    proxy_action = proxy_map.get(lookup_key) or proxy_map.get(key)
    if proxy_action:
        return (wg_service, proxy_action, '4', 'Proxy')
    return (wg_service, None, '1', 'Allow')


def _pick_richest_variant(variants):
    """Pick the variant with the most TOTAL descendant elements (not
    just top-level shape length). For policy-list and abs-policy-list,
    some variants have more top-level fields but a SHALLOWER settings
    subtree. The WG Web UI 12.5.9 requires the deep settings (forward-
    traffic-mgmt, log-for-report, geo-action, compliance-check, etc.).
    Verified against working Apple Bonjour-00 export: the variant
    cloned from FTP-proxy / WatchGuard Web UI factory policies has
    the right depth."""
    if not variants:
        return None
    def _score(v):
        try:
            clone = ET.fromstring(v['template_xml'])
            return sum(1 for _ in clone.iter())
        except ET.ParseError:
            return 0
    return max(variants, key=_score)


def fill_policies(list_elem, templates, records, ctx):
    variants = templates.get('policy-list', {}).get('shape_variants', [])
    if not variants or not records:
        return 0
    # SonicWall action -> WG firewall reference. Per jpa.xml empirical:
    #   /policy-list/policy/firewall:    NUMERIC (1=Allow, 2=Block, 4=Proxy)
    action_map = {
        'allow': 1, 'permit': 1, 'accept': 1,
        'deny': 2, 'block': 2, 'drop': 2, 'reject': 2, 'discard': 2,
        'proxy': 4,
    }
    # SonicWall source/dest → WG alias mapping is declared in
    # zone_mapping.ini, NOT hardcoded here. SonicWall uses lowercase
    # 'any', WG uses 'Any'. Built here as a dict to preserve the
    # existing call-site shape (alias_map.get(value)).
    alias_map = zone_mapper.all_zone_aliases()

    def normalize_alias(value):
        """Take a SonicWall source/dest token and return the matching
        WG alias name. Defaults to 'Any' if nothing recognized."""
        if not value:
            return 'Any'
        if isinstance(value, list):
            # Pick the first non-port token
            for v in value:
                if isinstance(v, str) and not v.startswith('port'):
                    return normalize_alias(v)
            return 'Any'
        if not isinstance(value, str):
            return 'Any'
        v = value.strip().lower()
        # Strip 'port ...' suffix patterns
        v = v.split()[0] if v else 'any'
        return alias_map.get(v, value if value[0].isupper() else 'Any')

    # jpa entries are WG factory policy package (Ping, WatchGuard Web
    # UI, DNS, Outgoing, Unhandled blocks). Preserve them; append
    # customer entries with name-dedupe (jpa wins). Without this, the
    # box would have no Ping/WatchGuard Web UI policies after import
    # and would reject all management traffic — verified against lab
    # T-30 12.5.9 after factory reset.
    existing = _existing_names(list_elem)
    # alias-list ref for auto-generated wrapper aliases per policy
    root = ctx.get('_root') if ctx else None
    alias_list = root.find('alias-list') if root is not None else None
    alias_existing = _existing_names(alias_list) if alias_list is not None \
                     else set()

    # -----------------------------------------------------------------
    # Access-rule filter pass (FES v1.8.6+).
    #
    # Drops records that match patterns in access_rule_filter.ini.
    # Applied BEFORE wrapper alias creation so dropped rules never
    # generate orphan .1.from / .1.to entries in <alias-list>. No
    # cascade-delete needed because nothing's been created yet for
    # dropped rules.
    #
    # Currently drops: family=ipv6 (per Captain instruction 2026-06-13).
    # Reversible: remove [drop.*] sections from the INI to re-enable.
    # See access_rule_filter.ini for the full rule catalog.
    # -----------------------------------------------------------------
    ar_filter_ini = Path(__file__).parent / 'access_rule_filter.ini'
    n_dropped_by_filter = 0
    if ar_filter_ini.is_file():
        import configparser as _cp_ar
        import re as _re_ar
        arcp = _cp_ar.ConfigParser()
        arcp.optionxform = str
        try:
            arcp.read(ar_filter_ini, encoding='utf-8')
        except _cp_ar.Error as _e:
            arcp = None
        drop_rules: list = []
        if arcp is not None:
            for sect in arcp.sections():
                if not sect.startswith('drop.'):
                    continue
                rule = {
                    'name': sect,
                    'family': arcp.get(sect, 'family',
                                       fallback='').strip().lower(),
                    'comment_pattern': arcp.get(sect, 'comment_pattern',
                                                fallback='').strip(),
                    'zone_from': arcp.get(sect, 'zone_from',
                                          fallback='').strip(),
                    'zone_to': arcp.get(sect, 'zone_to',
                                        fallback='').strip(),
                }
                # Compile the comment regex once if present
                if rule['comment_pattern']:
                    try:
                        rule['_comment_re'] = _re_ar.compile(
                            rule['comment_pattern']
                        )
                    except _re_ar.error:
                        rule['_comment_re'] = None
                else:
                    rule['_comment_re'] = None
                drop_rules.append(rule)
        if drop_rules:
            filtered_records = []
            for r in records:
                rec_family = str(r.get('family') or '').strip().lower()
                rec_comment = str(r.get('comment') or '')
                rec_from = str(r.get('from') or r.get('from_zone') or '').strip()
                rec_to = str(r.get('to') or r.get('to_zone') or '').strip()
                dropped_by = None
                for rule in drop_rules:
                    if rule['family'] and rule['family'] != 'any' \
                            and rule['family'] != rec_family:
                        continue
                    if rule['zone_from'] and rule['zone_from'] != rec_from:
                        continue
                    if rule['zone_to'] and rule['zone_to'] != rec_to:
                        continue
                    if rule['_comment_re'] is not None \
                            and not rule['_comment_re'].search(rec_comment):
                        continue
                    dropped_by = rule['name']
                    break
                if dropped_by:
                    n_dropped_by_filter += 1
                else:
                    filtered_records.append(r)
            if n_dropped_by_filter:
                print(
                    f'         (access-rule filter dropped '
                    f'{n_dropped_by_filter} records '
                    f'matching access_rule_filter.ini rules)'
                )
            records = filtered_records

    n = 0
    n_skipped = 0
    for r in records:
        raw_name = r.get('name') or r.get('_id')
        if not raw_name:
            continue
        # Customer name may be False (auto-generated SonicWall UUID).
        # Use a stable derived name.
        if raw_name is False or raw_name == 'False':
            raw_name = r.get('_id', 'unnamed-policy')
        # WG convention (verified against working Apple Bonjour-00
        # policy exported from a live Firebox):
        #   policy-list/policy/name = '<raw_name>-00'
        #   abs-policy-list/abs-policy/name = '<raw_name>' (no suffix)
        #   alias-list wrapper aliases: '<raw_name>.1.from', '.1.to'
        # The Web UI uses the unsuffixed name as the display name and
        # the .1.from/.1.to aliases as zone-routing wrappers.
        # Suffix declared in marker_mapping.ini [suffix_conventions].
        name = f'{raw_name}{wg_suffix("policy_list_entry")}'
        # jpa-wins dedupe (case-insensitive)
        if name in existing or str(name).lower() in {e.lower() for e in existing}:
            n_skipped += 1
            continue

        # Use the richest variant (12.5.9 schema with all required
        # fields). The default _pick_variant returns the FIRST variant
        # which may be an older shape missing fields the WG Web UI
        # requires to render the policy.
        # Use the richest variant (12.5.9 schema with all required
        # fields). The default _pick_variant returns the FIRST variant
        # which may be an older shape missing fields the WG Web UI
        # requires to render the policy.
        variant = _pick_richest_variant(variants)
        clone = _clone_template(variant['template_xml'])
        _set_leaf(clone, 'name', name)
        _set_leaf(clone, 'description', r.get('description', ''))

        # Resolve the customer's service to (wg_service, proxy_action,
        # firewall_code) using proxy_mapping.ini.
        #
        # WG policies are either:
        #   PROXY policy: firewall=4, <proxy>NAME</proxy>, service that
        #                 WG has an ALG/proxy for (HTTP, HTTPS, FTP,
        #                 H.323, SIP, SMTP, IMAP, POP3, DNS,
        #                 Explicit-Web, TCP-UDP-Proxy)
        #   PACKET FILTER: firewall=1/2 (Allow/Block), <proxy />,
        #                 any service including unknown/custom ones
        #
        # Apple Bonjour, custom ALGs, and any service WG doesn't proxy
        # get packet-filter treatment. Verified empirically: the
        # template was cloned from FTP-proxy-00 which has
        # <proxy>Default-FTP-Client</proxy>. For non-FTP customer
        # policies, the proxy ref made the policy invalid and the
        # Web UI hid it.
        raw_service = r.get('service') or 'Any'
        wg_service, proxy_action, fw_code, fw_str = \
            _resolve_service_and_proxy(raw_service)

        # service ref (case-normalized by post-fill pass)
        _set_leaf(clone, 'service', wg_service)

        # firewall action — prefer customer's action if present, else
        # use the resolver's default (Allow for packet-filter, Proxy
        # for proxy policy). Customer action override only applies to
        # packet-filter shape (proxy policies are always firewall=4).
        _, _, action_codes = _load_proxy_mapping()
        customer_action = (r.get('action') or '').strip().lower()
        if proxy_action:
            # Proxy policy — firewall=4 regardless of customer action
            _set_leaf(clone, 'firewall', fw_code)
            _set_leaf(clone, 'proxy', proxy_action)
        else:
            # Packet-filter policy — firewall from customer action
            mapped_fw = action_codes.get(customer_action, fw_code)
            _set_leaf(clone, 'firewall', mapped_fw)
            # Reset inherited proxy field to <proxy />
            proxy_elem = clone.find('proxy')
            if proxy_elem is not None:
                proxy_elem.text = None
                for c in list(proxy_elem):
                    proxy_elem.remove(c)

        # from-alias-list and to-alias-list — WG convention (verified
        # against working Apple Bonjour-00 policy export):
        # The policy references AUTO-GENERATED wrapper aliases named
        # '<raw_name>.1.from' and '<raw_name>.1.to'. Each wrapper alias
        # contains a single type=2 alias-member with <alias-name>
        # pointing at the actual zone alias (Any-Trusted, Any-External,
        # Any-Optional, Firebox).
        # The wrapper aliases are what carry the SonicWall zone -> WG
        # zone mapping. Direct zone refs (from-alias = 'Any-Trusted')
        # don't work — the Web UI doesn't render those.
        from_zone = r.get('from_zone') or r.get('from') or 'any'
        to_zone = r.get('to_zone') or r.get('to') or 'any'
        from_zone_alias = alias_map.get(str(from_zone).lower(), 'Any')
        to_zone_alias = alias_map.get(str(to_zone).lower(), 'Any')
        # Build the wrapper alias names. Suffixes declared in
        # marker_mapping.ini [suffix_conventions].
        from_wrapper = f'{raw_name}{wg_suffix("policy_from_zone_wrapper")}'
        to_wrapper = f'{raw_name}{wg_suffix("policy_to_zone_wrapper")}'
        # Create the wrapper aliases in alias-list (idempotent)
        if alias_list is not None:
            for wrapper_name, wrapped_zone in (
                    (from_wrapper, from_zone_alias),
                    (to_wrapper, to_zone_alias)):
                if wrapper_name in alias_existing:
                    continue
                new_alias = ET.SubElement(alias_list, 'alias')
                ET.SubElement(new_alias, 'name').text = wrapper_name
                ET.SubElement(new_alias, 'property').text = wg_enum_code('alias.property', 'builtin')
                aml = ET.SubElement(new_alias, 'alias-member-list')
                am = ET.SubElement(aml, 'alias-member')
                ET.SubElement(am, 'type').text = wg_enum_code('alias_member.type', 'alias-reference')
                ET.SubElement(am, 'alias-name').text = wrapped_zone
                alias_existing.add(wrapper_name)
        # Patch the policy's from/to-alias-list to point at the wrappers
        fal = clone.find('from-alias-list')
        if fal is not None:
            for c in list(fal):
                fal.remove(c)
            elem = ET.SubElement(fal, 'alias')
            elem.text = from_wrapper
        tal = clone.find('to-alias-list')
        if tal is not None:
            for c in list(tal):
                tal.remove(c)
            elem = ET.SubElement(tal, 'alias')
            elem.text = to_wrapper

        # schedule ref (if present)
        if r.get('schedule'):
            sched = clone.find('schedule')
            if sched is not None:
                _set_leaf(sched, 'settings/schedule', r['schedule'])

        list_elem.append(clone)
        existing.add(name)
        n += 1
    if n_skipped:
        print(f'         (skipped {n_skipped} duplicates — jpa policy package wins)')
    return n


# ---- VPN: site-to-site BOVPN ------------------------------------------------
#
# SonicWall site-to-site VPN -> WatchGuard BOVPN requires writing into
# THREE coordinated lists:
#   ipsec-proposal-list   <- phase2 transform (ESP-AES128-SHA1, etc.)
#   ike-policy-list       <- phase1 settings + peer-address
#   ipsec-action-list     <- tunnel definition tying it together
#
# SonicWall GroupVPN (mobile-VPN) -> WG IKEv2 MVPN. jpa has WG IKEv2
# MVPN pre-staged; we keep that and skip if customer GroupVPN names
# already collide.

def _vpn_extract_proposal(record):
    """Pull phase2 proposal name from customer VPN record."""
    p2 = record.get('phase2', {}) or {}
    enc = (p2.get('encryption') or 'aes-128').upper().replace('-', '')
    auth = (p2.get('authentication') or 'sha-1').upper().replace('-', '')
    return f'ESP-{enc}-{auth}'

def _peer_name_from_record(record):
    """Try to derive the customer's SonicWall NAME for the peer.
    Returns None if not found. Example: 'remote name someremotepeerfake'
    -> 'someremotepeerfake'."""
    for tok in (record.get('network') or []):
        captured = sw_after_prefix(tok, 'vpn_remote_network_name')
        if captured is not None:
            return captured
    return None


def _peer_ip_from_record(record):
    """Try to derive a peer-addr IP from the customer VPN record."""
    # ike-id has 'peer ipv4 14.14.14.14'
    am = record.get('auth-method', {}) or {}
    for tok in (am.get('ike-id') or []):
        if isinstance(tok, str) and 'peer ipv4' in tok:
            return tok.split()[-1]
    # gateway: 'primary fakeprigwtun' — that's an SW gateway-name not IP.
    # Without an IP we use Any (matches GroupVPN dynamic-peer pattern).
    return 'Any'


def fill_vpn_policies(root, templates, records, ctx):
    """Translate customer VPN policies into ipsec-action / ike-policy /
    ipsec-proposal entries. Returns count added."""
    if not records:
        return 0
    proposal_list = root.find('ipsec-proposal-list')
    ike_pol_list = root.find('ike-policy-list')
    ipsec_act_list = root.find('ipsec-action-list')
    if proposal_list is None or ike_pol_list is None or ipsec_act_list is None:
        return 0

    prop_existing = _existing_names(proposal_list)
    ike_existing = _existing_names(ike_pol_list)
    act_existing = _existing_names(ipsec_act_list)

    # address-group is referenced by ike-policy.peer-addr. WG requires
    # peer-addr to name a defined address-group (not a bare IP literal).
    # Verified against lab T-30 12.5.9 import error:
    #   "The remote gateway IP address '14.14.14.14' does not exist."
    # which fires because <peer-addr>14.14.14.14</peer-addr> has no
    # matching address-group with that name. jpa's convention (e.g.
    # bovpngateway.1 -> peer-addr=174.62.83.243) is to name the
    # address-group with the IP literal and include a host-ip-addr
    # member.
    addr_group_list = root.find('address-group-list')
    addr_group_existing = (_existing_names(addr_group_list)
                            if addr_group_list is not None else set())

    def _ensure_addr_group(group_name, host_ip=None, network_cidr=None):
        """Make sure an address-group named group_name exists with the
        given host-ip-addr or network member. Idempotent. Returns
        group_name (so caller can use it in a ref)."""
        if not group_name:
            return None
        if group_name in addr_group_existing:
            return group_name
        if addr_group_list is None:
            return group_name
        new_ag = ET.SubElement(addr_group_list, 'address-group')
        ET.SubElement(new_ag, 'name').text = group_name
        ET.SubElement(new_ag, 'description').text = ''
        ET.SubElement(new_ag, 'property').text = wg_enum_code('address_group.property', 'builtin')
        agm = ET.SubElement(new_ag, 'addr-group-member')
        mem = ET.SubElement(agm, 'member')
        if network_cidr:
            # WG schema requires NETWORK + MASK as separate dotted-quads,
            # not CIDR notation. Verified against jpa.xml: every
            # <ip-network-addr> in jpa is a bare IPv4 (no slash) with a
            # sibling <ip-mask>. Lab T-30 12.5.9 rejection:
            #   "Invalid IP address '192.168.1.0/24' for element
            #    'ip-network-addr'."
            if '/' in network_cidr:
                net, prefix = network_cidr.split('/', 1)
                try:
                    p = int(prefix)
                except ValueError:
                    p = 24
                # Convert prefix length to dotted-quad netmask
                bits = (0xFFFFFFFF << (32 - p)) & 0xFFFFFFFF
                netmask = '.'.join(str((bits >> s) & 0xFF)
                                    for s in (24, 16, 8, 0))
            else:
                net = network_cidr
                netmask = '255.255.255.0'
            ET.SubElement(mem, 'type').text = wg_enum_code('addr_group_member.type', 'ip-network')
            ET.SubElement(mem, 'ip-network-addr').text = net
            ET.SubElement(mem, 'ip-mask').text = netmask
        else:
            ET.SubElement(mem, 'type').text = wg_enum_code('addr_group_member.type', 'host-ip')
            ET.SubElement(mem, 'host-ip-addr').text = host_ip or '0.0.0.0'
        addr_group_existing.add(group_name)
        return group_name

    def _ensure_addr_group_with_members(group_name, members):
        """Emit an address-group with ONE OR MORE members. Each entry
        in `members` is a dict:
            {'type': 'host',    'value': IP}
            {'type': 'network', 'value': NETWORK, 'mask': NETMASK}

        Idempotent: if the group already exists in the emit, replace
        its addr-group-member contents with the new list (defensive —
        previous fill_vpn_policies passes may have emitted a stale
        placeholder via _ensure_addr_group). Returns group_name.
        """
        if not group_name:
            return None
        if addr_group_list is None:
            return group_name

        # Find existing or create new
        existing_elem = None
        for ag in addr_group_list.findall('address-group'):
            n = ag.find('name')
            if n is not None and n.text == group_name:
                existing_elem = ag
                break
        if existing_elem is None:
            new_ag = ET.SubElement(addr_group_list, 'address-group')
            ET.SubElement(new_ag, 'name').text = group_name
            ET.SubElement(new_ag, 'description').text = ''
            ET.SubElement(new_ag, 'property').text = wg_enum_code('address_group.property', 'builtin')
            agm = ET.SubElement(new_ag, 'addr-group-member')
            addr_group_existing.add(group_name)
        else:
            agm = existing_elem.find('addr-group-member')
            if agm is None:
                agm = ET.SubElement(existing_elem, 'addr-group-member')
            else:
                # Drop existing members; we'll rewrite with resolved set
                for c in list(agm):
                    agm.remove(c)

        for m in members:
            mem = ET.SubElement(agm, 'member')
            if m.get('type') == 'network':
                ET.SubElement(mem, 'type').text = wg_enum_code('addr_group_member.type', 'ip-network')
                ET.SubElement(mem, 'ip-network-addr').text = m.get('value', '0.0.0.0')
                ET.SubElement(mem, 'ip-mask').text = m.get('mask', '255.255.255.0')
            else:
                ET.SubElement(mem, 'type').text = wg_enum_code('addr_group_member.type', 'host-ip')
                ET.SubElement(mem, 'host-ip-addr').text = m.get('value', '0.0.0.0')
        return group_name

    def _ensure_peer_addr_group(peer_ip, host_ip=None):
        """Make sure an address-group named <peer_ip> exists with a
        host-ip-addr member.

        For IP-form peer values: name = host_ip = peer_ip (default).
        For name-form peer values: name = peer_ip (the name label),
          host_ip = caller-supplied placeholder (typically '0.0.0.0'
          when SonicWall config didn't provide an IP for the name).

        Idempotent. Firebox restore requires this entry to exist for
        every <peer-addr> value referenced from ike-policy.
        """
        if not peer_ip or peer_ip == 'Any':
            return
        if host_ip is None:
            host_ip = peer_ip
        _ensure_addr_group(peer_ip, host_ip=host_ip)

    # Templates may have been scrubbed from the live skeleton (because
    # they're jpa-customer-named like 'bovpntunnel.1'), but the shape
    # we need to clone was captured in templates.json BEFORE scrub.
    # Fall back to templates.json variants if the live list doesn't
    # have the named entry.
    def _find_template(list_elem, list_tag_for_json, prefer_name=None,
                         require_child_tag=None, forbid_child_tag=None):
        """Find a template. Search order:
           1. Live list, matching prefer_name (best case)
           2. templates.json shape_variants, matching prefer_name
           3. templates.json shape_variants, matching shape constraint
              (require_child_tag must appear, forbid_child_tag must not)
           4. First available variant
        """
        kids = list(list_elem)
        if prefer_name:
            for k in kids:
                n = k.find('name')
                if n is not None and n.text == prefer_name:
                    return k
        list_templates = templates.get(list_tag_for_json) or {}
        variants = list_templates.get('shape_variants') or []
        # Pass 2: by prefer_name in templates.json
        for v in variants:
            try:
                clone = ET.fromstring(v['template_xml'])
                n = clone.find('name')
                if prefer_name and n is not None and n.text == prefer_name:
                    return clone
            except ET.ParseError:
                continue
        # Pass 3: by shape (require/forbid child tag presence)
        if require_child_tag or forbid_child_tag:
            for v in variants:
                shape = set(v.get('shape', []))
                if require_child_tag and require_child_tag not in shape:
                    continue
                if forbid_child_tag and forbid_child_tag in shape:
                    continue
                try:
                    return ET.fromstring(v['template_xml'])
                except ET.ParseError:
                    continue
        # Pass 4: any variant
        if variants:
            try:
                return ET.fromstring(variants[0]['template_xml'])
            except ET.ParseError:
                pass
        if kids:
            return kids[-1]
        return None

    # Site-to-site ipsec-action template: must contain <ike-policy-group>
    # ref (NOT <ike-policy>). Verified against jpa: bovpntunnel.1 used
    # ike-policy-group while WG IKEv2 MVPN used ike-policy. WG Web UI
    # Branch Office VPN > Tunnels reads entries where the ipsec-action
    # references an ike-policy-group, and Gateways reads from
    # ike-policy-group-list itself.
    ipsec_template_s2s = _find_template(
        ipsec_act_list, 'ipsec-action-list',
        prefer_name=preferred_template('ipsec_action_site2site'),
        require_child_tag='ike-policy-group',
        forbid_child_tag='ike-policy',
    )
    ike_template = _find_template(ike_pol_list, 'ike-policy-list',
                                   preferred_template('ike_policy_default'))
    prop_template = _find_template(proposal_list, 'ipsec-proposal-list',
                                    preferred_template('ipsec_proposal_default'))

    # ike-action template: prefer the branch-office variant (mode=2)
    # for customer site-to-site tunnels. Falls back to first available
    # if the preferred isn't in templates.json.
    ike_act_list = root.find('ike-action-list')
    ike_act_existing = _existing_names(ike_act_list) if ike_act_list is not None else set()
    ike_action_template = None
    if ike_act_list is not None:
        ika_templates = templates.get('ike-action-list') or {}
        ika_variants = ika_templates.get('shape_variants') or []
        preferred_ika = preferred_template('ike_action_branchoffice')
        # Try preferred first; the prototype_name encoded inside the
        # template_xml's <name> tag is the canonical name we match against.
        for v in ika_variants:
            try:
                tmpl_xml = v.get('template_xml', '')
                if preferred_ika and preferred_ika in tmpl_xml[:200]:
                    ike_action_template = ET.fromstring(tmpl_xml)
                    break
            except ET.ParseError:
                continue
        # Fallback: any variant with mode=2 (branch-office)
        if ike_action_template is None:
            for v in ika_variants:
                try:
                    cand = ET.fromstring(v.get('template_xml', ''))
                    mode_el = cand.find('mode')
                    if mode_el is not None and (mode_el.text or '').strip() == '2':
                        ike_action_template = cand
                        break
                except ET.ParseError:
                    continue

    # ike-policy-group template: borrow from jpa via templates.json
    # (the list has been scrubbed in the live tree because jpa's
    # bovpngateway.1 group was a jpa-customer entry).
    ipg_list = root.find('ike-policy-group-list')
    if ipg_list is None:
        ipg_list = ET.SubElement(root, 'ike-policy-group-list')
    ipg_templates = templates.get('ike-policy-group-list') or {}
    ipg_variants = ipg_templates.get('shape_variants') or []
    ipg_template = None
    for v in ipg_variants:
        try:
            ipg_template = ET.fromstring(v['template_xml'])
            break
        except ET.ParseError:
            continue
    ipg_existing = _existing_names(ipg_list)

    if ipsec_template_s2s is None or ike_template is None \
            or prop_template is None:
        return 0

    n_added = 0
    for r in records:
        name = r.get('name') or r.get('_id')
        if not name:
            continue
        vpn_type = r.get('vpn_type') or ''
        is_site2site = 'site' in vpn_type.lower()

        # Both site-to-site and GroupVPN get an ike-policy entry per
        # customer VPN — gives each one its own peer-addr/proposal binding.
        # The difference: site-to-site -> ipsec-action entry too.
        # GroupVPN (mobile-VPN) reuses the WG IKEv2 MVPN action that
        # jpa already provides — we just register the customer's name
        # as an ike-policy so it shows up in the box.

        # 1) Build proposal entry if needed
        prop_name = _vpn_extract_proposal(r)
        if prop_name not in prop_existing:
            prop_clone = copy.deepcopy(prop_template)
            _set_leaf(prop_clone, 'name', prop_name)
            _set_leaf(prop_clone, 'description', f'From {name}')
            proposal_list.append(prop_clone)
            prop_existing.add(prop_name)

        # Compute peer_ip + peer_name once per record — used by both
        # ike-policy (peer-addr / peer-auth/ip-addr) and ipsec-action
        # (remote pair).
        peer_ip = _peer_ip_from_record(r)
        peer_name = _peer_name_from_record(r)

        # If the customer named their peer (e.g. 'someremotepeerfake'
        # in SonicWall address-objects), preserve that name as an
        # address-group AND as an alias-list entry. The peer-addr ref
        # in ike-policy points to peer_ip; the name-preserved
        # group/alias is for visibility in the WG Aliases panel.
        #
        # COLLISION GUARD (FES v1.8.6, P0 alias-crash fix):
        # If a customer address-object with the SAME NAME already exists
        # as an <alias> in the emit (placed there by fill_user_address_
        # objects from address_objects.json), DO NOT create a second
        # alias OR a ghost address-group named the same. Two reasons:
        #
        #   1. The customer's proper alias points at <peer_name>.1.alm
        #      (the proper backing group convention). The defensive
        #      emit below would create an address-group named <peer_name>
        #      directly (no .1.alm suffix) with the IKE PEER IP as
        #      host-ip-addr — completely wrong IP, since the SW VPN's
        #      'network remote name' is a CROSS-REFERENCE to the
        #      address-object, not an independent IP value.
        #
        #   2. WG Web UI alias panel CRASHES when an <alias> and an
        #      <address-group> share the same name. Lab-confirmed
        #      Captain Jim Ames TZ-300 cycle 2026-06-13 — the panel
        #      becomes unrenderable and logs the operator out.
        #
        # Provenance: SW source `vpn policy ... network remote name
        # tz300addressobject2wanzone` referenced address-object that
        # was correctly parsed by Fix D. Before this guard, the VPN
        # code created a ghost group with the same name + wrong IP.
        if peer_name and peer_ip and peer_ip != 'Any':
            alias_list = root.find('alias-list')
            alias_already_exists = False
            if alias_list is not None:
                for a in alias_list.findall('alias'):
                    an = a.find('name')
                    if an is not None and an.text == peer_name:
                        alias_already_exists = True
                        break
            if alias_already_exists:
                print(
                    f'  [vpn-collision-guard] VPN {name!r} references '
                    f'customer address-object {peer_name!r} which is '
                    f'already in alias-list (from fill_user_address_'
                    f'objects). Skipping defensive ghost emit to avoid '
                    f'name collision crash in WG Web UI.',
                    file=sys.stderr,
                )
            else:
                _ensure_addr_group(peer_name, host_ip=peer_ip)
                # Also emit alias-list entry — the WG Aliases panel reads
                # from alias-list, not address-group-list. Without this,
                # the customer's named peer doesn't appear in Aliases.
                if alias_list is not None:
                    alias_existing = _existing_names(alias_list)
                    if peer_name not in alias_existing:
                        new_alias = ET.SubElement(alias_list, 'alias')
                        ET.SubElement(new_alias, 'name').text = peer_name
                        ET.SubElement(new_alias, 'description').text = (
                            f'From SonicWall address-object {peer_name}'
                        )
                        # <property> is REQUIRED by WG schema (verified
                        # against jpa: all 49 alias entries have <property>).
                        # Without it, jpa_diff fires HARD.
                        ET.SubElement(new_alias, 'property').text = wg_enum_code('alias.property', 'user-defined')
                        aml = ET.SubElement(new_alias, 'alias-member-list')
                        am = ET.SubElement(aml, 'alias-member')
                        # WG alias-member shape (verified against jpa):
                        #   <type>N</type><user>X</user>
                        #   <address>IP_OR_GROUP</address><interface>X</interface>
                        # Type 1 = host-ip alias. The <address> field holds
                        # either an IP literal or an address-group name.
                        ET.SubElement(am, 'type').text = wg_enum_code('alias_member.type', 'host-or-named')
                        ET.SubElement(am, 'user').text = 'Any'
                        ET.SubElement(am, 'address').text = peer_ip
                        ET.SubElement(am, 'interface').text = 'Any'

        # 2) Build ike-policy entry per customer VPN
        ike_name = name
        if ike_name not in ike_existing:
            ike_clone = copy.deepcopy(ike_template)
            _set_leaf(ike_clone, 'name', ike_name)
            _set_leaf(ike_clone, 'description', f'From SonicWall {name}')

            # Extract IKE identity strings from SW record. SonicWall syntax:
            #   ike-id local domain-name localikedomainoripClaude
            #   ike-id peer  domain-name peerikedomainoripClaude
            #   ike-id local ipv4        192.0.2.1   (alternate form)
            # WG accepts BOTH FQDN and IP forms — the toolkit carries the
            # string through verbatim and sets the matching id-type.
            # An "internal domain" label that doesn't resolve via DNS is
            # perfectly valid here; IKE identity is just a label both peers
            # agree on. Decoded from golden_pair metadata.
            local_id_value: str | None = None
            local_id_kind: str | None = None  # 'fqdn' or 'ip'
            peer_id_value: str | None = None
            peer_id_kind: str | None = None
            am = r.get('auth-method', {}) or {}
            for tok in (am.get('ike-id') or []):
                if not isinstance(tok, str):
                    continue
                parts = tok.split(None, 2)
                if len(parts) < 3:
                    continue
                side, idkind, value = parts[0], parts[1], parts[2].strip()
                kind = 'fqdn' if idkind == 'domain-name' else (
                    'ip' if idkind == 'ipv4' else 'fqdn'
                )
                if side == 'local':
                    local_id_value, local_id_kind = value, kind
                elif side == 'peer':
                    peer_id_value, peer_id_kind = value, kind

            # Carry LOCAL IKE-ID into <local-cert>/<local-id-data>
            # plus <local-id-type> (2=FQDN, 1=IP, per wg_enums.ini).
            lc = ike_clone.find('local-cert')
            if lc is not None and local_id_value:
                lit = lc.find('local-id-type')
                if lit is not None:
                    # 2=FQDN, 1=IP — codes from CLEAN-6 wg_enums.ini
                    # Note: we don't have explicit enum entries for
                    # local-id-type; the values come from observation
                    # of the golden ref (local-id-type=2 with FQDN data).
                    lit.text = '2' if local_id_kind == 'fqdn' else '1'
                lid = lc.find('local-id-data')
                if lid is not None:
                    lid.text = local_id_value

            # Peer-addr: carry SW gateway 'primary <TOKEN>' through
            # verbatim. The token may be an IP literal OR a name label —
            # WG's <peer-addr> accepts both. Resolve from SW record.
            peer_endpoint = None  # (value, kind='ip'|'name'|'any')
            for tok in (r.get('gateway') or []):
                if isinstance(tok, str) and tok.startswith('primary '):
                    val = tok[len('primary '):].strip()
                    if val:
                        import ipaddress
                        try:
                            ipaddress.ip_address(val)
                            peer_endpoint = (val, 'ip')
                        except (ValueError, TypeError):
                            peer_endpoint = (val, 'name')
                        break
            if peer_endpoint is None:
                # Fallback to older derivation if no 'gateway primary' line
                peer_endpoint = (peer_ip, 'ip' if peer_ip != 'Any' else 'any')

            new_peer_addr, peer_kind = peer_endpoint
            # WG Firebox restore-time check: every <peer-addr> value
            # MUST have a matching <address-group> with the same name.
            # This applies whether the value is an IP literal OR a name
            # label. Lab T-30 12.5.9 rejection observed:
            #   "Restore Failed: 400 The remote gateway IP address
            #    'FakePriIPSECGwNameORAdrClaude' does not exist."
            # because the toolkit emitted the name but no backing group.
            #
            # For IP literals, the address-group's member holds the IP.
            # For name labels (DNS hostnames or arbitrary labels), the
            # SonicWall config didn't provide an IP — the customer's
            # SW config uses runtime DNS resolution. The toolkit emits
            # a placeholder member (0.0.0.0) and prints a SOFT warning
            # so the operator knows to edit the gateway IP in the WG
            # Web UI after import.
            if peer_kind == 'ip':
                _ensure_peer_addr_group(new_peer_addr)
            else:
                # Name-form peer: emit backing group with placeholder IP.
                # Group NAME matches peer-addr text; member is 0.0.0.0
                # placeholder. The Firebox accepts the config (restore
                # passes), tunnel won't come up until operator edits IP.
                _ensure_peer_addr_group(new_peer_addr, host_ip='0.0.0.0')
                print(
                    f'  [warn] VPN {name!r} peer-addr {new_peer_addr!r} '
                    f'is a name label (no IP in SonicWall config). '
                    f'Backing address-group emitted with placeholder '
                    f'0.0.0.0 — operator must edit gateway IP in WG '
                    f'Web UI before tunnel can come up.',
                    file=sys.stderr
                )
            _set_leaf(ike_clone, 'peer-addr', new_peer_addr)

            # peer-auth: route to the right WG sub-shape based on what
            # the SW peer IKE-ID is. <peer-auth-mask>=4 → match by domain
            # (then a <domain-name> child holds the value). =1 → match by
            # IP (then <ip-addr> child holds the value). Codes from
            # wg_enums.ini [enum.ike_policy.peer-auth.peer-auth-mask].
            pa = ike_clone.find('peer-auth')
            if pa is not None:
                if peer_id_kind == 'fqdn' and peer_id_value:
                    # FQDN peer auth (mask=4 = domain-name)
                    pam = pa.find('peer-auth-mask')
                    if pam is not None:
                        pam.text = '4'
                    dn = pa.find('domain-name')
                    if dn is None:
                        dn = ET.SubElement(pa, 'domain-name')
                    dn.text = peer_id_value
                    # When using FQDN auth, REMOVE <ip-addr> entirely
                    # — leaving it empty triggers qualities_validator
                    # HARD finding (jpa never empty at this XPath).
                    ipa = pa.find('ip-addr')
                    if ipa is not None:
                        pa.remove(ipa)
                elif peer_id_kind == 'ip' and peer_id_value:
                    pam = pa.find('peer-auth-mask')
                    if pam is not None:
                        pam.text = '1'
                    ipa = pa.find('ip-addr')
                    if ipa is None:
                        ipa = ET.SubElement(pa, 'ip-addr')
                    ipa.text = peer_id_value
                else:
                    # No explicit peer IKE-ID — fall back to peer-addr
                    # value as the peer-auth ip-addr (legacy behavior).
                    ipa = pa.find('ip-addr')
                    if ipa is not None and peer_kind == 'ip':
                        ipa.text = new_peer_addr

            # Emit a customer-specific ike-action (branch-office form)
            # before appending the ike-policy. The new action holds the
            # customer's actual Phase 1 crypto (encryption, auth, DH group,
            # lifetime). The ike-policy's <ike-action> element gets
            # repointed at this name so the WG Web UI shows the customer's
            # gateway with the right crypto.
            #
            # Provenance: golden_pair WG reference has
            # <ike-action><name>gateway.1.branchoffice.for.claude_bo</name>
            # with <encryp-algm>7</encryp-algm><encryp-key-len>32</...>
            # — code 7 = AES, key-len 32 = 256-bit. wg_enums.ini
            # [enum.ike_transform.*] has the full code tables.
            ika_name = f'{ike_name}{wg_suffix("ike_action_branchoffice")}'
            if (ike_act_list is not None
                    and ike_action_template is not None
                    and ika_name not in ike_act_existing):
                ika_clone = copy.deepcopy(ike_action_template)
                _set_leaf(ika_clone, 'name', ika_name)
                _set_leaf(ika_clone, 'description', f'From SonicWall {name}')

                # Translate customer phase1 crypto values via wg_enums.ini.
                # SW phase1 dict: {'exchange', 'encryption', 'authentication',
                #                  'dh_group', 'lifetime_seconds'}
                p1 = r.get('phase1', {}) or {}
                xform = ika_clone.find('ike-transform')
                if xform is not None:
                    members = xform.findall('member')
                    if members:
                        m = members[0]  # patch first transform member
                        # Encryption algorithm: aes/3des/des → numeric code
                        sw_enc = (p1.get('encryption') or '').lower()
                        if sw_enc.startswith('aes'):
                            enc_code = wg_enum_code('ike_transform.encryp-algm', 'aes')
                            # Key length: derive from aes-128/aes-192/aes-256
                            try:
                                key_code = wg_enum_code(
                                    'ike_transform.encryp-key-len', sw_enc
                                )
                            except KeyError:
                                key_code = '16'  # default to AES-128
                        elif '3des' in sw_enc:
                            enc_code = wg_enum_code('ike_transform.encryp-algm', '3des')
                            key_code = None
                        elif 'des' in sw_enc:
                            enc_code = wg_enum_code('ike_transform.encryp-algm', 'des')
                            key_code = None
                        else:
                            enc_code = None
                            key_code = None
                        if enc_code is not None:
                            ea = m.find('encryp-algm')
                            if ea is not None:
                                ea.text = enc_code
                        if key_code is not None:
                            ekl = m.find('encryp-key-len')
                            if ekl is not None:
                                ekl.text = key_code

                        # Auth algorithm: sha-1/sha2-256/md5 → numeric code
                        sw_auth = (p1.get('authentication') or '').lower().replace('-', '')
                        auth_map = {
                            'sha1': 'sha1',
                            'sha2256': 'sha2-256',
                            'sha2384': 'sha2-384',
                            'sha2512': 'sha2-512',
                            'md5': 'md5',
                        }
                        auth_friendly = auth_map.get(sw_auth)
                        if auth_friendly:
                            try:
                                auth_code = wg_enum_code(
                                    'ike_transform.auth-algm', auth_friendly
                                )
                                aa = m.find('auth-algm')
                                if aa is not None:
                                    aa.text = auth_code
                            except KeyError:
                                pass

                        # DH group: integer 2 → 'group2', 14 → 'group14'
                        sw_dh = p1.get('dh_group')
                        if sw_dh is not None:
                            try:
                                dh_code = wg_enum_code(
                                    'ike_transform.dh-group', f'group{sw_dh}'
                                )
                                dh = m.find('dh-group')
                                if dh is not None:
                                    dh.text = dh_code
                            except KeyError:
                                pass

                        # Lifetime: SW gives seconds; if >= 3600, convert
                        # to hours (with time-unit=1). Otherwise leave as
                        # seconds with time-unit=0.
                        sw_lifetime = p1.get('lifetime_seconds')
                        if isinstance(sw_lifetime, (int, float)) and sw_lifetime > 0:
                            lt = m.find('lifetime')
                            tu = m.find('time-unit')
                            if sw_lifetime % 3600 == 0 and sw_lifetime >= 3600:
                                hours = int(sw_lifetime // 3600)
                                if lt is not None:
                                    lt.text = str(hours)
                                if tu is not None:
                                    tu.text = wg_enum_code('ike_transform.time-unit', 'hours')
                            else:
                                if lt is not None:
                                    lt.text = str(int(sw_lifetime))
                                if tu is not None:
                                    tu.text = wg_enum_code('ike_transform.time-unit', 'seconds')

                ike_act_list.append(ika_clone)
                ike_act_existing.add(ika_name)

                # Repoint the ike-policy's <ike-action> reference at
                # our new customer action.
                ika_ref = ike_clone.find('ike-action')
                if ika_ref is not None:
                    ika_ref.text = ika_name

            ike_pol_list.append(ike_clone)
            ike_existing.add(ike_name)

        # 3) Site-to-site only: build ipsec-action entry + ike-policy-group
        if is_site2site:
            act_name = name

            # 3a) ike-policy-group entry (the GATEWAY container — what
            # the WG Web UI displays in Branch Office VPN > Gateways).
            # Contains a <member> pointing at the underlying ike-policy.
            ipg_name = name  # Use same name as VPN by convention
            if ipg_name not in ipg_existing and ipg_template is not None:
                ipg_clone = copy.deepcopy(ipg_template)
                _set_leaf(ipg_clone, 'name', ipg_name)
                # Replace member-list with our ike-policy ref
                ml = ipg_clone.find('member-list')
                if ml is not None:
                    for m in list(ml.findall('member')):
                        ml.remove(m)
                    new_m = ET.SubElement(ml, 'member')
                    ET.SubElement(new_m, 'ike-policy').text = ike_name
                ipg_list.append(ipg_clone)
                ipg_existing.add(ipg_name)

            # 3b) ipsec-action entry referencing the ike-policy-group
            # (NOT the ike-policy directly — that's the MVPN pattern).
            if act_name not in act_existing:
                act_clone = copy.deepcopy(ipsec_template_s2s)
                _set_leaf(act_clone, 'name', act_name)
                _set_leaf(act_clone, 'description', f'From SonicWall {name}')

                # PFS: faithful translation from SW. SonicWall syntax
                # 'no proposal ipsec perfect-forward-secrecy' encodes
                # PFS-OFF as a disabled-entry in the proposal list. The
                # parser preserves it as {'_disabled': True,
                # '_args': 'ipsec perfect-forward-secrecy'}.
                #
                # Without explicit handling, the toolkit inherits the
                # template's <pfs>1</pfs> (PFS-ON) and IKE negotiation
                # fails when the SW side wanted OFF.
                # Decoded from golden_pair: SW proposal list has the
                # _disabled marker, customer wants PFS off.
                pfs_off = False
                pfs_explicit = False
                for prop_item in (r.get('proposal') or []):
                    if isinstance(prop_item, dict):
                        args = prop_item.get('_args', '')
                        if 'perfect-forward-secrecy' in args:
                            pfs_explicit = True
                            if prop_item.get('_disabled'):
                                pfs_off = True
                    elif isinstance(prop_item, str):
                        if 'perfect-forward-secrecy' in prop_item:
                            pfs_explicit = True
                            # Active string entry means PFS ON
                if pfs_explicit:
                    pfs_elem = act_clone.find('pfs')
                    if pfs_elem is not None:
                        pfs_elem.text = wg_enum_code(
                            'ipsec_action.pfs',
                            'off' if pfs_off else 'on'
                        )
                    elif pfs_off:
                        # Template didn't include <pfs>; add explicit OFF
                        ET.SubElement(act_clone, 'pfs').text = \
                            wg_enum_code('ipsec_action.pfs', 'off')

                ipsec_prop = act_clone.find('ipsec-proposal')
                if ipsec_prop is not None:
                    for m in list(ipsec_prop.findall('member')):
                        ipsec_prop.remove(m)
                    new_m = ET.SubElement(ipsec_prop, 'member')
                    new_m.text = prop_name
                # CRITICAL: the site-to-site template has <ike-policy-group>.
                # Point it at OUR ike-policy-group, NOT the jpa one.
                ipg = act_clone.find('ike-policy-group')
                if ipg is not None:
                    ipg.text = ipg_name
                else:
                    # Template might unexpectedly have ike-policy. Force
                    # it into the right shape: add ike-policy-group.
                    ip_elem = act_clone.find('ike-policy')
                    if ip_elem is not None:
                        ip_elem.tag = 'ike-policy-group'
                        ip_elem.text = ipg_name

                # CRITICAL: override the cloned template's local-remote-
                # pair-list. The template came from bovpntunnel.1, which
                # references address-groups bovpntunnel.1.1.tlc/trm
                # (10.10.10.10 / 20.20.20.20). If we leave those refs,
                # the Firebox rejects:
                #   "There are duplicated local-remote-address-pairs:
                #    10.10.10.10-20.20.20.20 in bovpn-tunnel:fakesite2site"
                # because both bovpntunnel.1 AND fakesite2site point at
                # the same pair.
                #
                # Build per-VPN address-groups using jpa's naming
                # convention: <vpn-name>.1.tlc (local) and .trm (remote),
                # then reference them in the local-remote-pair. Suffixes
                # declared in marker_mapping.ini [suffix_conventions].
                local_group_name = f'{act_name}{wg_suffix("tunnel_local_endpoints")}'
                remote_group_name = f'{act_name}{wg_suffix("tunnel_remote_endpoints")}'

                # -----------------------------------------------------
                # Tunnel selector resolution (FES v1.8.7+, Fix F).
                #
                # SW VPN blocks reference selectors by GROUP NAME or
                # ADDRESS-OBJECT NAME, e.g.:
                #   network local group "LAN Subnets"
                #   network remote name tz300addressobject2wanzone
                #
                # Walk every 'network' token, call _resolve_vpn_selector
                # to convert references into concrete members, and emit
                # the .1.tlc / .1.trm address-groups with ALL resolved
                # members (not single placeholder).
                #
                # Falls back to placeholders + [warn] for unresolved
                # name labels (e.g. NSA-3600's 'monkeybusiness' DNS
                # label) so operator knows to edit Phase 2 in WG Web UI.
                # -----------------------------------------------------
                customer_dir = ctx.get('_customer_dir')
                local_members = []
                remote_members = []
                unresolved_local = []
                unresolved_remote = []
                if customer_dir is not None:
                    for tok in (r.get('network') or []):
                        side, members, unresolved = _resolve_vpn_selector(
                            tok, customer_dir, ctx
                        )
                        if side == 'local':
                            local_members.extend(members)
                            if unresolved:
                                unresolved_local.append(unresolved)
                        elif side == 'remote':
                            remote_members.extend(members)
                            if unresolved:
                                unresolved_remote.append(unresolved)

                # Build the .1.tlc local address-group with resolved members
                if local_members:
                    _ensure_addr_group_with_members(
                        local_group_name, local_members
                    )
                else:
                    # No resolved members. Either no network tokens, or
                    # all unresolved labels. Emit a placeholder so the
                    # WG XML is structurally valid and the tunnel can
                    # be opened in Web UI for operator edit.
                    fallback_label = (unresolved_local[0]
                                       if unresolved_local else None)
                    _ensure_addr_group_with_members(
                        local_group_name,
                        [{'type': 'network',
                          'value': '0.0.0.0',
                          'mask': '255.255.255.0'}]
                    )
                    if fallback_label:
                        print(
                            f'  [warn] VPN {name!r} local selector '
                            f'{fallback_label!r} did not resolve to a '
                            f'customer address-object or built-in '
                            f'group. Emitted placeholder 0.0.0.0/24 — '
                            f'operator must edit Phase 2 local-addr '
                            f'in WG Web UI.',
                            file=sys.stderr,
                        )

                # Build the .1.trm remote address-group with resolved members
                if remote_members:
                    _ensure_addr_group_with_members(
                        remote_group_name, remote_members
                    )
                else:
                    fallback_label = (unresolved_remote[0]
                                       if unresolved_remote else None)
                    _ensure_addr_group_with_members(
                        remote_group_name,
                        [{'type': 'host', 'value': '0.0.0.0'}]
                    )
                    if fallback_label:
                        print(
                            f'  [warn] VPN {name!r} remote selector '
                            f'{fallback_label!r} did not resolve to a '
                            f'customer address-object or built-in '
                            f'group. Emitted placeholder 0.0.0.0 — '
                            f'operator must edit Phase 2 remote-addr '
                            f'in WG Web UI.',
                            file=sys.stderr,
                        )

                # Now replace the local-remote-pair-list contents
                lrpl = act_clone.find('local-remote-pair-list')
                if lrpl is not None:
                    for c in list(lrpl):
                        lrpl.remove(c)
                    pair = ET.SubElement(lrpl, 'local-remote-pair')
                    ET.SubElement(pair, 'local-addr').text = local_group_name
                    ET.SubElement(pair, 'remote-addr').text = remote_group_name
                    ET.SubElement(pair, 'direction').text = wg_enum_code('local_remote_pair.direction', 'bidirectional')

                ipsec_act_list.append(act_clone)

                # 4) Site-to-site needs a VPN-VIRTUAL INTERFACE entry
                # in interface-list pointing at this ipsec-action.
                # Without it, the tunnel exists in ipsec-action-list but
                # doesn't appear in the WG Web UI Branch Office VPN
                # panel and isn't activated as a tunnel. jpa convention:
                #   <interface>
                #     <name>{tunnel-name}</name>
                #     <property>16</property>
                #     <if-item-list>
                #       <item>
                #         <item-type>4</item-type>
                #         <ipsec-action>{tunnel-name}</ipsec-action>
                #       </item>
                #     </if-item-list>
                #   </interface>
                intf_list = root.find('interface-list')
                if intf_list is not None:
                    # Idempotent: don't add if already present
                    existing_intf_names = {
                        i.find('name').text
                        for i in intf_list.findall('interface')
                        if i.find('name') is not None
                        and i.find('name').text
                    }
                    if act_name not in existing_intf_names:
                        new_intf = ET.SubElement(intf_list, 'interface')
                        ET.SubElement(new_intf, 'name').text = act_name
                        ET.SubElement(new_intf, 'description').text = ''
                        ET.SubElement(new_intf, 'property').text = wg_enum_code('interface.property', 'builtin')
                        iil = ET.SubElement(new_intf, 'if-item-list')
                        item = ET.SubElement(iil, 'item')
                        # VPN tunnel virtual interface uses item-type=4.
                        # Empirically verified against golden WG reference
                        # where tunnel.1.bovpntunn4claude has <item-type>4</item-type>.
                        ET.SubElement(item, 'item-type').text = wg_enum_code('interface_item.item-type', 'tunnel-if')
                        ET.SubElement(item, 'ipsec-action').text = act_name
                act_existing.add(act_name)
        n_added += 1
    return n_added


# ---- service-groups --------------------------------------------------------

def fill_service_groups(list_elem, templates, records, ctx):
    """SonicWall service groups -> WG service-list entries with
    multiple service-item/member children of type=8 (group)."""
    variants = templates.get('service-list', {}).get('shape_variants', [])
    if not variants or not records:
        return 0
    existing = _existing_names(list_elem)
    n_added = 0
    n_skipped = 0
    for r in records:
        name = r.get('name') or r.get('_id')
        if not name:
            continue
        if name in existing or str(name).lower() in {e.lower() for e in existing}:
            n_skipped += 1
            continue
        variant = _pick_variant(variants)
        clone = _clone_template(variant['template_xml'])
        _set_leaf(clone, 'name', name)
        _set_leaf(clone, 'description', r.get('description', ''))
        # service-groups in SonicWall have members; we emit as a service
        # with multiple service-item children referencing other services.
        members = r.get('members') or []
        si = clone.find('service-item')
        if si is not None and members:
            member_template = si.find('member')
            if member_template is not None:
                for m in list(si.findall('member')):
                    si.remove(m)
                for mrec in members:
                    m = copy.deepcopy(member_template)
                    member_name = mrec if isinstance(mrec, str) \
                                  else mrec.get('name', '')
                    if member_name:
                        # Leaves carry the group-member reference; type=8
                        # signals 'service-name reference'.
                        _set_leaf(m, 'type',
                                   wg_enum_code_int('service_item.type', 'mixed-protocol-group'))
                        # Reuse 'server-port' field as service-ref name
                        # (jpa shows mixed patterns; safest is to set
                        # both name-style and port-style entries)
                        sp = m.find('server-port')
                        if sp is not None:
                            sp.text = wg_enum_code('shared_pair.shared-port', 'no')
                    si.append(m)
        list_elem.append(clone)
        existing.add(name)
        n_added += 1
    if n_skipped:
        print(f'         (skipped {n_skipped} duplicates — jpa wins)')
    return n_added


# ----------------------------------------------------------------------------
# Filler registry — which records feed which lists
# ----------------------------------------------------------------------------

FILLERS = [
    # (list_tag, records_filename, filler_function)
    ('service-list',       'service_objects.json', fill_services),
    ('alias-list',         'implicit_address_objects.json', fill_aliases),
    # User-defined SW address-objects (from parser output, not enricher).
    # Run BEFORE fill_address_groups so any group referencing these names
    # finds the matching alias already present.
    ('address-group-list', 'address_objects.json', fill_user_address_objects),
    ('address-group-list', 'address_groups.json',  fill_address_groups),
    ('schedule-list',      'schedules.json',       fill_schedules),
    ('interface-list',     'interfaces.json',      fill_interfaces),
    ('policy-list',        'access_rules.json',    fill_policies),
    # service-groups: SW service-groups become WG services with grouped members
    ('service-list',       'service_groups.json',  fill_service_groups),
]

# Cross-list fillers — take the whole root, not a single list element.
# These need coordinated writes into multiple lists.

def fill_abs_policies(root, templates, records, ctx):
    """For every customer policy in policy-list that lacks a matching
    abs-policy entry, emit one. WG Web UI Firewall Policies panel
    reads abs-policy entries; without them, policies don't render.

    Each abs-policy contains a <policy-list><policy>NAME</policy>
    </policy-list> back-reference to the policy that uses it.
    """
    apl = root.find('abs-policy-list')
    pl = root.find('policy-list')
    if apl is None or pl is None:
        return 0

    abs_existing = _existing_names(apl)

    # Get the abs-policy template — borrow from jpa (use the richest
    # variant). All jpa abs-policy entries are factory; we clone one
    # and patch leaves.
    apl_templates = templates.get('abs-policy-list') or {}
    apl_variants = apl_templates.get('shape_variants') or []
    if not apl_variants:
        return 0
    # Pick richest variant by TOTAL descendant count, not top-level
    # shape length. Verified against working Apple Bonjour export:
    # WG renders policies whose abs-policy <settings> has the full
    # 12.5.9 set (forward-traffic-mgmt, reverse-traffic-mgmt,
    # log-for-report, notification-type, launch-interval, repeat-count,
    # quota-enabled, compliance-check, non-compliant-drop, geo-action).
    # Some variants have more TOP-LEVEL fields but a SHALLOWER settings
    # subtree — those don't render. Total-descendant scoring picks the
    # FTP-proxy / WatchGuard Web UI shape which has the deep settings.
    def _total_descendants(variant):
        try:
            clone = ET.fromstring(variant['template_xml'])
            return sum(1 for _ in clone.iter())
        except ET.ParseError:
            return 0

    apl_template = None
    for v in sorted(apl_variants, key=lambda x: -_total_descendants(x)):
        try:
            apl_template = ET.fromstring(v['template_xml'])
            break
        except ET.ParseError:
            continue
    if apl_template is None:
        return 0

    # Mapping numeric firewall -> abs-policy firewall string
    fw_to_str = {'1': 'Allow', '2': 'Block', '4': 'Proxy'}
    n = 0
    for p in pl.findall('policy'):
        n_elem = p.find('name')
        if n_elem is None or not n_elem.text:
            continue
        pol_name = n_elem.text
        # WG convention (verified against working Apple Bonjour-00):
        # policy-list/policy name ends with the policy_list_entry suffix
        # (currently '-00'); matching abs-policy uses the BARE name (no
        # suffix); back-ref points to the policy_list_entry name.
        # This applies to BOTH factory ('Outgoing-00' -> 'Outgoing')
        # AND customer policies emitted by this filler.
        # Suffix declared in marker_mapping.ini [suffix_conventions].
        _pol_suffix = wg_suffix("policy_list_entry")
        if pol_name.endswith(_pol_suffix):
            abs_name = pol_name[:-len(_pol_suffix)]
        else:
            abs_name = pol_name
        if abs_name in abs_existing:
            continue
        # Build abs-policy by cloning the template
        clone = copy.deepcopy(apl_template)
        _set_leaf(clone, 'name', abs_name)
        _set_leaf(clone, 'description', '')
        # service: copy from policy
        svc = p.find('service')
        if svc is not None and svc.text:
            _set_leaf(clone, 'service', svc.text)
        # firewall: numeric in policy, string in abs-policy
        fw = p.find('firewall')
        if fw is not None and fw.text:
            _set_leaf(clone, 'firewall',
                       fw_to_str.get(fw.text, 'Allow'))
        # proxy: copy from policy. For Proxy policies (firewall=4), the
        # <proxy>NAME</proxy> ref must appear in the abs-policy's
        # <settings>/<proxy> field per jpa convention. For Packet
        # Filter policies (firewall=1/2), leave <proxy /> empty.
        policy_proxy = p.find('proxy')
        proxy_name = (policy_proxy.text if policy_proxy is not None
                       and policy_proxy.text else None)
        if proxy_name:
            # settings/proxy is where the abs-policy carries the proxy
            # action ref
            settings = clone.find('settings')
            if settings is not None:
                _set_leaf(settings, 'proxy', proxy_name)
        # from-alias-list / to-alias-list: copy from policy
        for tag in ('from-alias-list', 'to-alias-list'):
            src = p.find(tag)
            dst = clone.find(tag)
            if src is not None and dst is not None:
                for c in list(dst):
                    dst.remove(c)
                for sc in src:
                    alias_clone = copy.deepcopy(sc)
                    dst.append(alias_clone)
        # policy-list back-ref: the abs-policy says "I'm used by THIS
        # policy". The Web UI uses this to render.
        pl_ref = clone.find('policy-list')
        if pl_ref is not None:
            for c in list(pl_ref):
                pl_ref.remove(c)
            ET.SubElement(pl_ref, 'policy').text = pol_name
        apl.append(clone)
        abs_existing.add(abs_name)
        n += 1
    return n


def fill_abs_ipsec_actions(root, templates, records, ctx):
    """For each customer VPN site-to-site, emit a matching abs-ipsec-action.
    The WG Web UI Branch Office VPN > Tunnels panel reads from
    abs-ipsec-action-list. Without an entry there, the tunnel doesn't
    render in the Web UI even though it exists in ipsec-action-list.

    jpa convention (verified against bovpntunnel.1):
       <abs-ipsec-action>
         <name>{tunnel-name}</name>
         <ike-policy>{ike-policy-name}</ike-policy>
         <ipsec-action>{ipsec-action-name}</ipsec-action>
         <local-remote-pair-list>...</local-remote-pair-list>
       </abs-ipsec-action>
    """
    if not records:
        return 0
    apl = root.find('abs-ipsec-action-list')
    if apl is None:
        return 0
    ipsec_list = root.find('ipsec-action-list')
    if ipsec_list is None:
        return 0

    # Template: borrow from jpa via templates.json
    apl_templates = templates.get('abs-ipsec-action-list') or {}
    apl_variants = apl_templates.get('shape_variants') or []
    apl_template = None
    for v in apl_variants:
        try:
            apl_template = ET.fromstring(v['template_xml'])
            break
        except ET.ParseError:
            continue
    if apl_template is None:
        return 0

    abs_existing = _existing_names(apl)
    n = 0
    for r in records:
        name = r.get('name') or r.get('_id')
        if not name:
            continue
        vpn_type = r.get('vpn_type') or ''
        if 'site' not in vpn_type.lower():
            continue  # only site-to-site
        if name in abs_existing:
            continue
        # Find the matching ipsec-action in ipsec-action-list to copy
        # its local-remote-pair-list shape
        ipsec_match = None
        for ia in ipsec_list.findall('ipsec-action'):
            n_elem = ia.find('name')
            if n_elem is not None and n_elem.text == name:
                ipsec_match = ia
                break
        if ipsec_match is None:
            continue
        # Clone template
        clone = copy.deepcopy(apl_template)
        _set_leaf(clone, 'name', name)
        _set_leaf(clone, 'description', '')
        # ike-policy: read from ipsec-action's ike-policy-group's member
        # (the ike-policy-group contains a member pointing at the ike-policy)
        ike_policy_name = None
        ipg_ref = ipsec_match.find('ike-policy-group')
        if ipg_ref is not None and ipg_ref.text:
            # Lookup the ike-policy-group's member
            ipg_list = root.find('ike-policy-group-list')
            if ipg_list is not None:
                for ipg in ipg_list.findall('ike-policy-group'):
                    n_el = ipg.find('name')
                    if n_el is not None and n_el.text == ipg_ref.text:
                        m = ipg.find('member-list/member/ike-policy')
                        if m is not None:
                            ike_policy_name = m.text
                        break
        if ike_policy_name:
            _set_leaf(clone, 'ike-policy', ike_policy_name)
        _set_leaf(clone, 'ipsec-action', name)
        # CRITICAL: blank the inherited local-remote-pair-list from the
        # jpa template (which carries 10.10.10.10/20.20.20.20). The
        # abs-ipsec-action uses a different inner shape than the
        # ipsec-action's lrpl (it uses <type>Host IP</type><value>IP
        # </value> children instead of address-group refs).
        # We rebuild it from the customer's record.
        lrpl = clone.find('local-remote-pair-list')
        if lrpl is not None:
            for c in list(lrpl):
                lrpl.remove(c)
            # Derive local subnet + remote IP from the customer record.
            # The abs-ipsec-action local-remote-pair format uses
            # <type>Host IP|Network IP</type><value>IP</value>.
            # jpa observed examples all use 'Host IP' with a single IP
            # literal — no CIDR allowed in <value>. For a Network IP,
            # the WG schema expects the format 'IP/MASK' but jpa
            # provides no example. Safest: use Host IP with the
            # customer's Trusted-side IP literal.
            local_ip = '192.168.1.0'
            local_type = 'Network IP'
            remote_ip = None
            # Network spec patterns ('local network', 'local host',
            # 'remote host') declared in sw_field_extractors.ini.
            for tok in (r.get('network') or []):
                if not isinstance(tok, str):
                    continue
                # local network IP MASK
                captured = sw_after_prefix(tok, 'vpn_local_network')
                if captured is not None:
                    parts = captured.split()
                    if len(parts) >= 1:
                        local_ip = parts[0]
                        local_type = 'Network IP'
                    continue
                # local host IP
                captured = sw_after_prefix(tok, 'vpn_local_host')
                if captured is not None:
                    parts = captured.split()
                    if len(parts) >= 1:
                        local_ip = parts[-1]
                        local_type = 'Host IP'
                    continue
                # remote host IP
                captured = sw_after_prefix(tok, 'vpn_remote_host')
                if captured is not None:
                    parts = captured.split()
                    if len(parts) >= 1:
                        remote_ip = parts[-1]
                    continue
            # Fall back to ike-id peer IP for remote
            if not remote_ip:
                am = r.get('auth-method', {}) or {}
                for tok in (am.get('ike-id') or []):
                    if isinstance(tok, str) and 'peer ipv4' in tok:
                        remote_ip = tok.split()[-1]
                        break
            pair = ET.SubElement(lrpl, 'local-remote-pair')
            la = ET.SubElement(pair, 'local-addr')
            ET.SubElement(la, 'type').text = local_type
            ET.SubElement(la, 'value').text = local_ip
            ET.SubElement(pair, 'direction').text = 'bi-directional'
            ra = ET.SubElement(pair, 'remote-addr')
            ET.SubElement(ra, 'type').text = 'Host IP'
            ET.SubElement(ra, 'value').text = remote_ip or '0.0.0.0'
            # WG schema REQUIRES the NAT-related children. Verified
            # against jpa: every local-remote-pair has these four in
            # this order. Lab T-30 12.5.9 rejection without them:
            #   "Element 'local-remote-pair': Missing child element(s).
            #    Expected is one of (one-to-one-nat-enabled,
            #    one-to-one-nat-addr, dnat-enabled, dnat-src-ip,
            #    dnat-src-ip6, nat-action, enable-broadcast)."
            ET.SubElement(pair, 'one-to-one-nat-enabled').text = 'false'
            ET.SubElement(pair, 'dnat-enabled').text = 'false'
            ET.SubElement(pair, 'dnat-src-ip').text = '0.0.0.0'
            ET.SubElement(pair, 'nat-action')
        apl.append(clone)
        abs_existing.add(name)
        n += 1
    return n


CROSS_LIST_FILLERS = [
    ('vpn_policies.json',  fill_vpn_policies),
    # MUST run AFTER policy-list and ipsec-action-list are filled,
    # since these read from those lists.
    ('access_rules.json',  fill_abs_policies),
    ('vpn_policies.json',  fill_abs_ipsec_actions),
    # NAT family — emits abs-policy + policy-list entry + from/to
    # wrapper aliases as a coordinated 4-shape family.
    # Note: NAT input comes from sonicwall_parser/output, not enricher
    # output. The filler resolves the path internally.
    ('nat_policies.json',  None),  # placeholder; fill_nat_policies wired below
]


def fill_nat_policies(root, templates, records, ctx):
    """Customer SonicWall nat-policy entries → WG 4-shape policy family.

    Each SW nat-policy becomes:
       1. abs-policy entry (abstract definition)
       2. policy-list entry with '-00' suffix (the operative policy)
       3. alias '.1.from' (from-zone wrapper)
       4. alias '.1.to' (to-zone wrapper)

    Plus proxy/service translation via proxy_mapping.ini:
       SW service name "H323 Call Signaling" → proxy_action H.323-Client
                                              + service H323-ALG

    Provenance: Decoded from golden_pair WG reference's H323-ALGforClaude
    family showing all four entries with cross-references. Service+proxy
    mapping verified against proxy_mapping.ini (extended this sprint to
    include the full SW service names).
    """
    if not records:
        return 0
    apl = root.find('abs-policy-list')
    pl = root.find('policy-list')
    alias_list = root.find('alias-list')
    if apl is None or pl is None or alias_list is None:
        return 0

    abs_existing = _existing_names(apl)
    pol_existing = _existing_names(pl)
    alias_existing = _existing_names(alias_list)

    proxy_map, service_aliases, _ = _load_proxy_mapping()

    # Use an existing policy-list factory entry as our cloning template
    # (it has the right top-level shape: <name>, <from-alias-list>,
    # <to-alias-list>, <service>, <firewall>, etc.).
    # Pick the first proxy policy in jpa as template — verified via
    # 'FTP-proxy-00' or similar in templates.
    pl_templates = templates.get('policy-list') or {}
    pl_variants = pl_templates.get('shape_variants') or []
    policy_template = None
    for v in pl_variants:
        try:
            cand = ET.fromstring(v.get('template_xml', ''))
            # Pick a template with proxy/firewall=4 shape (richer)
            fw = cand.find('firewall')
            if fw is not None and (fw.text or '').strip() == '4':
                policy_template = cand
                break
        except ET.ParseError:
            continue
    if policy_template is None and pl_variants:
        # Fallback: first available
        try:
            policy_template = ET.fromstring(pl_variants[0].get('template_xml', ''))
        except ET.ParseError:
            policy_template = None
    if policy_template is None:
        return 0

    # Same for abs-policy template
    apl_templates = templates.get('abs-policy-list') or {}
    apl_variants = apl_templates.get('shape_variants') or []
    abs_template = None
    for v in apl_variants:
        try:
            cand = ET.fromstring(v.get('template_xml', ''))
            fw = cand.find('firewall')
            # abs-policy uses STRING form for firewall (Proxy vs Packet-Filter)
            if fw is not None and (fw.text or '').strip().lower() == 'proxy':
                abs_template = cand
                break
        except ET.ParseError:
            continue
    if abs_template is None and apl_variants:
        try:
            abs_template = ET.fromstring(apl_variants[0].get('template_xml', ''))
        except ET.ParseError:
            abs_template = None
    if abs_template is None:
        return 0

    alias_map = zone_mapper.all_zone_aliases()

    def _parse_zone(spec):
        """Extract a zone token from SW 'group "WAN Subnets"' or 'any'."""
        if not spec:
            return 'any'
        s = str(spec).strip().lower()
        if s.startswith('group '):
            # 'group "WAN Subnets"' → 'wan' from quoted name first word
            inside = s[6:].strip().strip('"')
            return inside.split()[0] if inside else 'any'
        return s.split()[0] if s else 'any'

    def _parse_service(spec):
        """Extract a service name from SW 'name "H323 Call Signaling"' or 'any'."""
        if not spec:
            return 'any'
        s = str(spec).strip()
        if s.lower().startswith('name '):
            return s[5:].strip().strip('"')
        return s.strip().strip('"')

    n_added = 0
    for r in records:
        name = r.get('name') or r.get('_id')
        if not name or name is False:
            continue
        if name in abs_existing or f'{name}-00' in pol_existing:
            continue

        # Resolve zones for from/to aliases
        from_zone = _parse_zone(r.get('source'))
        to_zone = _parse_zone(r.get('destination'))
        from_alias = alias_map.get(from_zone, 'Any')
        to_alias = alias_map.get(to_zone, 'Any')

        # Resolve service / proxy via proxy_mapping.ini
        sw_service = _parse_service(r.get('service'))
        # service_aliases maps SW service name → WG service-list name
        wg_service = service_aliases.get(sw_service, sw_service)
        # proxy_map maps WG service name → proxy_action
        wg_proxy = proxy_map.get(wg_service, '')

        # Create the four shapes
        # --- 1. from-zone wrapper alias ---
        from_wrapper = f'{name}{wg_suffix("policy_from_zone_wrapper")}'
        if from_wrapper not in alias_existing:
            wa = ET.SubElement(alias_list, 'alias')
            ET.SubElement(wa, 'name').text = from_wrapper
            ET.SubElement(wa, 'property').text = wg_enum_code('alias.property', 'builtin')
            aml = ET.SubElement(wa, 'alias-member-list')
            am = ET.SubElement(aml, 'alias-member')
            ET.SubElement(am, 'type').text = wg_enum_code('alias_member.type', 'alias-reference')
            ET.SubElement(am, 'alias-name').text = from_alias
            alias_existing.add(from_wrapper)

        # --- 2. to-zone wrapper alias ---
        to_wrapper = f'{name}{wg_suffix("policy_to_zone_wrapper")}'
        if to_wrapper not in alias_existing:
            wa = ET.SubElement(alias_list, 'alias')
            ET.SubElement(wa, 'name').text = to_wrapper
            ET.SubElement(wa, 'property').text = wg_enum_code('alias.property', 'builtin')
            aml = ET.SubElement(wa, 'alias-member-list')
            am = ET.SubElement(aml, 'alias-member')
            ET.SubElement(am, 'type').text = wg_enum_code('alias_member.type', 'alias-reference')
            ET.SubElement(am, 'alias-name').text = to_alias
            alias_existing.add(to_wrapper)

        # --- 3. policy-list entry (with -00 suffix) ---
        pol_name = f'{name}{wg_suffix("policy_list_entry")}'
        if pol_name not in pol_existing:
            pclone = copy.deepcopy(policy_template)
            _set_leaf(pclone, 'name', pol_name)
            _set_leaf(pclone, 'description', f'From SonicWall NAT {name}')
            # Replace from/to alias references
            fal = pclone.find('from-alias-list')
            if fal is not None:
                for c in list(fal):
                    fal.remove(c)
                ET.SubElement(fal, 'alias').text = from_wrapper
            tal = pclone.find('to-alias-list')
            if tal is not None:
                for c in list(tal):
                    tal.remove(c)
                ET.SubElement(tal, 'alias').text = to_wrapper
            # Set service + proxy + firewall code
            svc = pclone.find('service')
            if svc is not None and wg_service:
                svc.text = wg_service
            # policy-list uses NUMERIC firewall code (proxy=4)
            fw = pclone.find('firewall')
            if fw is not None:
                fw.text = wg_enum_code('policy.firewall', 'proxy')
            ra = pclone.find('reject-action')
            if ra is not None:
                ra.text = wg_enum_code('policy.reject-action', 'tcp-rst')
            prx = pclone.find('proxy')
            if prx is not None and wg_proxy:
                prx.text = wg_proxy
            pl.append(pclone)
            pol_existing.add(pol_name)

        # --- 4. abs-policy entry (bare name, no suffix) ---
        if name not in abs_existing:
            aclone = copy.deepcopy(abs_template)
            _set_leaf(aclone, 'name', name)
            _set_leaf(aclone, 'description', f'From SonicWall NAT {name}')
            # abs-policy uses STRING form for firewall and reject-action
            fw = aclone.find('firewall')
            if fw is not None:
                fw.text = 'Proxy'
            ra = aclone.find('reject-action')
            if ra is not None:
                ra.text = 'TCP_RST'
            svc = aclone.find('service')
            if svc is not None and wg_service:
                svc.text = wg_service
            prx = aclone.find('proxy')
            if prx is not None and wg_proxy:
                prx.text = wg_proxy
            # Repoint from/to aliases on abs-policy too
            fal = aclone.find('from-alias-list')
            if fal is not None:
                for c in list(fal):
                    fal.remove(c)
                ET.SubElement(fal, 'alias').text = from_wrapper
            tal = aclone.find('to-alias-list')
            if tal is not None:
                for c in list(tal):
                    tal.remove(c)
                ET.SubElement(tal, 'alias').text = to_wrapper
            # Back-reference policy-list entry
            apl_inner = aclone.find('policy-list')
            if apl_inner is not None:
                for c in list(apl_inner):
                    apl_inner.remove(c)
                ET.SubElement(apl_inner, 'policy').text = pol_name
            apl.append(aclone)
            abs_existing.add(name)

        n_added += 1
    return n_added


def fill_vlan_interfaces(root, templates, records, ctx):
    """Customer SonicWall VLAN sub-interfaces → WG VLAN-logical interface.

    Each SonicWall `interface <PARENT> vlan <ID>` block becomes a WG
    `<interface>` entry with item-type=2 (vlan-if) and a member-list
    pointing back at the parent's physical interface (its <if-num>).

    Provenance:
       - golden_pair/sw_input.txt line 2096: `interface X2 vlan 77`
                                 line 2098: `ip 192.168.77.1`
                                 line 2103: `comment vlan77forclaude`
       - golden_pair/wg_reference.xml line 18178-18215: full <interface>
         shape for vlanconfig77forClaude (vlan-id=77, if-num=77,
         if-dev-name=vlan77, vif-property=8, intra-vlan-inspection=1,
         member-list points to if-num=2, ip=192.168.77.1).
       - Lab v1.8.2 push: VLAN-host slot rendered correctly in Web UI;
         Captain confirmed: "the only thing you need to do is wire
         vlan 77 to the vlan interface".

    Naming convention (matches golden ref, INI-tunable in future):
       WG <name>        = vlanconfig<VLAN_ID><SUFFIX>
       WG <description> = SW `comment` carries through verbatim
                          (e.g. 'vlan77forclaude')
       WG <if-num>      = the VLAN ID itself (matches SW conv 1:1)
       WG <if-dev-name> = vlan<VLAN_ID>
       WG <vif-property>=8 (standard VLAN-host child property)
       WG member parent <if-num>  = resolved from parent name via zone map
       WG member <if-dev-name>    = eth<N> matching parent
    """
    if not records:
        return 0
    if_list = root.find('interface-list')
    if if_list is None:
        return 0

    # Build a lookup from physical interface NAME -> (if-num, if-dev-name)
    # so we can resolve the parent token (e.g. 'X2' or 'Optional-1') to
    # the WG hardware port number that the VLAN's member must point at.
    name_to_phys = {}
    for intf in if_list.findall('interface'):
        n_el = intf.find('name')
        if n_el is None or not n_el.text:
            continue
        phys = intf.find('.//physical-if')
        if phys is None:
            continue
        ifn_el = phys.find('if-num')
        ifd_el = phys.find('if-dev-name')
        if ifn_el is not None and ifd_el is not None:
            name_to_phys[n_el.text] = (ifn_el.text or '', ifd_el.text or '')

    existing = _existing_names(if_list)
    n_added = 0
    suffix = wg_suffix('vlan_interface_name')  # e.g. 'forClaude' or ''

    for r in records:
        if not isinstance(r, dict):
            continue
        vlan_id = r.get('vlan_id')
        parent_sw = r.get('parent') or r.get('_id')
        if vlan_id is None or not parent_sw:
            continue

        # Resolve SW parent token (X2) to WG physical interface name.
        # SonicWall zone token is needed to pick the right WG slot.
        # The VLAN's parent SW interface (X2) was mapped to a WG name
        # during fill_interfaces — we need to find that same name now.
        # The VLAN's own SW record has 'ip-assignment {_args: "LAN static"}'
        # so we can recover the zone the same way fill_interfaces does.
        ipa = r.get('ip-assignment') or {}
        zone_token = ''
        if isinstance(ipa, dict):
            zone_args = (ipa.get('_args') or '').split()
            if zone_args:
                zone_token = zone_args[0].lower()

        # Find the parent's WG name. Two-step resolution:
        # 1. Walk zone candidates and pick the slot WG already populated
        #    matching this SW parent (X2 → first available LAN-zone slot
        #    that fill_interfaces *didn't* use — Optional-1 by convention)
        # 2. As a fallback, use the dedicated VLAN-host slot from
        #    interface_defaults.ini (Optional-1)
        parent_wg_name = None
        defaults = _load_interface_defaults()
        vlan_slots = defaults.get('vlan_host_slots') or set()
        # Prefer a slot declared as VLAN host in interface_defaults.ini
        for slot in vlan_slots:
            if slot in name_to_phys:
                parent_wg_name = slot
                break
        # Fallback: pick by zone candidates if VLAN-host slot isn't set
        if parent_wg_name is None and zone_token:
            for c in zone_mapper.get_interface_candidates(zone_token):
                if c in name_to_phys:
                    parent_wg_name = c
                    break
        if parent_wg_name is None:
            print(f'  [warn] VLAN {vlan_id}: no WG parent slot found for '
                  f'SW interface {parent_sw!r}; skipping',
                  file=sys.stderr)
            continue

        parent_ifnum, parent_ifdev = name_to_phys[parent_wg_name]

        # Derive WG interface name. Use SW comment as the descriptor
        # source (full provenance carry-through) and build the WG name
        # from the VLAN id + a fixed suffix convention.
        sw_comment = r.get('comment') or ''
        wg_name = f'vlanconfig{vlan_id}{suffix}'
        if wg_name in existing:
            continue  # already emitted (idempotent)

        # IP / netmask from SW ip-assignment block
        ip_val = ipa.get('ip') if isinstance(ipa, dict) else None
        nm_val = ipa.get('netmask') if isinstance(ipa, dict) else None

        # Build the WG <interface> element with byte-perfect golden-ref shape
        new_intf = ET.SubElement(if_list, 'interface')
        ET.SubElement(new_intf, 'name').text = wg_name
        # description: SW comment carries verbatim (full provenance).
        # If SW didn't supply a comment, fall back to derived label.
        ET.SubElement(new_intf, 'description').text = (
            sw_comment or f'descr{wg_name}'
        )
        ET.SubElement(new_intf, 'property').text = '0'
        ET.SubElement(new_intf, 'dns-forwarding').text = '1'
        ET.SubElement(new_intf, 'dnswatch').text = '2'
        ET.SubElement(new_intf, 'netflow').text = '0'
        mc = ET.SubElement(new_intf, 'multicast-if')
        ET.SubElement(mc, 'enabled').text = '0'
        ET.SubElement(mc, 'rp-candidate').text = '0'

        iil = ET.SubElement(new_intf, 'if-item-list')
        item = ET.SubElement(iil, 'item')
        ET.SubElement(item, 'item-type').text = wg_enum_code(
            'interface_item.item-type', 'vlan-if'
        )
        vlif = ET.SubElement(item, 'vlan-if')
        ET.SubElement(vlif, 'vlan-id').text = str(vlan_id)
        ET.SubElement(vlif, 'if-num').text = str(vlan_id)
        ET.SubElement(vlif, 'if-dev-name').text = f'vlan{vlan_id}'
        ET.SubElement(vlif, 'vif-property').text = '8'
        ET.SubElement(vlif, 'intra-vlan-inspection').text = '1'

        # member-list points at parent physical (if-num + if-dev-name)
        ml = ET.SubElement(vlif, 'member-list')
        mem = ET.SubElement(ml, 'member')
        ET.SubElement(mem, 'if-num').text = str(parent_ifnum)
        ET.SubElement(mem, 'if-dev-name').text = parent_ifdev
        ET.SubElement(mem, 'pvid-enabled').text = '0'

        ET.SubElement(vlif, 'ip').text = ip_val or '0.0.0.0'
        ET.SubElement(vlif, 'netmask').text = nm_val or '255.255.255.0'
        dhcp = ET.SubElement(vlif, 'dhcp-server')
        ET.SubElement(dhcp, 'server-type').text = '0'
        ET.SubElement(vlif, 'secondary-ip-list')
        ET.SubElement(vlif, 'ip-node-type').text = 'IP4_ONLY'

        existing.add(wg_name)
        n_added += 1
        print(f'  [emit] VLAN {vlan_id} (SW parent {parent_sw}) → '
              f'WG <interface>{wg_name}</interface> on '
              f'{parent_wg_name} (if-num={parent_ifnum})',
              file=sys.stderr)
    return n_added


# Register NAT filler in CROSS_LIST_FILLERS (replacing placeholder)
CROSS_LIST_FILLERS = [
    item if item[0] != 'nat_policies.json' else
    ('nat_policies.json', fill_nat_policies)
    for item in CROSS_LIST_FILLERS
]

# Add VLAN filler as another cross-list entry. Reads from parser output
# (interfaces_vlan.json — not in enricher output). Cross-list fallback
# is wired to look in sonicwall_parser/output/ when not in customer_dir.
CROSS_LIST_FILLERS.append(
    ('interfaces_vlan.json', fill_vlan_interfaces)
)


def fill(skeleton_path: Path, templates_path: Path,
         customer_dir: Path, output_path: Path) -> int:
    if not skeleton_path.is_file():
        print(f'ERROR: skeleton not found: {skeleton_path}', file=sys.stderr)
        return 2
    if not templates_path.is_file():
        print(f'ERROR: templates not found: {templates_path}', file=sys.stderr)
        return 2

    tree = ET.parse(skeleton_path)
    root = tree.getroot()
    templates = json.loads(templates_path.read_text(encoding='utf-8'))

    print(f'skeleton_filler:')
    print(f'  skeleton:   {skeleton_path}')
    print(f'  templates:  {templates_path}')
    print(f'  customer:   {customer_dir}')

    ctx = {'_root': root, '_customer_dir': customer_dir}

    # Pre-load SonicWall address-objects into ctx so transitive
    # references (address-group referencing an address-object name
    # which holds the actual IP) can be resolved during fill.
    #
    # Decoded from golden_pair: SW `address-group adrgrpforClaude`
    # references `address-object someremotepeerfakeadrobj4Claude` which
    # is `host 14.14.14.14`. The toolkit must resolve the NAME to the
    # IP at fill time so the WG `.1.alm` companion holds the actual
    # IP, not a dangling name reference.
    #
    # Search order:
    #   1. Enricher output: implicit_address_objects.json
    #      (system-generated subnet/IP objects for interfaces)
    #   2. Parser output: ../sonicwall_parser/output/address_objects.json
    #      (user-defined address-objects from `address-object ipv4 NAME`)
    # Both are merged into a single lookup dict, with user entries
    # winning on name collision.
    ao_lookup: dict[str, dict] = {}
    candidate_ao_paths = [
        customer_dir / 'implicit_address_objects.json',
        customer_dir.parent.parent / 'sonicwall_parser' / 'output' / 'address_objects.json',
    ]
    for ao_path in candidate_ao_paths:
        if not ao_path.is_file():
            continue
        try:
            ao_data = json.loads(ao_path.read_text(encoding='utf-8'))
            ao_records = ao_data.get('entries', ao_data) \
                if isinstance(ao_data, dict) else ao_data
            if isinstance(ao_records, list):
                for r in ao_records:
                    if isinstance(r, dict):
                        name = r.get('name') or r.get('_id')
                        if name:
                            ao_lookup[name] = r
        except json.JSONDecodeError:
            continue
    if ao_lookup:
        ctx['_addr_object_lookup'] = ao_lookup
        print(f'  [ctx] address-object lookup: {len(ao_lookup)} entries')

    total_added = 0
    for list_tag, records_file, filler in FILLERS:
        list_elem = root.find(list_tag)
        if list_elem is None:
            continue
        records_path = customer_dir / records_file
        # Fallback to parser output if file not in enricher output.
        # User SW address-objects live in sonicwall_parser/output and
        # don't get re-emitted by the enricher.
        if not records_path.is_file():
            parser_alt = customer_dir.parent.parent / 'sonicwall_parser' / 'output' / records_file
            if parser_alt.is_file():
                records_path = parser_alt
        if not records_path.is_file():
            print(f'  [skip] {list_tag}: no {records_file}')
            continue
        try:
            records_data = json.loads(records_path.read_text(encoding='utf-8'))
        except json.JSONDecodeError as e:
            print(f'  [warn] {list_tag}: failed to parse {records_file}: {e}')
            continue
        records = records_data.get('entries', records_data) \
                  if isinstance(records_data, dict) else records_data
        if not isinstance(records, list):
            records = []
        added = filler(list_elem, templates, records, ctx)
        total_added += added
        print(f'  [fill] {list_tag}: {added} entries')

    # Cross-list fillers — operate on root, coordinated writes across lists
    for records_file, filler in CROSS_LIST_FILLERS:
        records_path = customer_dir / records_file
        # Fallback: some records (NAT) come from parser output, not enricher.
        # If file isn't in customer_dir, look in ../sonicwall_parser/output/.
        if not records_path.is_file():
            parser_alt = customer_dir.parent.parent / 'sonicwall_parser' / 'output' / records_file
            if parser_alt.is_file():
                records_path = parser_alt
            else:
                continue
        try:
            records_data = json.loads(records_path.read_text(encoding='utf-8'))
        except json.JSONDecodeError:
            continue
        records = records_data.get('entries', records_data) \
                  if isinstance(records_data, dict) else records_data
        if not isinstance(records, list):
            records = []
        added = filler(root, templates, records, ctx)
        total_added += added
        print(f'  [fill] (cross-list) {records_file}: {added} entries')

    # Post-fill normalization pass: walk every leaf, normalize against
    # the leaves-quality matrix from jpa.xml. Fixes the 'any' -> 'Any'
    # class of trap by case-resolving against the closed enum at that
    # exact XPath, then by applying dominant casing for open-form leaves.
    matrix_path = Path(__file__).parent / 'output' / 'leaves_quality.json'
    matrix = {}
    if matrix_path.is_file():
        try:
            matrix = json.loads(matrix_path.read_text(encoding='utf-8'))
        except json.JSONDecodeError:
            pass
    normalized = 0
    if matrix:
        try:
            from value_normalizer import normalize_in_place
        except ImportError:
            # Running as a module-level script — add parent dir to path
            import sys as _sys
            _sys.path.insert(0, str(Path(__file__).parent))
            from value_normalizer import normalize_in_place
        parent_map = {id(c): p for p in root.iter() for c in p}

        def xpath_of(elem):
            parts = [elem.tag]
            cur = elem
            while id(cur) in parent_map:
                cur = parent_map[id(cur)]
                parts.append(cur.tag)
            return '/' + '/'.join(reversed(parts))

        for elem in root.iter():
            if list(elem):
                continue
            xp = xpath_of(elem)
            if normalize_in_place(elem, xp, matrix):
                normalized += 1
        print(f'  [norm] {normalized} leaves normalized against quality matrix')

    # ----------------------------------------------------------------------
    # Alias-crud filter pass (v1.8.5+).
    #
    # Drops aliases whose names match patterns in alias_filter.ini.
    # Two reasons to drop:
    #   1. CRITICAL — names containing reserved characters (e.g. ':') that
    #      crash the WG Web UI Aliases panel. Lab-discovered TZ-300 cycle
    #      2026-06-13: 'X2:V88 IPv6 Addresses' logged the operator out.
    #   2. Noise — SonicWall auto-generated interface bookkeeping
    #      ('X0 Subnet', 'X1 IP', 'MGMT IP') and jpa-template factory
    #      carry-throughs ('All Authorized Access Points', etc.) that
    #      clutter the panel without operator value.
    #
    # When an alias is dropped, we ALSO drop any address-group whose name
    # is the same alias name + '.1.alm' (the alias's backing address-group
    # companion) so dangling references don't break ref_integrity.
    # ----------------------------------------------------------------------
    alias_filter_ini = Path(__file__).parent / 'alias_filter.ini'
    if alias_filter_ini.is_file():
        import configparser as _cp
        import re as _re_af
        afcp = _cp.ConfigParser()
        afcp.optionxform = str
        afcp.read(alias_filter_ini, encoding='utf-8')
        drop_patterns: list[tuple[str, "_re_af.Pattern"]] = []
        for sect in afcp.sections():
            if not sect.startswith('drop.'):
                continue
            pat_src = afcp.get(sect, 'pattern', fallback='').strip()
            if not pat_src:
                continue
            try:
                drop_patterns.append((sect, _re_af.compile(pat_src)))
            except _re_af.error as _e:
                print(f'  [alias-filter] WARN: bad pattern in '
                      f'[{sect}]: {_e}', file=sys.stderr)
        alias_list = root.find('alias-list')
        agroup_list = root.find('address-group-list')
        dropped = 0
        if alias_list is not None and drop_patterns:
            # Collect names to drop first; then remove children. Modifying
            # the tree while iterating is unsafe in ElementTree.
            to_drop_alias_names: set = set()
            for alias_el in list(alias_list.findall('alias')):
                n = alias_el.find('name')
                if n is None or not n.text:
                    continue
                for rule_name, rx in drop_patterns:
                    if rx.match(n.text):
                        to_drop_alias_names.add(n.text)
                        alias_list.remove(alias_el)
                        dropped += 1
                        break
            # Cascade — drop the .1.alm companion address-groups for any
            # dropped aliases (those exist only to back the alias).
            companion_dropped = 0
            if agroup_list is not None and to_drop_alias_names:
                for ag_el in list(agroup_list.findall('address-group')):
                    n = ag_el.find('name')
                    if n is None or not n.text:
                        continue
                    base = n.text
                    if base.endswith('.1.alm'):
                        base = base[:-len('.1.alm')]
                    if base in to_drop_alias_names:
                        agroup_list.remove(ag_el)
                        companion_dropped += 1
            print(f'  [alias-filter] dropped {dropped} aliases '
                  f'+ {companion_dropped} backing .1.alm groups '
                  f'against {len(drop_patterns)} rules')

    # Write in BINARY mode so newlines stay LF on every platform. The
    # default tree.write() opens the file in text mode and Python's
    # io layer translates \n -> \r\n on Windows, which changes the
    # bytes (and thus the SHA) without changing the content. This
    # breaks cross-platform reproducibility. Binary mode + utf-8
    # encoding produces identical bytes on Linux/Mac/Windows.
    with open(output_path, 'wb') as f:
        tree.write(f, encoding='utf-8', xml_declaration=True)
    print(f'  -> wrote {output_path}')
    print(f'  total entries added: {total_added}')
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).parent
    p.add_argument('--skeleton', type=Path,
                   default=here / 'output' / 'skeleton.xml')
    p.add_argument('--templates', type=Path,
                   default=here / 'output' / 'templates.json')
    p.add_argument('--customer-dir', type=Path,
                   default=here.parent / 'enricher' / 'output')
    p.add_argument('--output', type=Path,
                   default=here / 'output' / 'configuration.xml')
    args = p.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    return fill(args.skeleton, args.templates, args.customer_dir, args.output)


if __name__ == '__main__':
    sys.exit(main())
