#!/usr/bin/env python3
"""
zone_mapper.py — load SW → WG zone mapping from zone_mapping.ini.

API:
    get_interface_candidates(sw_zone) -> list[str]
        Ordered list of WG interface names that can host an SW zone.
        First unassigned wins.

    get_alias(sw_zone) -> str
        Zone alias for SW zone, for policy from-alias / to-alias.
        Falls back to [custom_zone_policy] fallback_alias on miss.

    custom_zone_policy() -> dict
        {'unknown_zone_action': str, 'fallback_alias': str}

PROVENANCE
   Mapping declared in zone_mapping.ini, not hardcoded here.
"""
from __future__ import annotations

import configparser
from pathlib import Path

_INI_PATH = Path(__file__).resolve().parent / 'zone_mapping.ini'
_CACHE: dict | None = None


def _load() -> dict:
    global _CACHE
    if _CACHE is not None:
        return _CACHE
    if not _INI_PATH.is_file():
        raise FileNotFoundError(
            f'zone_mapper: zone_mapping.ini not found at {_INI_PATH}'
        )
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp.read(_INI_PATH, encoding='utf-8')

    interface_candidates: dict[str, list[str]] = {}
    if cp.has_section('interface_candidates'):
        for k, v in cp.items('interface_candidates'):
            interface_candidates[k.lower()] = [
                x.strip() for x in v.split(',') if x.strip()
            ]

    zone_to_alias: dict[str, str] = {}
    if cp.has_section('zone_to_alias'):
        for k, v in cp.items('zone_to_alias'):
            zone_to_alias[k.lower()] = v.strip()

    policy = {
        'unknown_zone_action': 'fallback_any',
        'fallback_alias': 'Any',
    }
    if cp.has_section('custom_zone_policy'):
        for k, v in cp.items('custom_zone_policy'):
            policy[k] = v.strip()

    _CACHE = {
        'interface_candidates': interface_candidates,
        'zone_to_alias': zone_to_alias,
        'custom_zone_policy': policy,
    }
    return _CACHE


def get_interface_candidates(sw_zone: str) -> list[str]:
    """Return ordered list of WG interfaces this SW zone may map to.
    Returns empty list if zone is unknown (caller handles fallback)."""
    return list(_load()['interface_candidates'].get(
        (sw_zone or '').lower(), []
    ))


def get_alias(sw_zone: str) -> str:
    """Return WG zone-alias for the given SW zone. On miss, returns
    fallback_alias from custom_zone_policy ('Any' by default)."""
    cfg = _load()
    sw_key = (sw_zone or '').lower()
    if sw_key in cfg['zone_to_alias']:
        return cfg['zone_to_alias'][sw_key]
    return cfg['custom_zone_policy'].get('fallback_alias', 'Any')


def custom_zone_policy() -> dict:
    """Return the [custom_zone_policy] section as a dict."""
    return dict(_load()['custom_zone_policy'])


def all_interface_candidates() -> dict[str, list[str]]:
    """Full map (for diagnostics)."""
    return {k: list(v) for k, v in _load()['interface_candidates'].items()}


def all_zone_aliases() -> dict[str, str]:
    """Full map (for diagnostics)."""
    return dict(_load()['zone_to_alias'])
