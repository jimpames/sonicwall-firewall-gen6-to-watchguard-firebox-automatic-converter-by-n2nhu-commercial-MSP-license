#!/usr/bin/env python3
"""
golden_pair_validator.py — composite golden-pair fidelity score.

Runs BOTH sub-validators and computes a weighted composite:
   composite = value_weight * value_score + structural_weight * structural_score

This is the ONE NUMBER that summarizes overall toolkit fidelity against
the golden reference pair.

EXIT
   0 if composite >= composite_pass threshold
   1 if composite <  pass threshold
   2 on config error
"""
from __future__ import annotations

import argparse
import configparser
import json
import subprocess
import sys
import re
from pathlib import Path


def _load_cfg(path: Path) -> dict:
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp.read(path, encoding='utf-8')
    return {
        'value_weight': cp.getfloat('thresholds', 'value_weight',
                                     fallback=0.5),
        'structural_weight': cp.getfloat('thresholds', 'structural_weight',
                                          fallback=0.5),
        'composite_pass': cp.getfloat('thresholds', 'composite_pass',
                                       fallback=0.85),
        'composite_warning': cp.getfloat('thresholds', 'composite_warning',
                                          fallback=0.70),
    }


def _run_subvalidator(script: Path, emit_xml: Path,
                       extra_args: list[str] | None = None,
                       ) -> tuple[float, int, str]:
    """Run a sub-validator and parse its score. Returns
    (score, return_code, full_output)."""
    cmd = [sys.executable, str(script), str(emit_xml), '--quiet']
    if extra_args:
        cmd.extend(extra_args)
    result = subprocess.run(
        cmd, capture_output=True, text=True, encoding='utf-8'
    )
    output = result.stdout + result.stderr
    # Both sub-validators print "fidelity score: 0.NNNN"
    match = re.search(r'fidelity score:\s+([0-9.]+)', output)
    score = float(match.group(1)) if match else 0.0
    return score, result.returncode, output


# =============================================================================
# Golden-pair registry (per-(branch, model) lookup) — added FES v1.8.4
# =============================================================================

def _load_registry(registry_path: Path) -> dict:
    """Parse golden_pair_registry.ini into a dict-of-entries.

    Returns: {
        'default': {...entry...},
        'entries': [{...entry...}, ...]   # in declaration order for
                                          # first-match-wins matching
    }
    """
    cp = configparser.ConfigParser(interpolation=None)
    cp.read(registry_path, encoding='utf-8')
    default_entry = {}
    entries = []
    for sect in cp.sections():
        if sect == 'meta':
            continue
        if sect == 'default':
            default_entry = dict(cp.items(sect))
            continue
        if sect.startswith('golden.'):
            entry = dict(cp.items(sect))
            entry['_section_name'] = sect
            entries.append(entry)
    return {'default': default_entry, 'entries': entries}


def _read_sonicos_version(toolkit_root: Path) -> dict:
    """Read the parser manifest to recover (branch, model). Returns dict
    with keys 'branch', 'model', 'firmware'. Empty strings on absence so
    callers can match-or-fall-through cleanly."""
    manifest_path = toolkit_root / 'sonicwall_parser' / 'output' / '_manifest.json'
    if not manifest_path.is_file():
        return {'branch': '', 'model': '', 'firmware': ''}
    try:
        m = json.loads(manifest_path.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError):
        return {'branch': '', 'model': '', 'firmware': ''}
    v = m.get('sonicos_version', {}) if isinstance(m, dict) else {}
    return {
        'branch': str(v.get('sonicos_version_branch_used', '') or '').strip(),
        'model': str(v.get('sonicos_model_detected', '') or '').strip(),
        'firmware': str(v.get('sonicos_version_detected', '') or '').strip(),
    }


def _select_entry(registry: dict, branch: str, model: str
                  ) -> tuple[dict, str]:
    """First-match-wins lookup. Returns (selected_entry, match_kind).

    match_kind is one of:
      'exact'              — branch AND model both matched
      'branch_only'        — branch matched, model didn't (warning)
      'default_fallback'   — no entry matched; using default
    """
    # Try exact match first
    for entry in registry['entries']:
        eb = entry.get('matches_branch', '').strip()
        em = entry.get('matches_model', '').strip()
        if eb == branch and em == model:
            return entry, 'exact'
    # Try branch-only (different model on same SonicOS family)
    if branch:
        for entry in registry['entries']:
            if entry.get('matches_branch', '').strip() == branch:
                return entry, 'branch_only'
    # Fallback to default
    return registry['default'], 'default_fallback'


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve().parent
    toolkit_root = here.parent
    p.add_argument('emit_xml', type=Path,
                    help='Path to emitted configuration.xml')
    p.add_argument('--config', type=Path,
                    default=here / 'golden_pair_config.ini')
    p.add_argument('--registry', type=Path,
                    default=here / 'golden_pair_registry.ini',
                    help='Path to golden_pair_registry.ini (per-(branch,model) '
                         'golden references)')
    p.add_argument('--verbose', action='store_true',
                    help='Print full output from both sub-validators')
    args = p.parse_args()

    if not args.config.is_file():
        print(f'ERROR: config not found: {args.config}', file=sys.stderr)
        return 2
    cfg = _load_cfg(args.config)

    # =========================================================================
    # Registry-driven golden pair selection (FES v1.8.4+)
    # =========================================================================
    # Look up (branch, model) from the parser's manifest and select the
    # right golden reference pair. Falls back to the default entry when
    # no match found, with a stderr warning so operators know.
    selected_entry: dict = {}
    match_kind = 'default_fallback'
    version_info = {'branch': '', 'model': '', 'firmware': ''}
    sw_input_override: Path | None = None
    wg_ref_override: Path | None = None
    skip_structural = False
    skip_reason = ''

    if args.registry.is_file():
        try:
            registry = _load_registry(args.registry)
            version_info = _read_sonicos_version(toolkit_root)
            selected_entry, match_kind = _select_entry(
                registry, version_info['branch'], version_info['model']
            )
            # Resolve paths (entries store paths relative to toolkit root)
            sw_ref_rel = selected_entry.get('sw_reference', '').strip()
            wg_ref_rel = selected_entry.get('wg_reference', '').strip()
            if sw_ref_rel:
                sw_input_override = toolkit_root / sw_ref_rel
            if wg_ref_rel:
                wg_ref_override = toolkit_root / wg_ref_rel

            # Honor pending status — WG reference not yet hand-built
            wg_status = selected_entry.get('wg_reference_status', '').strip()
            if wg_status == 'pending_hand_build':
                skip_structural = True
                skip_reason = ('wg_reference_status=pending_hand_build '
                               'for this (model, version) pair')
            elif wg_ref_override and not wg_ref_override.is_file():
                skip_structural = True
                skip_reason = (f'wg_reference file missing: '
                               f'{wg_ref_override}')
        except (configparser.Error, OSError) as e:
            print(f'  WARN: registry load failed ({e}); '
                  f'using golden_pair_config.ini paths as-is.',
                  file=sys.stderr)

    value_script = here / 'golden_pair_value_validator.py'
    struct_script = here / 'golden_pair_structural_validator.py'

    print('=' * 72)
    print(' golden_pair_validator — composite fidelity score')
    print('=' * 72)

    # Surface the selected golden in the validator output so operators see
    # which (model, version) pair is being used for comparison.
    if selected_entry:
        sect_name = selected_entry.get('_section_name', '(default)')
        lab_status = selected_entry.get('lab_status', 'unknown')
        print(f'  Golden reference:   {sect_name}')
        print(f'  Match kind:         {match_kind}')
        print(f'  SonicOS branch:     {version_info["branch"] or "(unknown)"}')
        print(f'  SonicWall model:    {version_info["model"] or "(unknown)"}')
        print(f'  Lab status:         {lab_status}')
        if lab_status == 'validator_only':
            print('  NOTE: this golden has not been lab-imported on real '
                  'hardware yet; comparison is validator-graded only.',
                  file=sys.stderr)
        if match_kind == 'branch_only':
            print(f'  WARN: no exact (model, version) match for '
                  f'{version_info["model"]!r}; using closest branch '
                  f'entry. Consider adding a dedicated registry entry.',
                  file=sys.stderr)
        if match_kind == 'default_fallback' and (
                version_info['branch'] or version_info['model']
        ):
            print(f'  WARN: no registry match for '
                  f'({version_info["branch"]!r}, {version_info["model"]!r}); '
                  f'using default fallback. Composite score may not '
                  f'reflect this model accurately.',
                  file=sys.stderr)
        print()

    # ------------------------------------------------------------------
    # Value subvalidator (always runs — it compares against SW input,
    # which exists for every registry entry)
    # ------------------------------------------------------------------
    value_extra: list[str] = []
    if sw_input_override is not None and sw_input_override.is_file():
        value_extra = ['--sw-input', str(sw_input_override)]
    print('  Running value validator...')
    value_score, value_rc, value_out = _run_subvalidator(
        value_script, args.emit_xml, value_extra
    )

    # ------------------------------------------------------------------
    # Structural subvalidator (may be skipped if WG ref is pending)
    # ------------------------------------------------------------------
    if skip_structural:
        print(f'  Structural validator: SKIPPED ({skip_reason})')
        struct_score = 0.0
        struct_rc = 0
        struct_out = f'skipped: {skip_reason}\n'
    else:
        struct_extra: list[str] = []
        if wg_ref_override is not None and wg_ref_override.is_file():
            struct_extra = ['--wg-ref', str(wg_ref_override)]
        print('  Running structural validator...')
        struct_score, struct_rc, struct_out = _run_subvalidator(
            struct_script, args.emit_xml, struct_extra
        )

    if args.verbose:
        print()
        print('--- value validator output ---')
        print(value_out)
        print('--- structural validator output ---')
        print(struct_out)

    # ------------------------------------------------------------------
    # Composite computation. When structural is skipped, the composite
    # reverts to value-fidelity alone (re-weighted to 100%). This is the
    # honest framing: the comparison ran what it could, and the manifest
    # records that structural was skipped.
    # ------------------------------------------------------------------
    if skip_structural:
        composite = value_score
        composite_basis = 'value_only_structural_skipped'
    else:
        composite = (cfg['value_weight'] * value_score
                     + cfg['structural_weight'] * struct_score)
        composite_basis = 'composite'

    print()
    print('  Sub-scores:')
    print(f'    value fidelity (vs SW input):     {value_score:.4f}  '
          f'(weight {cfg["value_weight"]:.2f})')
    if skip_structural:
        print(f'    structural fidelity (vs WG ref):  SKIPPED')
    else:
        print(f'    structural fidelity (vs WG ref):  {struct_score:.4f}  '
              f'(weight {cfg["structural_weight"]:.2f})')
    print()
    print('  Composite score:                    {0:.4f}'.format(composite))
    print(f'  Composite basis:                    {composite_basis}')
    print(f'  Pass threshold:                     {cfg["composite_pass"]:.4f}')
    print(f'  Warning threshold:                  {cfg["composite_warning"]:.4f}')

    # When structural is skipped (WG reference pending), we PASS as long
    # as the value-only score clears the warning threshold. Rationale:
    # the gauntlet's other 9 validators carry the structural correctness
    # load already (schema_shape, immutables, required_children, jpa_diff,
    # ref_integrity, marker_pairing). A pending WG reference is a known,
    # logged, recoverable state — not a failure condition.
    if skip_structural:
        if value_score >= cfg['composite_warning']:
            verdict = 'PASS (structural skipped — WG ref pending)'
            rc = 0
        else:
            verdict = 'FAIL (value-only score below warning threshold)'
            rc = 1
    else:
        if composite >= cfg['composite_pass']:
            verdict = 'PASS'
            rc = 0
        elif composite >= cfg['composite_warning']:
            verdict = 'WARN'
            rc = 1
        else:
            verdict = 'FAIL'
            rc = 1
    print(f'  Verdict:                            {verdict}')
    print('=' * 72)

    return rc


if __name__ == '__main__':
    sys.exit(main())
