#!/usr/bin/env python3
"""
qualities_validator.py — validate every leaf in a candidate XML against
the per-XPath leaves-quality matrix derived from jpa.xml.

The matrix tells us, for EACH XPath, exactly what qualities WG accepts
(observed in a working export). Any candidate leaf whose qualities
diverge from its XPath's matrix profile gets flagged. No generalization
across XPaths — each is judged on its own observed form.

CHECKS PER LEAF
  1. Closed-enum: if jpa shows a closed enum at this XPath, candidate's
     value MUST be in the enum (case-exact).
  2. Casing pattern: candidate value's casing must match one of the
     casing patterns jpa observed at this XPath.
  3. Format signature: candidate's structural fingerprint must match
     one observed at this XPath (or be in the dominant-signature family).
  4. Empty-allowed: candidate empty only when jpa allowed empty.
  5. Integer range: when this XPath is pure-integer in jpa, candidate
     must be integer and in [observed_min, observed_max].

SEVERITY
  HARD: closed-enum violation; type mismatch (string where jpa pure-int).
  SOFT: casing/signature divergence (might still import; flag for review).

USAGE
  python3 qualities_validator.py <candidate.xml>
                                  [--matrix output/leaves_quality.json]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

# Reuse the classifier logic from the extractor for consistency
from leaves_quality_extractor import (
    classify_value, casing_pattern, format_signature, build_xpath,
)


# Empirically-verified exceptions: XPaths where jpa.xml corpus shows a
# narrow type but WG actually accepts a broader set. The qualities
# matrix is bootstrapped from jpa.xml; these exceptions widen the
# accepted-type set based on what the golden_pair WG reference proves
# WG accepts in real T-30 12.5.9 hardware.
#
# Format: {XPath: set of additional accepted types}
# When candidate's classify_value() result is in the additional set,
# the HARD type-mismatch finding is downgraded to SOFT or dropped.
TYPE_DRIFT_EXCEPTIONS = {
    # local-id-data accepts hostname/FQDN form, not just IPv4.
    # Provenance: golden_pair/wg_reference.xml line 2992 has
    # <local-id-data>locgwendptbovpn4Claude</local-id-data> — a hostname.
    # jpa corpus only had IPv4 here because its lab-export was an IP-only
    # config. Lab T-30 12.5.9 verified hostname/FQDN form loads and
    # renders correctly via Web UI.
    '/profile/ike-policy-list/ike-policy/local-cert/local-id-data':
        frozenset(['hostname', 'string']),
}


def validate(candidate: Path, matrix_path: Path) -> int:
    if not matrix_path.is_file():
        print(f'ERROR: matrix not found: {matrix_path}', file=sys.stderr)
        return 2
    if not candidate.is_file():
        print(f'ERROR: candidate not found: {candidate}', file=sys.stderr)
        return 2
    matrix = json.loads(matrix_path.read_text(encoding='utf-8'))
    try:
        root = ET.parse(candidate).getroot()
    except ET.ParseError as e:
        print(f'ERROR: candidate parse failed: {e}', file=sys.stderr)
        return 2

    parent_map = {id(c): p for p in root.iter() for c in p}
    hard, soft, info = [], [], []

    for elem in root.iter():
        if list(elem):
            continue
        xpath = build_xpath(elem, parent_map)
        text = (elem.text or '').strip() if elem.text else ''
        prof = matrix.get(xpath)
        if prof is None:
            # Candidate has a leaf path jpa.xml never has. SOFT: might
            # be a customer extension; might be a SonicWall pass-through.
            info.append((xpath, text, 'leaf XPath not in jpa matrix'))
            continue

        # 1. Empty-allowed check
        if text == '':
            if not prof.get('empty_allowed', False):
                # jpa never has empty here — but we emit empty
                hard.append((
                    xpath, text,
                    f'empty value not allowed; jpa never empty at this '
                    f'XPath ({prof["total_observations"]} obs).'
                ))
            continue  # nothing more to check for empty

        # 2. Closed-enum check (HARDEST constraint)
        if prof.get('closed_enum'):
            enum_vals = prof.get('enum_values', [])
            if text not in enum_vals:
                # Try case-insensitive match — if found, that's the
                # likely fix
                nearest = None
                for v in enum_vals:
                    if v.lower() == text.lower():
                        nearest = v
                        break
                msg = (f'value {text!r} not in jpa enum '
                       f'{enum_vals[:10]}{"..." if len(enum_vals)>10 else ""}')
                if nearest:
                    msg += f' (case-insensitive match exists: {nearest!r})'
                hard.append((xpath, text, msg))
                continue

        # 3. Integer range check
        if 'integer_min' in prof:
            try:
                n = int(text)
                if n < prof['integer_min'] or n > prof['integer_max']:
                    hard.append((
                        xpath, text,
                        f'integer {n} outside jpa range '
                        f'[{prof["integer_min"]}, {prof["integer_max"]}]'
                    ))
                    continue
            except ValueError:
                hard.append((
                    xpath, text,
                    f'non-integer {text!r}; jpa shows only integers '
                    f'[{prof["integer_min"]}, {prof["integer_max"]}]'
                ))
                continue

        # 4. Type mismatch (jpa pure-numeric, candidate non-numeric)
        types = prof.get('value_types', {})
        if types and 'integer' in types and len(types) == 1:
            # jpa exclusively integer here
            if classify_value(text) != 'integer':
                hard.append((
                    xpath, text,
                    f'non-integer value {text!r} at integer-only XPath '
                    f'(jpa types: {types})'
                ))
                continue

        # 5. Casing pattern check (SOFT)
        cp = casing_pattern(text)
        jpa_casings = set(prof.get('casing_patterns', {}).keys())
        if jpa_casings and cp not in jpa_casings and cp != 'N/A':
            # The trap: 'any' (lower) vs jpa 'Any' (Upper-first).
            # If the value is alpha-only and case-insensitive match exists
            # in enum, that's HARD. Otherwise SOFT casing flag.
            soft.append((
                xpath, text,
                f'casing pattern {cp!r} not observed in jpa at this '
                f'XPath; jpa shows {sorted(jpa_casings)}. Dominant: '
                f'{prof.get("dominant_casing")!r}.'
            ))

        # 6. Format signature check — SOFT for free-form text; HARD when
        # jpa shows a HOMOGENEOUS STRUCTURED type at this XPath (ip4,
        # cidr4, mac, ip6, integer). Format drift on a structured type
        # means the value won't parse as the expected type — Firebox
        # rejects with messages like:
        #   "Invalid IP address '192.168.1.0/24' for element
        #    'ip-network-addr'."
        # because the leaf expects ip4 but the value is cidr4.
        sig = format_signature(text)
        jpa_sigs = set(prof.get('format_signatures', {}).keys())
        STRUCTURED_TYPES = frozenset(['ip4', 'cidr4', 'mac', 'ip6',
                                       'integer', 'hex'])
        dominant_type = prof.get('dominant_type')
        all_types = set(prof.get('value_types', {}).keys())
        is_homogeneous_structured = (
            dominant_type in STRUCTURED_TYPES
            and len(all_types) == 1
        )
        candidate_type = classify_value(text)

        if (jpa_sigs and sig not in jpa_sigs
                and is_homogeneous_structured
                and candidate_type != dominant_type):
            # Check empirically-verified exception list
            exc_types = TYPE_DRIFT_EXCEPTIONS.get(xpath)
            if exc_types is not None and candidate_type in exc_types:
                # WG accepts this broader type at this XPath; downgrade
                # to SOFT (informational only).
                soft.append((
                    xpath, text,
                    f'value type {candidate_type!r} not in jpa-observed '
                    f'set ({dominant_type!r}); accepted at this XPath '
                    f'per golden-pair empirical verification.'
                ))
            else:
                # Hard type drift on a structured leaf
                hard.append((
                    xpath, text,
                    f'value type {candidate_type!r} (signature {sig!r}) '
                    f'does not match jpa\'s homogeneous {dominant_type!r} '
                    f'at this XPath. jpa observed signatures: '
                    f'{sorted(jpa_sigs)}. Firebox will reject as '
                    f'"Invalid {dominant_type} value".'
                ))
        elif jpa_sigs and sig not in jpa_sigs and len(jpa_sigs) <= 5:
            soft.append((
                xpath, text,
                f'format signature {sig!r} not in jpa observed '
                f'{sorted(jpa_sigs)} at this XPath.'
            ))

    # Report
    print(f'qualities_validator')
    print(f'  candidate: {candidate}')
    print(f'  matrix:    {matrix_path}')
    print('=' * 72)
    print(f'HARD findings (likely Firebox rejection): {len(hard)}')
    print(f'SOFT findings (casing/format suspicious): {len(soft)}')
    print(f'INFO  (leaf not in jpa matrix at all):    {len(info)}')
    print()

    if hard:
        print('=' * 72)
        print(f'HARD findings (first 50 of {len(hard)}):')
        print('=' * 72)
        for xpath, text, msg in hard[:50]:
            print(f'\n  {xpath}')
            print(f'    value: {text!r}')
            print(f'    {msg}')
    if soft:
        print()
        print('=' * 72)
        print(f'SOFT findings (first 20 of {len(soft)}):')
        print('=' * 72)
        for xpath, text, msg in soft[:20]:
            print(f'\n  {xpath}')
            print(f'    value: {text!r}')
            print(f'    {msg}')

    return 0 if not hard else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('candidate', type=Path)
    p.add_argument('--matrix', type=Path,
                   default=Path(__file__).parent / 'output'
                          / 'leaves_quality.json')
    args = p.parse_args()
    return validate(args.candidate, args.matrix)


if __name__ == '__main__':
    sys.exit(main())
