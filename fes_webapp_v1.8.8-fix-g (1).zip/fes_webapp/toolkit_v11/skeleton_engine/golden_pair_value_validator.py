#!/usr/bin/env python3
"""
golden_pair_value_validator.py — value fidelity score vs SW input.

QUESTION
   For every marker-tagged field in the golden SW input, did the toolkit
   carry that value through to the emit at the predicted WG XPath?

WHAT IT MEASURES
   Customer DATA fidelity — the toolkit's primary job is to carry the
   customer's actual values (IPs, names, identities) through the
   conversion. This validator scores how well that happened.

WHAT IT DOESN'T MEASURE
   - Whether the emit is structurally complete (that's structural_validator)
   - Whether the emit conforms to jpa schema (qualities/jpa_diff)
   - Whether the WG reference's specific values match the emit (irrelevant —
     ref values are intentionally different to teach field mapping)

INPUTS
   - SW input file (path from golden_pair_config.ini)
   - Emit XML file (CLI arg)
   - marker_mapping.ini (shape catalog — already maintained)

OUTPUT
   Per-marker pair report + composite value-fidelity score [0.0, 1.0].

SCORING
   Each detected SW marker contributes one observation. For each:
     - 1.0  if the marker value appears at the predicted WG XPath in emit
     - 0.5  if it appears SOMEWHERE in emit but not at the predicted path
     - 0.0  if it's absent from emit entirely

   Score = mean over all observations.

EXIT
   0 if score >= value_fidelity_pass threshold
   1 if score <  pass threshold
   2 on configuration error
"""
from __future__ import annotations

import argparse
import configparser
import re
import sys
from pathlib import Path


def _load_cfg(path: Path) -> dict:
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp.read(path, encoding='utf-8')
    return {
        'sw_input': cp.get('golden_pair', 'sw_input', fallback=''),
        'pass_threshold': cp.getfloat('thresholds', 'value_fidelity_pass',
                                       fallback=0.90),
        'warning_threshold': cp.getfloat('thresholds',
                                          'value_fidelity_warning',
                                          fallback=0.70),
    }


def _load_marker_catalog(path: Path) -> dict[str, dict]:
    """Load marker_mapping.ini shape catalog (subset relevant to value
    extraction). Returns {shape_name: {marker_suffixes, wg_xpath_hints}}."""
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp.read(path, encoding='utf-8')
    shapes = {}
    for section in cp.sections():
        if not section.startswith('shape.'):
            continue
        name = section[len('shape.'):]
        d = dict(cp.items(section))
        suffixes = [s.strip() for s in
                     d.get('sw_marker_suffixes', '').split(',')
                     if s.strip()]
        # wg_shapes_required values like 'alias:NAME' encode the expected
        # element type the marker should land in.
        required = [s.strip() for s in
                     d.get('wg_shapes_required', '').split(',')
                     if s.strip()]
        if suffixes:
            shapes[name] = {
                'suffixes': suffixes,
                'required_shapes': required,
                'description': d.get('description', ''),
            }
    return shapes


def detect_sw_marker_values(sw_text: str, shapes: dict) -> list[tuple[str, str]]:
    """Find all (shape_name, marker_value) pairs in the SW input. The
    marker_value is the actual token that ends in one of the shape's
    marker suffixes."""
    found: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for sname, spec in shapes.items():
        for suffix in spec['suffixes']:
            pattern = re.compile(
                r'([A-Za-z0-9_.-]*' + re.escape(suffix) + r')',
                re.IGNORECASE
            )
            for m in pattern.finditer(sw_text):
                tok = m.group(1)
                key = (sname, tok)
                if key in seen:
                    continue
                seen.add(key)
                found.append(key)
    return found


def find_value_in_emit(marker_value: str, emit_text: str,
                       required_shapes: list[str]
                       ) -> tuple[float, str]:
    """Score this marker's presence in emit. Returns (score, evidence).

       1.0 — marker value appears at one of the expected WG XPath shapes
       0.5 — marker value appears anywhere in emit (carried but
             possibly at wrong path)
       0.0 — marker value absent from emit
    """
    # First, simple presence check
    if marker_value not in emit_text:
        return (0.0, 'absent from emit')

    # If we have shape templates, check structural placement.
    # Templates like 'alias:NAME' or 'ike-policy/local-cert/local-id-data'
    for tmpl in required_shapes:
        if ':' in tmpl:
            elem, name_template = tmpl.split(':', 1)
            expected_name = name_template.replace('NAME', marker_value)
            # Look for <elem>...<name>EXPECTED_NAME
            elem_open = f'<{elem}>'
            name_marker = f'<name>{expected_name}</name>'
            if name_marker in emit_text and elem_open in emit_text:
                return (1.0, f'<{elem}> contains <name>{expected_name}</name>')
        elif '/' in tmpl:
            # Path-style — check the value appears in the context of
            # the leaf element (loose check: the value sits inside
            # the leaf tag).
            leaf = tmpl.rsplit('/', 1)[-1]
            pattern = re.compile(
                r'<' + re.escape(leaf) + r'>\s*' + re.escape(marker_value)
            )
            if pattern.search(emit_text):
                return (1.0, f'<{leaf}>{marker_value} found')
        elif tmpl.startswith('interface-description-'):
            # Special case: interface-description shapes — the marker
            # value should appear inside an <interface>'s <description>
            # leaf. Both forms (wan vs lan) verify the same way; the
            # specific zone is enforced by the toolkit's interface
            # filler, not by this validator.
            pattern = re.compile(
                r'<description>\s*' + re.escape(marker_value) +
                r'\s*</description>'
            )
            if pattern.search(emit_text):
                return (1.0,
                        f'<description>{marker_value}</description> found')
        else:
            # Unknown shape-template form. Fall through to loose match
            # (presence anywhere → 0.5, handled below).
            pass

    # Marker present but not at predicted path — partial credit
    return (0.5, 'carried to emit but path not verified')


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve().parent
    p.add_argument('emit_xml', type=Path,
                    help='Path to emitted configuration.xml')
    p.add_argument('--config', type=Path,
                    default=here / 'golden_pair_config.ini')
    p.add_argument('--marker-ini', type=Path,
                    default=here / 'marker_mapping.ini')
    p.add_argument('--sw-input', type=Path,
                    help='Override SW input path (default: from config)')
    p.add_argument('--quiet', action='store_true',
                    help='Suppress per-marker output')
    args = p.parse_args()

    if not args.config.is_file():
        print(f'ERROR: config not found: {args.config}', file=sys.stderr)
        return 2
    cfg = _load_cfg(args.config)

    # Resolve toolkit root for relative config paths
    toolkit_root = args.config.resolve().parent.parent
    sw_input_path = args.sw_input or (toolkit_root / cfg['sw_input'])
    if not sw_input_path.is_file():
        print(f'ERROR: SW input not found: {sw_input_path}', file=sys.stderr)
        return 2
    if not args.emit_xml.is_file():
        print(f'ERROR: emit XML not found: {args.emit_xml}', file=sys.stderr)
        return 2
    if not args.marker_ini.is_file():
        print(f'ERROR: marker_mapping.ini not found: {args.marker_ini}',
              file=sys.stderr)
        return 2

    sw_text = sw_input_path.read_text(encoding='utf-8', errors='replace')
    emit_text = args.emit_xml.read_text(encoding='utf-8', errors='replace')
    shapes = _load_marker_catalog(args.marker_ini)
    markers = detect_sw_marker_values(sw_text, shapes)

    print('=' * 72)
    print(' golden_pair_value_validator — value fidelity vs SW input')
    print('=' * 72)
    print(f'  SW input: {sw_input_path}')
    print(f'  emit:     {args.emit_xml}')
    print(f'  catalog:  {args.marker_ini}')
    print(f'  markers detected in SW: {len(markers)}')
    print()

    if not markers:
        print('  No markers detected. Are you sure the SW input is the')
        print('  marker-tagged golden reference? Returning vacuous 1.0.')
        # Emit the canonical summary line so the composite wrapper can
        # parse a score. The "vacuous" tag is for human reviewers — the
        # number is honestly 1.0 because we have nothing to measure
        # against. The composite validator's pending-WG-ref logic
        # surfaces this in the verdict.
        print(f'  value fidelity score: 1.0000  [vacuous: no markers]')
        return 0

    scores: list[float] = []
    by_shape: dict[str, list[tuple[str, float, str]]] = {}

    for shape_name, marker_value in markers:
        spec = shapes[shape_name]
        score, evidence = find_value_in_emit(
            marker_value, emit_text, spec['required_shapes']
        )
        scores.append(score)
        by_shape.setdefault(shape_name, []).append(
            (marker_value, score, evidence)
        )

    if not args.quiet:
        for shape_name in sorted(by_shape):
            print(f'  [{shape_name}]')
            for marker, score, evidence in by_shape[shape_name]:
                icon = '✓' if score >= 0.99 else ('~' if score >= 0.5 else '✗')
                print(f'    {icon} {score:.2f}  {marker}')
                print(f'         {evidence}')

    composite = sum(scores) / len(scores) if scores else 0.0
    print()
    print('=' * 72)
    print(f'  value fidelity score: {composite:.4f}  '
          f'({sum(1 for s in scores if s >= 0.99)} exact / '
          f'{sum(1 for s in scores if 0.4 < s < 0.99)} partial / '
          f'{sum(1 for s in scores if s < 0.4)} absent  '
          f'of {len(scores)})')
    print(f'  pass threshold:       {cfg["pass_threshold"]:.4f}')
    print('=' * 72)

    return 0 if composite >= cfg['pass_threshold'] else 1


if __name__ == '__main__':
    sys.exit(main())
