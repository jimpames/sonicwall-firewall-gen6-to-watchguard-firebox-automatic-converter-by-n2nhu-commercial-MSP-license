#!/usr/bin/env python3
"""
customer_fidelity_validator.py — for every customer record produced by
the enricher, confirm it actually appears (by name) in the emitted XML.

Catches the class of failure where the parser+enricher do their work
but no filler exists to insert the record into the WG XML, so it
silently disappears.

USAGE
   python3 customer_fidelity_validator.py <candidate.xml>
                                           [--customer-dir <enricher/output>]
"""
from __future__ import annotations

import argparse
import configparser
import json
import sys
from pathlib import Path
import xml.etree.ElementTree as ET


def validate(candidate: Path, customer_dir: Path) -> int:
    if not candidate.is_file():
        print(f'ERROR: candidate not found: {candidate}', file=sys.stderr)
        return 2
    try:
        root = ET.parse(candidate).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: candidate parse failed: {e}', file=sys.stderr)
        return 2

    # Build a set of every name-bearing element in the emit
    all_names_in_emit = set()
    for n in root.iter('name'):
        if n.text and n.text.strip():
            all_names_in_emit.add(n.text.strip())
    # Also pull text-content of common reference elements
    for tag in ('service', 'firewall', 'ike-action', 'ipsec-action',
                'ike-policy', 'alias', 'member'):
        for e in root.iter(tag):
            if e.text and e.text.strip() and not list(e):
                all_names_in_emit.add(e.text.strip())

    # Build a set of every IP in physical-if entries (used to verify
    # customer interfaces made it onto a WG slot under a renamed
    # interface)
    all_ips_in_emit_physical = set()
    for phys in root.iter('physical-if'):
        ip = phys.find('ip')
        if ip is not None and ip.text and ip.text.strip():
            all_ips_in_emit_physical.add(ip.text.strip())

    # Customer record files to audit
    audit_files = [
        ('service_objects.json',        'services'),
        ('implicit_address_objects.json', 'address objects'),
        ('address_groups.json',         'address groups'),
        ('schedules.json',              'schedules'),
        ('interfaces.json',             'interfaces'),
        ('access_rules.json',           'access rules'),
        ('vpn_policies.json',           'VPN policies'),
        ('service_groups.json',         'service groups'),
    ]

    # Load alias-filter drop patterns so we don't flag SW auto-generated
    # bookkeeping (X0 Subnet, X1 IP, MGMT IP) or jpa-template factory
    # carry-throughs (All Authorized Access Points, RBL User White List)
    # as "missing customer records." These names are INTENTIONALLY
    # dropped by skeleton_filler's alias filter pass (v1.8.5+) because
    # they're noise that clutters the WG Web UI Aliases panel — AND
    # colon-bearing names (X<N>:V<N> ... ) actually CRASH the panel.
    # Shared source-of-truth: skeleton_engine/alias_filter.ini.
    import re as _re_cf
    alias_drop_patterns: list = []
    afp = Path(__file__).resolve().parent / 'alias_filter.ini'
    if afp.is_file():
        afcp = configparser.ConfigParser()
        afcp.optionxform = str
        try:
            afcp.read(afp, encoding='utf-8')
            for sect in afcp.sections():
                if not sect.startswith('drop.'):
                    continue
                pat_src = afcp.get(sect, 'pattern', fallback='').strip()
                if pat_src:
                    try:
                        alias_drop_patterns.append(_re_cf.compile(pat_src))
                    except _re_cf.error:
                        pass
        except (configparser.Error, OSError):
            pass

    def _is_alias_filter_drop(name: str) -> bool:
        for rx in alias_drop_patterns:
            if rx.match(name):
                return True
        return False

    # Load access-rule filter rules (FES v1.8.6+). When fill_policies
    # drops access-rule records (e.g. family=ipv6 categorical drop per
    # Captain 2026-06-13), we mirror those drops here so the customer-
    # fidelity validator doesn't flag the same rules as "missing."
    # Shared source-of-truth: skeleton_engine/access_rule_filter.ini.
    ar_drop_rules: list = []
    arp = Path(__file__).resolve().parent / 'access_rule_filter.ini'
    if arp.is_file():
        arcp = configparser.ConfigParser()
        arcp.optionxform = str
        try:
            arcp.read(arp, encoding='utf-8')
            for sect in arcp.sections():
                if not sect.startswith('drop.'):
                    continue
                rule = {
                    'family': arcp.get(sect, 'family',
                                       fallback='').strip().lower(),
                    'comment_pattern': arcp.get(sect, 'comment_pattern',
                                                fallback='').strip(),
                    'zone_from': arcp.get(sect, 'zone_from',
                                          fallback='').strip(),
                    'zone_to': arcp.get(sect, 'zone_to',
                                        fallback='').strip(),
                }
                if rule['comment_pattern']:
                    try:
                        rule['_comment_re'] = _re_cf.compile(
                            rule['comment_pattern']
                        )
                    except _re_cf.error:
                        rule['_comment_re'] = None
                else:
                    rule['_comment_re'] = None
                ar_drop_rules.append(rule)
        except (configparser.Error, OSError):
            pass

    def _is_access_rule_filter_drop(record: dict) -> bool:
        """True if this access-rule record matches any drop rule in
        access_rule_filter.ini. Mirrors fill_policies logic to keep the
        validator in sync."""
        if not ar_drop_rules:
            return False
        rec_family = str(record.get('family') or '').strip().lower()
        rec_comment = str(record.get('comment') or '')
        rec_from = str(record.get('from')
                       or record.get('from_zone')
                       or '').strip()
        rec_to = str(record.get('to')
                     or record.get('to_zone')
                     or '').strip()
        for rule in ar_drop_rules:
            if rule['family'] and rule['family'] != 'any' \
                    and rule['family'] != rec_family:
                continue
            if rule['zone_from'] and rule['zone_from'] != rec_from:
                continue
            if rule['zone_to'] and rule['zone_to'] != rec_to:
                continue
            if rule['_comment_re'] is not None \
                    and not rule['_comment_re'].search(rec_comment):
                continue
            return True
        return False

    total_records = 0
    total_missing = 0
    by_file = {}

    for fname, label in audit_files:
        fpath = customer_dir / fname
        if not fpath.is_file():
            continue
        try:
            data = json.loads(fpath.read_text(encoding='utf-8'))
        except json.JSONDecodeError:
            continue
        records = data.get('entries', data) \
                  if isinstance(data, dict) else data
        if not isinstance(records, list):
            continue
        present = []
        missing = []
        hw_dropped = []
        for r in records:
            if not isinstance(r, dict):
                continue
            # Interface-specific filter: only count records with an
            # actual IP assigned. SonicWall lists every physical port
            # even if inactive; WG T-30 has 5 physical slots. Inactive
            # ports legitimately don't need to be in the emit.
            if fname == 'interfaces.json':
                ipa = r.get('ip-assignment')
                if not (isinstance(ipa, dict) and ipa.get('ip')):
                    continue
            name = r.get('name')
            if name is False or name is None or name == 'False':
                name = r.get('_id')
            if not name:
                continue
            name = str(name).strip()
            # Apply alias-filter exemptions BEFORE counting. SW auto-gen
            # bookkeeping, jpa factory aliases, and colon-bearing names
            # are INTENTIONALLY dropped by skeleton_filler.py — they
            # should not count toward the customer-record total or the
            # missing-from-emit count. Provenance: alias_filter.ini.
            if _is_alias_filter_drop(name):
                continue
            # Apply access-rule-filter exemptions for access_rules.json
            # records. fill_policies drops these categorically (e.g. all
            # family=ipv6 per Captain 2026-06-13); they should not count
            # as missing customer records. Shared source-of-truth:
            # access_rule_filter.ini.
            if fname == 'access_rules.json' and _is_access_rule_filter_drop(r):
                continue
            total_records += 1
            if name in all_names_in_emit:
                present.append(name)
                continue
            # Case-insensitive check — if jpa preserved a built-in with
            # the same name in different casing (e.g. customer 'cu-seeme'
            # vs jpa 'CU-SeeMe'), that's a legitimate jpa-wins skip,
            # not a missing record.
            if name.lower() in {n.lower() for n in all_names_in_emit}:
                present.append(name + ' (case-collision with jpa, jpa wins)')
                continue
            # For interfaces specifically: customer's SonicWall name (X0
            # etc.) won't appear in WG output — WG uses Trusted/External.
            # Check whether the customer's IP made it onto one of WG's
            # locked physical interfaces.
            if fname == 'interfaces.json':
                ipa = r.get('ip-assignment') or {}
                cust_ip = ipa.get('ip')
                if cust_ip and cust_ip in all_ips_in_emit_physical:
                    # IP IS in the emit, just under a different WG name
                    present.append(name + f' (as IP {cust_ip})')
                    continue
                # Otherwise the customer's IP didn't fit any WG slot
                hw_dropped.append({
                    'name': name,
                    'sw_id': r.get('_id'),
                    'ip': cust_ip,
                    'reason': 'hardware-slot constraint (T-30 has 5 slots)',
                })
                continue
            missing.append({
                'name': name,
                '_id': r.get('_id'),
                'section': r.get('_section'),
                'sample_keys': list(r.keys())[:8],
            })
            total_missing += 1
        by_file[fname] = {
            'label': label,
            'present': len(present),
            'missing': len(missing),
            'hardware_dropped': len(hw_dropped),
            'missing_records': missing,
            'hw_dropped_records': hw_dropped,
        }

    print('customer_fidelity_validator')
    print(f'  candidate:    {candidate}')
    print(f'  customer dir: {customer_dir}')
    print('=' * 72)
    print(f'  total customer records: {total_records}')
    print(f'  PRESENT in emit:        {total_records - total_missing}')
    print(f'  MISSING from emit:      {total_missing}')
    print()
    for fname, info in by_file.items():
        marker = '✓' if info['missing'] == 0 else '✗'
        hw_note = (f', {info["hardware_dropped"]} hardware-dropped'
                   if info.get('hardware_dropped') else '')
        print(f'  {marker}  {fname}: {info["present"]} present, '
              f'{info["missing"]} missing{hw_note}  ({info["label"]})')
        for m in info['missing_records'][:5]:
            print(f'       - missing: {m["name"]!r}'
                  f' (_id={m["_id"]!r}, section={m["section"]!r})')
        if len(info['missing_records']) > 5:
            print(f'       ... and {len(info["missing_records"])-5} more')
        for hd in info.get('hw_dropped_records', [])[:3]:
            print(f'       - hw-dropped: {hd["name"]!r} ip={hd["ip"]!r} '
                  f'({hd["reason"]})')
    return 0 if total_missing == 0 else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('candidate', type=Path)
    p.add_argument('--customer-dir', type=Path,
                   default=Path(__file__).parent.parent / 'enricher' / 'output')
    args = p.parse_args()
    return validate(args.candidate, args.customer_dir)


if __name__ == '__main__':
    sys.exit(main())
