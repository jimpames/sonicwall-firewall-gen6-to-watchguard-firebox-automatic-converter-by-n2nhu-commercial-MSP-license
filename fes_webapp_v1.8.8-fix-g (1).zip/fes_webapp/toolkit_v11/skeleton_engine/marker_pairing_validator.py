#!/usr/bin/env python3
"""
marker_pairing_validator.py

Validator #9 — end-to-end semantic pairing check.

Reads marker_mapping.ini for the shape catalog. For each shape detected
in the SonicWall input, asserts the expected WG counterpart shape(s)
exist in the emitted XML.

PROVENANCE
----------
Empirically derived from two real working configs (NSA-3600 SonicOS 6.5.4
+ T-30 Fireware 12.5.9), with marker-tagged artifacts whose names carry
field-type labels. No claim without provenance.

EXIT CODES
----------
  0  every detected SW shape paired to its required WG shape(s)
  1  one or more shapes unpaired (HARD findings)
  2  validator misconfiguration (couldn't read INI, couldn't find files)

OUTPUT
------
Prints a pair-report:
  [N/M] ADROBJ  someremotepeerfakeadrobj4Claude
        ✓ alias:someremotepeerfakeadrobj4Claude  (found at line 17738)
  [N/M] VPN    FakeSite2SiteIKEClaude
        ✗ MISSING: ipsec-action:FakeSite2SiteIKEClaude
"""
from __future__ import annotations

import argparse
import configparser
import re
import sys
from pathlib import Path


def parse_shape_catalog(ini_path: Path) -> dict[str, dict]:
    """Read marker_mapping.ini and return {shape_name: {fields}}."""
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp.read(ini_path, encoding='utf-8')
    shapes = {}
    for section in cp.sections():
        if not section.startswith('shape.'):
            continue
        name = section[len('shape.'):]
        d = dict(cp.items(section))
        shapes[name] = {
            'pattern': re.compile(d.get('sw_detect_pattern', ''), re.MULTILINE)
                if d.get('sw_detect_pattern') else None,
            'marker_suffixes': [s.strip() for s in
                                  d.get('sw_marker_suffixes', '').split(',')
                                  if s.strip()],
            'required': [s.strip() for s in
                          d.get('wg_shapes_required', '').split(',')
                          if s.strip()],
            'optional': [s.strip() for s in
                          d.get('wg_shapes_optional', '').split(',')
                          if s.strip()],
            'description': d.get('description', ''),
        }
    families = {}
    if cp.has_section('families'):
        families = {k: v.strip() for k, v in cp.items('families')}
    return shapes, families


def detect_sw_shapes(sw_text: str, shapes: dict) -> list[tuple[str, str]]:
    """For each shape, find SW-side instances. Returns [(shape_name, marker), ...]"""
    found = []
    for sname, spec in shapes.items():
        # Strategy: marker-suffix match against any token. The pattern
        # is a secondary signal but the marker is the primary detector
        # for the Claude-tagged catalog.
        for suffix in spec['marker_suffixes']:
            # Find all tokens ending with this suffix (case-insensitive)
            for m in re.finditer(
                    r'([A-Za-z0-9_.-]*' + re.escape(suffix) + r')',
                    sw_text, re.IGNORECASE):
                found.append((sname, m.group(1)))
    # De-duplicate (same shape + same marker)
    return list(dict.fromkeys(found))


def check_wg_shape(wg_text: str, shape_template: str, base_name: str
                     ) -> tuple[bool, str]:
    """Given a shape template like 'alias:NAME' or 'alias:NAME.1.alm' and
    the SW marker base_name, check the WG text contains the expected shape.

    Returns (found, evidence_or_reason).
    """
    if ':' not in shape_template:
        # Path-style like 'ike-policy/local-cert/local-id-data' — check
        # for the marker's presence inside a relevant element.
        # We treat this as a "marker text appears somewhere" check; if
        # the SW base_name string shows up in the WG XML, that's a pair.
        if base_name in wg_text:
            return True, f'found {base_name} in {shape_template}'
        return False, f'expected {shape_template} containing {base_name}'

    elem, name_template = shape_template.split(':', 1)
    expected_name = name_template.replace('NAME', base_name)
    # Look for <elem><name>EXPECTED_NAME</name>
    # or just <name>EXPECTED_NAME</name> inside a parent of type elem.
    # We allow either:
    #   1. <elem>...<name>EXPECTED_NAME</name>
    #   2. <name>EXPECTED_NAME</name>  (and elem appears as ancestor)
    # For the validator, the simpler text-scan is sufficient: if both
    # `<name>EXPECTED_NAME</name>` and `<elem>` appear, the pair is real.
    name_marker = f'<name>{expected_name}</name>'
    elem_open = f'<{elem}>'
    if name_marker in wg_text and elem_open in wg_text:
        return True, f'<{elem}><name>{expected_name}</name>'
    # Some WG names are inline attributes — e.g. policy aliases as
    # children of policy elements. Try also a simpler "the name appears
    # somewhere in a relevant context".
    if expected_name in wg_text:
        return True, f'{expected_name} (loose match)'
    return False, f'expected <{elem}> with name {expected_name}'


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--sw-config', required=True,
                    help='SonicWall input config (the customer upload)')
    p.add_argument('--wg-xml', required=True,
                    help='Emitted WG XML (skeleton_engine/output/configuration.xml)')
    p.add_argument('--marker-ini',
                    default=str(Path(__file__).resolve().parent
                                  / 'marker_mapping.ini'))
    args = p.parse_args()

    ini_path = Path(args.marker_ini)
    if not ini_path.is_file():
        print(f'ERROR: marker_mapping.ini not found at {ini_path}',
              file=sys.stderr)
        sys.exit(2)

    sw_path = Path(args.sw_config)
    wg_path = Path(args.wg_xml)
    if not sw_path.is_file():
        print(f'ERROR: SW config not found at {sw_path}', file=sys.stderr)
        sys.exit(2)
    if not wg_path.is_file():
        print(f'ERROR: WG XML not found at {wg_path}', file=sys.stderr)
        sys.exit(2)

    sw_text = sw_path.read_text(encoding='utf-8', errors='replace')
    wg_text = wg_path.read_text(encoding='utf-8', errors='replace')

    shapes, families = parse_shape_catalog(ini_path)
    detected = detect_sw_shapes(sw_text, shapes)

    print('=' * 72)
    print(' marker_pairing_validator — empirical end-to-end pairing check')
    print('=' * 72)
    print(f'  SW: {sw_path}')
    print(f'  WG: {wg_path}')
    print(f'  shape catalog: {ini_path}')
    print(f'  shapes detected on SW side: {len(detected)}')
    print()

    paired = 0
    total = 0
    hard_findings = []

    for shape_name, marker in detected:
        spec = shapes[shape_name]
        fam = families.get(shape_name, shape_name.upper())
        req = spec['required']
        if not req:
            # Optional-only shapes are not counted in the pair tally
            print(f'  [skip] {fam:8} {marker}  (no required WG shape)')
            continue
        all_found = True
        evidence = []
        for tmpl in req:
            total += 1
            found, why = check_wg_shape(wg_text, tmpl, marker)
            if found:
                paired += 1
                evidence.append(f'    ✓ {tmpl}: {why}')
            else:
                all_found = False
                evidence.append(f'    ✗ MISSING: {why}')
                hard_findings.append((fam, marker, tmpl, why))
        status = '✓' if all_found else '✗'
        print(f'  [{status}] {fam:8} {marker}')
        for e in evidence:
            print(e)

    print()
    print('=' * 72)
    print(f'  pair rate: {paired}/{total} required shapes paired')
    print(f'  HARD findings (unpaired required shapes): {len(hard_findings)}')
    print('=' * 72)
    if hard_findings:
        print()
        print('UNPAIRED SHAPES (each is a toolkit gap):')
        for fam, marker, tmpl, why in hard_findings:
            print(f'  - {fam} {marker} → {tmpl}')
    sys.exit(0 if not hard_findings else 1)


if __name__ == '__main__':
    main()
