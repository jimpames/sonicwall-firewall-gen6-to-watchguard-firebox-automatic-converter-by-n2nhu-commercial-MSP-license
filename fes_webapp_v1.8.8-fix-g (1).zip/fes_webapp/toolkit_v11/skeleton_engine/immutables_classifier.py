#!/usr/bin/env python3
"""
immutables_classifier.py — identify every element in jpa.xml whose
content is dictated by the physical box, the firmware build, or the
WatchGuard licensing system. These are HARDWARE/FIRMWARE IMMUTABLES.

The filler MUST NOT touch immutables. The customer's source config
describes a DIFFERENT box (SonicWall NSA-3600 with N interfaces, M
licenses, etc.). When we migrate to a T-30, the IMMUTABLES come from
the T-30's jpa.xml — never from the customer.

OUTPUT
   immutables.json:
     - structural_immutables: lists where the COUNT and SHAPE must match
       jpa exactly (e.g. interface-list count = T-30's physical port count)
     - value_immutables: XPaths whose value must remain exactly jpa's
       (e.g. for-version, rs-version, base-model, signature-update times)
     - cardinality_constraints: lists that must have a MIN/MAX/EXACT count
     - touchable_within: lists where the structure is immutable but
       certain leaves (description, ip) are touchable

CLASSIFICATION RULES
   1. Top-level scalar leaves at /profile/ — many are firmware/license
      identifiers (for-version, rs-version, product-grade, etc.). All
      treated as value-immutable.
   2. interface-list: cardinality immutable (model-dependent count of
      physical interfaces). Within each interface, name + property +
      multicast-if structure immutable; description + ip touchable.
   3. system-parameters, alarm-action-list, signature-update,
      proxy-action-list, dlp-sensor-list, gateway-wireless-controller:
      fully immutable (WG-defined; customer doesn't override).
   4. revision-history, policy-view, geolocation-blocking: structural
      immutable; counts must match.
   5. radius-conf-list and similar AAA: structural immutable count
      (cardinality from jpa), values customer-supplied.

USAGE
   python3 immutables_classifier.py [--reference jpa.xml]
                                     [--output immutables.json]
"""
from __future__ import annotations

import argparse
import configparser
import json
import sys
from collections import Counter
from pathlib import Path
import xml.etree.ElementTree as ET


# ---- INI-driven classification of top-level elements ------------------------
#
# Classifications live in immutables.ini, ONE source of truth.
# See immutables.ini for the full table and rationale notes.

_INI_PATH = Path(__file__).resolve().parent / 'immutables.ini'


def _load_classification_ini(ini_path: Path) -> tuple[dict, dict]:
    """Load immutables.ini and return:
       (top_level_classification, structural_lock_touchable_leaves)

    top_level_classification: {tag: (class, rationale)}
    structural_lock_touchable_leaves: {list_tag: set(leaf_names)}
    """
    if not ini_path.is_file():
        raise FileNotFoundError(
            f'immutables.ini not found at {ini_path}. The classifier '
            f'requires this file as its single source of truth.'
        )
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp.read(ini_path, encoding='utf-8')

    classification: dict[str, tuple[str, str]] = {}
    touchable: dict[str, set[str]] = {}

    for section in cp.sections():
        if not section.startswith('list.'):
            continue
        tag = section[len('list.'):]
        cls = cp.get(section, 'class', fallback='').strip()
        if not cls:
            print(f'WARNING: [{section}] missing class= field; skipping',
                  file=sys.stderr)
            continue
        rationale = cp.get(section, 'rationale', fallback='').strip()
        classification[tag] = (cls, rationale)
        # Touchable leaves are only meaningful for STRUCTURAL_LOCK entries.
        leaves_raw = cp.get(section, 'touchable_leaves', fallback='').strip()
        if leaves_raw:
            leaves = {x.strip() for x in leaves_raw.split(',') if x.strip()}
            if leaves:
                touchable[tag] = leaves
    return classification, touchable


# Module-level lazy load. Code that imported the old constants kept
# working because immutables_classifier was always called via subprocess,
# so the in-memory dict is reloaded each run.
TOP_LEVEL_CLASSIFICATION, STRUCTURAL_LOCK_TOUCHABLE_LEAVES = \
    _load_classification_ini(_INI_PATH)


def extract(reference: Path, output: Path) -> int:
    if not reference.is_file():
        print(f'ERROR: reference not found: {reference}', file=sys.stderr)
        return 2
    try:
        root = ET.parse(reference).getroot()
    except ET.ParseError as e:
        print(f'ERROR: jpa.xml parse failed: {e}', file=sys.stderr)
        return 2

    # Audit jpa's top-level — confirm we know about every element
    seen_tags = {child.tag for child in root}
    classified_tags = set(TOP_LEVEL_CLASSIFICATION.keys())
    unclassified = seen_tags - classified_tags
    unused_classified = classified_tags - seen_tags

    # Build cardinalities for STRUCTURAL_LOCK lists
    cardinalities = {}
    for tag, (cls, _) in TOP_LEVEL_CLASSIFICATION.items():
        if cls != 'STRUCTURAL_LOCK':
            continue
        elem = root.find(tag)
        if elem is None:
            cardinalities[tag] = 0
            continue
        # Count direct children
        kids = list(elem)
        cardinalities[tag] = len(kids)
        # Capture the names of locked entries (so filler can lookup-by-name)
        names = []
        for k in kids:
            n = k.find('name')
            if n is not None and n.text:
                names.append(n.text)
        cardinalities[tag + '__names'] = names

    # Capture frozen scalar values (top-level leaves that are FROZEN)
    frozen_scalars = {}
    for tag, (cls, _) in TOP_LEVEL_CLASSIFICATION.items():
        if cls != 'FROZEN':
            continue
        elem = root.find(tag)
        if elem is None:
            continue
        # If it's a scalar leaf, capture its text
        if not list(elem):
            frozen_scalars[tag] = (elem.text or '').strip()

    immutables = {
        'classification': {
            tag: {'class': cls, 'rationale': rat}
            for tag, (cls, rat) in TOP_LEVEL_CLASSIFICATION.items()
        },
        'structural_lock_cardinalities': cardinalities,
        'structural_lock_touchable_leaves': {
            k: sorted(v) for k, v in STRUCTURAL_LOCK_TOUCHABLE_LEAVES.items()
        },
        'frozen_scalars': frozen_scalars,
        'audit': {
            'jpa_top_level_tags': sorted(seen_tags),
            'unclassified_tags':  sorted(unclassified),
            'unused_classified_tags': sorted(unused_classified),
        },
    }

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(immutables, indent=2, sort_keys=True),
                      encoding='utf-8')

    print(f'immutables classification complete')
    print(f'  reference: {reference}')
    print(f'  output:    {output}')
    print()
    counts = Counter(cls for cls, _ in TOP_LEVEL_CLASSIFICATION.values())
    for cls, n in counts.most_common():
        print(f'  {cls:<22} {n}')
    print()
    print(f'  jpa top-level tags found: {len(seen_tags)}')
    if unclassified:
        print(f'  UNCLASSIFIED (need rule!): {sorted(unclassified)}')
    if unused_classified:
        print(f'  unused in jpa: {sorted(unused_classified)}')
    print()
    print(f'  STRUCTURAL_LOCK cardinalities:')
    for tag, (cls, _) in TOP_LEVEL_CLASSIFICATION.items():
        if cls != 'STRUCTURAL_LOCK':
            continue
        names = cardinalities.get(tag + '__names', [])
        print(f'     {tag}: count={cardinalities.get(tag, 0)}, '
              f'locked-names={names}')
    return 0 if not unclassified else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--reference', type=Path,
                   default=Path(__file__).parent.parent
                          / 'schema_learner' / 'corpus' / 'T30jpa1.xml')
    p.add_argument('--output', type=Path,
                   default=Path(__file__).parent / 'output'
                          / 'immutables.json')
    args = p.parse_args()
    return extract(args.reference, args.output)


if __name__ == '__main__':
    sys.exit(main())
