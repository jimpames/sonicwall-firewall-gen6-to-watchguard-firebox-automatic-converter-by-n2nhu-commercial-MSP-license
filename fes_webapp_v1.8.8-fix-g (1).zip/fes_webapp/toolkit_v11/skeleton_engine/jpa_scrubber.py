#!/usr/bin/env python3
"""
jpa_scrubber.py — apply scrub_config.ini to the skeleton.

For each [scrub.<list-tag>] section in scrub_config.ini, walks the
matching <list-tag> in the skeleton and REMOVES every entry whose
<name> is not in factory_names and doesn't match any factory_patterns.

When `keep_all = true` is set for a list, that list is left untouched
(the service-list is in this category — it's a catalog, not customer
data).

INVOCATION
   - As a step in build_pipeline (the normal path)
   - Standalone: python3 jpa_scrubber.py [--skeleton path] [--config path]

DESIGN
   Object × Verb = Action:
     Object: a jpa list tag (alias-list, address-group-list, ...)
     Verb:   scrub-by-allowlist (defined in scrub_config.ini)
     Action: remove non-factory entries in place; report what was scrubbed
"""
from __future__ import annotations

import argparse
import configparser
import re
import sys
from collections import defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET


def _parse_lines(value: str) -> list[str]:
    """Parse a multi-line INI value into a stripped, non-empty list."""
    if not value:
        return []
    return [ln.strip() for ln in value.splitlines() if ln.strip()]


def load_scrub_config(config_path: Path) -> dict:
    """Return:
       {
         'lists': {
            'alias-list': {
              'factory_names': set[str],
              'factory_patterns': list[re.Pattern],
              'keep_all': bool,
            },
            ...
         },
         'private_strings': list[str],
         'cascade_ref_tags': list[str],
       }
    """
    if not config_path.is_file():
        raise FileNotFoundError(f'scrub config not found: {config_path}')
    parser = configparser.ConfigParser()
    parser.read(config_path, encoding='utf-8')

    out = {'lists': {}, 'private_strings': [], 'cascade_ref_tags': []}

    for section in parser.sections():
        if section.startswith('scrub.'):
            list_tag = section[len('scrub.'):]
            names = set(_parse_lines(parser.get(section, 'factory_names',
                                                  fallback='')))
            patterns_raw = _parse_lines(parser.get(section, 'factory_patterns',
                                                     fallback=''))
            patterns = []
            for p in patterns_raw:
                try:
                    patterns.append(re.compile(p))
                except re.error as e:
                    print(f'ERROR: bad pattern {p!r} in [{section}]: {e}',
                          file=sys.stderr)
                    continue
            keep_all = parser.getboolean(section, 'keep_all',
                                          fallback=False)
            out['lists'][list_tag] = {
                'factory_names': names,
                'factory_patterns': patterns,
                'keep_all': keep_all,
            }
        elif section == 'private_strings':
            out['private_strings'] = _parse_lines(
                parser.get(section, 'strings', fallback='')
            )
        elif section == 'cascade':
            # Leaf XML tags whose text may contain a name-reference to a
            # scrubbed entity. Used by the cascade-removal pass to find
            # and drop dangling references after entry-level scrubbing.
            out['cascade_ref_tags'] = _parse_lines(
                parser.get(section, 'ref_tags', fallback='')
            )

    return out


def is_factory(name: str, rule: dict) -> bool:
    """Return True if `name` matches the factory allowlist for this list."""
    if not name:
        return False
    if name in rule['factory_names']:
        return True
    for pat in rule['factory_patterns']:
        if pat.match(name):
            return True
    return False


def _structural_lock_dependencies(root, immutables_path: Path) -> dict[str, set[str]]:
    """Walk every STRUCTURAL_LOCK entry in jpa and collect the names it
    REFERENCES (via child text). Returns {referenced_list_tag: {names}}.

    These names are factory-required: if STRUCTURAL_LOCK has them as
    dependencies, scrubbing them from PRESERVE_AND_APPEND lists would
    break the locked entries.

    For example, jpa has interface 'bovpntunnel.1' (STRUCTURAL_LOCK)
    that references ipsec-action 'bovpntunnel.1'. If we scrub the
    ipsec-action without keeping the reference, the interface's
    <item> becomes invalid:
       "Element 'item': Missing child element(s). Expected is one of
        (..., ipsec-action, ...)"
    """
    import json
    if not immutables_path.is_file():
        return {}
    try:
        immut = json.loads(immutables_path.read_text(encoding='utf-8'))
    except json.JSONDecodeError:
        return {}
    cls_map = immut.get('classification', {})
    locked_tags = {tag for tag, info in cls_map.items()
                    if info.get('class') == 'STRUCTURAL_LOCK'}
    # Tag names that ARE references to entries in other lists. The
    # cleanest mapping: any leaf inside a STRUCTURAL_LOCK entry whose
    # text matches the <name> of an entry in another list = reference.
    deps: dict[str, set[str]] = defaultdict(set)
    # Build a global name -> set-of-list-tags map first (a name can
    # exist in multiple lists, e.g. 'bovpntunnel.1' lives in BOTH
    # ipsec-action-list AND abs-ipsec-action-list)
    name_to_lists: dict[str, set[str]] = defaultdict(set)
    for top in root:
        for entry in top:
            n = entry.find('name')
            if n is not None and n.text and n.text.strip():
                name_to_lists[n.text.strip()].add(top.tag)

    # Now walk locked entries. For interface-list (the STRUCTURAL_LOCK
    # list), we only resolve dependencies from PHYSICAL interfaces
    # (item-type=1). VPN-virtual interfaces (item-type=4) are dropped
    # by the cascade pass when their tunnel is scrubbed, so they don't
    # constitute a structural dependency.
    for locked_tag in locked_tags:
        list_elem = root.find(locked_tag)
        if list_elem is None:
            continue
        for entry in list_elem:
            # For interface entries, skip if it's a VPN-virtual (item-
            # type=4) — those are scrub-eligible together with their
            # tunnel.
            if locked_tag == 'interface-list':
                iil = entry.find('if-item-list')
                if iil is not None:
                    item_types = [t.text for t in iil.iter('item-type')]
                    if item_types and '1' not in item_types:
                        # No physical-if item — this is a VPN-virtual
                        # or logical alias; skip dep collection.
                        continue
            for leaf in entry.iter():
                if list(leaf):
                    continue  # not a leaf
                if not leaf.text or not leaf.text.strip():
                    continue
                val = leaf.text.strip()
                # Add as a dependency in EVERY list that has an entry
                # with this name (except the locked list itself).
                for referenced_in in name_to_lists.get(val, set()):
                    if referenced_in != locked_tag:
                        deps[referenced_in].add(val)
    return dict(deps)


def scrub(skeleton_path: Path, config_path: Path,
          output_path: Path = None,
          immutables_path: Path = None) -> int:
    """Apply scrub_config.ini to skeleton_path. Overwrite skeleton_path
    unless output_path is given. Returns 0 on success."""
    config = load_scrub_config(config_path)
    try:
        tree = ET.parse(skeleton_path)
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: skeleton parse failed: {e}', file=sys.stderr)
        return 2
    root = tree.getroot()

    # Compute structural-lock dependencies BEFORE scrubbing. Any name
    # referenced by a STRUCTURAL_LOCK entry is implicitly factory and
    # must be preserved. Add those names to the corresponding factory
    # allowlists at runtime.
    if immutables_path is None:
        immutables_path = Path(__file__).parent / 'output' / 'immutables.json'
    sl_deps = _structural_lock_dependencies(root, immutables_path)
    if sl_deps:
        print(f'  [deps] STRUCTURAL_LOCK dependencies (auto-added to '
              f'factory_names):')
        for list_tag, names in sl_deps.items():
            print(f'     <{list_tag}>: {sorted(names)}')
            # Augment runtime allowlist
            rule = config['lists'].get(list_tag)
            if rule is None:
                continue
            rule['factory_names'] = rule['factory_names'] | names

    total_kept = 0
    total_scrubbed = 0
    scrub_report: list[tuple[str, list[str]]] = []

    for list_tag, rule in config['lists'].items():
        list_elem = root.find(list_tag)
        if list_elem is None:
            continue
        if rule['keep_all']:
            n_kids = len(list(list_elem))
            print(f'  [keep-all] <{list_tag}>: {n_kids} entries kept '
                  f'(catalog list)')
            total_kept += n_kids
            continue

        kept = []
        scrubbed = []
        for child in list(list_elem):
            n = child.find('name')
            name = n.text if (n is not None and n.text) else ''
            name = name.strip()
            if is_factory(name, rule):
                kept.append(name)
            else:
                scrubbed.append(name)
                list_elem.remove(child)

        total_kept += len(kept)
        total_scrubbed += len(scrubbed)
        if scrubbed:
            scrub_report.append((list_tag, scrubbed))
            print(f'  [scrub] <{list_tag}>: kept {len(kept)}, '
                  f'scrubbed {len(scrubbed)} jpa-customer-private '
                  f'entries')
        else:
            print(f'  [scrub] <{list_tag}>: kept {len(kept)}, '
                  f'nothing to scrub')

    out_path = output_path or skeleton_path
    # Binary mode prevents Windows CRLF translation — see comment in
    # skeleton_filler.py for full rationale.
    with open(out_path, 'wb') as f:
        tree.write(f, encoding='utf-8', xml_declaration=True)

    # Cascade-delete pass: scan the entire skeleton for references to
    # names we just scrubbed and remove those references. This catches
    # cases where a kept factory alias (e.g. WatchGuard.1.from) had been
    # extended by the jpa-customer to include their private alias (e.g.
    # FAKECO-2025MGT-SOURCES). Without cascade-delete, the reference
    # survives the scrub and the private string leaks through.
    scrubbed_names = set()
    for list_tag, names in scrub_report:
        for n in names:
            scrubbed_names.add(n)

    if scrubbed_names:
        # Cascade pass 1: drop VPN-virtual interfaces (item-type=4)
        # whose <ipsec-action> ref is in the scrubbed-names set.
        # These interfaces exist solely to bind a tunnel into the box's
        # interface list; if the underlying ipsec-action was scrubbed,
        # the interface must go too. The 5 PHYSICAL interfaces (item-
        # type=1) are NOT touched — those are hardware-immutable.
        il = root.find('interface-list')
        vpn_intfs_dropped = []
        if il is not None:
            for intf in list(il.findall('interface')):
                iil = intf.find('if-item-list')
                if iil is None:
                    continue
                for item in iil.findall('item'):
                    it = item.find('item-type')
                    if it is None or it.text != '4':
                        continue
                    ia = item.find('ipsec-action')
                    if ia is not None and ia.text in scrubbed_names:
                        n = intf.find('name')
                        intf_name = n.text if n is not None else '?'
                        il.remove(intf)
                        vpn_intfs_dropped.append(intf_name)
                        break
        if vpn_intfs_dropped:
            print(f'  [cascade] dropped {len(vpn_intfs_dropped)} VPN-virtual '
                  f'interface(s) whose tunnel was scrubbed: '
                  f'{vpn_intfs_dropped}')

        # Cascade pass 2: scan the entire skeleton for references to
        # names we just scrubbed and remove those references.
        # The leaf-tag list is declared in scrub_config.ini [cascade]
        # ref_tags, not hardcoded here. New SonicWall/WG shapes that
        # introduce new reference-bearing leaf tags are added by editing
        # the INI; no code change required.
        ref_tags_to_walk = config.get('cascade_ref_tags') or []
        if not ref_tags_to_walk:
            print('  [cascade] WARNING: no [cascade] ref_tags declared '
                  'in scrub_config.ini — skipping cascade reference walk',
                  file=sys.stderr)
        cascade_removed = 0
        for ref_tag in ref_tags_to_walk:
            for elem in list(root.iter(ref_tag)):
                if elem.text and elem.text.strip() in scrubbed_names:
                    # Remove the PARENT container of this ref (e.g. the
                    # whole <alias-member> not just the <alias-name>),
                    # because the container is the unit a reference lives
                    # in. Find parent.
                    for parent in root.iter():
                        if elem in list(parent):
                            # Decide: drop the parent container, or just
                            # blank the leaf? For <alias-member>, the
                            # container is the right granularity. For
                            # bare <interface>X</interface> inside a
                            # leaf-only context, blanking is safer.
                            if parent.tag in ('alias-member', 'member',
                                                'local-remote-pair'):
                                # Walk up one more — these containers
                                # are part of a list and should be
                                # removed wholesale.
                                for grandparent in root.iter():
                                    if parent in list(grandparent):
                                        grandparent.remove(parent)
                                        cascade_removed += 1
                                        break
                            else:
                                # Just remove the leaf reference
                                parent.remove(elem)
                                cascade_removed += 1
                            break
        if cascade_removed:
            print(f'  [cascade] removed {cascade_removed} reference(s) to '
                  f'scrubbed names from kept entries')

        # Cascade pass 3: any <alias-member-list> emptied by the cascade
        # needs a placeholder. WG schema requires at least one
        # <alias-member> inside. Verified against jpa: 49/49 alias
        # entries have non-empty alias-member-list.
        # The natural placeholder is type=1, user=Any, address=Any,
        # interface=Any — a wildcard member that matches the WG
        # factory pattern for "any source/destination".
        empty_filled = 0
        for alias in root.iter('alias'):
            aml = alias.find('alias-member-list')
            if aml is None:
                continue
            if not list(aml):
                am = ET.SubElement(aml, 'alias-member')
                ET.SubElement(am, 'type').text = '1'
                ET.SubElement(am, 'user').text = 'Any'
                ET.SubElement(am, 'address').text = 'Any'
                ET.SubElement(am, 'interface').text = 'Any'
                empty_filled += 1
        if empty_filled:
            print(f'  [cascade] refilled {empty_filled} alias-member-list '
                  f'container(s) emptied by reference scrub')

        if cascade_removed or empty_filled:
            # Rewrite with cascade applied (binary mode for byte-stable
            # cross-platform output)
            with open(out_path, 'wb') as f:
                tree.write(f, encoding='utf-8', xml_declaration=True)

    print()
    print(f'jpa_scrubber summary')
    print(f'  total kept:     {total_kept}')
    print(f'  total scrubbed: {total_scrubbed}')
    print(f'  wrote skeleton: {out_path}')
    if scrub_report:
        print()
        print(f'  Detailed scrub list:')
        for list_tag, names in scrub_report:
            print(f'    <{list_tag}>:')
            for n in names:
                print(f'       - {n}')
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--skeleton', type=Path,
                   default=Path(__file__).parent / 'output' / 'skeleton.xml')
    p.add_argument('--config', type=Path,
                   default=Path(__file__).parent / 'scrub_config.ini')
    p.add_argument('--output', type=Path, default=None,
                   help='Write scrubbed skeleton here instead of overwriting')
    args = p.parse_args()
    return scrub(args.skeleton, args.config, args.output)


if __name__ == '__main__':
    sys.exit(main())
