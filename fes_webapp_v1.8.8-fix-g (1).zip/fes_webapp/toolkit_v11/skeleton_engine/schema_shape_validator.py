#!/usr/bin/env python3
"""
schema_shape_validator.py — catch any element in the emitted XML whose
TAG NAME doesn't appear as a child of the same parent in jpa.xml.

This catches the entire CLASS of "invented tag name" failures, e.g.
   "Element 'network-addr': This element is not expected.
    Expected is one of (host-ip-addr, ip-network-addr, ...)"
which fires when the filler creates a tag the WG schema doesn't allow
at that path.

PRINCIPLE
   jpa.xml is the schema's empirical truth. If a tag T appears under
   parent P in the emit but T NEVER appears under P in jpa.xml, T is
   either invented or misplaced — both of which the Firebox will
   reject.

CHECK
   For every (parent_tag, child_tag) pair seen in the candidate:
   1. Is the same pair observed in jpa.xml?
   2. If not — flag as a HARD finding.

USAGE
   python3 schema_shape_validator.py <candidate.xml>
                                      [--reference jpa.xml]
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict
from pathlib import Path
import xml.etree.ElementTree as ET


def parent_child_pairs(root: ET.Element) -> set[tuple[str, str]]:
    """Return every (parent_tag, child_tag) pair observed in the tree."""
    pairs = set()
    for parent in root.iter():
        for child in parent:
            pairs.add((parent.tag, child.tag))
    return pairs


def index_parent_to_children(root: ET.Element) -> dict[str, set[str]]:
    """parent_tag -> set of allowed child tags (per jpa observation)."""
    p2c: dict[str, set[str]] = defaultdict(set)
    for parent in root.iter():
        for child in parent:
            p2c[parent.tag].add(child.tag)
    return dict(p2c)


# Empirically-verified parent/child pairs that DON'T appear in the
# bootstrapping jpa.xml corpus but DO appear in golden_pair/wg_reference.xml
# (a hand-built T-30 12.5.9 config that loaded and rendered in Web UI).
# These represent WG-valid shapes that the jpa training corpus simply
# didn't exercise, NOT toolkit bugs.
#
# Format: (parent_tag, child_tag) — both observed in golden ref.
# Provenance comment names the specific golden ref line.
SHAPE_EXCEPTIONS_FROM_GOLDEN_PAIR = frozenset([
    # peer-auth/domain-name: FQDN-based IKE peer auth.
    # Golden ref line 2977-2979 shows <peer-auth>
    # <peer-auth-mask>4</peer-auth-mask>
    # <domain-name>rmtdomain4gwendpt4Claude</domain-name>
    # — verified at T-30 12.5.9 lab. Not in jpa corpus because jpa uses
    # IP-based peer-auth only.
    ('peer-auth', 'domain-name'),
    # item/vlan-if: VLAN-logical interface item-type=2.
    # Golden ref line 18190-18213 shows <item><item-type>2</item-type>
    # <vlan-if>...<vlan-id>77</vlan-id>...</vlan-if></item> as a
    # separate <interface> in interface-list. jpa training corpus has
    # only item-type=1 (physical-if) and item-type=4 (tunnel-if), never
    # VLAN. Lab v1.8.2 confirmed Web UI VLAN/Add page renders this
    # shape correctly; Captain requested wire-up at lab push 2026-06-11.
    ('item', 'vlan-if'),
    # VLAN member-list children. Inside vlan-if/member-list/member,
    # the golden ref (line 18199-18203) has THREE children that jpa's
    # member contexts (policy-list, address-group, etc.) never carry:
    #   <if-num>2</if-num>          (parent physical hardware port)
    #   <if-dev-name>eth2</if-dev-name>  (parent dev name)
    #   <pvid-enabled>0</pvid-enabled>   (port-VLAN-ID enable flag)
    # These are VLAN-specific and harmless under <member> in jpa
    # corpus only because corpus has no VLAN sub-interfaces.
    ('member', 'if-num'),
    ('member', 'if-dev-name'),
    ('member', 'pvid-enabled'),
])


def validate(candidate: Path, reference: Path) -> int:
    try:
        cand_root = ET.parse(candidate).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: candidate parse failed: {e}', file=sys.stderr)
        return 2
    try:
        ref_root = ET.parse(reference).getroot()
    except (OSError, ET.ParseError) as e:
        print(f'ERROR: reference parse failed: {e}', file=sys.stderr)
        return 2

    ref_index = index_parent_to_children(ref_root)
    cand_pairs = parent_child_pairs(cand_root)

    # Find pairs in candidate that aren't observed under the same parent
    # in jpa
    invented = []
    for (parent, child) in sorted(cand_pairs):
        if parent not in ref_index:
            # parent itself isn't in jpa — let other validators handle
            continue
        if child not in ref_index[parent]:
            # Check empirically-verified exception list (shapes valid
            # in WG but not in jpa training corpus).
            if (parent, child) in SHAPE_EXCEPTIONS_FROM_GOLDEN_PAIR:
                continue
            invented.append((parent, child, sorted(ref_index[parent])))

    print(f'schema_shape_validator')
    print(f'  candidate: {candidate}')
    print(f'  reference: {reference}')
    print('=' * 72)
    print(f'  parent/child pairs in candidate: {len(cand_pairs)}')
    print(f'  pairs in jpa: {sum(len(v) for v in ref_index.values())}')
    print(f'  INVENTED pairs (not observed in jpa): {len(invented)}')
    print()
    if invented:
        for parent, child, allowed in invented:
            print(f'  <{parent}><{child}>  — never seen in jpa.')
            allowed_preview = allowed[:8]
            more = f' ... +{len(allowed)-8}' if len(allowed) > 8 else ''
            print(f'    jpa allows under <{parent}>: '
                  f'{allowed_preview}{more}')
            # Suggest closest match by substring
            child_lower = child.lower()
            suggestions = [a for a in allowed
                            if child_lower in a.lower()
                            or a.lower() in child_lower]
            if suggestions:
                print(f'    closest jpa tag(s): {suggestions}')
            print()
    return 0 if not invented else 1


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('candidate', type=Path)
    p.add_argument('--reference', type=Path,
                   default=Path(__file__).parent.parent
                          / 'schema_learner' / 'corpus' / 'T30jpa1.xml')
    args = p.parse_args()
    return validate(args.candidate, args.reference)


if __name__ == '__main__':
    sys.exit(main())
