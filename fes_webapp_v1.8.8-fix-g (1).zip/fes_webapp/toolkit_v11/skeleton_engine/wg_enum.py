#!/usr/bin/env python3
"""
wg_enum.py — single source of truth for WG XML numeric enum codes.

WG XML uses opaque numeric codes (<type>1</type>, <property>16</property>, ...).
This module reads wg_enums.ini and exposes:

    code(context, friendly_name) -> str
        Return the numeric code as a string suitable for `.text=` assignment.

    name(context, code) -> str
        Reverse lookup: human-readable name for a numeric code.

    code_int(context, friendly_name) -> int
        Same as code() but returns int (for callers using _set_leaf with int).

The 'context' is a section key like 'alias.property' or 'service_item.type'.
A missing context or missing name raises KeyError with diagnostic info.

PROVENANCE
   Codes declared in wg_enums.ini, derived from T-30 jpa.xml and lab
   T-30 12.5.9 Web UI verification. NO numeric literals in this file
   or callers (the whole point of the enum module).
"""
from __future__ import annotations

import configparser
from pathlib import Path

_INI_PATH = Path(__file__).resolve().parent / 'wg_enums.ini'
_CACHE: dict[str, dict[str, str]] | None = None


def _load() -> dict[str, dict[str, str]]:
    """{context: {friendly_name: code_str}}"""
    global _CACHE
    if _CACHE is not None:
        return _CACHE
    if not _INI_PATH.is_file():
        raise FileNotFoundError(
            f'wg_enum: wg_enums.ini not found at {_INI_PATH}'
        )
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    cp.read(_INI_PATH, encoding='utf-8')
    out: dict[str, dict[str, str]] = {}
    for section in cp.sections():
        if not section.startswith('enum.'):
            continue
        context = section[len('enum.'):]
        out[context] = {k: v.strip() for k, v in cp.items(section)}
    _CACHE = out
    return out


def code(context: str, friendly_name: str) -> str:
    """Return the numeric code (as str) for a friendly enum name."""
    table = _load()
    if context not in table:
        raise KeyError(
            f'wg_enum: context {context!r} not declared in wg_enums.ini. '
            f'Available contexts: {sorted(table)}'
        )
    if friendly_name not in table[context]:
        raise KeyError(
            f'wg_enum: name {friendly_name!r} not declared in '
            f'[enum.{context}]. Available: {sorted(table[context])}'
        )
    return table[context][friendly_name]


def code_int(context: str, friendly_name: str) -> int:
    """Same as code() but returns int."""
    return int(code(context, friendly_name))


def name(context: str, numeric_code: str | int) -> str:
    """Reverse lookup: human-readable name for a numeric code.
    Returns the code as a string if no mapping exists (graceful)."""
    table = _load()
    if context not in table:
        return str(numeric_code)
    target = str(numeric_code)
    for fn, c in table[context].items():
        if c == target:
            return fn
    return target


def all_contexts() -> list[str]:
    """List all declared contexts (for diagnostics)."""
    return sorted(_load())
