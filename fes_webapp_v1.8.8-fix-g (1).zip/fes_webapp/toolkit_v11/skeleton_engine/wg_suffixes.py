#!/usr/bin/env python3
"""
wg_suffixes.py — single source of truth for WatchGuard name-suffix
conventions.

WG XML uses specific name suffixes to encode entity-family relationships.
For example:
  - address-group alias "X" pairs with address-group "X.1.alm"
  - abs-policy "X" pairs with policy-list/policy "X-00"
  - ipsec-action "X" pairs with address-group "X.1.tlc" + "X.1.trm"
  - ike-action site-to-site "X" gets the "_bo" suffix

This module reads marker_mapping.ini's [suffix_conventions] section and
provides one function:

    get(friendly_name) -> str

Use:
    from wg_suffixes import get as suffix
    paired = f'{name}{suffix("addr_group_companion")}'      # → 'X.1.alm'
    pol = f'{base}{suffix("policy_list_entry")}'            # → 'X-00'

PROVENANCE
   Suffixes are declared in marker_mapping.ini → [suffix_conventions]
   and derived empirically from T-30 jpa.xml + lab-verified Web UI
   behavior. NO hardcoded literals in this file or callers.
"""
from __future__ import annotations

import configparser
from pathlib import Path

_INI_PATH = Path(__file__).resolve().parent / 'marker_mapping.ini'
_CACHE: dict[str, str] | None = None


def _load() -> dict[str, str]:
    """Lazy-load the [suffix_conventions] section. Cached for reuse."""
    global _CACHE
    if _CACHE is not None:
        return _CACHE
    cp = configparser.ConfigParser(interpolation=None)
    cp.optionxform = str
    if not _INI_PATH.is_file():
        raise FileNotFoundError(
            f'wg_suffixes: marker_mapping.ini not found at {_INI_PATH}. '
            f'Cannot resolve suffix conventions without it.'
        )
    cp.read(_INI_PATH, encoding='utf-8')
    if not cp.has_section('suffix_conventions'):
        raise KeyError(
            f'wg_suffixes: [suffix_conventions] section missing from '
            f'{_INI_PATH}. Cannot resolve suffix conventions.'
        )
    _CACHE = {k: v.strip() for k, v in cp.items('suffix_conventions')}
    return _CACHE


def get(friendly_name: str) -> str:
    """Return the WG suffix for a given friendly name.

    Raises KeyError if the friendly_name isn't declared in the INI.
    Empty string is a valid return value (some entities use the base
    name verbatim).
    """
    suffixes = _load()
    if friendly_name not in suffixes:
        raise KeyError(
            f'wg_suffixes: friendly name {friendly_name!r} not declared '
            f'in [suffix_conventions]. Available: {sorted(suffixes)}'
        )
    return suffixes[friendly_name]


def all_suffixes() -> dict[str, str]:
    """Return the full friendly_name → suffix map (read-only copy).
    Useful for diagnostics and for code that needs to test multiple
    suffix patterns (e.g. parsing a name to identify its family)."""
    return dict(_load())


def endswith_any(name: str, friendly_names: list[str]) -> str | None:
    """If `name` ends with one of the suffixes for the given friendly
    names, return that friendly_name. Otherwise None.

    Useful for "what family does this name belong to" checks without
    hardcoding the suffix string in the caller.
    """
    suffixes = _load()
    for fn in friendly_names:
        s = suffixes.get(fn, '')
        if s and name.endswith(s):
            return fn
    return None
