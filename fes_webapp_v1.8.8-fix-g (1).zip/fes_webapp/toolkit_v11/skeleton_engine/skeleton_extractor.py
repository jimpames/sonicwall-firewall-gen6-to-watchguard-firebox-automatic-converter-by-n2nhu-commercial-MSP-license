#!/usr/bin/env python3
"""
skeleton_extractor.py — turn jpa.xml into a structural skeleton + template
catalog.

OUTPUT
   skeleton.xml: jpa.xml with customer values wiped (lists emptied,
                 names blanked, UUIDs cleared) but every structural
                 element preserved with jpa's exact ordering.

   templates.json: catalog of {list_name: example_instance_xml_string}
                   from jpa.xml. Used by the filler to clone a template
                   per customer entry and replace values inside.

PHILOSOPHY
   jpa.xml is ground truth. We do NOT build XML from scratch. We
   copy jpa verbatim and surgically replace customer-relevant content.
   Customer-specific lists are wiped to empty; the filler then
   re-populates them by cloning a template instance per customer record.

USAGE
   python3 skeleton_extractor.py [--reference jpa.xml] [--output-dir .]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
import xml.etree.ElementTree as ET
import copy


# ----------------------------------------------------------------------------
# Classification of WG XML top-level elements lives in immutables.ini
# (single source of truth, consumed by 5 pipeline files via
# immutables.json). See immutables_classifier.py for the loader.
#
# This file previously held duplicate Python constants (WIPE_LISTS,
# PRESERVE_AND_APPEND_LISTS, CUSTOMER_LISTS, CUSTOMER_SCALARS) that
# were never referenced after the classifier started writing
# immutables.json — they were dead code masquerading as authoritative.
# Removed entirely to eliminate that future-bug risk.
# ----------------------------------------------------------------------------


def extract(reference: Path, output_dir: Path) -> int:
    if not reference.is_file():
        print(f'ERROR: reference not found: {reference}', file=sys.stderr)
        return 2
    try:
        tree = ET.parse(reference)
    except ET.ParseError as e:
        print(f'ERROR: jpa.xml parse failed: {e}', file=sys.stderr)
        return 2
    root = tree.getroot()

    # Load classifications. The classifier MUST have run first; if it
    # hasn't, run it now (it's deterministic from jpa.xml).
    immut_path = output_dir / 'immutables.json'
    if not immut_path.is_file():
        # Run classifier inline
        import subprocess
        rc = subprocess.run(
            ['python3',
             str(Path(__file__).parent / 'immutables_classifier.py'),
             '--reference', str(reference),
             '--output', str(immut_path)],
            check=False
        ).returncode
        if rc != 0 and not immut_path.is_file():
            print(f'ERROR: immutables classifier failed', file=sys.stderr)
            return 2
    classification = json.loads(immut_path.read_text(encoding='utf-8'))
    cls_map = classification['classification']

    # Derive working sets from the classification
    customer_fill = {t for t, c in cls_map.items()
                     if c['class'] == 'CUSTOMER_FILL'}
    preserve_append = {t for t, c in cls_map.items()
                       if c['class'] == 'PRESERVE_AND_APPEND'}
    structural_lock = {t for t, c in cls_map.items()
                       if c['class'] == 'STRUCTURAL_LOCK'}

    templates = {}
    wiped_lists = []
    preserved_lists = []
    locked_lists = []

    # Process the union of all classes that need template capture
    for list_tag in (customer_fill | preserve_append | structural_lock):
        list_elem = root.find(list_tag)
        if list_elem is None:
            continue
        children = list(list_elem)
        if not children:
            templates[list_tag] = None
            continue

        template_elem = children[0]
        template_xml = ET.tostring(template_elem, encoding='unicode')
        inner_tag = template_elem.tag

        shape_variants = {}
        for inst in children:
            shape_key = tuple(c.tag for c in inst)
            if shape_key not in shape_variants:
                shape_variants[shape_key] = ET.tostring(inst, encoding='unicode')

        mode = ('preserve+append' if list_tag in preserve_append
                else 'structural-lock' if list_tag in structural_lock
                else 'wipe+fill')
        templates[list_tag] = {
            'inner_tag': inner_tag,
            'primary_template_xml': template_xml,
            'shape_variants': [
                {'shape': list(k), 'template_xml': v}
                for k, v in shape_variants.items()
            ],
            'jpa_count': len(children),
            'mode': mode,
        }

        if list_tag in customer_fill:
            for c in children:
                list_elem.remove(c)
            wiped_lists.append(list_tag)
        elif list_tag in preserve_append:
            preserved_lists.append(list_tag)
        else:  # structural_lock
            # Keep jpa entries EXACTLY — filler patches specific leaves
            # in place; never adds/removes entries.
            locked_lists.append(list_tag)

    # Write skeleton XML (binary mode for byte-stable cross-platform output)
    skel_path = output_dir / 'skeleton.xml'
    with open(skel_path, 'wb') as f:
        tree.write(f, encoding='utf-8', xml_declaration=True)

    # Write templates catalog
    tmpl_path = output_dir / 'templates.json'
    tmpl_path.write_text(json.dumps(templates, indent=2), encoding='utf-8')

    print(f'jpa.xml skeleton extraction complete')
    print(f'  reference:        {reference}')
    print(f'  skeleton:         {skel_path}')
    print(f'  templates:        {tmpl_path}')
    print(f'  wiped lists:      {len(wiped_lists)} (CUSTOMER_FILL: filler re-populates)')
    for lt in wiped_lists:
        n = templates[lt]['jpa_count']
        nv = len(templates[lt]['shape_variants'])
        print(f'     {lt}: was {n} entries, {nv} variant(s)')
    print(f'  preserved lists:  {len(preserved_lists)} (PRESERVE_AND_APPEND: jpa kept, customer appended)')
    for lt in preserved_lists:
        n = templates[lt]['jpa_count']
        nv = len(templates[lt]['shape_variants'])
        print(f'     {lt}: kept {n} jpa entries, {nv} variant(s)')
    print(f'  locked lists:     {len(locked_lists)} (STRUCTURAL_LOCK: count/names immutable)')
    for lt in locked_lists:
        n = templates[lt]['jpa_count']
        print(f'     {lt}: {n} entries locked')
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--reference', type=Path,
                   default=Path(__file__).parent.parent
                          / 'schema_learner' / 'corpus' / 'T30jpa1.xml')
    p.add_argument('--output-dir', type=Path,
                   default=Path(__file__).parent / 'output')
    args = p.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    return extract(args.reference, args.output_dir)


if __name__ == '__main__':
    sys.exit(main())
