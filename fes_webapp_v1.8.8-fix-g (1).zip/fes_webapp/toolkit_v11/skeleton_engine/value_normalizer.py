#!/usr/bin/env python3
"""
value_normalizer.py — given an XPath and a candidate value, return the
form the leaves-quality matrix says should be emitted at that XPath.

NORMALIZATION RULES (in order)
  1. If the matrix shows a closed enum at this XPath and the candidate's
     case-insensitive match exists → return the EXACT-CASED enum value.
     (Fixes the 'any' → 'Any' trap.)
  2. If the matrix's dominant_casing differs from the candidate's casing
     and the candidate has only letters/spaces/standard separators → apply
     the dominant casing pattern (Title / UPPER / lower / Upper-first).
  3. If the matrix is integer-only, ensure the value parses as integer.
  4. Otherwise return the value unchanged.

USAGE (programmatic)
  from value_normalizer import normalize
  fixed = normalize('/profile/policy-list/policy/service', 'any', matrix)
  # fixed == 'Any'
"""
from __future__ import annotations

from typing import Optional


def _retitle(text: str) -> str:
    """Title case respecting separators: 'work hours' -> 'Work Hours'."""
    import re
    parts = re.split(r'(\s+|[-_/])', text)
    return ''.join(p.capitalize() if p and p[0].isalpha() else p
                   for p in parts)


def _to_upper_first(text: str) -> str:
    if not text:
        return text
    return text[0].upper() + text[1:].lower()


def _apply_casing(text: str, pattern: str) -> str:
    if pattern == 'UPPER':
        return text.upper()
    if pattern == 'lower':
        return text.lower()
    if pattern == 'Title':
        return _retitle(text)
    if pattern == 'Upper-first':
        return _to_upper_first(text)
    return text


def normalize(xpath: str, value: str, matrix: dict) -> str:
    """Return the value normalized to match jpa's qualities at xpath."""
    if value is None:
        return ''
    value = str(value)
    prof = matrix.get(xpath)
    if prof is None:
        return value  # no matrix entry — pass through unchanged

    # Rule 1: case-insensitive match against EVERY value jpa observed
    # at this XPath. If found, return jpa's exact-cased form.
    # This is the 'any' -> 'Any' / 'dns' -> 'DNS' / 'http-proxy' ->
    # 'HTTP-proxy' fix. Works whether the XPath is closed-enum or open.
    observed = prof.get('distinct_values') or prof.get('enum_values') or []
    if value in observed:
        return value  # already matches exactly
    lower = value.lower()
    for v in observed:
        if v.lower() == lower:
            return v  # exact-cased jpa form

    # Rule 2: integer-only XPath → coerce to int form
    types = prof.get('value_types', {})
    if types and 'integer' in types and len(types) == 1:
        try:
            return str(int(value.strip()))
        except (ValueError, AttributeError):
            return value

    # Rule 3: dominant casing — DISABLED on identifier leaves where the
    # value is unique by design (names, UUIDs, IDs). Rewriting these
    # corrupts cross-references and is the wrong fix.
    #
    # Only safe when the leaf is a REFERENCE to a closed value set
    # observed in jpa — which is exactly what Rule 1 catches. If Rule 1
    # didn't match, the value is novel; we leave it alone.
    #
    # Disabled paths: anything ending in '/name', '/uuid', '/id',
    # or with 'description' (free text). Effectively this disables
    # Rule 3 for almost everything — and that's correct, because
    # SonicWall customer values shouldn't be coerced into matching
    # jpa-customer-specific casing patterns. The right form is what
    # the customer wrote, unless it case-collides with a closed enum.
    return value


def normalize_in_place(elem, xpath: str, matrix: dict) -> bool:
    """Normalize elem.text against matrix. Returns True if changed."""
    if elem.text is None:
        return False
    new = normalize(xpath, elem.text, matrix)
    if new != elem.text:
        elem.text = new
        return True
    return False
