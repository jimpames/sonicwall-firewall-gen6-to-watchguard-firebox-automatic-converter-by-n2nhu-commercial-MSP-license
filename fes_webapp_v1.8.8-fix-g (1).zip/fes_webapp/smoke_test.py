#!/usr/bin/env python3
"""End-to-end smoke test of the FES webapp.

Boots uvicorn, runs through every endpoint we care about, prints PASS/FAIL,
then shuts uvicorn down. Returns exit 0 if everything green.
"""
import json
import os
import signal
import subprocess
import sys
import time
import urllib.request
import urllib.error
import urllib.parse
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent / 'app'
BASE = 'http://127.0.0.1:8001'  # use a different port to avoid conflicts
PASS = 'CHANGE_ME_BEFORE_DEPLOYING_OR_BE_VERY_SAD'
SAMPLE = (Path(__file__).resolve().parent
            / 'toolkit_v11' / 'sonicwall_parser' / 'input' / 'nsa3600.txt')

# Wipe state
(Path(__file__).resolve().parent / 'data' / 'fes.db').unlink(missing_ok=True)
import shutil
contrib_dir = Path(__file__).resolve().parent / 'data' / 'contrib_uploads'
if contrib_dir.exists():
    shutil.rmtree(contrib_dir)
sb_dir = Path(__file__).resolve().parent / 'sandbox' / 'runs'
if sb_dir.exists():
    shutil.rmtree(sb_dir, ignore_errors=True)

# Start uvicorn
env = os.environ.copy()
env['PYTHONIOENCODING'] = 'utf-8'
env['PYTHONUTF8'] = '1'
proc = subprocess.Popen(
    [sys.executable, '-m', 'uvicorn', 'main:app',
     '--host', '127.0.0.1', '--port', '8001'],
    cwd=str(APP_DIR), env=env,
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
)

def cleanup():
    try:
        proc.terminate()
        proc.wait(timeout=5)
    except Exception:
        proc.kill()

# Wait for boot
for _ in range(40):
    time.sleep(0.5)
    try:
        with urllib.request.urlopen(f'{BASE}/healthz', timeout=1) as r:
            if r.status == 200:
                break
    except Exception:
        pass
else:
    print('FAIL: server never came up')
    cleanup()
    sys.exit(2)

def get(path, headers=None):
    req = urllib.request.Request(BASE + path, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, r.read(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read(), dict(e.headers)

def post_multipart(path, fields, files=None, headers=None):
    import uuid
    boundary = uuid.uuid4().hex
    body = []
    for k, v in fields.items():
        body.append(f'--{boundary}\r\n'.encode())
        body.append(
            f'Content-Disposition: form-data; name="{k}"\r\n\r\n'.encode())
        body.append(str(v).encode() + b'\r\n')
    for k, (fname, data) in (files or {}).items():
        body.append(f'--{boundary}\r\n'.encode())
        body.append(
            (f'Content-Disposition: form-data; name="{k}"; '
             f'filename="{fname}"\r\n'
             'Content-Type: application/octet-stream\r\n\r\n').encode())
        body.append(data + b'\r\n')
    body.append(f'--{boundary}--\r\n'.encode())
    payload = b''.join(body)
    hdrs = {
        'Content-Type': f'multipart/form-data; boundary={boundary}',
        'Content-Length': str(len(payload)),
    }
    hdrs.update(headers or {})
    req = urllib.request.Request(BASE + path, data=payload, headers=hdrs)
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            return r.status, r.read(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read(), dict(e.headers)

failures = 0
def check(label, cond, detail=''):
    global failures
    if cond:
        print(f'  PASS  {label}')
    else:
        failures += 1
        print(f'  FAIL  {label}   {detail}')

print('\n=== 1. /api/config has certification ===')
status, body, _ = get('/api/config')
data = json.loads(body)
check('status 200', status == 200)
check('certification.status = BETA', data['certification']['status'] == 'BETA')
check('disclaimer has 4 lines', len(data['certification']['lines']) == 4)
check('contrib.enabled = true', data['contrib']['enabled'] is True)
check('contrib.delivery_window_days = 14',
      data['contrib']['delivery_window_days'] == 14)

print('\n=== 2. /api/contrib_options has dropdowns ===')
status, body, _ = get('/api/contrib_options')
data = json.loads(body)
check('status 200', status == 200)
check('sonicwall_models > 30', len(data['sonicwall_models']) > 30,
      f'got {len(data["sonicwall_models"])}')
check('watchguard_models > 20', len(data['watchguard_models']) > 20,
      f'got {len(data["watchguard_models"])}')

print('\n=== 3. Paid path still works ===')
sample = SAMPLE.read_bytes()
status, body, _ = post_multipart('/api/upload',
    {'tos_accepted': 'true'},
    files={'file': ('nsa3600.txt', sample)})
check('upload 200', status == 200, f'got {status}: {body[:200]}')
upload_data = json.loads(body)
sid = upload_data['session']['id']
print(f'    session={sid}')
# Stream the SSE until settle
import socket
host, port = '127.0.0.1', 8001
got_settle = False
output_sha = None
with socket.create_connection((host, port)) as s:
    s.sendall(f'GET /api/run/{sid} HTTP/1.1\r\nHost: {host}\r\n'
              f'Accept: text/event-stream\r\n\r\n'.encode())
    s.settimeout(5)
    buf = b''
    deadline = time.time() + 180
    while time.time() < deadline:
        try:
            chunk = s.recv(8192)
        except socket.timeout:
            # SSE may pause between lines — keep waiting
            if b'event: settle' in buf:
                break
            continue
        if not chunk:
            break
        buf += chunk
        if b'event: settle' in buf:
            # Read a tiny bit more to catch the data: line
            s.settimeout(2)
            try:
                while True:
                    more = s.recv(8192)
                    if not more:
                        break
                    buf += more
            except socket.timeout:
                pass
            got_settle = True
            text = buf.decode('utf-8', errors='replace')
            in_settle = False
            for line in text.split('\n'):
                if line.startswith('event: settle'):
                    in_settle = True
                    continue
                if in_settle and line.startswith('data: '):
                    try:
                        d = json.loads(line[6:])
                        if d.get('event') == 'done':
                            output_sha = d['session']['output_sha256']
                    except Exception:
                        pass
                    break
            break
check('SSE settle event received', got_settle)
check('output SHA = canonical a03f4aab...',
      output_sha == 'a03f4aab57af62c2d987401e5e13bce14352fbba84db3f20e2a7071b6283a40e',
      f'got {output_sha}')

print('\n=== 4. CONTRIB submit ===')
status, body, _ = post_multipart('/api/contrib_submit',
    {
        'email': 'jim@n2nhu.com',
        'source_model': 'NSA 3700',
        'target_model': 'Firebox T80',
        'notes': 'verify VPN survives',
        'tos_accepted': 'true',
    },
    files={'file': ('myconfig.txt', sample)})
check('contrib_submit 200', status == 200, f'got {status}: {body[:200]}')
c = json.loads(body)
print(f'    submission_id={c["submission_id"]}, input_sha={c["input_sha256"][:16]}...')
check('input_sha256 returned', len(c.get('input_sha256', '')) == 64)
check('email returned', c.get('email') == 'jim@n2nhu.com')

print('\n=== 5. CONTRIB rejects unknown source model ===')
status, body, _ = post_multipart('/api/contrib_submit',
    {
        'email': 'x@x.com',
        'source_model': 'FakeModel-9999',
        'target_model': 'Firebox T80',
        'tos_accepted': 'true',
    },
    files={'file': ('myconfig.txt', sample)})
check('rejected with 400', status == 400)

print('\n=== 6. Ops gate ===')
status, _, _ = get('/ops/submissions')
check('no passphrase -> 404', status == 404)
status, _, _ = get('/ops/submissions', {'X-Ops-Passphrase': 'wrong'})
check('wrong passphrase -> 404', status == 404)
status, body, _ = get('/ops/submissions', {'X-Ops-Passphrase': PASS})
check('correct passphrase -> 200', status == 200)
ops_data = json.loads(body)
check('lists 1 submission', len(ops_data['submissions']) == 1,
      f'got {len(ops_data["submissions"])}')
sub = ops_data['submissions'][0]
check('correct email recorded', sub['email'] == 'jim@n2nhu.com')
check('correct SHA recorded', sub['input_sha256'] == c['input_sha256'])

print('\n=== 7. Ops detail + audit log ===')
status, body, _ = get(f'/ops/submission/{c["submission_id"]}',
                       {'X-Ops-Passphrase': PASS})
check('detail 200', status == 200)
d = json.loads(body)
check('audit log has 1 entry', len(d['audit_log']) >= 1)

print('\n=== 8. Ops download serves stored input ===')
status, body, headers = get(
    f'/ops/submission/{c["submission_id"]}/download',
    {'X-Ops-Passphrase': PASS})
check('download 200', status == 200)
check('X-Input-SHA256 header present',
      any(k.lower() == 'x-input-sha256' and v == c['input_sha256']
            for k, v in headers.items()))
check('downloaded bytes == upload bytes',
      len(body) == len(sample),
      f'got {len(body)} vs sample {len(sample)}')

# Verify the SHA-256 of the downloaded bytes
import hashlib
dl_sha = hashlib.sha256(body).hexdigest()
check('downloaded SHA matches', dl_sha == c['input_sha256'])

print('\n=== 9. Ops can update status ===')
status, body, _ = post_multipart(
    f'/ops/submission/{c["submission_id"]}/status',
    {'new_status': 'delivered', 'note': 'emailed jim'},
    headers={'X-Ops-Passphrase': PASS})
check('status update 200', status == 200,
      f'got {status}: {body[:200]}')
# Re-read
status, body, _ = get(f'/ops/submission/{c["submission_id"]}',
                       {'X-Ops-Passphrase': PASS})
d = json.loads(body)
check('status now = delivered',
      d['submission']['status'] == 'delivered')
check('delivered_at populated',
      d['submission'].get('delivered_at') is not None)
check('audit log grew',
      len(d['audit_log']) >= 2)

cleanup()
print()
if failures:
    print(f'!! {failures} FAILURE(S) !!')
    sys.exit(1)
else:
    print('ALL CHECKS GREEN ✓')
    sys.exit(0)
