# Firewall Ejector Seat — Web App

**n2nhu lab — Jim Ames**

A thin, INI-driven web wrapper around the v11 SonicWall → WatchGuard migration toolkit. Customers drag-and-drop a SonicOS export, authorize a payment, watch the conversion stream in real time, and download the validated WatchGuard XML.

**The toolkit is not modified.** This webapp shells out to `python skeleton_engine/build_pipeline.py` against an unmodified v11 copy. Zero code change in the toolkit.

---

## Algebraic-design discipline

Every business knob in the web app — price, currency, sandbox limits, colors, ToS text, Stripe mode, domain, feature flags — is declared in `config/fes_webapp.ini`. The Python code reads the INI at boot and the front-end pulls a sanitized projection via `/api/config`. No magic numbers in code. No hard-coded brand strings in templates. No buried tunables.

Same Object × Verb = Action discipline that cracked the toolkit, applied to the web layer.

---

## Quick start (dev)

```bash
cd fes_webapp
./run-dev.sh
# Open http://localhost:8000
```

The launcher creates a venv, installs deps (FastAPI + uvicorn + Jinja), and starts uvicorn with auto-reload.

## Quick start (Docker)

```bash
cd fes_webapp
docker-compose up --build
# Open http://localhost:8000
```

---

## Driving the app via INI

Edit `config/fes_webapp.ini`, restart the app. Everything responds.

| Section | Knobs |
|---|---|
| `[brand]` | Product name, tagline, domain, support email, copyright holder |
| `[colors]` | Primary, accent, background — all CSS variables computed from these |
| `[pricing]` | `amount_usd = 250.00`, `display_amount = $250` |
| `[stripe]` | `mode = stub` / `test` / `live`, key fields, stub latency |
| `[sandbox]` | Timeout, max upload size, download TTL, allowed extensions, SonicOS sniff signatures |
| `[ui]` | Hero image path, log stream lines, show output SHA |
| `[tos]` | Path to ToS file, version, lawyer-reviewed flag |
| `[server]` | Host, port, debug, CORS origins |
| `[security]` | Redact regexes, download token bytes, force HTTPS |
| `[features]` | Feature flags for incremental rollout |

To change the price from $250 to $499: edit `amount_usd` and `display_amount` in `[pricing]`, restart. No code change.

To rebrand to a different domain: edit `domain` in `[brand]`, restart. No code change.

To swap in your real Stripe keys: set `mode = test`, fill `publishable_key` + `secret_key`, restart. (Real Stripe SDK integration is stubbed where marked `TODO real`; uncomment the `import stripe` line in `requirements.txt` and the real-mode branches in `app/main.py`.)

---

## Stripe — stub mode by default

The app starts in **stub mode**. The `StripeClient` simulates the PaymentIntent lifecycle locally:

1. Customer clicks Convert
2. App "authorizes" a PaymentIntent (capture_method=manual) — fake but realistic
3. Toolkit runs
4. Exit 0 → app "captures" the charge
5. Exit ≠0 → app "voids" the authorization — customer is NEVER charged

This lets the entire UI/flow be demoed end-to-end with no Stripe account. When you wire real Stripe:

1. Get test keys from your Stripe dashboard
2. `pip install stripe>=8.0.0` (uncomment in `requirements.txt`)
3. Set `mode = test` and fill in the keys in INI
4. Uncomment the real-mode branches in `StripeClient.create_payment_intent`, `.capture`, `.void` in `app/main.py` (each marked `# TODO real`)
5. Restart

Per Stripe docs at https://docs.stripe.com/api/payment_intents the auth-then-capture pattern is built-in via `capture_method='manual'`. The webhook secret is in INI when you wire webhooks later.

---

## Security posture

This service handles **highly sensitive customer firewall configurations** (PSKs, peer IPs, admin password hashes). The architecture is designed around that:

- **Ephemeral sandbox per conversion.** Each session gets its own directory under `sandbox/runs/{session_id}/` containing a fresh copy of the toolkit + the customer's upload. Destroyed on download or TTL expiry (default 15 min).
- **No persistent storage of customer payloads.** Configs never touch a database. They live in the sandbox dir for the conversion window, then are shredded.
- **No logging of customer payloads.** Validator stdout is streamed to the customer's browser via SSE and a last-N-lines window is kept in memory for the result panel only. The full output is never written to disk by the webapp.
- **Single-use download tokens.** Each successful conversion produces one URL-safe random token. Use it once, the file's gone and the sandbox is shredded.
- **Auth-then-capture payment.** Customers are never charged for a failed conversion.
- **Defense-in-depth redaction.** Any text we do persist (operational telemetry) passes through PSK/password regexes that replace matches with `<redacted>`.
- **Production deployment runs each conversion in a Docker sandbox** with `--network=none --memory=512m --cpus=1 --read-only --tmpfs /work`. (Dev mode runs as subprocess; the contract is identical.)

What's still your responsibility:
- HTTPS termination (use nginx + Let's Encrypt; set `[security].force_https = true` once HTTPS is live)
- A real legal review of the ToS before going live (`[tos].lawyer_reviewed = false` by default; the UI shows a draft warning until you flip it)
- Stripe key management (don't commit keys; use environment variables in prod)

---

## Project layout

```
fes_webapp/
├── README.md                  ← you are here
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
├── run-dev.sh                 ← local launcher
├── config/
│   ├── fes_webapp.ini         ← ALL knobs live here
│   └── tos_boilerplate.txt    ← Draft ToS (lawyer review required)
├── app/
│   └── main.py                ← FastAPI app (single file, ~470 lines)
├── templates/
│   ├── index.html             ← Landing page (Jinja, INI-driven)
│   └── tos.html               ← Terms page
├── static/
│   └── banner.png             ← Hero image
├── sandbox/
│   └── runs/                  ← Ephemeral per-conversion sandboxes
└── toolkit_v11/               ← UNMODIFIED v11 toolkit
```

---

## API surface

| Route | Method | Purpose |
|---|---|---|
| `/` | GET | Landing page |
| `/tos` | GET | Terms of Service |
| `/api/config` | GET | Public config projection (front end reads this) |
| `/api/upload` | POST | Accept upload + create PaymentIntent |
| `/api/run/{session_id}` | GET | SSE stream of toolkit stdout |
| `/api/session/{session_id}` | GET | Session status JSON |
| `/download/{token}` | GET | Single-use, time-limited config download |
| `/healthz` | GET | Liveness + counts |

---

## Going to production

Checklist before flipping firewallejectorseat.com from a parked domain to live:

1. **Legal review of ToS** — flip `[tos].lawyer_reviewed = true` after counsel approves
2. **Real Stripe keys** — switch `[stripe].mode = live`, populate keys, test with a real card
3. **HTTPS** — nginx in front, Let's Encrypt cert, set `[security].force_https = true`
4. **Production CORS origins** — narrow `[server].cors_origins` to just your real domain
5. **Per-conversion Docker sandboxing** — replace the subprocess call in `run_conversion()` with a `docker run` invocation per the sandbox section in this README
6. **Audit logging** — decide what (if anything) you persist about conversions for compliance; right now nothing is logged beyond timestamps + exit codes
7. **Backup / DR plan** — there's nothing stateful to back up, but you still want monitoring on the host
8. **Rate limiting** — add nginx-level rate limits on `/api/upload` to prevent abuse
9. **Set `[server].debug = false`**
10. **Test the kill switch** — `[features].enable_conversion = false` puts the site in "maintenance" mode without taking it down

---

## Footnotes for the architecture geek

The webapp inherits the toolkit's "no claim without provenance" discipline. The result panel surfaces the SHA-256 of the output file ([ui].show_output_sha = true) so the customer can independently verify what they downloaded matches what the validators approved. If WatchGuard or an auditor ever needs to reproduce a conversion, they can. The SHA travels in the `X-Output-SHA256` response header on the download too.

The streaming log is real Server-Sent Events, not polling. One SSE event per stdout line from the toolkit. The customer sees `qualities_validator exit: 0` show up live as it happens. Same psychological effect as the ProcMon demo — the work is visibly happening, not magically appearing.

The `/api/config` endpoint is the algebraic bridge to the front end. The Python side reads INI; the JS side reads `/api/config`. Same data, two consumers, single source of truth on disk.

---

## v1.2 additions

### BETA certification disclaimer

A cyan-bordered notice panel sits above the upload zone showing the
currently certified model pair. Driven by `[certification]` in
`fes_webapp.ini`:

```ini
[certification]
status              = BETA
certified_source    = SonicWall NSA-3600
certified_target    = WatchGuard Firebox T-30
disclaimer_line_1   = ⚠️  Today we CERTIFY conversion ONLY for {certified_source} → {certified_target}.
disclaimer_line_2   = During BETA we migrate: address objects (aliases), VPNs, policies, and LAN interface.
disclaimer_line_3   = Need a different model pair? Submit in CONTRIB mode below — we lab it free and email you the result within 14 days.
```

The `{certified_source}` and `{certified_target}` placeholders are
resolved at render time so editing the two field values rewrites all
three lines coherently.

### CONTRIB mode

A checkbox under the file dropzone enables CONTRIB mode. When checked:

- Two dropdowns appear: source SonicWall model + target WatchGuard model
- Both populated from `[models].sonicwall_models` and
  `[models].watchguard_models` (multi-line comma lists)
- Email + notes fields appear
- The "Convert for $250" button changes to "Submit for FREE lab
  conversion (14 days)"

On submit:

1. **No Stripe call.** No charge.
2. The upload is stored under `[contrib].storage_dir/<sha>.txt` (same
   SHA = same file on disk; deduplicates).
3. A row is written to `contrib_submissions` with email, model pair,
   notes, input SHA-256, remote IP, and a 21-day expiry.
4. An audit row is written to `contrib_audit_log`.
5. The customer gets a thank-you splash with their input SHA-256
   shown as the audit key.

### SQLite database

INI-declared schema in `[database]`:

```ini
[database]
path                = ./data/fes.db
table.contrib_submissions = *id:INTEGER, created_at:TEXT NOT NULL, ...
table.contrib_audit_log   = *id:INTEGER, ts:TEXT NOT NULL, ...
```

Add a column? Add it to the spec, restart. The DB layer is
`CREATE TABLE IF NOT EXISTS` only — no migrations file, no schema
versioning. The trade-off (no destructive ALTER, no rollback) is
acceptable for a single-operator MSP tool.

### Ops panel — internal admin UI

Visit `/ops` from an RFC1918 IP (or loopback, if
`[ops_panel].allow_loopback = true`). You'll see a passphrase prompt.
Enter the passphrase from `[ops_panel].passphrase`. After unlock you
get a table of CONTRIB submissions with filter + drill-down +
status update + stored-input download.

**Defense in depth — both checks must pass:**

1. **RFC1918 check.** Anyone hitting `/ops/submissions` etc. from a
   public IP gets HTTP 404 (not 403 — we don't acknowledge the endpoint
   exists). Proxy-aware: only trusts `X-Forwarded-For` if the immediate
   peer is in `[ops_panel].trusted_proxies`.

2. **Passphrase check.** The data endpoints additionally require
   `X-Ops-Passphrase` header. Wrong passphrase → 404 (same as no
   passphrase — no oracle for guessing). Constant-time compare via
   `hmac.compare_digest`.

**Endpoints:**

| Method | Path | Purpose |
|---|---|---|
| GET | `/ops` | HTML passphrase prompt (RFC1918 only) |
| GET | `/ops/submissions[?status_filter=pending]` | List submissions |
| GET | `/ops/submission/{id}` | Detail + audit log |
| GET | `/ops/submission/{id}/download` | Stored input file |
| POST | `/ops/submission/{id}/status` | Update status |

**Before you deploy:**

```ini
[ops_panel]
passphrase = <CHANGE FROM DEFAULT>   ; app warns at boot if still default
trusted_proxies = 10.0.0.5            ; your nginx IP, if behind a proxy
allow_loopback = false                ; production: typically false
```

