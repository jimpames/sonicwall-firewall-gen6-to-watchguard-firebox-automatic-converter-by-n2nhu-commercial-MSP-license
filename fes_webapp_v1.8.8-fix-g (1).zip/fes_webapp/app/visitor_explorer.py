# =============================================================================
# fes_webapp/app/visitor_explorer.py
# =============================================================================
# Lightweight "fun" visitor explorer for the public landing page.
#
# DESIGN PRINCIPLES:
#   1. Privacy-first: ONLY domain ROOT is exposed (e.g. 'comcast.net', not
#      'pc-of-jane.cust-12.subnet-99.comcast.net'). Full hostnames or IPs
#      NEVER appear in the public API response.
#   2. In-memory only: ring buffer holds last N visits, no persistent
#      storage. Resets on app restart. This is by design — a "recent
#      visitors" widget, not an audit log.
#   3. Filtered: localhost, private IPs, bot User-Agents, and known
#      health-check hosts never enter the buffer.
#   4. Aggregated only: the public API returns counts by domain root +
#      a coarse "recent" timeframe, never per-visitor records.
#   5. Async reverse-DNS: lookups happen in a background thread pool
#      with a hard 0.5s timeout; cached for the lifetime of the buffer
#      entry. Pages never block on DNS.
#
# OPERATIONAL KNOBS (config/fes_webapp.ini, [visitor_explorer] section):
#   enabled              : 'true' to record + serve; 'false' to no-op
#   buffer_size          : ring buffer capacity (default 200)
#   dns_timeout_seconds  : reverse-DNS timeout (default 0.5)
#   public_min_count     : domain root must have at least N visits to
#                          appear in public API (default 1; raise to
#                          obscure low-traffic roots further)
#
# AUTHORSHIP:
#   Built by J P Ames (n2nhu lab) as a fun-but-tasteful supplement to
#   the FES landing page. Algebraic-design discipline: knobs declared
#   in INI, evaluated at runtime, never hardcoded.
# =============================================================================

from __future__ import annotations

import asyncio
import ipaddress
import socket
import time
from collections import Counter, deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from threading import Lock
from typing import Optional

# ---------------------------------------------------------------------------
# Bot User-Agent fragments (lower-case substring match). Filtered out at
# record time so they never enter the buffer. Not exhaustive; covers the
# noisy ones. Add more in the INI if needed via [visitor_explorer.bot_ua].
# ---------------------------------------------------------------------------
DEFAULT_BOT_UA_FRAGMENTS = (
    'bot', 'crawler', 'spider', 'scraper', 'curl', 'wget', 'python-requests',
    'go-http-client', 'java/', 'ahrefs', 'semrush', 'mj12bot', 'dotbot',
    'bingpreview', 'slackbot', 'discordbot', 'twitterbot', 'facebookbot',
    'linkedinbot', 'embedly', 'preview', 'monitor', 'uptime', 'healthcheck',
    'pingdom', 'site24x7',
)

# ---------------------------------------------------------------------------
# Common public-suffix-style tails. For domain-ROOT extraction we want
# 'acme-corp.com' from 'pc-of-jane.subnet-99.acme-corp.com', and
# 'verizon.net' from 'pool-99-99.fios.verizon.net'. The list below is
# intentionally minimal; for genuine PSL accuracy you'd use the publicsuffix2
# library, but a flat list of common TLDs and second-level public suffixes
# (co.uk, com.au, etc.) catches 95%+ of real traffic.
# ---------------------------------------------------------------------------
MULTIPART_TLDS = frozenset((
    'co.uk', 'co.jp', 'co.kr', 'co.nz', 'co.za', 'co.in', 'co.id',
    'com.au', 'com.br', 'com.mx', 'com.cn', 'com.sg', 'com.tr',
    'net.au', 'net.br', 'net.cn',
    'org.uk', 'org.au', 'gov.uk', 'gov.au', 'ac.uk', 'ac.jp',
))


# ---------------------------------------------------------------------------
@dataclass
class VisitEntry:
    """A single visit, kept in the ring buffer."""
    domain_root: str             # e.g. 'comcast.net' — public-safe
    timestamp: float             # unix epoch seconds; coarse-binned in output
    is_resolved: bool = True     # False if reverse-DNS failed; domain_root then == 'unresolved'


# ---------------------------------------------------------------------------
class VisitorExplorer:
    """Ring-buffer-backed visitor explorer.

    Single shared instance is created at app startup and used via the
    module-level functions below.
    """

    def __init__(
        self,
        buffer_size: int = 200,
        dns_timeout: float = 0.5,
        public_min_count: int = 1,
        enabled: bool = True,
    ):
        self.enabled = enabled
        self.buffer_size = max(10, int(buffer_size))
        self.dns_timeout = max(0.1, float(dns_timeout))
        self.public_min_count = max(1, int(public_min_count))

        self._buffer: deque[VisitEntry] = deque(maxlen=self.buffer_size)
        self._lock = Lock()

        # Reverse-DNS cache: ip-string -> (domain_root, expires_epoch)
        self._dns_cache: dict[str, tuple[str, float]] = {}
        self._dns_cache_ttl = 3600.0  # 1 hour
        self._dns_cache_max = 500

        # Background executor for reverse-DNS lookups so we never block
        # the request handler on a slow DNS resolver.
        self._executor = ThreadPoolExecutor(
            max_workers=2,
            thread_name_prefix='visitor-dns'
        )

    # -----------------------------------------------------------------------
    # Filtering
    # -----------------------------------------------------------------------
    @staticmethod
    def _is_private_or_local(ip_str: str) -> bool:
        """True if the IP is loopback, private RFC1918, link-local, or
        otherwise not a public address. We never record these."""
        try:
            ip = ipaddress.ip_address(ip_str)
        except (ValueError, TypeError):
            return True
        return (ip.is_private or ip.is_loopback or ip.is_link_local
                or ip.is_multicast or ip.is_reserved or ip.is_unspecified)

    @staticmethod
    def _is_bot_ua(user_agent: str) -> bool:
        if not user_agent:
            return True  # missing UA: treat as bot
        ua_lower = user_agent.lower()
        return any(frag in ua_lower for frag in DEFAULT_BOT_UA_FRAGMENTS)

    # -----------------------------------------------------------------------
    # Domain-root extraction
    # -----------------------------------------------------------------------
    @staticmethod
    def _domain_root(hostname: str) -> str:
        """Extract the public-safe ROOT of a hostname.

        Examples:
          'pc-of-jane.cust-12.comcast.net'        -> 'comcast.net'
          'pool-99-99.fios.verizon.net'           -> 'verizon.net'
          'ec2-1-2-3-4.compute-1.amazonaws.com'   -> 'amazonaws.com'
          'mail.bbc.co.uk'                        -> 'bbc.co.uk'
        """
        if not hostname or '.' not in hostname:
            return 'unresolved'
        parts = hostname.lower().rstrip('.').split('.')
        if len(parts) < 2:
            return 'unresolved'

        # Check for multipart TLD (e.g. co.uk)
        if len(parts) >= 3:
            last_two = '.'.join(parts[-2:])
            if last_two in MULTIPART_TLDS:
                return '.'.join(parts[-3:])

        return '.'.join(parts[-2:])

    # -----------------------------------------------------------------------
    # Reverse DNS (with cache + timeout)
    # -----------------------------------------------------------------------
    def _reverse_dns_blocking(self, ip_str: str) -> Optional[str]:
        """Blocking reverse-DNS call. Returns hostname or None on
        failure. Wrapped in a thread + timeout by the caller."""
        # Set the socket default timeout for this call. The
        # gethostbyaddr() in Python's stdlib doesn't honor a per-call
        # timeout directly; the socket-level default is the cleanest
        # control point.
        try:
            socket.setdefaulttimeout(self.dns_timeout)
            host, _aliases, _addrs = socket.gethostbyaddr(ip_str)
            return host
        except (socket.herror, socket.gaierror, socket.timeout, OSError):
            return None
        finally:
            socket.setdefaulttimeout(None)

    def _reverse_dns_cached(self, ip_str: str) -> Optional[str]:
        """Cache-aware reverse-DNS. Returns hostname or None.
        Blocks for up to dns_timeout seconds on first call per IP."""
        now = time.time()

        # Cache hit
        with self._lock:
            cached = self._dns_cache.get(ip_str)
            if cached and cached[1] > now:
                return cached[0] if cached[0] else None

        # Cache miss — go to network, in a thread with timeout enforcement
        future = self._executor.submit(self._reverse_dns_blocking, ip_str)
        try:
            host = future.result(timeout=self.dns_timeout + 0.1)
        except Exception:
            host = None

        # Cache the result (even None — to avoid re-querying failed IPs)
        with self._lock:
            self._dns_cache[ip_str] = (host or '', now + self._dns_cache_ttl)
            # Trim cache if over capacity
            if len(self._dns_cache) > self._dns_cache_max:
                # Pop oldest entries (by expiry time)
                sorted_items = sorted(self._dns_cache.items(),
                                       key=lambda kv: kv[1][1])
                for k, _ in sorted_items[:50]:
                    self._dns_cache.pop(k, None)
        return host

    # -----------------------------------------------------------------------
    # Record visit
    # -----------------------------------------------------------------------
    def record_visit(self, ip_str: str, user_agent: str = '',
                      path: str = '') -> None:
        """Called from the request middleware. Non-blocking from caller's
        perspective: filtering is fast; reverse-DNS happens with a hard
        timeout but the worst case is sub-second."""
        if not self.enabled:
            return

        # Skip API endpoints, health checks, ops surface — we only want
        # human-facing page visits in the explorer.
        if path.startswith('/api/') or path == '/healthz' \
                or path.startswith('/ops') or path.startswith('/download'):
            return

        if self._is_private_or_local(ip_str):
            return
        if self._is_bot_ua(user_agent):
            return

        # Reverse-DNS with timeout
        host = self._reverse_dns_cached(ip_str)
        if host:
            root = self._domain_root(host)
            is_resolved = (root != 'unresolved')
        else:
            root = 'unresolved'
            is_resolved = False

        entry = VisitEntry(
            domain_root=root,
            timestamp=time.time(),
            is_resolved=is_resolved,
        )
        with self._lock:
            self._buffer.append(entry)

    # -----------------------------------------------------------------------
    # Read API (used by the FastAPI endpoints)
    # -----------------------------------------------------------------------
    def get_recent_summary(self) -> dict:
        """Aggregated summary for the public API. Returns:
          {
            'enabled': true/false,
            'total_unique_domains': N,
            'total_visits_in_buffer': N,
            'recent_domains': [{'domain': str, 'count': int, 'last_seen_minutes': int}, ...],
            'oldest_in_buffer_minutes': int,
          }

        Only domain roots with at least public_min_count visits are
        included. Sorted by most-recent-first, then by count desc.
        """
        if not self.enabled:
            return {'enabled': False, 'recent_domains': []}

        now = time.time()
        with self._lock:
            entries = list(self._buffer)

        if not entries:
            return {
                'enabled': True,
                'total_unique_domains': 0,
                'total_visits_in_buffer': 0,
                'recent_domains': [],
                'oldest_in_buffer_minutes': 0,
            }

        # Aggregate
        domain_count = Counter()
        domain_last_seen = {}  # domain -> latest timestamp
        for e in entries:
            domain_count[e.domain_root] += 1
            if e.domain_root not in domain_last_seen \
                    or e.timestamp > domain_last_seen[e.domain_root]:
                domain_last_seen[e.domain_root] = e.timestamp

        # Filter by public_min_count
        recent_domains = []
        for domain, count in domain_count.items():
            if count < self.public_min_count:
                continue
            last_seen = domain_last_seen[domain]
            minutes_ago = max(0, int((now - last_seen) / 60))
            recent_domains.append({
                'domain': domain,
                'count': count,
                'last_seen_minutes': minutes_ago,
            })

        # Sort: most-recent first; tie-break by count desc
        recent_domains.sort(
            key=lambda d: (d['last_seen_minutes'], -d['count'])
        )

        oldest_minutes = int((now - entries[0].timestamp) / 60)
        return {
            'enabled': True,
            'total_unique_domains': len(recent_domains),
            'total_visits_in_buffer': len(entries),
            'recent_domains': recent_domains,
            'oldest_in_buffer_minutes': oldest_minutes,
        }

    def get_full_table(self, max_rows: int = 50) -> dict:
        """Richer table for the /explorer page. Same privacy posture —
        domain root only, coarse timestamps. Returns rows in
        most-recent-first order."""
        summary = self.get_recent_summary()
        # The summary already gives the sorted aggregated view we want;
        # the table view just caps the row count for display.
        summary['recent_domains'] = summary.get('recent_domains', [])[:max_rows]
        return summary


# ---------------------------------------------------------------------------
# Module-level singleton management
# ---------------------------------------------------------------------------
_singleton: Optional[VisitorExplorer] = None


def initialize(enabled: bool = True, buffer_size: int = 200,
               dns_timeout: float = 0.5, public_min_count: int = 1) -> None:
    """Called from app startup with config-loaded knobs."""
    global _singleton
    _singleton = VisitorExplorer(
        enabled=enabled,
        buffer_size=buffer_size,
        dns_timeout=dns_timeout,
        public_min_count=public_min_count,
    )


def record_visit(ip_str: str, user_agent: str = '', path: str = '') -> None:
    """Module-level convenience wrapper."""
    if _singleton is None:
        return
    _singleton.record_visit(ip_str, user_agent, path)


def get_recent_summary() -> dict:
    if _singleton is None:
        return {'enabled': False, 'recent_domains': []}
    return _singleton.get_recent_summary()


def get_full_table(max_rows: int = 50) -> dict:
    if _singleton is None:
        return {'enabled': False, 'recent_domains': []}
    return _singleton.get_full_table(max_rows)
