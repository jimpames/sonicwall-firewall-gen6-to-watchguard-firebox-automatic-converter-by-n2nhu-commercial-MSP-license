"""
fes_webapp/app/ops_security.py

Defense in depth for the ops panel.

TWO independent checks, BOTH must pass:
  1. Client IP is RFC1918 (or loopback if INI permits)
  2. X-Ops-Passphrase header matches the INI passphrase

Behind nginx / a CDN, the apparent client.host is the reverse proxy. We
trust X-Forwarded-For ONLY if the immediate caller is on the configured
trusted-proxies list. Otherwise we use the raw socket peer.

This is the standard pattern. Don't roll your own with bare
request.client.host alone — that lets a malicious proxy header bypass
the RFC1918 check.
"""
from __future__ import annotations

import hmac
import ipaddress
from typing import Iterable

from fastapi import HTTPException, Request


def _to_networks(specs: Iterable[str]):
    nets = []
    for s in specs:
        s = s.strip()
        if not s:
            continue
        try:
            nets.append(ipaddress.ip_network(s, strict=False))
        except ValueError:
            # tolerate one-line typos; just skip
            continue
    return nets


RFC1918_NETS = _to_networks([
    '10.0.0.0/8',
    '172.16.0.0/12',
    '192.168.0.0/16',
])
LOOPBACK_NETS = _to_networks(['127.0.0.0/8', '::1/128'])


def _client_ip(request: Request, trusted_proxies: list[str]) -> str:
    """Resolve the *real* client IP.

    If the immediate socket peer is in trusted_proxies, trust the
    *leftmost* X-Forwarded-For entry. Otherwise use the socket peer.
    """
    peer = request.client.host if request.client else ''
    if not peer:
        return ''
    trusted_set = set()
    for t in trusted_proxies:
        t = t.strip()
        if t:
            trusted_set.add(t)
    if peer in trusted_set:
        xff = request.headers.get('x-forwarded-for', '')
        if xff:
            # X-F-F is a comma list; the leftmost is the original client
            first = xff.split(',')[0].strip()
            if first:
                return first
    return peer


def _is_private(ip_str: str, allow_loopback: bool) -> bool:
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    if any(ip in n for n in RFC1918_NETS):
        return True
    if allow_loopback and any(ip in n for n in LOOPBACK_NETS):
        return True
    return False


def ops_gate(request: Request,
              passphrase_expected: str,
              allow_loopback: bool,
              trusted_proxies: list[str]) -> str:
    """Raises HTTPException unless BOTH checks pass.

    Returns the resolved client IP on success (for audit logging).
    """
    ip = _client_ip(request, trusted_proxies)
    if not _is_private(ip, allow_loopback):
        # Don't leak detail about why — just 404. Bots scanning for
        # admin endpoints get a generic miss.
        raise HTTPException(status_code=404)
    given = request.headers.get('x-ops-passphrase', '')
    # Constant-time compare avoids timing oracle on the passphrase
    if not hmac.compare_digest(given, passphrase_expected):
        raise HTTPException(status_code=404)
    return ip
