"""
fes_webapp/app/main.py

Firewall Ejector Seat — FastAPI wrapper around the v11 SonicWall→WatchGuard
migration toolkit.

ARCHITECTURE
============
The v11 toolkit is treated as a sealed black box. This webapp:

  1. Accepts a SonicOS config upload via drag-drop
  2. Creates a Stripe PaymentIntent (auth-then-capture pattern) — stubbed
     until real Stripe keys are wired
  3. Spins an ephemeral sandbox directory per conversion
  4. Shells out to `python skeleton_engine/build_pipeline.py --input ...`
     against an UNMODIFIED copy of the v11 toolkit
  5. Streams the pipeline's stdout to the browser via Server-Sent Events
  6. On exit 0: captures the Stripe charge, exposes a single-use download
  7. On exit != 0: voids the Stripe auth, returns the failure log
  8. After download OR TTL: shreds the sandbox

EVERY business knob (price, currency, sandbox limits, colors, ToS path,
Stripe mode, domain) is in config/fes_webapp.ini. NO knobs in code.

This honors the algebraic-design principle: Object × Verb = Action,
expressed as INI, evaluated at runtime, never hardcoded.
"""
from __future__ import annotations

import asyncio
import configparser
import hashlib
import json
import logging
import os
import re
import secrets
import shutil
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import AsyncIterator

from fastapi import (FastAPI, File, Form, Header, HTTPException, Request,
                      UploadFile, status)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import (FileResponse, HTMLResponse, JSONResponse,
                                StreamingResponse)
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

# Local imports
import db
import ops_security

# ----------------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------------
APP_ROOT = Path(__file__).resolve().parent.parent
INI_PATH = APP_ROOT / 'config' / 'fes_webapp.ini'

# ----------------------------------------------------------------------------
# INI loader
# ----------------------------------------------------------------------------
class Config:
    """Thin wrapper around configparser that's strict about missing keys
    and types every value we expect. Reloaded once at boot; the ToS text
    file is re-read per request so legal updates don't require restart."""

    def __init__(self, path: Path):
        self.path = path
        cp = configparser.ConfigParser(interpolation=None)
        cp.optionxform = str  # preserve case
        if not path.is_file():
            raise FileNotFoundError(f'config not found: {path}')
        cp.read(path, encoding='utf-8')
        self.cp = cp

    def get(self, section: str, key: str, default=None) -> str:
        if self.cp.has_option(section, key):
            return self.cp.get(section, key).strip()
        if default is None:
            raise KeyError(f'[{section}].{key} missing from {self.path}')
        return default

    def getint(self, section: str, key: str, default: int | None = None) -> int:
        return int(self.get(section, key, str(default) if default is not None
                                else None))

    def getfloat(self, section: str, key: str,
                 default: float | None = None) -> float:
        return float(self.get(section, key, str(default) if default is not None
                                  else None))

    def getbool(self, section: str, key: str,
                default: bool | None = None) -> bool:
        v = self.get(section, key, str(default).lower() if default is not None
                       else None)
        return v.lower() in ('true', '1', 'yes', 'on')

    def getlist(self, section: str, key: str,
                separator: str = ',') -> list[str]:
        return [x.strip() for x in self.get(section, key).split(separator)
                  if x.strip()]

    def section(self, name: str) -> dict[str, str]:
        if not self.cp.has_section(name):
            return {}
        return {k: v.strip() for k, v in self.cp.items(name)}


CFG = Config(INI_PATH)

# ----------------------------------------------------------------------------
# Logging
# ----------------------------------------------------------------------------
logging.basicConfig(
    level=logging.DEBUG if CFG.getbool('server', 'debug', False)
            else logging.INFO,
    format='%(asctime)s %(levelname)-7s %(name)s: %(message)s',
)
log = logging.getLogger('fes')

# Redact patterns for any text we DO emit to logs
_REDACT_PATTERNS = [
    re.compile(CFG.get('security', 'redact_psk_regex'), re.IGNORECASE),
    re.compile(CFG.get('security', 'redact_password_regex'), re.IGNORECASE),
]


def redact(text: str) -> str:
    """Strip PSKs and passwords from any text before it's persisted or
    logged. Defense in depth — primary protection is NOT logging
    customer payloads at all."""
    for pat in _REDACT_PATTERNS:
        text = pat.sub(r'\1=<redacted>', text)
    return text


# ----------------------------------------------------------------------------
# Session store (in-process, ephemeral)
# ----------------------------------------------------------------------------
@dataclass
class Session:
    """One conversion session. Lives entirely in memory; no DB.

    Lifecycle:
      created → paid → running → (succeeded → downloaded → shredded)
                              \\→ failed → voided → shredded
    """
    id: str
    created_at: datetime
    expires_at: datetime
    state: str = 'created'   # created | paid | running | succeeded | failed
    upload_path: Path | None = None
    upload_size: int = 0
    sandbox_dir: Path | None = None
    output_path: Path | None = None
    output_sha256: str | None = None
    download_token: str | None = None
    payment_intent_id: str | None = None
    payment_status: str = 'pending'  # pending | authorized | captured | voided
    log_lines: list[str] = field(default_factory=list)
    exit_code: int | None = None
    tos_version_accepted: str | None = None
    error_message: str | None = None

    def to_public(self) -> dict:
        """Subset safe to send to the browser."""
        return {
            'id': self.id,
            'state': self.state,
            'created_at': self.created_at.isoformat(),
            'expires_at': self.expires_at.isoformat(),
            'payment_status': self.payment_status,
            'exit_code': self.exit_code,
            'output_sha256': self.output_sha256,
            'has_download': bool(self.download_token
                                   and self.state == 'succeeded'),
            'error_message': self.error_message,
        }


SESSIONS: dict[str, Session] = {}
DOWNLOAD_TOKENS: dict[str, str] = {}  # token -> session_id


def new_session() -> Session:
    sid = uuid.uuid4().hex
    ttl_min = CFG.getint('sandbox', 'download_ttl_minutes')
    now = datetime.now(timezone.utc)
    s = Session(id=sid, created_at=now,
                  expires_at=now + timedelta(minutes=ttl_min))
    SESSIONS[sid] = s
    return s


def shred_session(s: Session) -> None:
    """Destroy all session artifacts. Called on download, TTL expiry, or
    server shutdown. Files are unlinked; sandbox dirs rmtree'd."""
    log.info(f'shredding session {s.id} (state={s.state})')
    try:
        if s.sandbox_dir and s.sandbox_dir.exists():
            shutil.rmtree(s.sandbox_dir, ignore_errors=True)
        if s.download_token:
            DOWNLOAD_TOKENS.pop(s.download_token, None)
    finally:
        SESSIONS.pop(s.id, None)


async def ttl_reaper():
    """Background task: every 30s, shred any session past expiry."""
    while True:
        await asyncio.sleep(30)
        now = datetime.now(timezone.utc)
        expired = [s for s in list(SESSIONS.values()) if now > s.expires_at]
        for s in expired:
            shred_session(s)


# ----------------------------------------------------------------------------
# Stripe (stub mode by default)
# ----------------------------------------------------------------------------
class StripeClient:
    """Thin abstraction over Stripe so the rest of the app doesn't care
    whether we're in stub, test, or live mode.

    Stub mode: simulates a Stripe PaymentIntent lifecycle locally with
    configurable latency. Useful for demoing the UI before Stripe keys
    exist.

    Test/live mode: TODO — wire the real Stripe SDK once an API key
    arrives. The interface below is intentionally shaped to match the
    Stripe PaymentIntent API so the swap is mechanical.
    Reference: https://docs.stripe.com/api/payment_intents
    """

    def __init__(self, cfg: Config):
        self.mode = cfg.get('stripe', 'mode').lower()
        self.latency_ms = cfg.getint('stripe', 'stub_latency_ms', 1500)
        self.success_rate = cfg.getfloat('stripe', 'stub_success_rate', 1.0)
        self.amount_cents = int(round(
            cfg.getfloat('pricing', 'amount_usd') * 100))
        self.currency = cfg.get('pricing', 'stripe_currency')
        if self.mode == 'live':
            log.warning('Stripe mode=live but real client not yet wired')
        log.info(f'StripeClient initialized: mode={self.mode}, '
                 f'amount={self.amount_cents}c {self.currency}')

    async def create_payment_intent(self, session_id: str) -> dict:
        """Create a PaymentIntent with capture_method=manual.
        Returns: dict with 'id' and 'status' (always 'requires_capture'
        on success in stub mode).
        """
        await asyncio.sleep(self.latency_ms / 1000)
        if self.mode == 'stub':
            pi_id = f'pi_stub_{secrets.token_hex(12)}'
            log.info(f'[stub Stripe] auth created: {pi_id} '
                     f'for session {session_id}')
            return {
                'id': pi_id,
                'status': 'requires_capture',
                'amount': self.amount_cents,
                'currency': self.currency,
                'capture_method': 'manual',
            }
        # TODO real Stripe — per docs.stripe.com/api/payment_intents/create:
        #   import stripe
        #   stripe.api_key = CFG.get('stripe', 'secret_key')
        #   pi = stripe.PaymentIntent.create(
        #       amount=self.amount_cents, currency=self.currency,
        #       capture_method='manual',
        #       metadata={'session_id': session_id},
        #   )
        #   return {'id': pi.id, 'status': pi.status, ...}
        raise NotImplementedError(f'Stripe mode {self.mode!r} not wired')

    async def capture(self, payment_intent_id: str) -> dict:
        """Capture a previously-authorized PaymentIntent. Called only
        after the toolkit exits 0."""
        await asyncio.sleep(self.latency_ms / 1000)
        if self.mode == 'stub':
            log.info(f'[stub Stripe] capture: {payment_intent_id}')
            return {'id': payment_intent_id, 'status': 'succeeded'}
        # TODO real: stripe.PaymentIntent.capture(payment_intent_id)
        raise NotImplementedError(f'Stripe mode {self.mode!r} not wired')

    async def void(self, payment_intent_id: str) -> dict:
        """Cancel an authorization (called when toolkit fails). Customer
        is NEVER charged for a failed conversion."""
        await asyncio.sleep(self.latency_ms / 1000)
        if self.mode == 'stub':
            log.info(f'[stub Stripe] void: {payment_intent_id}')
            return {'id': payment_intent_id, 'status': 'canceled'}
        # TODO real: stripe.PaymentIntent.cancel(payment_intent_id)
        raise NotImplementedError(f'Stripe mode {self.mode!r} not wired')


STRIPE = StripeClient(CFG)

# ----------------------------------------------------------------------------
# Upload validation
# ----------------------------------------------------------------------------
def sniff_sonicos(content_head: bytes) -> bool:
    """Cheap detector: does the first N KB look like a SonicOS export?
    Defense in depth alongside extension and size checks. Not crypto —
    just stops obvious uploads-of-the-wrong-thing before they hit the
    sandbox."""
    sigs = CFG.getlist('sandbox', 'sonicos_signatures')
    head = content_head.decode('utf-8', errors='ignore').lower()
    return any(sig.lower() in head for sig in sigs)


def looks_binary(content_head: bytes) -> tuple[bool, str]:
    """Heuristic 'is this file binary?' check.

    Returns (is_binary, reason_if_binary).

    SonicWall E-CLI exports are plain ASCII/UTF-8 text. Binary .exp
    archives, PE/ELF executables, ZIPs, gzipped configs, etc. need to
    be rejected BEFORE the parser sees them — both because the parser
    will crash, and because we don't want to spend sandbox CPU on
    obviously-not-text uploads.

    Three independent signals; any one positive trips the rejection:
      1. NUL byte in the first chunk (almost-certain binary marker)
      2. Known binary magic numbers (ZIP/gzip/PE/ELF/PDF)
      3. >10% of the first chunk is non-printable bytes
    """
    if not content_head:
        return True, 'empty file'

    # 1. NUL byte — the classic file(1) heuristic
    if b'\x00' in content_head[:8192]:
        return True, 'file contains NUL bytes (binary content not allowed)'

    # 2. Common magic-number prefixes for files we know we don't want
    magics = [
        (b'PK\x03\x04', 'ZIP archive'),
        (b'PK\x05\x06', 'ZIP archive (empty)'),
        (b'\x1f\x8b',   'gzip-compressed file'),
        (b'\x7fELF',    'ELF executable'),
        (b'MZ',         'Windows PE executable'),
        (b'%PDF-',      'PDF document'),
        (b'\x89PNG',    'PNG image'),
        (b'GIF8',       'GIF image'),
        (b'\xff\xd8\xff', 'JPEG image'),
        (b'BZh',        'bzip2 archive'),
        (b'\xfd7zXZ\x00', 'XZ archive'),
        (b'7z\xbc\xaf\x27\x1c', '7-Zip archive'),
        (b'Rar!\x1a\x07', 'RAR archive'),
    ]
    for sig, label in magics:
        if content_head.startswith(sig):
            return True, f'detected {label}; SonicWall E-CLI is plain text'

    # 3. Non-printable byte ratio. Printable = printable ASCII +
    # common whitespace (tab/LF/CR). Anything else (control chars,
    # high-bit bytes) counts as non-printable.
    sample = content_head[:8192]
    printable = sum(
        1 for b in sample
        if 32 <= b <= 126 or b in (9, 10, 13)
    )
    ratio = printable / max(len(sample), 1)
    if ratio < 0.90:
        return True, (f'file is {int((1 - ratio) * 100)}% non-text bytes; '
                       f'SonicWall E-CLI export must be plain text '
                       f'(generated by `export current-config cli`)')

    return False, ''


def validate_upload(filename: str, size: int, head: bytes) -> str | None:
    """Returns None if OK, else an error message.

    Layered defense:
      1. Size > 0 and ≤ max_upload_mb
      2. Filename extension in allow-list
      3. Content is not binary (NUL bytes, magic numbers, low printable ratio)
      4. Content sniff matches SonicOS signature
    """
    if size <= 0:
        return 'empty file'
    max_mb = CFG.getint('sandbox', 'max_upload_mb')
    if size > max_mb * 1024 * 1024:
        return f'file too large (max {max_mb} MB)'
    exts = [e.strip().lower() for e in CFG.getlist('sandbox',
                                                      'allowed_extensions')]
    ext = Path(filename).suffix.lower()
    if ext not in exts:
        return f'unsupported file extension {ext!r}; expected one of {exts}'
    binary, why = looks_binary(head)
    if binary:
        return why
    if not sniff_sonicos(head):
        return ('file does not appear to be a SonicWall E-CLI export. '
                'Generate the input by running `export current-config cli` '
                'on your SonicWall, NOT by exporting a binary .exp config.')
    return None


# ----------------------------------------------------------------------------
# Conversion runner
# ----------------------------------------------------------------------------
async def run_conversion(s: Session) -> AsyncIterator[str]:
    """Spawn the v11 toolkit as a subprocess in the session's sandbox.
    Yield each stdout line as it arrives so the HTTP layer can stream
    via SSE. The toolkit itself is UNMODIFIED — we just shell out.

    NB: This implementation runs the toolkit as a regular subprocess.
    Production deployment should wrap this in Docker:
        docker run --rm --network=none --memory=512m --cpus=1 \\
            --read-only --tmpfs /work:size=128m \\
            -v {sandbox}:/work:rw \\
            fes-toolkit:v11 \\
            python /opt/toolkit/skeleton_engine/build_pipeline.py \\
                --input /work/input.txt --full-rebuild
    The contract (stdout streamed, exit code matters) is identical.
    """
    toolkit_root = (APP_ROOT / CFG.get('sandbox', 'toolkit_root')).resolve()
    if not toolkit_root.is_dir():
        s.state = 'failed'
        s.error_message = (f'toolkit not found at {toolkit_root}. '
                           f'Place the v11 toolkit there or set '
                           f'[sandbox].toolkit_root in {INI_PATH.name}.')
        yield f'ERROR: {s.error_message}\n'
        return

    if not s.upload_path or not s.upload_path.is_file():
        s.state = 'failed'
        s.error_message = 'upload missing at conversion time'
        yield f'ERROR: {s.error_message}\n'
        return

    # Each conversion gets a sandbox directory that's a copy of the
    # toolkit (so concurrent runs don't stomp each other's intermediate
    # files). Cheap because the toolkit is small.
    s.sandbox_dir = (APP_ROOT / CFG.get('sandbox', 'sandbox_root')
                       / s.id).resolve()
    s.sandbox_dir.mkdir(parents=True, exist_ok=True)
    sandbox_toolkit = s.sandbox_dir / 'toolkit'
    shutil.copytree(toolkit_root, sandbox_toolkit, dirs_exist_ok=True)

    # Move the upload INTO the sandbox so the toolkit reads it from a
    # path inside its own tree.
    sandbox_input = sandbox_toolkit / 'sonicwall_parser' / 'input' \
                       / 'customer_upload.txt'
    sandbox_input.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(s.upload_path, sandbox_input)

    s.state = 'running'

    # Force UTF-8 (Windows compat carryover from the toolkit)
    env = os.environ.copy()
    env['PYTHONIOENCODING'] = 'utf-8'
    env['PYTHONUTF8'] = '1'

    cmd = [
        sys.executable,
        'skeleton_engine/build_pipeline.py',
        '--input', str(sandbox_input),
        '--full-rebuild',
    ]
    yield f'$ {" ".join(cmd)}\n'

    timeout = CFG.getint('sandbox', 'timeout_seconds')
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        cwd=sandbox_toolkit,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        env=env,
    )

    start = time.monotonic()
    try:
        while True:
            try:
                line = await asyncio.wait_for(proc.stdout.readline(),
                                                timeout=timeout)
            except asyncio.TimeoutError:
                proc.kill()
                s.state = 'failed'
                s.error_message = (f'toolkit exceeded {timeout}s timeout — '
                                    f'killed')
                yield f'\nERROR: {s.error_message}\n'
                return
            if not line:
                break
            decoded = line.decode('utf-8', errors='replace')
            # Stash only operational lines (validator summary) — never
            # store the entire toolkit stdout, which can contain customer
            # IPs and PSKs. Keep last N lines for the result panel.
            s.log_lines.append(decoded.rstrip())
            max_keep = CFG.getint('ui', 'log_stream_lines', 200)
            if len(s.log_lines) > max_keep:
                s.log_lines = s.log_lines[-max_keep:]
            yield decoded
            if time.monotonic() - start > timeout:
                proc.kill()
                s.state = 'failed'
                s.error_message = f'toolkit exceeded {timeout}s wall clock'
                yield f'\nERROR: {s.error_message}\n'
                return

        rc = await proc.wait()
        s.exit_code = rc

        if rc == 0:
            # Locate output and SHA it
            out = sandbox_toolkit / 'skeleton_engine' / 'output' \
                    / 'configuration.xml'
            if not out.is_file():
                s.state = 'failed'
                s.error_message = ('toolkit exited 0 but configuration.xml '
                                     'not found at expected path')
                yield f'\nERROR: {s.error_message}\n'
                return
            s.output_path = out
            s.output_sha256 = hashlib.sha256(out.read_bytes()).hexdigest()
            tok_bytes = CFG.getint('security', 'download_token_bytes', 32)
            s.download_token = secrets.token_urlsafe(tok_bytes)
            DOWNLOAD_TOKENS[s.download_token] = s.id
            s.state = 'succeeded'
            yield (f'\n[done] configuration.xml ready, '
                   f'SHA256={s.output_sha256}\n')
        else:
            s.state = 'failed'
            s.error_message = f'toolkit exited {rc}'
            yield f'\nERROR: toolkit exited with code {rc}\n'
    finally:
        # Don't shred sandbox here — the download endpoint needs the
        # output file. Shred happens on download OR TTL expiry.
        pass


# ----------------------------------------------------------------------------
# FastAPI app
# ----------------------------------------------------------------------------
app = FastAPI(
    title=CFG.get('brand', 'product_name'),
    version=CFG.get('brand', 'toolkit_version'),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CFG.getlist('server', 'cors_origins'),
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

app.mount('/static', StaticFiles(directory=str(APP_ROOT / 'static')),
            name='static')
templates = Jinja2Templates(directory=str(APP_ROOT / 'templates'))


@app.on_event('startup')
async def on_startup():
    log.info(f'{CFG.get("brand", "product_name")} starting on '
             f'{CFG.get("server", "host")}:{CFG.getint("server", "port")}')
    log.info(f'  toolkit: {(APP_ROOT / CFG.get("sandbox", "toolkit_root")).resolve()}')
    log.info(f'  Stripe mode: {CFG.get("stripe", "mode")}')
    log.info(f'  price: {CFG.get("pricing", "display_amount")}')
    log.info(f'  ToS lawyer_reviewed: '
             f'{CFG.getbool("tos", "lawyer_reviewed")} '
             f'(version {CFG.get("tos", "version")})')
    # Initialize SQLite DB from INI-declared schema
    db_path = (APP_ROOT / CFG.get('database', 'path')).resolve()
    table_specs = {}
    for key, val in CFG.section('database').items():
        if key.startswith('table.'):
            table_specs[key[len('table.'):]] = val
    db.init_db(db_path, table_specs)
    log.info(f'  database: {db_path} '
             f'({len(table_specs)} table(s) declared)')
    # Create contrib storage dir
    contrib_dir = (APP_ROOT / CFG.get('contrib', 'storage_dir')).resolve()
    contrib_dir.mkdir(parents=True, exist_ok=True)
    log.info(f'  contrib storage: {contrib_dir}')
    log.info(f'  ops panel: enabled={CFG.getbool("ops_panel", "enabled")} '
             f'path={CFG.get("ops_panel", "path_prefix")}')
    if CFG.get('ops_panel', 'passphrase').startswith('CHANGE_ME'):
        log.warning('!!! ops_panel passphrase still default — '
                    'change before deploying !!!')
    asyncio.create_task(ttl_reaper())


# ---- Routes ----------------------------------------------------------------
@app.get('/', response_class=HTMLResponse)
async def landing(request: Request):
    """Landing page. All UI strings + colors pulled from INI so a brand
    update is INI-only."""
    return templates.TemplateResponse(request, 'index.html', {
        'brand': CFG.section('brand'),
        'colors': CFG.section('colors'),
        'pricing': CFG.section('pricing'),
        'ui': CFG.section('ui'),
        'tos': CFG.section('tos'),
        'features': CFG.section('features'),
        'tos_lawyer_reviewed': CFG.getbool('tos', 'lawyer_reviewed'),
        'tos_version': CFG.get('tos', 'version'),
    })


@app.get('/tos', response_class=HTMLResponse)
async def tos_page(request: Request):
    """Full Terms of Service — read FRESH from disk each request so
    a legal update doesn't require restart."""
    tos_file = APP_ROOT / CFG.get('tos', 'file')
    text = tos_file.read_text(encoding='utf-8') if tos_file.is_file() \
            else '(Terms of Service file not found.)'
    return templates.TemplateResponse(request, 'tos.html', {
        'brand': CFG.section('brand'),
        'colors': CFG.section('colors'),
        'tos_text': text,
        'tos_lawyer_reviewed': CFG.getbool('tos', 'lawyer_reviewed'),
        'tos_version': CFG.get('tos', 'version'),
    })


@app.get('/api/config')
async def public_config():
    """Subset of INI safe to expose to the browser. Drives front-end
    behavior (price display, max upload size, feature flags, disclaimer)."""
    return {
        'brand': CFG.section('brand'),
        'colors': CFG.section('colors'),
        'pricing': CFG.section('pricing'),
        'sandbox': {
            'max_upload_mb': CFG.getint('sandbox', 'max_upload_mb'),
            'allowed_extensions': CFG.getlist('sandbox', 'allowed_extensions'),
            'timeout_seconds': CFG.getint('sandbox', 'timeout_seconds'),
            'download_ttl_minutes': CFG.getint('sandbox',
                                                  'download_ttl_minutes'),
        },
        'features': {k: CFG.getbool('features', k)
                       for k in CFG.section('features')
                       if k not in ('demo_video_url',)},
        'demo_video_url': CFG.get('features', 'demo_video_url', ''),
        'ui': CFG.section('ui'),
        'stripe_mode': CFG.get('stripe', 'mode'),
        'certification': {
            'status': CFG.get('certification', 'status'),
            'certified_source': CFG.get('certification', 'certified_source'),
            'certified_target': CFG.get('certification', 'certified_target'),
            'lines': [
                CFG.get('certification', 'disclaimer_line_1').format(
                    certified_source=CFG.get('certification',
                                              'certified_source'),
                    certified_target=CFG.get('certification',
                                              'certified_target')),
                CFG.get('certification', 'disclaimer_line_2'),
                CFG.get('certification', 'disclaimer_line_3'),
                CFG.get('certification', 'disclaimer_line_4'),
            ],
        },
        'contrib': {
            'enabled': CFG.getbool('features', 'enable_contrib'),
            'delivery_window_days': CFG.getint('contrib',
                                                 'delivery_window_days'),
            'free_credit_quantity': CFG.getint('contrib',
                                                 'free_credit_quantity'),
        },
    }


@app.post('/api/upload')
async def upload(file: UploadFile = File(...),
                  tos_accepted: str = Form(...)):
    """Accept upload, create session, validate, stash file."""
    if not CFG.getbool('features', 'enable_conversion'):
        raise HTTPException(503, 'conversion temporarily disabled')
    if CFG.getbool('tos', 'require_checkbox') and tos_accepted != 'true':
        raise HTTPException(400, 'Terms of Service must be accepted')

    # Buffer & validate
    head = await file.read(CFG.getint('sandbox', 'sonicos_sniff_kb') * 1024)
    rest = await file.read()
    body = head + rest
    err = validate_upload(file.filename or 'upload', len(body), head)
    if err:
        raise HTTPException(400, err)

    s = new_session()
    s.tos_version_accepted = CFG.get('tos', 'version')
    s.upload_size = len(body)
    # Stage upload in session sandbox (not toolkit yet — that copy
    # happens in run_conversion)
    s.sandbox_dir = (APP_ROOT / CFG.get('sandbox', 'sandbox_root')
                       / s.id).resolve()
    s.sandbox_dir.mkdir(parents=True, exist_ok=True)
    s.upload_path = s.sandbox_dir / 'upload.txt'
    s.upload_path.write_bytes(body)
    log.info(f'upload accepted: session={s.id} bytes={s.upload_size} '
             f'tos_v={s.tos_version_accepted}')

    # Create Stripe auth (auth-then-capture pattern, never capture until
    # the toolkit exits 0)
    pi = await STRIPE.create_payment_intent(s.id)
    s.payment_intent_id = pi['id']
    s.payment_status = 'authorized'
    s.state = 'paid'
    return {
        'session': s.to_public(),
        'payment_intent_id': pi['id'],
        'amount': pi['amount'],
        'currency': pi['currency'],
    }


@app.get('/api/run/{session_id}')
async def run(session_id: str):
    """Stream toolkit stdout via Server-Sent Events. On exit 0, capture
    the Stripe charge. On exit !=0, void the auth."""
    s = SESSIONS.get(session_id)
    if not s:
        raise HTTPException(404, 'session not found or expired')
    if s.state not in ('paid', 'created'):
        raise HTTPException(409, f'session state {s.state!r} not runnable')

    async def event_stream():
        try:
            async for line in run_conversion(s):
                # SSE envelope
                data = json.dumps({'line': line.rstrip('\n')})
                yield f'data: {data}\n\n'
            # Final settlement event
            if s.state == 'succeeded':
                cap = await STRIPE.capture(s.payment_intent_id)
                s.payment_status = 'captured'
                final = {
                    'event': 'done',
                    'session': s.to_public(),
                    'download_token': s.download_token,
                }
            else:
                void = await STRIPE.void(s.payment_intent_id or '')
                s.payment_status = 'voided'
                final = {
                    'event': 'failed',
                    'session': s.to_public(),
                }
            yield f'event: settle\ndata: {json.dumps(final)}\n\n'
        except Exception as e:
            log.exception('run error')
            yield ('event: error\n'
                   f'data: {json.dumps({"message": redact(str(e))})}\n\n')

    return StreamingResponse(event_stream(),
                               media_type='text/event-stream')


@app.get('/api/session/{session_id}')
async def session_status(session_id: str):
    s = SESSIONS.get(session_id)
    if not s:
        raise HTTPException(404, 'session not found or expired')
    return s.to_public()


@app.get('/download/{token}')
async def download(token: str):
    """Single-use, time-limited download. After the customer downloads,
    the entire sandbox is shredded."""
    if not CFG.getbool('features', 'enable_download'):
        raise HTTPException(503, 'downloads temporarily disabled')
    sid = DOWNLOAD_TOKENS.get(token)
    if not sid:
        raise HTTPException(404, 'download token invalid, used, or expired')
    s = SESSIONS.get(sid)
    if not s or s.state != 'succeeded' or not s.output_path:
        raise HTTPException(404, 'session not in downloadable state')
    if datetime.now(timezone.utc) > s.expires_at:
        shred_session(s)
        raise HTTPException(410, 'download link expired')

    # Read the file BEFORE shredding (StreamingResponse holds open file
    # handles, but we want a clean single-use semantic)
    data = s.output_path.read_bytes()
    filename = 'configuration.xml'
    sha = s.output_sha256

    # Single-use: invalidate the token NOW so a refresh can't re-download
    DOWNLOAD_TOKENS.pop(token, None)
    s.download_token = None

    # Schedule shred for after this response flushes
    asyncio.create_task(_delayed_shred(s))

    headers = {
        'Content-Disposition': f'attachment; filename="{filename}"',
        'X-Output-SHA256': sha or '',
        'Cache-Control': 'no-store',
    }
    return StreamingResponse(
        iter([data]),
        media_type='application/xml',
        headers=headers,
    )


async def _delayed_shred(s: Session):
    await asyncio.sleep(2)  # let the download flush
    shred_session(s)


@app.get('/healthz')
async def healthz():
    return {
        'status': 'ok',
        'sessions': len(SESSIONS),
        'toolkit_present': (APP_ROOT
                              / CFG.get('sandbox', 'toolkit_root')).is_dir(),
        'stripe_mode': CFG.get('stripe', 'mode'),
    }


# ----------------------------------------------------------------------------
# CONTRIB endpoints — free 14-day lab conversion for non-certified pairs
# ----------------------------------------------------------------------------
def _parse_model_list(raw: str) -> list[str]:
    """[models] entries are comma-separated lists that may span multiple
    lines. Parse them into a clean list."""
    if not raw:
        return []
    items = []
    for chunk in raw.replace('\n', ',').split(','):
        v = chunk.strip()
        if v:
            items.append(v)
    return items


@app.get('/api/contrib_options')
async def contrib_options():
    """Returns the SonicWall + WatchGuard model lists for the CONTRIB
    dropdowns. Drives the front end."""
    return {
        'certification': {
            'status': CFG.get('certification', 'status'),
            'certified_source': CFG.get('certification', 'certified_source'),
            'certified_target': CFG.get('certification', 'certified_target'),
            'lines': [
                CFG.get('certification', 'disclaimer_line_1').format(
                    certified_source=CFG.get('certification',
                                              'certified_source'),
                    certified_target=CFG.get('certification',
                                              'certified_target')),
                CFG.get('certification', 'disclaimer_line_2'),
                CFG.get('certification', 'disclaimer_line_3'),
                CFG.get('certification', 'disclaimer_line_4'),
            ],
        },
        'sonicwall_models': _parse_model_list(
            CFG.get('models', 'sonicwall_models')),
        'watchguard_models': _parse_model_list(
            CFG.get('models', 'watchguard_models')),
        'contrib': {
            'delivery_window_days': CFG.getint('contrib',
                                                 'delivery_window_days'),
            'free_credit_quantity': CFG.getint('contrib',
                                                 'free_credit_quantity'),
            'thanks_title': CFG.get('contrib', 'thanks_title'),
            'thanks_subtitle': CFG.get('contrib', 'thanks_subtitle'),
        },
    }


@app.post('/api/contrib_submit')
async def contrib_submit(request: Request,
                          file: UploadFile = File(...),
                          email: str = Form(...),
                          source_model: str = Form(...),
                          target_model: str = Form(...),
                          notes: str = Form(''),
                          tos_accepted: str = Form(...)):
    """Accept a CONTRIB submission. We:
      1. Validate the upload (same as paid conversions)
      2. Compute SHA-256 of the INPUT (used as the audit key)
      3. Store the file under [contrib].storage_dir keyed by SHA
      4. Insert a row in contrib_submissions
      5. Return the thanks payload (input SHA + email + ETA)
    NO charge, NO conversion runs here. The operator runs labs offline."""
    if not CFG.getbool('features', 'enable_contrib'):
        raise HTTPException(503, 'CONTRIB mode is disabled')
    if CFG.getbool('tos', 'require_checkbox') and tos_accepted != 'true':
        raise HTTPException(400, 'Terms of Service must be accepted')
    # Basic email sanity (don't over-engineer; ops panel can sanity check)
    if '@' not in email or len(email) < 5 or len(email) > 254:
        raise HTTPException(400, 'invalid email address')
    if not source_model or not target_model:
        raise HTTPException(400, 'source and target models are required')
    # Verify models are in the configured lists (prevents arbitrary text)
    sw = _parse_model_list(CFG.get('models', 'sonicwall_models'))
    wg = _parse_model_list(CFG.get('models', 'watchguard_models'))
    if source_model not in sw:
        raise HTTPException(400, f'unknown source model: {source_model}')
    if target_model not in wg:
        raise HTTPException(400, f'unknown target model: {target_model}')

    # Read + validate the upload
    head = await file.read(CFG.getint('sandbox', 'sonicos_sniff_kb') * 1024)
    rest = await file.read()
    body = head + rest
    err = validate_upload(file.filename or 'upload', len(body), head)
    if err:
        raise HTTPException(400, err)

    # Compute INPUT SHA-256 — the audit key
    input_sha = hashlib.sha256(body).hexdigest()

    # Store file under [contrib].storage_dir keyed by SHA. Multiple
    # submissions with the same SHA share a single on-disk file; that's
    # fine (it's deduplication, and the DB row is per-submission).
    contrib_dir = (APP_ROOT / CFG.get('contrib', 'storage_dir')).resolve()
    contrib_dir.mkdir(parents=True, exist_ok=True)
    stored_path = contrib_dir / f'{input_sha}.txt'
    if not stored_path.exists():
        stored_path.write_bytes(body)

    # Capture remote IP (proxy-aware) for audit purposes
    trusted = CFG.getlist('ops_panel', 'trusted_proxies') \
        if CFG.section('ops_panel') else []
    remote_ip = ops_security._client_ip(request, trusted)

    now = datetime.now(timezone.utc)
    retention_days = CFG.getint('contrib', 'retention_days')
    expires_at = now + timedelta(days=retention_days)

    submission_id = db.insert(
        'contrib_submissions',
        created_at=now.isoformat(),
        email=email.strip().lower(),
        source_model=source_model,
        target_model=target_model,
        notes=(notes or '').strip()[:2000],
        input_sha256=input_sha,
        input_bytes=len(body),
        stored_path=str(stored_path),
        remote_ip=remote_ip,
        status='pending',
        expires_at=expires_at.isoformat(),
    )
    db.log_audit(submission_id, 'submission_received', actor=remote_ip,
                  details=f'{source_model} -> {target_model}, '
                          f'{len(body)} bytes')
    log.info(f'CONTRIB submission #{submission_id}: '
             f'{source_model} -> {target_model} from {redact(email)} '
             f'(input SHA {input_sha[:12]}...)')

    return {
        'submission_id': submission_id,
        'input_sha256': input_sha,
        'email': email.strip().lower(),
        'source_model': source_model,
        'target_model': target_model,
        'delivery_window_days': CFG.getint('contrib',
                                              'delivery_window_days'),
        'expires_at': expires_at.isoformat(),
    }


# ----------------------------------------------------------------------------
# OPS PANEL — RFC1918 + passphrase, two independent checks
# ----------------------------------------------------------------------------
def _ops_gate(request: Request) -> str:
    """Call this at the top of every ops endpoint. Returns the verified
    client IP for audit logging."""
    if not CFG.getbool('ops_panel', 'enabled'):
        raise HTTPException(status_code=404)
    return ops_security.ops_gate(
        request,
        passphrase_expected=CFG.get('ops_panel', 'passphrase'),
        allow_loopback=CFG.getbool('ops_panel', 'allow_loopback'),
        trusted_proxies=CFG.getlist('ops_panel', 'trusted_proxies'),
    )


def _ops_prefix() -> str:
    return CFG.get('ops_panel', 'path_prefix').rstrip('/')


@app.get('/ops', response_class=HTMLResponse)
@app.get('/ops/', response_class=HTMLResponse)
async def ops_landing(request: Request):
    """Ops panel HTML. Requires RFC1918 + passphrase.

    The passphrase is sent via X-Ops-Passphrase header. The browser
    flow: user navigates to /ops and is met with a passphrase prompt
    page; that page does a fetch() to /ops/submissions with the
    header. We don't use HTTP Basic Auth because we don't want to
    surface the passphrase in the URL or in the browser's password
    manager."""
    # Note: this endpoint is intentionally NOT gated by passphrase —
    # it serves the prompt page. The DATA endpoints below ARE gated.
    # We still gate by RFC1918, so external scanners see 404.
    trusted = CFG.getlist('ops_panel', 'trusted_proxies')
    ip = ops_security._client_ip(request, trusted)
    if not ops_security._is_private(
            ip, CFG.getbool('ops_panel', 'allow_loopback')):
        raise HTTPException(status_code=404)
    return templates.TemplateResponse(request, 'ops.html', {
        'brand': CFG.section('brand'),
        'colors': CFG.section('colors'),
        'ops_prefix': _ops_prefix(),
        'client_ip': ip,
    })


@app.get('/ops/submissions')
async def ops_list_submissions(request: Request,
                                 status_filter: str = '',
                                 limit: int = 0):
    """List CONTRIB submissions. RFC1918 + passphrase required."""
    _ops_gate(request)
    page_size = limit or CFG.getint('ops_panel', 'page_size')
    if status_filter:
        rows = db.query(
            'SELECT * FROM contrib_submissions WHERE status = ? '
            'ORDER BY created_at ASC LIMIT ?',
            (status_filter, page_size))
    else:
        rows = db.query(
            'SELECT * FROM contrib_submissions '
            'ORDER BY created_at ASC LIMIT ?',
            (page_size,))
    return {'submissions': [dict(r) for r in rows]}


@app.get('/ops/submission/{submission_id}')
async def ops_get_submission(request: Request, submission_id: int):
    """Full detail on one submission. RFC1918 + passphrase required."""
    _ops_gate(request)
    rows = db.query('SELECT * FROM contrib_submissions WHERE id = ?',
                     (submission_id,))
    if not rows:
        raise HTTPException(404, 'submission not found')
    audit = db.query(
        'SELECT * FROM contrib_audit_log WHERE submission_id = ? '
        'ORDER BY ts ASC', (submission_id,))
    return {
        'submission': dict(rows[0]),
        'audit_log': [dict(r) for r in audit],
    }


@app.get('/ops/submission/{submission_id}/download')
async def ops_download_submission(request: Request, submission_id: int):
    """Download the stored INPUT file. RFC1918 + passphrase required."""
    ip = _ops_gate(request)
    rows = db.query('SELECT * FROM contrib_submissions WHERE id = ?',
                     (submission_id,))
    if not rows:
        raise HTTPException(404, 'submission not found')
    row = rows[0]
    p = Path(row['stored_path'])
    if not p.is_file():
        raise HTTPException(410, 'stored file no longer on disk')
    db.log_audit(submission_id, 'ops_downloaded_input', actor=ip)
    return FileResponse(
        p,
        media_type='application/octet-stream',
        filename=f'contrib_{submission_id}_{row["input_sha256"][:12]}.txt',
        headers={
            'Content-Disposition': (f'attachment; filename='
                                      f'"contrib_{submission_id}.txt"'),
            'X-Input-SHA256': row['input_sha256'],
            'Cache-Control': 'no-store',
        },
    )


@app.post('/ops/submission/{submission_id}/status')
async def ops_update_status(request: Request, submission_id: int,
                              new_status: str = Form(...),
                              note: str = Form('')):
    """Update a submission's status. Used to mark 'delivered' after
    emailing the converted file to the customer."""
    ip = _ops_gate(request)
    valid = {'pending', 'in_lab', 'delivered', 'rejected', 'expired'}
    if new_status not in valid:
        raise HTTPException(400, f'status must be one of {sorted(valid)}')
    rows = db.query('SELECT id, status FROM contrib_submissions WHERE id = ?',
                     (submission_id,))
    if not rows:
        raise HTTPException(404, 'submission not found')
    old = rows[0]['status']
    extra = {}
    if new_status == 'delivered':
        extra['delivered_at'] = datetime.now(timezone.utc).isoformat()
    db.update('contrib_submissions', where={'id': submission_id},
                status=new_status, **extra)
    db.log_audit(submission_id, 'status_changed', actor=ip,
                  details=f'{old} -> {new_status}'
                          f'{": " + note if note else ""}')
    return {'submission_id': submission_id, 'old_status': old,
             'new_status': new_status}


# ----------------------------------------------------------------------------
# CLI entrypoint
# ----------------------------------------------------------------------------
if __name__ == '__main__':
    import uvicorn
    uvicorn.run(
        'main:app',
        host=CFG.get('server', 'host'),
        port=CFG.getint('server', 'port'),
        reload=CFG.getbool('server', 'debug'),
    )
