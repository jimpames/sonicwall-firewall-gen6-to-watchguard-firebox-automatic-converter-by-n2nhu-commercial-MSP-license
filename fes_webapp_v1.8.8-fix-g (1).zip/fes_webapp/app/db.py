"""
fes_webapp/app/db.py

Tiny INI-driven SQLite layer.

Schema declared in [database] section of fes_webapp.ini:
    table.<name> = col:TYPE [NOT NULL], col:TYPE, ...
Each col may be prefixed with '*' to mark it PRIMARY KEY (with AUTOINCREMENT
for INTEGER PKs). At boot we CREATE TABLE IF NOT EXISTS.

This avoids a migrations file: a new column? add a line, restart. The
trade-off (no schema versioning, no destructive ALTER) is acceptable for
a single-operator MSP tool.

Algebraic-design discipline: business knobs in INI, code reads INI.
"""
from __future__ import annotations

import re
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator


_LOCK = threading.RLock()
_DB_PATH: Path | None = None


def _parse_column(spec: str) -> tuple[str, str, bool]:
    """Parse 'colname:TYPE [NOT NULL]' or '*colname:TYPE'.

    Returns (column_name, sql_type_with_constraints, is_pk).

    Examples:
      '*id:INTEGER'                 -> ('id', 'INTEGER PRIMARY KEY AUTOINCREMENT', True)
      'email:TEXT NOT NULL'         -> ('email', 'TEXT NOT NULL', False)
      'notes:TEXT'                  -> ('notes', 'TEXT', False)
    """
    s = spec.strip()
    is_pk = s.startswith('*')
    if is_pk:
        s = s[1:].lstrip()
    if ':' not in s:
        raise ValueError(f'bad column spec (missing type): {spec!r}')
    name, raw_type = s.split(':', 1)
    name = name.strip()
    raw_type = raw_type.strip().upper()
    # Validate the type prefix
    base_type_match = re.match(r'^(INTEGER|REAL|TEXT|BLOB)', raw_type)
    if not base_type_match:
        raise ValueError(f'bad column type in {spec!r}: must start with '
                          f'INTEGER, REAL, TEXT, or BLOB')
    base_type = base_type_match.group(1)
    rest = raw_type[len(base_type):].strip()
    if is_pk:
        if base_type == 'INTEGER':
            sql_type = 'INTEGER PRIMARY KEY AUTOINCREMENT'
        else:
            sql_type = f'{base_type} PRIMARY KEY'
        if rest:
            sql_type = f'{sql_type} {rest}'
    else:
        sql_type = base_type
        if rest:
            sql_type = f'{sql_type} {rest}'
    if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', name):
        raise ValueError(f'bad column name: {name!r}')
    return name, sql_type, is_pk


def _parse_table_spec(spec: str) -> list[tuple[str, str, bool]]:
    """Parse a multi-column table spec into a list of (name, sql_type, is_pk)."""
    # Allow line breaks inside the INI value (ConfigParser handles
    # continuation lines). Split on commas, drop empties.
    parts = [p.strip() for p in spec.replace('\n', ' ').split(',')
              if p.strip()]
    return [_parse_column(p) for p in parts]


def init_db(db_path: Path, table_specs: dict[str, str]) -> None:
    """Create the DB file + tables described by INI.

    table_specs is {table_name: column_spec_string} as read from the
    [database] section's 'table.<name>' keys.
    """
    global _DB_PATH
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    _DB_PATH = db_path
    with connect() as cn:
        for tname, spec in table_specs.items():
            cols = _parse_table_spec(spec)
            col_sql = ', '.join(f'{n} {t}' for (n, t, _) in cols)
            sql = f'CREATE TABLE IF NOT EXISTS {tname} ({col_sql})'
            cn.execute(sql)
        cn.commit()


@contextmanager
def connect() -> Iterator[sqlite3.Connection]:
    """Thread-safe context manager around a sqlite3 connection.

    SQLite is happy with multiple readers but only one writer at a time;
    we serialize all access with a module-level RLock. For our traffic
    levels (CONTRIB submissions are rare), this is fine and avoids the
    'database is locked' class of bugs entirely.
    """
    if _DB_PATH is None:
        raise RuntimeError('db.init_db() was never called')
    with _LOCK:
        cn = sqlite3.connect(str(_DB_PATH), timeout=10,
                              isolation_level='DEFERRED')
        cn.row_factory = sqlite3.Row
        cn.execute('PRAGMA foreign_keys = ON')
        try:
            yield cn
        finally:
            cn.close()


def insert(table: str, **cols: Any) -> int:
    """Insert a row, return its rowid."""
    names = list(cols.keys())
    placeholders = ', '.join('?' for _ in names)
    sql = (f'INSERT INTO {table} ({", ".join(names)}) '
           f'VALUES ({placeholders})')
    with connect() as cn:
        cur = cn.execute(sql, [cols[n] for n in names])
        cn.commit()
        return cur.lastrowid


def query(sql: str, params: tuple = ()) -> list[sqlite3.Row]:
    with connect() as cn:
        return list(cn.execute(sql, params).fetchall())


def update(table: str, where: dict[str, Any], **cols: Any) -> int:
    set_clause = ', '.join(f'{k} = ?' for k in cols)
    where_clause = ' AND '.join(f'{k} = ?' for k in where)
    sql = f'UPDATE {table} SET {set_clause} WHERE {where_clause}'
    params = list(cols.values()) + list(where.values())
    with connect() as cn:
        cur = cn.execute(sql, params)
        cn.commit()
        return cur.rowcount


def log_audit(submission_id: int | None, event: str,
                actor: str | None = None,
                details: str | None = None) -> None:
    """Convenience: write an audit_log row. Cheap, lets us reconstruct
    what happened to any submission."""
    from datetime import datetime, timezone
    insert(
        'contrib_audit_log',
        ts=datetime.now(timezone.utc).isoformat(),
        submission_id=submission_id,
        event=event,
        actor=actor,
        details=details,
    )
